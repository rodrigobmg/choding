#ifndef __FEELS_CFRUSTUM_HEADER__
#define __FEELS_CFRUSTUM_HEADER__


#include <d3d9.h>
#include <d3dx9.h>
#include <d3dx9math.h>


class CFrustum
{
private :
	LPDIRECT3DDEVICE9 m_pDevice;	
	
	enum ePlane{ _NEAR, _FAR, _LEFT, _RIGHT, _TOP, _BOTTOM };
	D3DXPLANE m_Plane[6];

public :
	CFrustum( LPDIRECT3DDEVICE9 pDevice );

	BOOL Create();
	BOOL CheckPoint( D3DXVECTOR3 *pPos );
	BOOL CheckSphere( D3DXVECTOR3 *pPos, float radius );
};


#endif __FEELS_CFRUSTUM_HEADER__