#ifndef __FEELS_LOG_HEADER__
#define __FEELS_LOG_HEADER__

#include <stdio.h>

class CLog
{
private :
	FILE *m_fp;

public :
	CLog( const char *szName )
	{
		Open( szName );
	}
	~CLog()
	{
		if( m_fp )	fclose( m_fp );
	}

	void Log( const char *format, ... )
	{
		char buf[1024];
		va_list marker; 
		va_start( marker, format ); 
		vsprintf( buf, format, marker );
		fputs( buf, m_fp );
	}
	void Open( const char *szName )
	{
		m_fp = fopen( szName, "wt" );
	}
	void Close()
	{
		if( m_fp )	fclose( m_fp );
	}
};


class CText
{
public :
	struct sText
	{
		char m_str[128];
		int x;
		int y;
	};

private :
	sText m_textData[100];
	int m_textCount;

	CText() : m_textCount(0)	{}

public :
	static CText &GetInstance()
	{
		static CText text;
		return text;
	}

	void Reset()	{	m_textCount = 0;	}
	int Size()		{	return m_textCount;	}

	void DrawText( char *str, int x, int y )
	{
		if( m_textCount < 100 )
		{
			strcpy( m_textData[m_textCount].m_str, str );
			m_textData[m_textCount].x = x;
			m_textData[m_textCount].y = y;

			++m_textCount;
		}
	}

	sText *Pop()
	{
		if( m_textCount )	return &(m_textData[--m_textCount]);
		else				return 0;
	}
};


#endif __FEELS_LOG_HEADER__