#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>

#include "CCamera.h"
#include "CFrustum.h"
#include "CTerrain.h"

#include "Log.h"

#define SAFE_RELEASE( data )		{	if(data) { data->Release(); data = NULL; }	}
#define SAFE_DELETE( data )			{	if(data) { delete data; data = NULL; }	}
#define SAFE_DELETE_ARRAY( data )	{	if(data) { delete[] data; data = NULL; }	}


//////////////////////////////////////////////////////////////////////////
// Global Data
LPDIRECT3D9       g_pD3D    = NULL;
LPDIRECT3DDEVICE9 g_pDevice = NULL;

HWND g_hWnd = NULL;

// Font
ID3DXFont	*g_pFont = NULL;
ID3DXSprite	*g_pTextSprite = NULL;

// Window Init
const char TitleName[] = "RoamTest";
const int  width  = 640;
const int  height = 480;

// Custom Class
ZCamera  *g_pCamera  = NULL;
CFrustum *g_pFrustum = NULL;
CRoamTerrain *g_pTerrain = NULL;


//////////////////////////////////////////////////////////////////////////
// Init d3d
HRESULT InitD3D()
{
	g_pD3D = Direct3DCreate9( D3D_SDK_VERSION );
	if( !g_pD3D )
	{
		MessageBox( g_hWnd, "Direct3DCreate Error", 0, MB_OK );
		return E_FAIL;
	}

	D3DPRESENT_PARAMETERS d3dpp;
	ZeroMemory( &d3dpp, sizeof(d3dpp));
	d3dpp.Windowed = TRUE;
	d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;
	d3dpp.EnableAutoDepthStencil = TRUE;
	d3dpp.AutoDepthStencilFormat = D3DFMT_D16;


	if( FAILED( g_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, g_hWnd,
		D3DCREATE_SOFTWARE_VERTEXPROCESSING, &d3dpp, &g_pDevice )))
	{
		MessageBox( g_hWnd, "CreateDevice Error", 0, MB_OK );
		return E_FAIL;
	}

	if( FAILED( D3DXCreateFont( g_pDevice, 15, 0, FW_BOLD, 1, FALSE, DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Arial", &g_pFont )))
	{
		MessageBox( g_hWnd, "D3DXCreateFont Error", 0, MB_OK );
		return E_FAIL;
	}
	if( FAILED( D3DXCreateSprite( g_pDevice, &g_pTextSprite )))
	{
		MessageBox( g_hWnd, "D3DXCreateSprite Error", 0, MB_OK );
		return E_FAIL;
	}
	
	g_pDevice->SetRenderState( D3DRS_ZENABLE, TRUE );

	return S_OK;
}


void SetD3D()
{
	D3DXMATRIXA16			g_matWorld;
	D3DXMATRIXA16			g_matView;
	D3DXMATRIXA16			g_matProj;

	/// ���� ��� ����
	D3DXMatrixIdentity( &g_matWorld );
	g_pDevice->SetTransform( D3DTS_WORLD, &g_matWorld );

	/// �� ����� ����
	D3DXVECTOR3 vEyePt( 50.0f, 50.0f, -1.0f );
	D3DXVECTOR3 vLookatPt( 50.0f, 0.0f, 30.0f );
	D3DXVECTOR3 vUpVec( 0.0f, 1.0f, 0.0f );
	D3DXMatrixLookAtLH( &g_matView, &vEyePt, &vLookatPt, &vUpVec );
	g_pDevice->SetTransform( D3DTS_VIEW, &g_matView );

	/// ���� �������� ���
	D3DXMatrixPerspectiveFovLH( &g_matProj, D3DX_PI/4, 1.0f, 1.0f, 1500.0f );
	g_pDevice->SetTransform( D3DTS_PROJECTION, &g_matProj );

	//////////////////////////////////////////////////////////////////////////
	// Option
	g_pDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME );

	//////////////////////////////////////////////////////////////////////////
	// Create Camera
	g_pCamera = new ZCamera;
	g_pCamera->SetView( &vEyePt, &vLookatPt, &vUpVec );
}


void Cleanup()
{
	SAFE_DELETE( g_pCamera );

	SAFE_RELEASE( g_pFont );
	SAFE_RELEASE( g_pTextSprite );

	SAFE_RELEASE( g_pDevice );
	SAFE_RELEASE( g_pD3D );
}


void DeleteObjects()
{
	SAFE_DELETE( g_pFrustum );
	SAFE_DELETE( g_pTerrain );
}


HRESULT InitObjects()
{
	g_pFrustum = new CFrustum( g_pDevice );
	g_pFrustum->Create();

	g_pTerrain = new CRoamTerrain( g_pDevice, g_pFrustum );
	g_pTerrain->Load( "Terrain.bmp" );
	g_pTerrain->Init();

	return S_OK;
}


float CalcFPS()
{
	static FLOAT fFPS      = 0.0f; 
	static FLOAT fLastTime = 0.0f; 
	static DWORD dwFrames  = 0L; 

	//Keep track of the time lapse and frame count 
	FLOAT fTime = GetTickCount() * 0.001f; 
	++dwFrames; 

	//Update the frame rate once per second 
	if(fTime - fLastTime > 1.0f) 
	{ 
		fFPS      = dwFrames / (fTime - fLastTime); 
		fLastTime = fTime; 
		dwFrames  = 0L; 
	} 

	return fFPS; 
}


D3DXVECTOR3 g_vLight;
VOID Animate()
{
	POINT pt;
	GetCursorPos( &pt );			/// Ŀ���� ��ũ�� ��ǥ�� ��´�.
	ScreenToClient( g_hWnd, &pt );	/// ��ũ�� ��ǥ�� Ŭ���̾�Ʈ ��ǥ��� �ٲ۴�.

	g_vLight.x = -( ( ( 2.0f * pt.x ) / 640 ) - 1 );
	g_vLight.y = -( ( ( 2.0f * pt.y ) / 480 ) - 1 );
	g_vLight.z = 0.0f;

	if( D3DXVec3Length( &g_vLight ) > 1.0f )
		D3DXVec3Normalize( &g_vLight, &g_vLight );		/// ������ ����ȭ
	else
		g_vLight.z = sqrtf( 1.0f - g_vLight.x*g_vLight.x
		- g_vLight.y*g_vLight.y );
}


void DrawText()
{
	g_pTextSprite->Begin( D3DXSPRITE_ALPHABLEND | D3DXSPRITE_SORT_TEXTURE );

	RECT rc;
	char str[1024];
	SetRect( &rc, 5, 5, 0, 0 );
	sprintf( str, "Fps : %f\nTriangle : %ld\nWire : 1, Texture : 2\nKeys : w,a,s,d,arrow keys", 
		CalcFPS(), g_pTerrain->GetNumTriangle());	
	g_pFont->DrawText( g_pTextSprite, str, -1, &rc, DT_NOCLIP, D3DXCOLOR(1,1,1,1));

	g_pTextSprite->End();

	CText::GetInstance().Reset();
}


//////////////////////////////////////////////////////////////////////////
// Render
void Render()
{
	/// �ĸ���ۿ� Z���� �ʱ�ȭ
	g_pDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0,0,255), 1.0f, 0 );

	/// ������ ����
	if( SUCCEEDED( g_pDevice->BeginScene() ) )
	{
		g_pTerrain->Render();

		DrawText();	

		g_pDevice->EndScene();
	}

	/// �ĸ���۸� ���̴� ȭ������!
	g_pDevice->Present( NULL, NULL, NULL, NULL );
}


//////////////////////////////////////////////////////////////////////////
// Update
void Update()
{
	Animate();

	D3DXMATRIXA16 matView;
	float tx = 0.f, ty = 0.f, tz = 0.f;
	g_pDevice->GetTransform( D3DTS_VIEW, &matView );

	if( GetAsyncKeyState( VK_UP ))		tz += 1.5f;
	if( GetAsyncKeyState( VK_DOWN ))	tz -= 1.5f;
	if( GetAsyncKeyState( VK_LEFT ))	tx -= 1.5f;
	if( GetAsyncKeyState( VK_RIGHT ))	tx += 1.5f;
	if( GetAsyncKeyState( VK_INSERT ))	ty -= 1.5f;
	if( GetAsyncKeyState( VK_DELETE ))	ty += 1.5f;

	D3DXMATRIXA16 matRotX, matTrans, matTemp, matTemp2;
	float rx = 0.f, ry = 0.f;

	if( GetAsyncKeyState( 'A' ))	ry -= 0.01f;
	if( GetAsyncKeyState( 'D' ))	ry += 0.01f;
	if( GetAsyncKeyState( 'W' ))	rx -= 0.01f;
	if( GetAsyncKeyState( 'S' ))	rx += 0.01f;

	g_pCamera->MoveLocalX( tx );
	g_pCamera->MoveLocalY( ty );
	g_pCamera->MoveLocalZ( tz );
	g_pCamera->RotateLocalX( rx );
	g_pCamera->RotateLocalY( ry );

	g_pDevice->SetTransform( D3DTS_VIEW, g_pCamera->GetViewMatrix());

	//////////////////////////////////////////////////////////////////////////
	g_pTerrain->Update( g_pCamera->GetEye());
}

//////////////////////////////////////////////////////////////////////////
// Msg Proc
LRESULT WINAPI MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch( msg )
	{
	case WM_DESTROY :
		Cleanup();
		PostQuitMessage( 0 );
		return 0;
	case WM_KEYDOWN : 
		switch( wParam )
		{
		case VK_ESCAPE :
			PostMessage( hWnd, WM_DESTROY, 0, 0L );
			break;
		}
		break;
	}

	return DefWindowProc( hWnd, msg, wParam, lParam );
}



/**-----------------------------------------------------------------------------
* ���α׷� ������
*------------------------------------------------------------------------------
*/
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
	/// ������ Ŭ���� ���
	WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC, MsgProc, 0L, 0L,
		GetModuleHandle(NULL), NULL, NULL, NULL, NULL, TitleName, NULL };
	RegisterClassEx( &wc );

	/// ������ ����
	HWND hWnd = CreateWindow( TitleName, TitleName, WS_OVERLAPPEDWINDOW, 0, 0, width, height,
		GetDesktopWindow(), NULL, wc.hInstance, NULL );

	g_hWnd = hWnd;

	/// Direct3D �ʱ�ȭ
	if( SUCCEEDED( InitD3D()))
	{		
		SetD3D();
		if( SUCCEEDED( InitObjects()))
		{
			/// ������ ���
			ShowWindow( hWnd, SW_SHOWDEFAULT );
			UpdateWindow( hWnd );

			/// �޽��� ����
			MSG msg;
			ZeroMemory( &msg, sizeof(msg) );
			while( msg.message != WM_QUIT )
			{
				/// �޽���ť�� �޽����� ������ �޽��� ó��
				if( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) )
				{
					TranslateMessage( &msg );
					DispatchMessage( &msg );
				}
				else
				{
					/// ó���� �޽����� ������ Render()�Լ� ȣ��
					Update();
					Render();
				}
			}
		}
	}

	DeleteObjects();
	UnregisterClass( TitleName, wc.hInstance );
	return 0;
}
