#include "CFrustum.h"


CFrustum::CFrustum( LPDIRECT3DDEVICE9 pDevice )
{
	m_pDevice = pDevice;
}


BOOL CFrustum::Create()
{
	D3DXMATRIXA16 matView, matProj, matTemp;

	m_pDevice->GetTransform( D3DTS_VIEW, &matView );
	m_pDevice->GetTransform( D3DTS_PROJECTION, &matProj );

	D3DXMatrixMultiply( &matTemp, &matView, &matProj );

	// _NEAR
	m_Plane[_NEAR].a = matTemp._14 + matTemp._13;
	m_Plane[_NEAR].b = matTemp._24 + matTemp._23;
	m_Plane[_NEAR].c = matTemp._34 + matTemp._33;
	m_Plane[_NEAR].d = matTemp._44 + matTemp._43;
	D3DXPlaneNormalize( &m_Plane[_NEAR], &m_Plane[_NEAR] );

	// _FAR
	m_Plane[_FAR].a = matTemp._14 - matTemp._13;
	m_Plane[_FAR].b = matTemp._24 - matTemp._23;
	m_Plane[_FAR].c = matTemp._34 - matTemp._33;
	m_Plane[_FAR].d = matTemp._44 - matTemp._43;
	D3DXPlaneNormalize( &m_Plane[_FAR], &m_Plane[_FAR] );

	// _LEFT
	m_Plane[_LEFT].a = matTemp._14 + matTemp._11;
	m_Plane[_LEFT].b = matTemp._24 + matTemp._21;
	m_Plane[_LEFT].c = matTemp._34 + matTemp._31;
	m_Plane[_LEFT].d = matTemp._44 + matTemp._41;
	D3DXPlaneNormalize( &m_Plane[_LEFT], &m_Plane[_LEFT] );

	// _RIGHT
	m_Plane[_RIGHT].a = matTemp._14 - matTemp._11;
	m_Plane[_RIGHT].b = matTemp._24 - matTemp._21;
	m_Plane[_RIGHT].c = matTemp._34 - matTemp._31;
	m_Plane[_RIGHT].d = matTemp._44 - matTemp._41;
	D3DXPlaneNormalize( &m_Plane[_RIGHT], &m_Plane[_RIGHT] );

	// _TOP
	m_Plane[_TOP].a = matTemp._14 - matTemp._12;
	m_Plane[_TOP].b = matTemp._24 - matTemp._22;
	m_Plane[_TOP].c = matTemp._34 - matTemp._32;
	m_Plane[_TOP].d = matTemp._44 - matTemp._42;
	D3DXPlaneNormalize( &m_Plane[_TOP], &m_Plane[_TOP] );

	// _BOTTOM
	m_Plane[_BOTTOM].a = matTemp._14 + matTemp._12;
	m_Plane[_BOTTOM].b = matTemp._24 + matTemp._22;
	m_Plane[_BOTTOM].c = matTemp._34 + matTemp._32;
	m_Plane[_BOTTOM].d = matTemp._44 + matTemp._42;
	D3DXPlaneNormalize( &m_Plane[_BOTTOM], &m_Plane[_BOTTOM] );

	return TRUE;
}


BOOL CFrustum::CheckPoint( D3DXVECTOR3 *pPos )
{
	if( D3DXPlaneDotCoord( &m_Plane[_NEAR],	  pPos ) < 0.f )	return FALSE;
	if( D3DXPlaneDotCoord( &m_Plane[_FAR],	  pPos ) < 0.f )	return FALSE;
	if( D3DXPlaneDotCoord( &m_Plane[_LEFT],	  pPos ) < 0.f )	return FALSE;
	if( D3DXPlaneDotCoord( &m_Plane[_RIGHT],  pPos ) < 0.f )	return FALSE;
//	if( D3DXPlaneDotCoord( &m_Plane[_TOP],	  pPos ) < 0.f )	return FALSE;
//	if( D3DXPlaneDotCoord( &m_Plane[_BOTTOM], pPos ) < 0.f )	return FALSE;

	return TRUE;
}


BOOL CFrustum::CheckSphere( D3DXVECTOR3 *pPos, float radius )
{
	if( D3DXPlaneDotCoord( &m_Plane[_NEAR],	  pPos ) < -radius )	return FALSE;
	if( D3DXPlaneDotCoord( &m_Plane[_FAR],	  pPos ) < -radius )	return FALSE;
	if( D3DXPlaneDotCoord( &m_Plane[_LEFT],	  pPos ) < -radius )	return FALSE;
	if( D3DXPlaneDotCoord( &m_Plane[_RIGHT],  pPos ) < -radius )	return FALSE;
//	if( D3DXPlaneDotCoord( &m_Plane[_TOP],	  pPos ) < -radius )	return FALSE;
//	if( D3DXPlaneDotCoord( &m_Plane[_BOTTOM], pPos ) < -radius )	return FALSE;

	return TRUE;
}

