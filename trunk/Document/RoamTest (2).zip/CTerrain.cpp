#include "CTerrain.h"

#include "Dib.h"
#include <math.h>

#include "Log.h"
#include "CFrustum.h"

sVertex vertex[(MAP_SIZE-1)*(MAP_SIZE-1)*6];

WORD  CRoamTerrain::m_NodePointerIndex = 0;
sNode CRoamTerrain::m_NodePool[POOL_SIZE];


void Patch::Split( sNode *tri )
{
	// �̹� ������ �Ǿ��ִٸ�
	if( tri->pLeftChild )
		return;

	// ���̾Ƹ������ �̷��� �ʾҴٸ�
	if( tri->pBaseNeighbor && (tri->pBaseNeighbor->pBaseNeighbor != tri))
		Split(tri->pBaseNeighbor);

	// �ڽ� ����
	tri->pLeftChild  = CRoamTerrain::AllocateTri();
	tri->pRightChild = CRoamTerrain::AllocateTri();
	
	if( !tri->pLeftChild )
		return;

	// Link
	tri->pLeftChild->pBaseNeighbor  = tri->pLeftNeighbor;
	tri->pLeftChild->pLeftNeighbor  = tri->pRightChild;

	tri->pRightChild->pBaseNeighbor  = tri->pRightNeighbor;
	tri->pRightChild->pRightNeighbor = tri->pLeftChild;

	// pLeftNeighbor Link
	if( tri->pLeftNeighbor )
	{
		if( tri->pLeftNeighbor->pBaseNeighbor == tri )
			tri->pLeftNeighbor->pBaseNeighbor = tri->pLeftChild;
		else if( tri->pLeftNeighbor->pLeftNeighbor == tri )
			tri->pLeftNeighbor->pLeftNeighbor = tri->pLeftChild;
		else if( tri->pLeftNeighbor->pRightNeighbor == tri )
			tri->pLeftNeighbor->pRightNeighbor = tri->pLeftChild;
	}

	// pRightNeighbor Link
	if( tri->pRightNeighbor )
	{
		if( tri->pRightNeighbor->pBaseNeighbor == tri )
			tri->pRightNeighbor->pBaseNeighbor = tri->pRightChild;
		else if( tri->pRightNeighbor->pRightNeighbor == tri )
			tri->pRightNeighbor->pRightNeighbor = tri->pRightChild;
		else if( tri->pRightNeighbor->pLeftNeighbor == tri )
			tri->pRightNeighbor->pLeftNeighbor = tri->pRightChild;
	}

	// pBaseNeighbor �� ������ Child Link
	if( tri->pBaseNeighbor )
	{
		if ( tri->pBaseNeighbor->pLeftChild )
		{
			tri->pBaseNeighbor->pLeftChild->pRightNeighbor = tri->pRightChild;
			tri->pBaseNeighbor->pRightChild->pLeftNeighbor = tri->pLeftChild;
			tri->pLeftChild->pRightNeighbor = tri->pBaseNeighbor->pRightChild;
			tri->pRightChild->pLeftNeighbor = tri->pBaseNeighbor->pLeftChild;
		}
		else
		{
			// ���̾Ƹ�����ε� ���̽��̿��� ���ҵ��� �ʾҴٸ�
			Split( tri->pBaseNeighbor);
		}
	}
	else
	{
		tri->pLeftChild->pRightNeighbor = NULL;
		tri->pRightChild->pLeftNeighbor = NULL;
	}
}


void Patch::RecursTessellate( sNode *tri, int leftX, int leftZ, int rightX, int rightZ, int apexX, int apexZ )
{
	int centerX = (leftX + rightX) / 2;
	int centerZ = (leftZ + rightZ) / 2;

	// ���� ���
	int centerY = *DIB_DATAXY_INV( m_HeightMap, centerX, centerZ );
	int leftY   = *DIB_DATAXY_INV( m_HeightMap, leftX, leftZ );
	int rightY  = *DIB_DATAXY_INV( m_HeightMap, rightX, rightZ );
	// ���� ���
	float variance = fabs(centerY - (leftY + rightY) / 2.f);
	// LOD�� ���� �Ÿ����
	float distance = 1.0f + sqrtf( ((float)centerX - m_CameraPos.x) * ((float)centerX - m_CameraPos.x) +
		((float)centerZ - m_CameraPos.z) * ((float)centerZ - m_CameraPos.z));
	// ������ �Ÿ��� ������ ��ġ ���
	float TriVariance = ((float)variance * MAP_SIZE * 2) / distance;

	if( TriVariance > LOD_VARIANCE )
	{
		Split(tri);
		
		if( tri->pLeftChild && ((abs(leftX - rightX) >= MIN_TRI_SIZE) || (abs(leftZ - rightZ) >= MIN_TRI_SIZE)))
		{
			RecursTessellate( tri->pLeftChild,   apexX,  apexZ, leftX, leftZ, centerX, centerZ );
			RecursTessellate( tri->pRightChild, rightX, rightZ, apexX, apexZ, centerX, centerZ );
		}
	}
}


void Patch::RecursRender( sNode *tri, int leftX, int leftZ, int rightX, int rightZ, int apexX, int apexZ, DWORD &numTri )
{
	if( tri->pLeftChild )
	{
		int centerX = (leftX + rightX) / 2;
		int centerZ = (leftZ + rightZ) / 2;

		RecursRender( tri->pLeftChild,   apexX,  apexZ, leftX, leftZ, centerX, centerZ, numTri );
		RecursRender( tri->pRightChild, rightX, rightZ, apexX, apexZ, centerX, centerZ, numTri );
	}
	else
	{
		vertex[numTri*3].pos.x = float(leftX);
		vertex[numTri*3].pos.y = float(*DIB_DATAXY_INV( m_HeightMap, leftX, leftZ )) / 5.f;
		vertex[numTri*3].pos.z = float(leftZ);

		vertex[1+numTri*3].pos.x = float(apexX);
		vertex[1+numTri*3].pos.y = float(*DIB_DATAXY_INV( m_HeightMap, apexX, apexZ )) / 5.f;
		vertex[1+numTri*3].pos.z = float(apexZ);

		vertex[2+numTri*3].pos.x = float(rightX);
		vertex[2+numTri*3].pos.y = float(*DIB_DATAXY_INV( m_HeightMap, rightX, rightZ )) / 5.f;
		vertex[2+numTri*3].pos.z = float(rightZ);
		
		CRoamTerrain::CalcNormal( &vertex[numTri*3].nor,
			&vertex[numTri*3].pos, &vertex[1+numTri*3].pos, &vertex[2+numTri*3].pos );

		vertex[1+numTri*3].nor = vertex[numTri*3].nor;
		vertex[2+numTri*3].nor = vertex[numTri*3].nor;

		++numTri;
	}
}


void Patch::Init( int x, int z, unsigned char *hMap )
{
	m_Left.pRightNeighbor = m_Left.pLeftNeighbor = m_Right.pRightNeighbor = m_Right.pLeftNeighbor =
	m_Left.pLeftChild = m_Left.pRightChild = m_Right.pLeftChild = m_Right.pRightChild = NULL;

	m_Left.pBaseNeighbor = &m_Right;
	m_Right.pBaseNeighbor = &m_Left;

	m_WorldX = x;
	m_WorldZ = z;

	m_IsVisible = FALSE;

	m_HeightMap = hMap;
}


void Patch::Reset()
{	
	m_Left.pLeftChild = m_Left.pRightChild = m_Right.pLeftChild = m_Right.pRightChild = 
	m_Left.pRightNeighbor = m_Left.pLeftNeighbor = m_Right.pRightNeighbor = m_Right.pLeftNeighbor = NULL;

	m_Left.pBaseNeighbor = &m_Right;
	m_Right.pBaseNeighbor = &m_Left;

	m_IsVisible = FALSE;
}


void Patch::Tessellate( D3DXVECTOR3 *pCameraPos )
{
	m_CameraPos = D3DXVECTOR3( pCameraPos->x, pCameraPos->y, pCameraPos->z );

	// Left
	RecursTessellate( &m_Left, 
		m_WorldX + PATCH_SIZE, m_WorldZ, m_WorldX, m_WorldZ + PATCH_SIZE, m_WorldX, m_WorldZ );

	// Right
	RecursTessellate( &m_Right,	
		m_WorldX, m_WorldZ + PATCH_SIZE, m_WorldX + PATCH_SIZE, m_WorldZ, m_WorldX + PATCH_SIZE, m_WorldZ + PATCH_SIZE );
}


void Patch::Render( DWORD &numTri )
{
	// Left
	RecursRender( &m_Left, 
		m_WorldX + PATCH_SIZE, m_WorldZ, m_WorldX, m_WorldZ + PATCH_SIZE, m_WorldX, m_WorldZ, numTri );
	// Right
	RecursRender( &m_Right, 
		m_WorldX, m_WorldZ + PATCH_SIZE, m_WorldX + PATCH_SIZE, m_WorldZ, m_WorldX + PATCH_SIZE, m_WorldZ + PATCH_SIZE, numTri );
}


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
// CRoamTerrain
CRoamTerrain::CRoamTerrain( LPDIRECT3DDEVICE9 pDevice, CFrustum *pFrustum )
{
	m_pDevice = pDevice;

	m_pTex = NULL;
	m_pTexLight = NULL;

	m_pHeightData = NULL;
	m_FVF = D3DFVF_XYZ | D3DFVF_NORMAL;

	m_NumTri = 0;
	m_NodePointerIndex = 0;

	m_pFrustum = pFrustum;
}


CRoamTerrain::~CRoamTerrain()
{
	DibDeleteHandle( m_pHeightData );
	if( m_pTex )		m_pTex->Release();
	if( m_pTexLight )	m_pTexLight->Release();	
}


BOOL CRoamTerrain::Load( char *name )
{
	char curpath[256];
	GetCurrentDirectory( MAX_PATH, curpath );
	char respath[MAX_PATH];
	sprintf( respath , "%s\\%s" , curpath , name );

	m_pHeightData = DibLoadHandle( name );

	if( !m_pHeightData )	
	{
		MessageBox( 0, "Terrain Load Fail", 0, MB_OK );
		return FALSE;
	}

	if( FAILED( D3DXCreateTextureFromFile( m_pDevice, "Tile.tga", &m_pTex )))
	{
		MessageBox( 0, "D3DXCreateTextureFromFile Error", 0,  MB_OK );
		return FALSE;
	}

	if( FAILED( D3DXCreateTextureFromFile( m_pDevice, "TerrainLightMap.tga", &m_pTexLight )))
	{
		MessageBox( 0, "D3DXCreateTextureFromFile Error", 0,  MB_OK );
		return FALSE;
	}

	return TRUE;
}


sNode *CRoamTerrain::AllocateTri()
{
	sNode *pTri;

	if( m_NodePointerIndex >= POOL_SIZE )
		return NULL;

	pTri = &(m_NodePool[m_NodePointerIndex++]);
	pTri->pLeftChild = pTri->pRightChild = NULL;

	return pTri;
}


void CRoamTerrain::Init()
{
	for( int z = 0 ; z < PATCH_PER_SIDE; ++z )
	{
		for( int x = 0 ; x < PATCH_PER_SIDE ; ++x )
		{
			m_Patch[z][x].Init( x * PATCH_SIZE, z * PATCH_SIZE, m_pHeightData );
		}
	}
}


void CRoamTerrain::Reset()
{
	m_NodePointerIndex = 0;
	m_NumTri = 0;

	for( int z = 0 ; z < PATCH_PER_SIDE ; ++z )
	{
		for( int x = 0 ; x < PATCH_PER_SIDE ; ++x )
		{
			m_Patch[z][x].Reset();

			//================================================================*
			// �ø�
			float half = PATCH_SIZE / 2.f;
			D3DXVECTOR3 *pVec = m_Patch[z][x].GetPos();
			D3DXVECTOR3 vec = D3DXVECTOR3( pVec->x + half, pVec->y, pVec->z + half );
			m_Patch[z][x].SetVisible( m_pFrustum->CheckSphere( &vec, sqrtf(half*half + half*half)));
			//================================================================*

			if( m_Patch[z][x].IsVisible())
			{
				if( x > 0 )		m_Patch[z][x].m_Left.pRightNeighbor = &m_Patch[z][x-1].m_Right;
				else			m_Patch[z][x].m_Left.pRightNeighbor = NULL;

				if( z > 0 )		m_Patch[z][x].m_Left.pLeftNeighbor = &m_Patch[z-1][x].m_Right;
				else			m_Patch[z][x].m_Left.pLeftNeighbor = NULL;

				if( x < (PATCH_PER_SIDE-1)) 	m_Patch[z][x].m_Right.pRightNeighbor = &m_Patch[z][x+1].m_Left;
				else							m_Patch[z][x].m_Right.pRightNeighbor = NULL;

				if( z < (PATCH_PER_SIDE-1))		m_Patch[z][x].m_Right.pLeftNeighbor = &m_Patch[z+1][x].m_Left;
				else							m_Patch[z][x].m_Right.pLeftNeighbor = NULL;
			}
		}
	}

}


void CRoamTerrain::Tessellate( D3DXVECTOR3 *pCameraPos )
{
	for( int z = 0 ; z < PATCH_PER_SIDE ; ++z )
	{
		for( int x = 0 ; x < PATCH_PER_SIDE ; ++x )
		{
			if( m_Patch[z][x].IsVisible())
				m_Patch[z][x].Tessellate( pCameraPos );
		}
	}
}


void CRoamTerrain::CalcNormal( D3DXVECTOR3 *pOut, D3DXVECTOR3 *pVec1, D3DXVECTOR3 *pVec2, D3DXVECTOR3 *pVec3 )
{
	D3DXVECTOR3 vec1 = *pVec1 - *pVec2;
	D3DXVECTOR3 vec2 = *pVec1 - *pVec3;

	D3DXVec3Cross( pOut, &vec1, &vec2 );
	D3DXVec3Normalize( pOut, pOut );
}


void CRoamTerrain::Update( D3DXVECTOR3 *pCameraPos )
{
	m_pFrustum->Create();

	Reset();
	Tessellate( pCameraPos );
}


void CRoamTerrain::Render()
{
	if( GetAsyncKeyState( '1' ))
		m_pDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME );
	if( GetAsyncKeyState( '2' ))
		m_pDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );

	m_NumTri = 0;

	for( int z = 0 ; z < PATCH_PER_SIDE ; ++z )
	{
		for( int x = 0 ; x < PATCH_PER_SIDE ; ++x )
		{
			if( m_Patch[z][x].IsVisible())
				m_Patch[z][x].Render( m_NumTri );
		}		
	}
	
	//////////////////////////////////////////////////////////////////////////
	// �ؽ��ļ���

	// �����ؽ���
	m_pDevice->SetTexture( 0, m_pTex );
	m_pDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
	m_pDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1 );
	m_pDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDevice->SetTextureStageState( 0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT2 );
	m_pDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX, D3DTSS_TCI_CAMERASPACEPOSITION );

	// uv �ڵ�����
	D3DXMATRIX matView, matViewInv;
	m_pDevice->GetTransform( D3DTS_VIEW, &matView );
	D3DXMatrixInverse( &matViewInv, 0, &matView );

	D3DXMATRIX matScale;
	D3DXMatrixIdentity( &matScale );
	matScale._22 = 0.f;
	matScale._33 = 0.f;
	matScale._44 = 0.f;

	matScale._11 = 1.f / 80.f;	
	matScale._32 = 1.f / 80.f;

	matView = matViewInv * matScale;
	m_pDevice->SetTransform( D3DTS_TEXTURE0, &matView );

	// ����Ʈ��
	m_pDevice->SetTexture( 1, m_pTexLight );
	m_pDevice->SetSamplerState( 1, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
	m_pDevice->SetTextureStageState( 1, D3DTSS_COLOROP, D3DTOP_MODULATE2X );
	m_pDevice->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDevice->SetTextureStageState( 1, D3DTSS_COLORARG2, D3DTA_CURRENT );
	m_pDevice->SetTextureStageState( 1, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT2 );
	m_pDevice->SetTextureStageState( 1, D3DTSS_TEXCOORDINDEX, D3DTSS_TCI_CAMERASPACEPOSITION );

	matScale._11 = 1.f / 256.f;	
	matScale._32 = 1.f / 256.f;
	matView = matViewInv * matScale;
	m_pDevice->SetTransform( D3DTS_TEXTURE1, &matView );

	//////////////////////////////////////////////////////////////////////////
	// ������
	m_pDevice->SetFVF( m_FVF );
	m_pDevice->DrawPrimitiveUP( D3DPT_TRIANGLELIST, m_NumTri, vertex, sizeof(sVertex));

	m_pDevice->SetTextureStageState( 1, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_DISABLE );
	m_pDevice->SetTextureStageState( 1, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_DISABLE );
}
