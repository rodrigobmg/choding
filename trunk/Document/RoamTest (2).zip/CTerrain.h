#ifndef __FEELS_CTERRAIN_HEADER__
#define __FEELS_CTERRAIN_HEADER__

#include <d3d9.h>
#include <d3dx9.h>
#include <d3dx9math.h>


//////////////////////////////////////////////////////////////////////////
// MAP & PATCH SIZE
#define MAP_SIZE		256
#define PATCH_SIZE		32
#define PATCH_PER_SIDE	(MAP_SIZE/PATCH_SIZE)

#define POOL_SIZE		5000
#define LOD_VARIANCE	20
#define MIN_TRI_SIZE	10


class CFrustum;

//////////////////////////////////////////////////////////////////////////
// sVertex
struct sVertex
{
	D3DXVECTOR3 pos;
	D3DXVECTOR3 nor;
};

//////////////////////////////////////////////////////////////////////////
// sNode
struct sNode
{
	sNode *pLeftChild;
	sNode *pRightChild;
	sNode *pBaseNeighbor;
	sNode *pLeftNeighbor;
	sNode *pRightNeighbor;
};

//////////////////////////////////////////////////////////////////////////
// Patch
class Patch
{
protected:
	BYTE *m_HeightMap;
	int m_WorldX, m_WorldZ;

	BOOL m_IsVisible;

	D3DXVECTOR3 m_Position;
	D3DXVECTOR3 m_CameraPos;

public :
	// <patch>
	// -------
	// | \(2)|
	// |  \  |
	// |(1)\ |
	// -------
	sNode m_Left;	// (1)
	sNode m_Right;	// (2)

public:
	void Init( int x, int z, unsigned char *hMap );
	void Reset();
	void Tessellate( D3DXVECTOR3 *pCameraPos );
	void Render( DWORD &numTri );

	void Split( sNode *tri);
	void RecursTessellate( sNode *tri, int leftX, int leftZ, int rightX, int rightZ, int apexX, int apexZ );
	void RecursRender( sNode *tri, int leftX, int leftZ, int rightX, int rightZ, int apexX, int apexZ, DWORD &numTri );

	void SetVisible( BOOL flag )	{	m_IsVisible = flag;		}
	BOOL IsVisible()				{	return m_IsVisible;		}

	D3DXVECTOR3 *GetPos()
	{
		m_Position = D3DXVECTOR3( float(m_WorldX), 0.f, float(m_WorldZ));
		return &m_Position;
	}
};


//////////////////////////////////////////////////////////////////////////
// CRoamTerrain
class CRoamTerrain
{
private :
	LPDIRECT3DDEVICE9	m_pDevice;
	LPDIRECT3DTEXTURE9	m_pTex;
	LPDIRECT3DTEXTURE9	m_pTexLight;

	BYTE *m_pHeightData;
	Patch m_Patch[PATCH_PER_SIDE][PATCH_PER_SIDE];

	//////////////////////////////////////////////////////////////////////////	
	// Simple Memory Pool
	static sNode m_NodePool[POOL_SIZE];
	static WORD  m_NodePointerIndex;
    
	//////////////////////////////////////////////////////////////////////////
	// sVertex
	DWORD m_FVF;
	DWORD m_NumTri;

	//////////////////////////////////////////////////////////////////////////
	// Frustum
	CFrustum *m_pFrustum;

public :
	CRoamTerrain( LPDIRECT3DDEVICE9 pDevice, CFrustum *pFrustum );
	~CRoamTerrain();

	BOOL Load( char *name );
	void Init();
	void Update( D3DXVECTOR3 *pCameraPos );

	DWORD GetNumTriangle()	{ return m_NumTri; }
	static void CalcNormal( D3DXVECTOR3 *pOut, D3DXVECTOR3 *pVec1, D3DXVECTOR3 *pVec2, D3DXVECTOR3 *pVec3 );
	static sNode *AllocateTri();

	void Reset();
	void Tessellate( D3DXVECTOR3 *pCameraPos );
	void Render();
};


#endif