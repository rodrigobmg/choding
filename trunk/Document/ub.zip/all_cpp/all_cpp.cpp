// all_cpp.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#include "stdafx.h"
#include <windows.h>
#include <string>
#include <vector>
#include <iostream>
#include <algorithm>
#include <assert.h>

namespace { using namespace std; }

class ScopeFile
{
	FILE* fp_;
public:
	ScopeFile(char const * fname, char const * mode)
		: fp_(NULL)
	{
		errno_t rt = fopen_s(&fp_, fname, mode);
		rt;
	}
	~ScopeFile(){ if(fp_)fclose(fp_); fp_=NULL; }
	operator FILE* (){return fp_;}
	FILE* operator ->() {return fp_;}
};
void include_std_afx(const char * fname, FILE * fp_log);
void print_unity_x(vector<string>const& vec);

const int UNITY_NUM = 4;	//Unity_XXX.cpp ����.

int _tmain(int argc, _TCHAR* argv[])
{
	ScopeFile fp_dst("all_cpp.txt", "wt");
	ScopeFile fp_src("Audition2.vcproj", "rt");

	ScopeFile fp_log("include_std_afx_log.txt", "wt");

	if(!fp_src || !fp_dst)
	{
		fclose(fp_src);
		fclose(fp_dst);
		return 0;
	}

	//std::string::trim
	char buff[2048];
	//char fname[2048];
	char tmp[2048];
	size_t len;
	const char * ptr;
	const char * const tok = ".cpp\"\n";
	int cnt = 0;

	vector<string>	vec;
	vec.reserve(500);

	while(fgets(buff, 2048, fp_src))
	{
		len = strlen(buff);
		if(len <= 7)
			continue;

		ptr = buff+len-6;
		if(!_stricmp(ptr, tok))
		{
			//@{ ���� ���ϵ�
			if (strstr(buff, "Unity_"))
				continue;
			if (strstr(buff, "XUnzip.cpp"))
				continue;
			if (strstr(buff, "a2_stdafx.cpp"))
				continue;
			//@}

			ptr = std::find(buff, buff+len, '\"');
			////@{ insert [#include "a2_stdafx.h"]
			//strncpy_s(fname, ptr+1,len);
			//{
			//	size_t flen = strlen(fname);
			//	fname[flen-1] = 0;
			//	fname[flen-2] = 0;

			//	include_std_afx(fname, fp_log);
			//}
			////@}

			sprintf_s(tmp, "#include \".%s", ptr+1);
			vec.push_back(tmp);

			fprintf(fp_dst, "#include \".%s", ptr+1);

			cout << ptr;
			++cnt;
		}
	}

	assert(cnt == vec.size());
	print_unity_x(vec);



	cout << "cnt : " << cnt << endl;

	return 0;
}

template<int N>
void close_files(FILE* (&arr)[N])
{
	for (int i=0; i<N; ++i) {
		if (arr[i]) {
			fclose(arr[i]);
			arr[i] = NULL;
		}
	}
}

void print_unity_x(vector<string>const& vec)
{
	FILE* arr[UNITY_NUM] = {NULL,};
	char fname[MAX_PATH];
	for (int i=0; i<UNITY_NUM; ++i) {
		sprintf_s(fname, "Unity_%d.cpp", i+1);
		fopen_s(&arr[i], fname, "wt");

		if (!arr[i]) {
			close_files(arr);
			return;
		}

		fputs("#include \"a2_stdafx.h\"\n\n", arr[i]);
	}

	typedef vector<string>::const_iterator iterator;

	int i=0;
	for (iterator itr=vec.begin(); itr!=vec.end(); ++itr) {

		fprintf(arr[i], "%s", (*itr).c_str());

		++i;
		if (i>=UNITY_NUM)
			i=0;
	}

	close_files(arr);
}

int file_size(FILE * fp)
{
	fseek(fp , 0 , SEEK_END);
	int size = ftell (fp);
	rewind (fp);

	return size;
}

char g_file_buffer[1024*1024*4];
int read_all(const char * fname)
{
	ScopeFile fp(fname, "rb");

	if(!fp)
	{
		assert(!"��");
		return 0;
	}
	int size = file_size(fp);

	if(size)
	{
		size_t ichk = fread_s(g_file_buffer, sizeof(g_file_buffer)-1, size, 1, fp);
		assert(ichk == 1);
	}

	return size;
}


void include_std_afx(const char * fname, FILE * fp_log)
{
	int size=read_all(fname);

	ScopeFile fp(fname, "wb");
	if(!fp)
	{
		fprintf_s(fp_log, "FOPEN failed -- %s\r\n", fname);
		return;
	}

	int ichk = 0;
	ichk = fputs("#include \"a2_stdafx.h\"\r\n", fp);
	if(ichk == EOF)
	{
		fprintf_s(fp_log, "FPUTS failed -- %s\r\n", fname);
	}
	if(size)
	{
		ichk = (int)fwrite(g_file_buffer, size, 1, fp);
		if(ichk != 1)
		{
			fprintf_s(fp_log, "FWRITE failed -- %s\r\n", fname);
		}
	}
}