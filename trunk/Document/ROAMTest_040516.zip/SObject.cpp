#include "SObject.h"

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

SObject::SObject()
{
	Init();
}

SObject::~SObject()
{

}

void SObject::Init()
{
	m_vPos	 = D3DXVECTOR3(0.0f,0.0f,0.0f);
	m_vDir	 = D3DXVECTOR3(0.0f,0.0f,1.0f);
	m_vUp	 = D3DXVECTOR3(0.0f,1.0f,0.0f);
	m_vScale = D3DXVECTOR3(1.0f,1.0f,1.0f);
	SetWorldMatrix(&m_vPos,&m_vDir,&m_vUp);
}

void SObject::RotateXAxis(float fAngle)
{
	D3DXMATRIX matRot;
	D3DXMatrixRotationX(&matRot,fAngle);

	D3DXVECTOR3 vNewDir,vNewUp;
	D3DXVec3TransformCoord(&vNewDir,&m_vDir,&matRot);
	D3DXVec3TransformCoord(&vNewUp,&m_vUp,&matRot);
	
	SetWorldMatrix(NULL,&vNewDir,&vNewUp);
}

void SObject::RotateYAxis(float fAngle)
{
	D3DXMATRIX matRot;
	D3DXMatrixRotationY(&matRot,fAngle);

	D3DXVECTOR3 vNewDir,vNewUp;
	D3DXVec3TransformCoord(&vNewDir,&m_vDir,&matRot);
	D3DXVec3TransformCoord(&vNewUp,&m_vUp,&matRot);
	
	SetWorldMatrix(NULL,&vNewDir,&vNewUp);
}

void SObject::RotateZAxis(float fAngle)
{
	D3DXMATRIX matRot;
	D3DXMatrixRotationZ(&matRot,fAngle);

	D3DXVECTOR3 vNewDir,vNewUp;
	D3DXVec3TransformCoord(&vNewDir,&m_vDir,&matRot);
	D3DXVec3TransformCoord(&vNewUp,&m_vUp,&matRot);
	
	SetWorldMatrix(NULL,&vNewDir,&vNewUp);
}

void SObject::RotateCAxis(float fAngle)
{
	D3DXVECTOR3 vCross;
	D3DXVec3Cross(&vCross,&m_vUp,&m_vDir);

	D3DXMATRIX matRot;
	D3DXMatrixRotationAxis(&matRot,&vCross,fAngle);

	D3DXVECTOR3 vNewDir,vNewUp;
	D3DXVec3TransformCoord(&vNewDir,&m_vDir,&matRot);
	D3DXVec3Cross(&vNewUp,&vNewDir,&vCross);
	
	SetWorldMatrix(NULL,&vNewDir,&vNewUp);
}

void SObject::RotateUAxis(float fAngle)
{
	D3DXMATRIX matRot;
	D3DXMatrixRotationAxis(&matRot,&m_vUp,fAngle);

	D3DXVECTOR3 vNewDir;
	D3DXVec3TransformCoord(&vNewDir,&m_vDir,&matRot);

	SetWorldMatrix(NULL,&vNewDir,NULL);
}

void SObject::RotateDAxis(float fAngle)
{
	D3DXMATRIX matRot;
	D3DXMatrixRotationAxis(&matRot,&m_vDir,fAngle);

	D3DXVECTOR3 vNewUp;
	D3DXVec3TransformCoord(&vNewUp,&m_vUp,&matRot);

	SetWorldMatrix(NULL,NULL,&vNewUp);
}

void SObject::TranslateXAxis(float fDistance)
{
	D3DXVECTOR3 vNewPos	= m_vPos;	

	vNewPos.x += fDistance;
	
	SetWorldMatrix(&vNewPos,NULL,NULL);
}

void SObject::TranslateYAxis(float fDistance)
{
	D3DXVECTOR3 vNewPos	= m_vPos;	

	vNewPos.y += fDistance;
	
	SetWorldMatrix(&vNewPos,NULL,NULL);
}

void SObject::TranslateZAxis(float fDistance)
{
	D3DXVECTOR3 vNewPos	= m_vPos;	

	vNewPos.z += fDistance;
	
	SetWorldMatrix(&vNewPos,NULL,NULL);
}

void SObject::TranslateCAxis(float fDistance)
{
	D3DXVECTOR3 vNewPos	= m_vPos;
	D3DXVECTOR3 vNewDir	= m_vDir;

	D3DXVECTOR3 vCross;
	D3DXVec3Cross(&vCross,&m_vUp,&m_vDir);

	D3DXVECTOR3 vMove;
	D3DXVec3Normalize(&vMove,&vCross);
	vMove	*= fDistance;
	vNewPos += vMove;
	
	SetWorldMatrix(&vNewPos,&vNewDir,NULL);
}

void SObject::TranslateUAxis(float fDistance)
{
	D3DXVECTOR3 vNewPos	= m_vPos;
	D3DXVECTOR3 vNewDir	= m_vDir;

	D3DXVECTOR3 vMove;
	D3DXVec3Normalize(&vMove,&m_vUp);
	vMove	*= fDistance;
	vNewPos += vMove;
	
	SetWorldMatrix(&vNewPos,&vNewDir,NULL);
}

void SObject::TranslateDAxis(float fDistance)
{
	D3DXVECTOR3 vNewPos	= m_vPos;
	D3DXVECTOR3 vNewDir	= m_vDir;

	D3DXVECTOR3 vMove;
	D3DXVec3Normalize(&vMove,&m_vDir);
	vMove	*= fDistance;
	vNewPos += vMove;

	SetWorldMatrix(&vNewPos,&vNewDir,NULL);
}

void SObject::SetWorldMatrix(D3DXVECTOR3* pPos,D3DXVECTOR3* pDir,D3DXVECTOR3* pUp)
{
	if(pPos) m_vPos = *pPos;
	if(pDir) D3DXVec3Normalize(&m_vDir,pDir);
	if(pUp)  D3DXVec3Normalize(&m_vUp,pUp);

	D3DXMatrixScaling(&m_matWorld,m_vScale.x,m_vScale.y,m_vScale.z);

	D3DXMATRIX matrix;
	D3DXVECTOR3 vOrigin(0.0f,0.0f,0.0f);
	D3DXMatrixLookAtLH(&matrix,&vOrigin,pDir,&m_vUp);
	D3DXMatrixInverse(&matrix,NULL,&matrix);
	matrix._41 = 0.0f; matrix._42 = 0.0f; matrix._43 = 0.0f;
	
	m_matWorld *= matrix;

	D3DXMatrixTranslation(&matrix,m_vPos.x,m_vPos.y,m_vPos.z);

	m_matWorld *= matrix;
}

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
