#include "SFrustum.h"

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

D3DXVECTOR3	SFrustum::s_vVtx[8];
D3DXPLANE	SFrustum::s_Plane[6];

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

BOOL SFrustum::Update(D3DXMATRIX* pView,D3DXMATRIX* pProj)
{
	D3DXMATRIX matrix = (*pView)*(*pProj);
	
	// projected �� ��ü ȭ��
	s_vVtx[0].x = -1.0f; s_vVtx[0].y = -1.0f; s_vVtx[0].z = 0.0f;
	s_vVtx[1].x =  1.0f; s_vVtx[1].y = -1.0f; s_vVtx[1].z = 0.0f;
	s_vVtx[2].x =  1.0f; s_vVtx[2].y = -1.0f; s_vVtx[2].z = 1.0f;
	s_vVtx[3].x = -1.0f; s_vVtx[3].y = -1.0f; s_vVtx[3].z = 1.0f;
	s_vVtx[4].x = -1.0f; s_vVtx[4].y =  1.0f; s_vVtx[4].z = 0.0f;
	s_vVtx[5].x =  1.0f; s_vVtx[5].y =  1.0f; s_vVtx[5].z = 0.0f;
	s_vVtx[6].x =  1.0f; s_vVtx[6].y =  1.0f; s_vVtx[6].z = 1.0f;
	s_vVtx[7].x = -1.0f; s_vVtx[7].y =  1.0f; s_vVtx[7].z = 1.0f;

	D3DXMatrixInverse(&matrix,NULL,&matrix);

	// View * Proj �� ������� Vertex �� ���ϸ� World ��ǥ�� ���´�
	for(int i=0;i<8;i++) D3DXVec3TransformCoord(&s_vVtx[i],&s_vVtx[i],&matrix);

	// ������� World ��ǥ�� Frustum Plane �� �����
	D3DXPlaneFromPoints(&s_Plane[0],s_vVtx+4,s_vVtx+7,s_vVtx+6); // Up plane
	D3DXPlaneFromPoints(&s_Plane[1],s_vVtx,s_vVtx+1,s_vVtx+2);	 // Bottom plane
	D3DXPlaneFromPoints(&s_Plane[2],s_vVtx,s_vVtx+4,s_vVtx+5);	 // Near plane
	D3DXPlaneFromPoints(&s_Plane[3],s_vVtx+2,s_vVtx+6,s_vVtx+7); // Far plane
	D3DXPlaneFromPoints(&s_Plane[4],s_vVtx,s_vVtx+3,s_vVtx+7);	 // Left plane
	D3DXPlaneFromPoints(&s_Plane[5],s_vVtx+1,s_vVtx+5,s_vVtx+6); // Right plane

	return TRUE;
}

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
