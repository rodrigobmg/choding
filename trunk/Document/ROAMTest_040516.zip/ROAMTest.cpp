//-----------------------------------------------------------------------------
// File: ROAMTest.cpp
//
// Desc: DirectX window application created by the DirectX AppWizard
//-----------------------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DUtil.h"
#include "resource.h"
#include "ROAMTest.h"
#include "SUtil.h"
#include "SCamera.h"
#include "SFrustum.h"

//-----------------------------------------------------------------------------
// Global access to the app (needed for the global WndProc())
//-----------------------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;

//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: Entry point to the program. Initializes everything, and goes into a
//       message-processing loop. Idle time is used to render the scene.
//-----------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}

//-----------------------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: Application constructor.   Paired with ~CMyD3DApplication()
//       Member variables should be initialized to a known state here.  
//       The application window has not yet been created and no Direct3D device 
//       has been created, so any initialization that depends on a window or 
//       Direct3D should be deferred to a later stage. 
//-----------------------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
    m_dwCreationWidth           = 1024;
    m_dwCreationHeight          = 768;
    m_strWindowTitle            = TEXT( "ROAMTest" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    // Create a D3D font using d3dfont.cpp
    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );

	m_pTexture					= NULL;
	m_bWireFrame				= FALSE;
}

//-----------------------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: Application destructor.  Paired with CMyD3DApplication()
//-----------------------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}

//-----------------------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: Paired with FinalCleanup().
//       The window has been created and the IDirect3D9 interface has been
//       created, but the device has not been created yet.  Here you can
//       perform application-related initialization and cleanup that does
//       not depend on a device.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // TODO: perform one time initialization

    // Drawing loading status message until app finishes loading
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: Called during device initialization, this code checks the display device
//       for some minimum set of capabilities
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps, DWORD dwBehavior,
                                          D3DFORMAT Format )
{
    UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    
    BOOL bCapsAcceptable;

    // TODO: Perform checks to see if these display caps are acceptable.
    bCapsAcceptable = TRUE;

    if( bCapsAcceptable )         
        return S_OK;
    else
        return E_FAIL;
}

//-----------------------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: Paired with DeleteDeviceObjects()
//       The device has been created.  Resources that are not lost on
//       Reset() can be created here -- resources in D3DPOOL_MANAGED,
//       D3DPOOL_SCRATCH, or D3DPOOL_SYSTEMMEM.  Image surfaces created via
//       CreateImageSurface are never lost and can be created here.  Vertex
//       shaders and pixel shaders can also be created here as they are not
//       lost on Reset().
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    // TODO: create device objects
	if(!m_Map.Load("Data\\Temp_64_128_2.map",m_pd3dDevice)) MessageBox(NULL,"Load map failed!!!","Error",MB_OK);

	if(FAILED(D3DXCreateTextureFromFile(m_pd3dDevice,"Data\\Sand.dds",&m_pTexture))) MessageBox(NULL,"Load texture failed!!!","Error",MB_OK);

    // Init the font
    m_pFont->InitDeviceObjects( m_pd3dDevice );

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: Paired with InvalidateDeviceObjects()
//       The device exists, but may have just been Reset().  Resources in
//       D3DPOOL_DEFAULT and any other device state that persists during
//       rendering should be set here.  Render states, matrices, textures,
//       etc., that don't change during rendering can be set once here to
//       avoid redundant state setting during Render() or FrameMove().
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
    // TODO: setup render states
	if(!m_Map.Restore()) MessageBox(NULL,"Load map failed!!!","Error",MB_OK);

    // Setup a material
    D3DMATERIAL9 mtrl;
    D3DUtil_InitMaterial( mtrl, 1.0f, 1.0f, 1.0f );
    m_pd3dDevice->SetMaterial( &mtrl );

    // Set up the textures
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
	m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR );

    // Set miscellaneous render states
    m_pd3dDevice->SetRenderState( D3DRS_DITHERENABLE,   FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,        TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_AMBIENT,        0x000F0F0F );
	//m_pd3dDevice->SetRenderState( D3DRS_SHADEMODE,      D3DSHADE_FLAT );

    // Set the world matrix
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity( &matIdentity );
    m_pd3dDevice->SetTransform( D3DTS_WORLD,  &matIdentity );

    // Set up our view matrix. A view matrix can be defined given an eye point,
    // a point to lookat, and a direction for which way is up. Here, we set the
    // eye five units back along the z-axis and up three units, look at the
    // origin, and define "up" to be in the y-direction.
	float xMid = SMap::GetXMapSize()*SMap::GetScale()/2.0f;
	float zMid = SMap::GetZMapSize()*SMap::GetScale()/2.0f;
	D3DXVECTOR3 vCameraEye	  = D3DXVECTOR3(xMid,SMap::GetScale()*128.0f,zMid);
	D3DXVECTOR3 vCameraLookat = D3DXVECTOR3(xMid,0.0f,zMid);
	D3DXVECTOR3 vCameraUp	  = D3DXVECTOR3(0.0f,0.0f,1.0f);
	SCamera::SetViewParams(&vCameraEye,&vCameraLookat,&vCameraUp);
	m_pd3dDevice->SetTransform( D3DTS_VIEW, SCamera::GetViewMatrix() );

    // Set the projection matrix
	FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
	SCamera::SetProjParams(D3DX_PI/4,fAspect,1.0f,SMap::GetScale()*256);
	m_pd3dDevice->SetTransform( D3DTS_PROJECTION, SCamera::GetProjMatrix() );

    // Set up lighting states
    D3DLIGHT9 light;
    D3DUtil_InitLight( light, D3DLIGHT_DIRECTIONAL, 0.0f, -1.0f, 0.0f );
    m_pd3dDevice->SetLight( 0, &light );
    m_pd3dDevice->LightEnable( 0, TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );

    // Restore the font
    m_pFont->RestoreDeviceObjects();

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: FrameMove()
// Desc: Called once per frame, the call is the entry point for animating
//       the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
    // Update user input state
    UpdateInput( &m_UserInput );

    // Update the world state according to user input
    if( m_UserInput.bLeft && !m_UserInput.bRight )
	{
		SCamera::TranslateXAxis(-SMap::GetScale());
	}
    else if( m_UserInput.bRight && !m_UserInput.bLeft )
	{
        SCamera::TranslateXAxis(SMap::GetScale());
	}

    if( m_UserInput.bUp && !m_UserInput.bDown )
	{
		SCamera::TranslateZAxis(SMap::GetScale());
	}
    else if( m_UserInput.bDown && !m_UserInput.bUp )
	{
        SCamera::TranslateZAxis(-SMap::GetScale());
	}

    if( m_UserInput.bPageUp && !m_UserInput.bPageDown )
	{
        SCamera::TranslateYAxis(-SMap::GetScale());
	}
    else if( m_UserInput.bPageDown && !m_UserInput.bPageUp )
	{
        SCamera::TranslateYAxis(SMap::GetScale());
	}
	
    if( m_UserInput.bHome && !m_UserInput.bEnd )
	{
		SCamera::RotateCAxis(-0.01f);
	}
    else if( m_UserInput.bEnd && !m_UserInput.bHome )
	{
        SCamera::RotateCAxis(0.01f);
	}

	if( m_UserInput.bF5 ) m_bWireFrame = TRUE;
	else				  m_bWireFrame = FALSE;

	m_pd3dDevice->SetTransform( D3DTS_VIEW, SCamera::GetViewMatrix() );

	// TODO: update world
	SFrustum::Update(SCamera::GetViewMatrix(),SCamera::GetProjMatrix());

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: UpdateInput()
// Desc: Update the user input.  Called once per frame 
//-----------------------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
    pUserInput->bUp		   = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bDown	   = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bLeft	   = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRight	   = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );
	pUserInput->bPageUp	   = ( m_bActive && (GetAsyncKeyState( VK_NEXT )  & 0x8000) == 0x8000 );
    pUserInput->bPageDown  = ( m_bActive && (GetAsyncKeyState( VK_PRIOR ) & 0x8000) == 0x8000 );
	pUserInput->bHome	   = ( m_bActive && (GetAsyncKeyState( VK_HOME )  & 0x8000) == 0x8000 );
    pUserInput->bEnd	   = ( m_bActive && (GetAsyncKeyState( VK_END )   & 0x8000) == 0x8000 );
	pUserInput->bF5		   = ( m_bActive && (GetAsyncKeyState( VK_F5 )    & 0x8000) == 0x8000 );
}

//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Called once per frame, the call is the entry point for 3d
//       rendering. This function sets up render states, clears the
//       viewport, and renders the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
    // Clear the viewport
    m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(65,133,169), 1.0f, 0L );

    // Begin the scene
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
        // TODO: render world
		float fFogFPlane = SMap::GetScale()*256;
		float fFogNPlane = fFogFPlane*0.5f;
		m_pd3dDevice->SetRenderState(D3DRS_FOGENABLE,TRUE);
		m_pd3dDevice->SetRenderState(D3DRS_FOGCOLOR,D3DCOLOR_XRGB(65,133,169));
		m_pd3dDevice->SetRenderState(D3DRS_FOGSTART,*((DWORD*)(&fFogNPlane)));
		m_pd3dDevice->SetRenderState(D3DRS_FOGEND,*((DWORD*)(&fFogFPlane)));
		m_pd3dDevice->SetRenderState(D3DRS_FOGTABLEMODE,D3DFOG_LINEAR);

		m_pd3dDevice->SetTexture(0,m_pTexture);
		m_Map.Render();
		m_pd3dDevice->SetTexture(0,NULL);

		m_pd3dDevice->SetRenderState(D3DRS_FOGENABLE,FALSE);

		if(m_bWireFrame)
		{
			m_pd3dDevice->SetRenderState(D3DRS_ZENABLE,D3DZB_FALSE);
			m_pd3dDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_NONE);
			m_pd3dDevice->SetRenderState(D3DRS_FILLMODE,D3DFILL_WIREFRAME);
			m_pd3dDevice->LightEnable(0,FALSE);
			m_Map.Render();
			m_pd3dDevice->SetRenderState(D3DRS_ZENABLE,D3DZB_TRUE);
			m_pd3dDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_CCW);
			m_pd3dDevice->SetRenderState(D3DRS_FILLMODE,D3DFILL_SOLID);
			m_pd3dDevice->LightEnable(0,TRUE);
		}

        // Render stats and help text  
        RenderText();

        // End the scene.
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: RenderText()
// Desc: Renders stats and help text to the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor    = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    // Output display stats
    FLOAT fNextLine = 0.0f; 

	fNextLine += 20.0f;
	wsprintf(szMsg,"Total Poligon : %d, Total Node : %d",SPatch::s_iTotalPoligon,SPatch::GetNextNode());
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

	fNextLine += 20.0f;
    lstrcpy( szMsg, m_strFrameStats );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

	fNextLine += 20.0f;
    lstrcpy( szMsg, m_strDeviceStats );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

	fNextLine += 40.0f;
	m_pFont->DrawText( 2, fNextLine, fontColor, "View Wire-Frame : F5");
	fNextLine += 20.0f;
	m_pFont->DrawText( 2, fNextLine, fontColor, "Camera Movement : Arrow Key, PageUp, PageDown, Home, End");

	fNextLine += 20.0f;
	sprintf(szMsg,"Camera Posision : (%f, %f, %f)",SCamera::GetEye()->x,SCamera::GetEye()->y,SCamera::GetEye()->z);
	m_pFont->DrawText( 2, fNextLine, fontColor, szMsg);

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: Overrrides the main WndProc, so the sample can do custom message
//       handling (e.g. processing mouse, keyboard, or menu commands).
//-----------------------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,
                                    LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // Draw on the window tell the user that the app is loading
                // TODO: change as needed
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf( strMsg, TEXT("Loading... Please wait") );
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}

//-----------------------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: Invalidates device objects.  Paired with RestoreDeviceObjects()
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
    // TODO: Cleanup any objects created in RestoreDeviceObjects()
	m_Map.Invalid();

    m_pFont->InvalidateDeviceObjects();

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: Paired with InitDeviceObjects()
//       Called when the app is exiting, or the device is being changed,
//       this function deletes any device dependent objects.  
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
    // TODO: Cleanup any objects created in InitDeviceObjects()
	m_Map.Release();
	SRELEASE(m_pTexture);

    m_pFont->DeleteDeviceObjects();

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: FinalCleanup()
// Desc: Paired with OneTimeSceneInit()
//       Called before the app exits, this function gives the app the chance
//       to cleanup after itself.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
    // TODO: Perform any final cleanup needed
    // Cleanup D3D font
    SAFE_DELETE( m_pFont );

    return S_OK;
}
