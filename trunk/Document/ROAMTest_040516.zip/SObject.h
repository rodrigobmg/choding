#pragma once

#include <d3d9.h>
#include <d3dx9.h>

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

class SObject
{
protected:
	D3DXVECTOR3	m_vPos;
	D3DXVECTOR3	m_vDir;
	D3DXVECTOR3	m_vUp;
	D3DXVECTOR3	m_vScale;
	D3DXMATRIX	m_matWorld;

public:
	SObject();
	virtual ~SObject();

public:
	inline D3DXVECTOR3*	GetPos()					  { return &m_vPos; }
	inline D3DXVECTOR3*	GetDir()					  { return &m_vDir; }
	inline D3DXVECTOR3*	GetUp()						  { return &m_vUp; }
	inline D3DXVECTOR3*	GetScale()					  { return &m_vScale; }
	inline D3DXMATRIX*	GetWorldMatrix()			  { return &m_matWorld; }
	inline void			SetScale(D3DXVECTOR3* pScale) { m_vScale = *pScale; SetWorldMatrix(NULL,NULL,NULL); }

public:
	virtual void Init();

public:	
	void RotateXAxis(float fAngle);
	void RotateYAxis(float fAngle);
	void RotateZAxis(float fAngle);
	void RotateCAxis(float fAngle);
	void RotateUAxis(float fAngle);
	void RotateDAxis(float fAngle);
	void TranslateXAxis(float fDistance);
	void TranslateYAxis(float fDistance);
	void TranslateZAxis(float fDistance);
	void TranslateCAxis(float fDistance);
	void TranslateUAxis(float fDistance);
	void TranslateDAxis(float fDistance);
	void SetWorldMatrix(D3DXVECTOR3* pPos,D3DXVECTOR3* pDir,D3DXVECTOR3* pUp);
};

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
