#include <stdio.h>
#include "SMap.h"
#include "SUtil.h"
#include "SCamera.h"
#include "SFrustum.h"

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

#define HEADERFILESIZE	(sizeof(int)*3+sizeof(float))
#define INDEXINFOSIZE	(SSQUARE(SMap::GetPatchSize())*6)
#define VERTEXINFOSIZE	(SSQUARE(SMap::GetPatchSize()+1))
#define PATCHFILESIZE	(VERTEXINFOSIZE*sizeof(short))

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

int						SPatch::s_iNextNode;
STRINODE				SPatch::s_NodePool[POOL_SIZE];
float					SPatch::s_fLODFactor = 0.05f;
int						SPatch::s_iTotalPoligon;
int						SMap::s_xMapSize;
int						SMap::s_zMapSize;
int						SMap::s_iPatchSize;
int						SMap::s_xPatchCount;
int						SMap::s_zPatchCount;
float					SMap::s_fScale;
LPDIRECT3DDEVICE9		SMap::s_pD3DDevice;
SFileSystem				SMap::s_FileSystem;

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

SPatch::SPatch()
{
	m_xWorld = 0;
	m_zWorld = 0;
	m_pHeight = NULL;
	m_fMinHeight = 0.0f;
	m_fMaxHeight = 0.0f;
	m_wIndex = 0;
	m_pIndex = NULL;
	m_pIBuffer = NULL;
	m_pVBuffer = NULL;

	Reset();
}

SPatch::~SPatch()
{
	Release();
}

void SPatch::_Split(STRINODE* pNode)
{
	if(pNode->pRChild) return;

	if(pNode->pBNeighbor && (pNode->pBNeighbor->pBNeighbor != pNode)) _Split(pNode->pBNeighbor);

	if((pNode->pLChild = _AllocNode()) == NULL) return;
	if((pNode->pRChild = _AllocNode()) == NULL) return;

	pNode->pLChild->pBNeighbor = pNode->pLNeighbor;
	pNode->pLChild->pLNeighbor = pNode->pRChild;
	pNode->pRChild->pBNeighbor = pNode->pRNeighbor;
	pNode->pRChild->pRNeighbor = pNode->pLChild;

	if(pNode->pLNeighbor)
	{
		if(pNode->pLNeighbor->pBNeighbor == pNode)
			pNode->pLNeighbor->pBNeighbor = pNode->pLChild;
		else if(pNode->pLNeighbor->pLNeighbor == pNode)
			pNode->pLNeighbor->pLNeighbor = pNode->pLChild;
		else if(pNode->pLNeighbor->pRNeighbor == pNode)
			pNode->pLNeighbor->pRNeighbor = pNode->pLChild;
	}

	if(pNode->pRNeighbor)
	{
		if(pNode->pRNeighbor->pBNeighbor == pNode)
			pNode->pRNeighbor->pBNeighbor = pNode->pRChild;
		else if(pNode->pRNeighbor->pRNeighbor == pNode)
			pNode->pRNeighbor->pRNeighbor = pNode->pRChild;
		else if(pNode->pRNeighbor->pLNeighbor == pNode)
			pNode->pRNeighbor->pLNeighbor = pNode->pRChild;
	}

	if(pNode->pBNeighbor)
	{
		if(pNode->pBNeighbor->pRChild)
		{
			pNode->pBNeighbor->pLChild->pRNeighbor = pNode->pRChild;
			pNode->pBNeighbor->pRChild->pLNeighbor = pNode->pLChild;
			pNode->pLChild->pRNeighbor = pNode->pBNeighbor->pRChild;
			pNode->pRChild->pLNeighbor = pNode->pBNeighbor->pLChild;
		}
		else
			_Split(pNode->pBNeighbor);
	}
	else
	{
		pNode->pLChild->pRNeighbor = NULL;
		pNode->pRChild->pLNeighbor = NULL;
	}
}

void SPatch::_Build(STRINODE* pNode,int xLeft,int zLeft,int xRight,int zRight,int xApex,int zApex,int iNode)
{
	int xCenter = (xLeft+xRight)/2;
	int zCenter = (zLeft+zRight)/2;

	float fRadius = SVEC2LENGTH((float)xLeft,(float)zLeft,(float)xCenter,(float)zCenter)*SMap::GetScale();
	float fDistance = SVEC2LENGTH(xCenter*SMap::GetScale(),zCenter*SMap::GetScale(),SCamera::GetEye()->x,SCamera::GetEye()->z);

	if(fRadius/fDistance >= s_fLODFactor)
	{
		if(abs(xLeft-xRight) > 1 || abs(zLeft-zRight) > 1)
		{
			_Split(pNode);

			if(pNode->pRChild)
			{
				_Build(pNode->pLChild,xApex,zApex,xLeft,zLeft,xCenter,zCenter,iNode*2);
				_Build(pNode->pRChild,xRight,zRight,xApex,zApex,xCenter,zCenter,iNode*2+1);
			}
		}
	}
}

void SPatch::_Render(STRINODE* pNode,int xLeft,int zLeft,int xRight,int zRight,int xApex,int zApex)
{
	if(pNode->pRChild)
	{
		int xCenter = (xLeft+xRight)/2;
		int zCenter = (zLeft+zRight)/2;

		_Render(pNode->pLChild,xApex,zApex,xLeft,zLeft,xCenter,zCenter);
		_Render(pNode->pRChild,xRight,zRight,xApex,zApex,xCenter,zCenter);
	}
	else
	{
		m_pIndex[m_wIndex++] = (WORD)(xLeft+zLeft*(SMap::GetPatchSize()+1));
		m_pIndex[m_wIndex++] = (WORD)(xRight+zRight*(SMap::GetPatchSize()+1));
		m_pIndex[m_wIndex++] = (WORD)(xApex+zApex*(SMap::GetPatchSize()+1));

		s_iTotalPoligon++;
	}
}

void SPatch::Release()
{
	m_xWorld = 0;
	m_zWorld = 0;
	SDELETEARRAY(m_pHeight);
	m_fMinHeight = 0.0f;
	m_fMaxHeight = 0.0f;

	Reset();

	ReleaseIVBuffer();
}

BOOL SPatch::Load(int xInx,int zInx)
{
	Release();

	char strPatch[_MAX_FNAME];
	SMap::GetPatchName(xInx,zInx,strPatch);

	SFileHandle* pFH = SMap::GetFileSystem()->OpenFile(strPatch);
	if(!pFH)
	{
		Release();
		return FALSE;
	}

	m_xWorld = xInx*SMap::GetPatchSize();
	m_zWorld = zInx*SMap::GetPatchSize();
	m_pHeight = new short[VERTEXINFOSIZE];
	pFH->Read(m_pHeight,PATCHFILESIZE);

	SMap::GetFileSystem()->CloseFile(pFH);

	Reset();

	if(!CreateIVBuffer())
	{
		Release();
		return FALSE;
	}

	return TRUE;
}

void SPatch::ReleaseIVBuffer()
{
	SRELEASE(m_pIBuffer);
	SRELEASE(m_pVBuffer);
}

BOOL SPatch::CreateIVBuffer()
{
	ReleaseIVBuffer();

	if(!m_pIBuffer)
	{
		int iMemSize = INDEXINFOSIZE*sizeof(WORD);
		if(FAILED(SMap::GetD3DDevice()->CreateIndexBuffer(iMemSize,0,D3DFMT_INDEX16,D3DPOOL_DEFAULT,&m_pIBuffer,NULL)))
		{
			Release();
			return FALSE;
		}
	}

	int iMemSize = VERTEXINFOSIZE*sizeof(SVERTEX_PNT2);
	if(FAILED(SMap::GetD3DDevice()->CreateVertexBuffer(iMemSize,D3DUSAGE_WRITEONLY,D3DFVF_PNT2,D3DPOOL_DEFAULT,&m_pVBuffer,NULL)))
	{
		Release();
		return FALSE;
	}

	SVERTEX_PNT2* pVertex;
    if(FAILED(m_pVBuffer->Lock(0,iMemSize,(void**)&pVertex,0)))
	{
		Release();
		return FALSE;
	}

	int x,z,iCount = 0;
	for(z=0;z<SMap::GetPatchSize()+1;z++)
	{
		for(x=0;x<SMap::GetPatchSize()+1;x++)
		{
			pVertex[iCount].vPos.x = (m_xWorld+x)*SMap::GetScale();
			pVertex[iCount].vPos.z = (m_zWorld+z)*SMap::GetScale();
			pVertex[iCount].vPos.y = m_pHeight[x+z*(SMap::GetPatchSize()+1)];
			pVertex[iCount].vNormal = CheckNormal(x,z);
			pVertex[iCount].fU1 = x/8.0f; // �ӽø��
			pVertex[iCount].fV1 = z/8.0f; // �ӽø��
			pVertex[iCount].fU2 = (float)x/(float)(SMap::GetPatchSize()+1); // �ӽø��
			pVertex[iCount++].fV2 = (float)z/(float)(SMap::GetPatchSize()+1); // �ӽø��
		}
	}

	m_pVBuffer->Unlock();

	CheckMinMaxHeight();

	return TRUE;
}

void SPatch::Reset()
{
	m_bVisible = FALSE;
	m_LBase.pBNeighbor = &m_RBase;
	m_RBase.pBNeighbor = &m_LBase;
	m_LBase.pLChild = m_LBase.pRChild = m_LBase.pLNeighbor = m_LBase.pRNeighbor = NULL;
	m_RBase.pLChild = m_RBase.pRChild = m_RBase.pLNeighbor = m_RBase.pRNeighbor = NULL;
}

void SPatch::Build()
{
	_Build(&m_LBase,m_xWorld,m_zWorld+SMap::GetPatchSize(),m_xWorld+SMap::GetPatchSize(),m_zWorld,m_xWorld,m_zWorld,1);
					
	_Build(&m_RBase,m_xWorld+SMap::GetPatchSize(),m_zWorld,m_xWorld,m_zWorld+SMap::GetPatchSize(),m_xWorld+SMap::GetPatchSize(),m_zWorld+SMap::GetPatchSize(),1);
}

BOOL SPatch::Render()
{
	m_wIndex = 0;
	if(FAILED(m_pIBuffer->Lock(0,INDEXINFOSIZE*sizeof(WORD),(void**)&m_pIndex,0))) return FALSE;

	_Render(&m_LBase,0,SMap::GetPatchSize(),SMap::GetPatchSize(),0,0,0);
	_Render(&m_RBase,SMap::GetPatchSize(),0,0,SMap::GetPatchSize(),SMap::GetPatchSize(),SMap::GetPatchSize());

	m_pIBuffer->Unlock();

	SMap::GetD3DDevice()->SetStreamSource(0,m_pVBuffer,0,sizeof(SVERTEX_PNT2));
	SMap::GetD3DDevice()->SetFVF(D3DFVF_PNT2);
	SMap::GetD3DDevice()->SetIndices(m_pIBuffer);
	SMap::GetD3DDevice()->DrawIndexedPrimitive(D3DPT_TRIANGLELIST,0,0,VERTEXINFOSIZE,0,m_wIndex/3);

	return TRUE;
}

void SPatch::CheckMinMaxHeight()
{
	float fH;
	m_fMinHeight =  BIG_FLOAT;
	m_fMaxHeight = -BIG_FLOAT;
	for(int z=0;z<SMap::GetPatchSize()+1;z++)
	{
		for(int x=0;x<SMap::GetPatchSize()+1;x++)
		{
			fH = m_pHeight[x+z*(SMap::GetPatchSize()+1)];
			if(fH < m_fMinHeight) m_fMinHeight = fH;
			if(fH > m_fMaxHeight) m_fMaxHeight = fH;
		}
	}
}

D3DXVECTOR3 SPatch::CheckNormal(int x,int z)
{
	return D3DXVECTOR3(0.0f,1.0f,0.0f);

	D3DXVECTOR3 vVec[4],vNormal(0.0f,0.0f,0.0f);
	vVec[0] = D3DXVECTOR3(0.0f,m_pHeight[x+z*(SMap::GetPatchSize()+1)],0.0f);

	if(m_xWorld + x + 1 <= SMap::GetPatchSize() && m_zWorld + z - 1 >= 0)
	{
		vVec[1] = D3DXVECTOR3(0.0f,m_pHeight[x+(z-1)*(SMap::GetPatchSize()+1)],-SMap::GetScale())-vVec[0];
		vVec[2] = D3DXVECTOR3(SMap::GetScale(),m_pHeight[x+1+(z-1)*(SMap::GetPatchSize()+1)],-SMap::GetScale())-vVec[0];
		D3DXVec3Cross(&vVec[3],&vVec[2],&vVec[1]); D3DXVec3Normalize(&vVec[3],&vVec[3]); vNormal += vVec[3];
	}
	if(m_xWorld + x + 1 <= SMap::GetPatchSize() && m_zWorld + z - 1 >= 0)
	{
		vVec[1] = D3DXVECTOR3(SMap::GetScale(),m_pHeight[x+1+(z-1)*(SMap::GetPatchSize()+1)],-SMap::GetScale())-vVec[0];
		vVec[2] = D3DXVECTOR3(SMap::GetScale(),m_pHeight[x+1+z*(SMap::GetPatchSize()+1)],0.0f)-vVec[0];
		D3DXVec3Cross(&vVec[3],&vVec[2],&vVec[1]); D3DXVec3Normalize(&vVec[3],&vVec[3]); vNormal += vVec[3];
	}
	if(m_xWorld + x + 1 <= SMap::GetPatchSize() && m_zWorld + z + 1 <= SMap::GetPatchSize())
	{
		vVec[1] = D3DXVECTOR3(SMap::GetScale(),m_pHeight[x+1+z*(SMap::GetPatchSize()+1)],0.0f)-vVec[0];
		vVec[2] = D3DXVECTOR3(SMap::GetScale(),m_pHeight[x+1+(z+1)*(SMap::GetPatchSize()+1)],SMap::GetScale())-vVec[0];
		D3DXVec3Cross(&vVec[3],&vVec[2],&vVec[1]); D3DXVec3Normalize(&vVec[3],&vVec[3]); vNormal += vVec[3];
	}
	if(m_xWorld + x + 1 <= SMap::GetPatchSize() && m_zWorld + z + 1 <= SMap::GetPatchSize())
	{
		vVec[1] = D3DXVECTOR3(SMap::GetScale(),m_pHeight[x+1+(z+1)*(SMap::GetPatchSize()+1)],SMap::GetScale())-vVec[0];
		vVec[2] = D3DXVECTOR3(0.0f,m_pHeight[x+(z+1)*(SMap::GetPatchSize()+1)],SMap::GetScale())-vVec[0];
		D3DXVec3Cross(&vVec[3],&vVec[2],&vVec[1]); D3DXVec3Normalize(&vVec[3],&vVec[3]); vNormal += vVec[3];
	}
	if(m_xWorld + x - 1 >= 0 && m_zWorld + z + 1 <= SMap::GetPatchSize())
	{
		vVec[1] = D3DXVECTOR3(0.0f,m_pHeight[x+(z+1)*(SMap::GetPatchSize()+1)],SMap::GetScale())-vVec[0];
		vVec[2] = D3DXVECTOR3(-SMap::GetScale(),m_pHeight[x-1+(z+1)*(SMap::GetPatchSize()+1)],SMap::GetScale())-vVec[0];
		D3DXVec3Cross(&vVec[3],&vVec[2],&vVec[1]); D3DXVec3Normalize(&vVec[3],&vVec[3]); vNormal += vVec[3];
	}
	if(m_xWorld + x - 1 >= 0 && m_zWorld + z + 1 <= SMap::GetPatchSize())
	{
		vVec[1] = D3DXVECTOR3(-SMap::GetScale(),m_pHeight[x-1+(z+1)*(SMap::GetPatchSize()+1)],SMap::GetScale())-vVec[0];
		vVec[2] = D3DXVECTOR3(-SMap::GetScale(),m_pHeight[x-1+z*(SMap::GetPatchSize()+1)],0.0f)-vVec[0];
		D3DXVec3Cross(&vVec[3],&vVec[2],&vVec[1]); D3DXVec3Normalize(&vVec[3],&vVec[3]); vNormal += vVec[3];
	}
	if(m_xWorld + x - 1 >= 0 && m_zWorld + z - 1 >= 0)
	{
		vVec[1] = D3DXVECTOR3(-SMap::GetScale(),m_pHeight[x-1+z*(SMap::GetPatchSize()+1)],0.0f)-vVec[0];
		vVec[2] = D3DXVECTOR3(-SMap::GetScale(),m_pHeight[x-1+(z-1)*(SMap::GetPatchSize()+1)],-SMap::GetScale())-vVec[0];
		D3DXVec3Cross(&vVec[3],&vVec[2],&vVec[1]); D3DXVec3Normalize(&vVec[3],&vVec[3]); vNormal += vVec[3];
	}
	if(m_xWorld + x - 1 >= 0 && m_zWorld + z - 1 >= 0)
	{
		vVec[1] = D3DXVECTOR3(-SMap::GetScale(),m_pHeight[x-1+(z-1)*(SMap::GetPatchSize()+1)],-SMap::GetScale())-vVec[0];
		vVec[2] = D3DXVECTOR3(0.0f,m_pHeight[x+(z-1)*(SMap::GetPatchSize()+1)],-SMap::GetScale())-vVec[0];
		D3DXVec3Cross(&vVec[3],&vVec[2],&vVec[1]); D3DXVec3Normalize(&vVec[3],&vVec[3]); vNormal += vVec[3];
	}

	D3DXVec3Normalize(&vNormal,&vNormal);

	return vNormal;
}

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

SMap::SMap()
{
	m_xCurPatch = 0;
	m_zCurPatch = 0;
	m_xSrtPatch = 0;
	m_zSrtPatch = 0;
	m_xEndPatch = 0;
	m_zEndPatch = 0;
}

SMap::~SMap()
{
	Release();
}

void SMap::Release()
{
	s_xMapSize = 0;
	s_zMapSize = 0;
	s_iPatchSize = 0;
	s_xPatchCount = 0;
	s_zPatchCount = 0;
	s_fScale = 0.0f;
	s_pD3DDevice = NULL;
	s_FileSystem.CloseFileSystem();

	for(SPatchMap_i it=m_PatchMap.begin();it!=m_PatchMap.end();++it) delete (*it).second;
	m_PatchMap.clear();
	m_xCurPatch = 0;
	m_zCurPatch = 0;
	m_xSrtPatch = 0;
	m_zSrtPatch = 0;
	m_xEndPatch = 0;
	m_zEndPatch = 0;
}

BOOL SMap::Create(const char* strPath,int iPatchSize,int xPatchCount,int zPatchCount,float fScale,LPDIRECT3DDEVICE9 pD3DDevice,BOOL bSavePatch)
{
	Release();

	if(!s_FileSystem.NewFileSystem(strPath) || !s_FileSystem.OpenFileSystem(strPath))
	{
		Release();
		return FALSE;
	}

	s_iPatchSize = iPatchSize;
	s_xPatchCount = xPatchCount;
	s_zPatchCount = zPatchCount;
	s_xMapSize = s_iPatchSize*s_xPatchCount;
	s_zMapSize = s_iPatchSize*s_zPatchCount;
	s_fScale = fScale;
	s_pD3DDevice = pD3DDevice;

	if(!SaveHeader())
	{
		Release();
		return FALSE;
	}

	if(bSavePatch)
	{
		for(int z=0;z<s_zPatchCount;z++)
		{
			for(int x=0;x<s_xPatchCount;x++)
			{
				if(!SavePatch(x,z))
				{
					Release();
					return FALSE;
				}
			}
		}
	}

	return TRUE;
}

BOOL SMap::Load(const char* strPath,LPDIRECT3DDEVICE9 pD3DDevice)
{
	Release();

	if(!s_FileSystem.OpenFileSystem(strPath))
	{
		Release();
		return FALSE;
	}
	
	SFileHandle* pFH = s_FileSystem.OpenFile("Header.map");
	if(!pFH)
	{
		Release();
		return FALSE;
	}

	pFH->Read(&s_iPatchSize,sizeof(int));
	pFH->Read(&s_xPatchCount,sizeof(int));
	pFH->Read(&s_zPatchCount,sizeof(int));
	s_xMapSize = s_iPatchSize*s_xPatchCount;
	s_zMapSize = s_iPatchSize*s_zPatchCount;
	pFH->Read(&s_fScale,sizeof(float));
	s_pD3DDevice = pD3DDevice;

	SMap::GetFileSystem()->CloseFile(pFH);

	return TRUE;
}

BOOL SMap::SaveHeader()
{
	BYTE* pData = new BYTE[HEADERFILESIZE];
	memcpy(pData,&s_iPatchSize,sizeof(int));
	int iPos = sizeof(int);
	memcpy(pData+iPos,&s_xPatchCount,sizeof(int));
	iPos += sizeof(int);
	memcpy(pData+iPos,&s_zPatchCount,sizeof(int));
	iPos += sizeof(int);
	memcpy(pData+iPos,&s_fScale,sizeof(float));

	s_FileSystem.Remove("Header.map");
	if(!s_FileSystem.AddFile("Header.map",pData,HEADERFILESIZE))
	{
		delete pData;
		return FALSE;
	}

	delete pData;

	return TRUE;
}

BOOL SMap::SavePatch(int xInx,int zInx)
{
	BYTE* pData = new BYTE[PATCHFILESIZE];
	
	SPatch* pPatch = GetPatch(xInx,zInx);
	if(!pPatch)
	{
		ZeroMemory(pData,PATCHFILESIZE);
	}
	else
	{
		memcpy(pData,pPatch->GetHeight(),PATCHFILESIZE);
	}

	char strPatch[_MAX_FNAME];
	GetPatchName(xInx,zInx,strPatch);

	s_FileSystem.Remove(strPatch);
	if(!s_FileSystem.AddFile(strPatch,pData,PATCHFILESIZE))
	{
		delete pData;
		return FALSE;
	}

	delete pData;

	return TRUE;
}

void SMap::Invalid()
{
	for(SPatchMap_i it=m_PatchMap.begin();it!=m_PatchMap.end();++it) (*it).second->ReleaseIVBuffer();
}

BOOL SMap::Restore()
{
	for(SPatchMap_i it=m_PatchMap.begin();it!=m_PatchMap.end();++it)
	{
		if(!(*it).second->CreateIVBuffer())
		{
			Release();
			return FALSE;
		}
	}

	return TRUE;
}

void SMap::Reset()
{
	static D3DXVECTOR3 s_vVec[8];

	SPatch::SetNextNode(0);
	SPatch::s_iTotalPoligon = 0;

	SPatch *pPatch,*pNeighbor;
	for(int z=m_zSrtPatch;z<=m_zEndPatch;z++)
	{
		for(int x=m_xSrtPatch;x<=m_xEndPatch;x++)
		{
			pPatch = GetPatch(x,z);
			if(!pPatch) continue;

			pPatch->Reset();

			s_vVec[0].x = s_vVec[4].x = x*s_iPatchSize*s_fScale;
			s_vVec[0].z = s_vVec[4].z = z*s_iPatchSize*s_fScale;
			s_vVec[1].x = s_vVec[5].x = (x+1)*s_iPatchSize*s_fScale;
			s_vVec[1].z = s_vVec[5].z = z*s_iPatchSize*s_fScale;
			s_vVec[2].x = s_vVec[6].x = x*s_iPatchSize*s_fScale;
			s_vVec[2].z = s_vVec[6].z = (z+1)*s_iPatchSize*s_fScale;
			s_vVec[3].x = s_vVec[7].x = (x+1)*s_iPatchSize*s_fScale;
			s_vVec[3].z = s_vVec[7].z = (z+1)*s_iPatchSize*s_fScale;
			s_vVec[0].y = s_vVec[1].y = s_vVec[2].y = s_vVec[3].y = pPatch->GetMinHeight();
			s_vVec[4].y = s_vVec[5].y = s_vVec[6].y = s_vVec[7].y = pPatch->GetMaxHeight();
			pPatch->SetVisible((SFrustum::Check(8,s_vVec) == CLIPPING)? FALSE : TRUE);

			if(pPatch->GetVisible())
			{
				pNeighbor = GetPatch(x-1,z);
				pPatch->GetLBase()->pLNeighbor = (!pNeighbor)? NULL : pNeighbor->GetRBase();

				pNeighbor = GetPatch(x+1,z);
				pPatch->GetRBase()->pLNeighbor = (!pNeighbor)? NULL : pNeighbor->GetLBase();

				pNeighbor = GetPatch(x,z-1);
				pPatch->GetLBase()->pRNeighbor = (!pNeighbor)? NULL : pNeighbor->GetRBase();

				pNeighbor = GetPatch(x,z+1);
				pPatch->GetRBase()->pRNeighbor = (!pNeighbor)? NULL : pNeighbor->GetLBase();
			}
		}
	}
}

void SMap::Build()
{
	Reset();

	for(SPatchMap_i it=m_PatchMap.begin();it!=m_PatchMap.end();++it)
	{
		if((*it).second->GetVisible()) (*it).second->Build();
	}
}

BOOL SMap::Update()
{
	m_xCurPatch = GetXPatchIndex(SCamera::GetEye()->x);
	m_zCurPatch = GetZPatchIndex(SCamera::GetEye()->z);
	m_xSrtPatch = max(0,m_xCurPatch-GetXPatchIndex(SCamera::GetFPlane()));
	m_zSrtPatch = max(0,m_zCurPatch-GetZPatchIndex(SCamera::GetFPlane()));
	m_xEndPatch = min(s_xPatchCount-1,m_xCurPatch+GetXPatchIndex(SCamera::GetFPlane()));
	m_zEndPatch = min(s_zPatchCount-1,m_zCurPatch+GetZPatchIndex(SCamera::GetFPlane()));

	SPatchMap_i mit;
	set<int> PatchSet;
	for(mit=m_PatchMap.begin();mit!=m_PatchMap.end();++mit) PatchSet.insert((*mit).first);

	int iPatchID;
	SPatch* pPatch;
	for(int z=m_zSrtPatch;z<=m_zEndPatch;z++)
	{
		for(int x=m_xSrtPatch;x<=m_xEndPatch;x++)
		{
			iPatchID = GetPatchID(x,z);
			if(PatchSet.find(iPatchID) != PatchSet.end())
			{
				PatchSet.erase(iPatchID);
			}
			else
			{
				pPatch = new SPatch;
				if(!pPatch->Load(x,z))
				{
					delete pPatch;
					return FALSE;
				}
				m_PatchMap.insert(SPatchMap_vt(iPatchID,pPatch));
			}
		}
	}

	for(set<int>::iterator sit=PatchSet.begin();sit!=PatchSet.end();++sit)
	{
		delete (*m_PatchMap.find(*sit)).second;
		m_PatchMap.erase(*sit);
	}

	return TRUE;
}

BOOL SMap::Render()
{
	if(!Update()) return FALSE;

	Build();

	s_pD3DDevice->SetStreamSource(0,NULL,0,sizeof(SVERTEX_PD));
	s_pD3DDevice->SetFVF(D3DFVF_PD);

	for(SPatchMap_i it=m_PatchMap.begin();it!=m_PatchMap.end();++it)
	{
		if((*it).second->GetVisible())
		{
			if(!(*it).second->Render()) return FALSE;
		}
	}

	return TRUE;
}

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
