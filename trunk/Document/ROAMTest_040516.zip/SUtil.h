#pragma once

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

#define BIG_FLOAT		1000000.0f

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

#define SDELETE(P)		{ if(P) { delete (P);     (P)=NULL; } }
#define SDELETEARRAY(P)	{ if(P) { delete[] (P);   (P)=NULL; } }
#define SRELEASE(P)		{ if(P) { (P)->Release(); (P)=NULL; } }

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

#define SSQUARE(X)							((X)*(X))
#define SVEC2LENGTH(X1,Y1,X2,Y2)			(sqrtf(SSQUARE((X1)-(X2))+SSQUARE((Y1)-(Y2))))
#define SVEC3LENGTH(X1,Y1,Z1,X2,Y2,Z2)		(sqrtf(SSQUARE((X1)-(X2))+SSQUARE((Y1)-(Y2))+SSQUARE((Z1)-(Z2))))
#define SVEC2LENGTHSQ(X1,Y1,X2,Y2)			((SSQUARE((X1)-(X2))+SSQUARE((Y1)-(Y2))))
#define SVEC3LENGTHSQ(X1,Y1,Z1,X2,Y2,Z2)	((SSQUARE((X1)-(X2))+SSQUARE((Y1)-(Y2))+SSQUARE((Z1)-(Z2))))

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

#define D3DFVF_PD		(D3DFVF_XYZ|D3DFVF_DIFFUSE)
#define D3DFVF_PT1		(D3DFVF_XYZ|D3DFVF_TEX1)
#define D3DFVF_PT2		(D3DFVF_XYZ|D3DFVF_TEX2)
#define D3DFVF_PDT1		(D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1)
#define D3DFVF_PDT2		(D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX2)
#define D3DFVF_PNT1		(D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1)
#define D3DFVF_PNT2		(D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX2)
#define D3DFVF_PNDT1	(D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX1)
#define D3DFVF_PNDT2	(D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX2)

typedef struct tagSVERTEX_PD
{
	D3DXVECTOR3 vPos;
	DWORD		dwDiffuse;

}SVERTEX_PD;

typedef struct tagSVERTEX_PT1
{
	D3DXVECTOR3 vPos;
	float		fU1,fV1;

}SVERTEX_PT1;

typedef struct tagSVERTEX_PT2
{
	D3DXVECTOR3 vPos;
	float		fU1,fV1;
	float		fU2,fV2;

}SVERTEX_PT2;

typedef struct tagSVERTEX_PDT1
{
	D3DXVECTOR3 vPos;
	DWORD		dwDiffuse;
	float		fU1,fV1;

}SVERTEX_PDT1;

typedef struct tagSVERTEX_PDT2
{
	D3DXVECTOR3 vPos;
	DWORD		dwDiffuse;
	float		fU1,fV1;
	float		fU2,fV2;

}SVERTEX_PDT2;

typedef struct tagSVERTEX_PNT1
{
	D3DXVECTOR3 vPos;
	D3DXVECTOR3	vNormal;
	float		fU1,fV1;

}SVERTEX_PNT1;

typedef struct tagSVERTEX_PNT2
{
	D3DXVECTOR3 vPos;
	D3DXVECTOR3	vNormal;
	float		fU1,fV1;
	float		fU2,fV2;

}SVERTEX_PNT2;

typedef struct tagSVERTEX_PNDT1
{
	D3DXVECTOR3 vPos;
	D3DXVECTOR3	vNormal;
	DWORD		dwDiffuse;
	float		fU1,fV1;

}SVERTEX_PNDT1;

typedef struct tagSVERTEX_PNDT2
{
	D3DXVECTOR3 vPos;
	D3DXVECTOR3	vNormal;
	DWORD		dwDiffuse;
	float		fU1,fV1;
	float		fU2,fV2;

}SVERTEX_PNDT2;

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
