Classes created:    
    CMyD3DApplication in .cpp
    Base Application: CD3DApplication in D3DApp.cpp
    Direct3D Settings: CD3DSettingsDialog in D3DSettings.cpp
    Direct3D Enumeration: CD3DEnumeration in D3DEnumeration.cpp
    3D Font Texture Support: CD3DFont in D3DFont.cpp
    Generic Direct3D Support in D3DUtil.cpp
    Generic DirectX Support in DXUtil.cpp
