#pragma once

#pragma warning(disable:4702)
#pragma warning(disable:4786)

#include <set>
#include <hash_map>
using namespace std;

#include <d3d9.h>
#include <d3dx9.h>
#include "SFileSystem.h"

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

#define POOL_SIZE 65536

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

typedef struct tagSTRINODE
{
	tagSTRINODE* pLChild;
	tagSTRINODE* pRChild;
	tagSTRINODE* pBNeighbor;
	tagSTRINODE* pLNeighbor;
	tagSTRINODE* pRNeighbor;

}STRINODE;

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

class SPatch
{
private:
	static int						s_iNextNode;
	static STRINODE					s_NodePool[POOL_SIZE];
	static float					s_fLODFactor;

public:
	static int						s_iTotalPoligon;

private:
	int								m_xWorld;
	int								m_zWorld;
	short*							m_pHeight;
	float							m_fMinHeight;
	float							m_fMaxHeight;
	WORD							m_wIndex;
	WORD*							m_pIndex;
	LPDIRECT3DINDEXBUFFER9			m_pIBuffer;
	LPDIRECT3DVERTEXBUFFER9			m_pVBuffer;

private:
	BOOL							m_bVisible;
	STRINODE						m_LBase;
	STRINODE						m_RBase;

public:
	inline static int  GetNextNode()		  { return s_iNextNode; }
	inline static void SetNextNode(int iNode) { s_iNextNode = iNode; }

private:
	inline static STRINODE* _AllocNode()
	{
		if(s_iNextNode >= POOL_SIZE) return NULL;

		STRINODE* pNode = &s_NodePool[s_iNextNode++];
		pNode->pLChild = pNode->pRChild = NULL;

		return pNode;
	}

public:
	SPatch();
	virtual ~SPatch();

public:
	inline short*	 GetHeight()			   { return m_pHeight; }
	inline STRINODE* GetLBase()				   { return &m_LBase; }
	inline STRINODE* GetRBase()				   { return &m_RBase; }
	inline float	 GetMinHeight()			   { return m_fMinHeight; }
	inline float	 GetMaxHeight()			   { return m_fMaxHeight; }
	inline BOOL		 GetVisible()			   { return m_bVisible; }
	inline void		 SetVisible(BOOL bVisible) { m_bVisible = bVisible; }

private:
	void _Split(STRINODE* pNode);
	void _Build(STRINODE* pNode,int xLeft,int zLeft,int xRight,int zRight,int xApex,int zApex,int iNode);
	void _Render(STRINODE* pNode,int xLeft,int zLeft,int xRight,int zRight,int xApex,int zApex);

public:
	void Release();
	BOOL Load(int xInx,int zInx);
	void ReleaseIVBuffer();
	BOOL CreateIVBuffer();

public:
	void Reset();
	void Build();
	BOOL Render();
	void CheckMinMaxHeight();
	D3DXVECTOR3 CheckNormal(int x,int z);
};

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

typedef stdext::hash_map<int,SPatch*>				SPatchMap;
typedef stdext::hash_map<int,SPatch*>::iterator		SPatchMap_i;
typedef stdext::hash_map<int,SPatch*>::value_type	SPatchMap_vt;

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

class SMap
{
private:
	static int						s_xMapSize;
	static int						s_zMapSize;
	static int						s_iPatchSize;
	static int						s_xPatchCount;
	static int						s_zPatchCount;
	static float					s_fScale;
	static LPDIRECT3DDEVICE9		s_pD3DDevice;
	static SFileSystem				s_FileSystem;

private:
	SPatchMap						m_PatchMap;
	int								m_xCurPatch;
	int								m_zCurPatch;
	int								m_xSrtPatch;
	int								m_zSrtPatch;
	int								m_xEndPatch;
	int								m_zEndPatch;

public:
	static inline int				GetXMapSize()	 { return s_xMapSize; }
	static inline int				GetZMapSize()	 { return s_zMapSize; }
	static inline int				GetPatchSize()	 { return s_iPatchSize; }
	static inline int				GetXPatchCount() { return s_xPatchCount; }
	static inline int				GetZPatchCount() { return s_zPatchCount; }
	static inline float				GetScale()		 { return s_fScale; }
	static inline LPDIRECT3DDEVICE9 GetD3DDevice()	 { return s_pD3DDevice; }
	static inline SFileSystem*		GetFileSystem()	 { return &s_FileSystem; }

public:
	static inline int GetPatchID(int xInx,int zInx)
	{
		return xInx*10000+zInx;
	}
	static inline void GetPatchName(int xInx,int zInx,char* strName)
	{
		wsprintf(strName,"%d.map",GetPatchID(xInx,zInx));
	}
	static inline int GetXPatchIndex(float fPos)
	{
		return max(0,min(s_xPatchCount-1,(int)(fPos/(s_iPatchSize*s_fScale))));
	}
	static inline int GetZPatchIndex(float fPos)
	{
		return max(0,min(s_zPatchCount-1,(int)(fPos/(s_iPatchSize*s_fScale))));
	}

public:
	SMap();
	virtual ~SMap();

public:
	inline SPatchMap* GetPatchMap()	 { return &m_PatchMap; }
	inline int		  GetXCurPatch() { return m_xCurPatch; }
	inline int		  GetZCurPatch() { return m_zCurPatch; }
	inline int		  GetXSrtPatch() { return m_xSrtPatch; }
	inline int		  GetZSrtPatch() { return m_zSrtPatch; }
	inline int		  GetXEndPatch() { return m_xEndPatch; }
	inline int		  GetZEndPatch() { return m_zEndPatch; }

public:
	inline SPatch* GetPatch(int xInx,int zInx)
	{
		SPatchMap_i it = m_PatchMap.find(GetPatchID(xInx,zInx));
		if(it != m_PatchMap.end()) return (*it).second;

		return NULL;
	}

public:
	void Release();
	BOOL Create(const char* strPath,int iPatchSize,int xPatchCount,int zPatchCount,float fScale,LPDIRECT3DDEVICE9 pD3DDevice,BOOL bSavePatch=TRUE);
	BOOL Load(const char* strPath,LPDIRECT3DDEVICE9 pD3DDevice);
	BOOL SaveHeader();
	BOOL SavePatch(int xInx,int zInx);
	void Invalid();
	BOOL Restore();

public:
	void Reset();
	void Build();
	BOOL Update();
	BOOL Render();
};

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
