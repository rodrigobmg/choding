#pragma once

#include <d3d9.h>
#include <d3dx9.h>

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

enum CLIPTYPE {CLIPPING,SOMECLIPPING,NOCLIPPING};

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

class SFrustum
{
private:
	static D3DXVECTOR3	s_vVtx[8];
	static D3DXPLANE	s_Plane[6];

public:
	static BOOL Update(D3DXMATRIX* pView,D3DXMATRIX* pProj);

public:
	inline static CLIPTYPE Check(D3DXVECTOR3* pVec,float fRadius)
	{
		if(!pVec) return CLIPPING;

		for(int i=0;i<6;i++)
		{
			if(D3DXPlaneDotCoord(&s_Plane[i],pVec) > fRadius) return CLIPPING;
		}

		return NOCLIPPING;
	}
	inline static CLIPTYPE Check(int iCount,D3DXVECTOR3* pV)
	{
		int i,j;
		for(i=0;i<iCount;i++)
		{
			if(!pV[i]) return CLIPPING;
		}

		char c1,c2 = 0;
		for(i=0;i<6;i++)
		{
			c1 = 0;
			for(j=0;j<iCount;j++)
			{
				if(D3DXPlaneDotCoord(&s_Plane[i],&pV[j]) <= 0) c1++;
			}

			if(c1 == iCount) c2++;
			else if(!c1) return CLIPPING;
		}

		return (c2 == 6)? NOCLIPPING : SOMECLIPPING;
	}
};

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
