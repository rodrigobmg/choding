//-----------------------------------------------------------------------------
// File: ROAMTest.h
//
// Desc: Header file ROAMTest sample app
//-----------------------------------------------------------------------------
#pragma once

#include "SMap.h"

//-----------------------------------------------------------------------------
// Defines, and constants
//-----------------------------------------------------------------------------
// TODO: change "DirectX AppWizard Apps" to your name or the company name
#define DXAPP_KEY        TEXT("Software\\DirectX AppWizard Apps\\ROAMTest")

// Struct to store the current input state
struct UserInput
{
    // TODO: change as needed
    BOOL bUp;
    BOOL bDown;
    BOOL bLeft;
    BOOL bRight;
	BOOL bPageUp;
	BOOL bPageDown;
	BOOL bHome;
	BOOL bEnd;
	BOOL bF5;
};

//-----------------------------------------------------------------------------
// Name: class CMyD3DApplication
// Desc: Application class. The base class (CD3DApplication) provides the 
//       generic functionality needed in all Direct3D samples. CMyD3DApplication 
//       adds functionality specific to this sample program.
//-----------------------------------------------------------------------------
class CMyD3DApplication : public CD3DApplication
{
    BOOL                    m_bLoadingApp;          // TRUE, if the app is loading
    CD3DFont*               m_pFont;                // Font for drawing text
    UserInput               m_UserInput;            // Struct for storing user input 

	SMap					m_Map;
	LPDIRECT3DTEXTURE9		m_pTexture;
	BOOL					m_bWireFrame;

protected:
    virtual HRESULT OneTimeSceneInit();
    virtual HRESULT InitDeviceObjects();
    virtual HRESULT RestoreDeviceObjects();
    virtual HRESULT InvalidateDeviceObjects();
    virtual HRESULT DeleteDeviceObjects();
    virtual HRESULT Render();
    virtual HRESULT FrameMove();
    virtual HRESULT FinalCleanup();
    virtual HRESULT ConfirmDevice( D3DCAPS9*, DWORD, D3DFORMAT );

    HRESULT RenderText();

    void    UpdateInput( UserInput* pUserInput );
public:
    LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
    CMyD3DApplication();
    virtual ~CMyD3DApplication();
};
