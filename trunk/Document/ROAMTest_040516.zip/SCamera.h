#pragma once

#include <d3d9.h>
#include <d3dx9.h>

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

class SCamera
{
protected:
	static float		s_fFOV;
	static float		s_fAspect;
	static float		s_fNPlane;
	static float		s_fFPlane;
	static D3DXVECTOR3	s_vEye;
	static D3DXVECTOR3	s_vLookat;
	static D3DXVECTOR3	s_vUp;
	static D3DXVECTOR3	s_vDir;
	static D3DXVECTOR3	s_vCross;
	static D3DXMATRIX	s_matProj;
	static D3DXMATRIX	s_matView;
	static D3DXMATRIX	s_matBillboard;

public:
	inline static float		   GetNPlane()			{ return s_fNPlane; }
	inline static float		   GetFPlane()			{ return s_fFPlane; }
	inline static D3DXVECTOR3* GetEye()				{ return &s_vEye; }
	inline static D3DXVECTOR3* GetLookat()			{ return &s_vLookat; }
	inline static D3DXVECTOR3* GetUp()				{ return &s_vUp; }
	inline static D3DXVECTOR3* GetDir()				{ return &s_vDir; }
	inline static D3DXVECTOR3* GetCross()			{ return &s_vCross; }
	inline static D3DXMATRIX*  GetProjMatrix()		{ return &s_matProj; }
	inline static D3DXMATRIX*  GetViewMatrix()		{ return &s_matView; }
	inline static D3DXMATRIX*  GetBillboardMatrix() { return &s_matBillboard; }

public:
	static void RotateXAxis(float angle);
	static void RotateYAxis(float angle);
	static void RotateZAxis(float angle);
	static void RotateCAxis(float angle);
	static void RotateUAxis(float angle);
	static void RotateDAxis(float angle);
	static void TranslateXAxis(float distance);
	static void TranslateYAxis(float distance);
	static void TranslateZAxis(float distance);
	static void TranslateCAxis(float distance);
	static void TranslateUAxis(float distance);
	static void TranslateDAxis(float distance);
	static void SetProjParams(float fFOV,float fAspect,float fNPlane,float fFPlane);
	static void SetViewParams(D3DXVECTOR3* pEye,D3DXVECTOR3* pLookat,D3DXVECTOR3* pUp);
};

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
