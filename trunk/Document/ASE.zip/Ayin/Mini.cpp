#include "_Stdafx.h"
#include "define.h"
#include "Mini.h"



CMini::CMini()
{	
	m_lpMiniTex = NULL;
	m_lpVB = NULL;
	m_iNum = 0;
}

CMini::~CMini()
{

}

void CMini::ShutDown()
{
	for(int i=0; i < m_iNum; i++)
		SAFE_RELEASE(m_lpMiniTex[i]);


	SAFE_RELEASE(m_lpVB);
}


HRESULT CMini::InitMini(LPDIRECT3DDEVICE9 lpDevice, LPCSTR filename)
{
	m_lpDevice = lpDevice;
	
	FILE *fp = fopen("./DataInfo/MiniMap.txt", "r");
		
	if(fp == NULL)
		return E_FAIL;

	char chLine[256];
	char chString[80];
	int  cNum = 0;

	while(!feof(fp))
	{

		fgets(chLine, 256,fp);
		sscanf(chLine, "%s", chString);

		if(_stricmp(chString , "*") == 0)
			continue;
		else if(_stricmp(chString, "MAXNUM") == 0)
		{	
			//�ؽ��� ������ŭ �ؽ��ĸ� �������� �Ҵ��Ѵ�.
			sscanf(chLine, "%s %d", chString, &m_iNum);
			m_lpMiniTex = new LPDIRECT3DTEXTURE9[m_iNum];
			continue;
		}
 

		if(FAILED(D3DXCreateTextureFromFile(m_lpDevice, chString , & m_lpMiniTex[cNum++])))	
			return E_FAIL;

	}
	
	fclose(fp);
	InitVB();

	return S_OK;
}


HRESULT CMini::InitVB()
{

	float fSize = 13.0f;
	/// �ﰢ���� �������ϱ����� ������ ������ ����
	MiniVERTEX MiniVB[] =
	{
		{ -fSize, 0.0f,  fSize, 0.0f, 0.0f,},
		{  fSize, 0.0f,  fSize, 1.0f, 0.0f,},
		{ -fSize, 0.0f, -fSize, 0.0f, 1.0f,},
		{  fSize, 0.0f, -fSize, 1.0f, 1.0f,},
	};

	/// �������� ����
	if( FAILED( m_lpDevice->CreateVertexBuffer( 4*sizeof(MiniVERTEX),
		0, MiniVERTEX::FVF,
		D3DPOOL_DEFAULT, &m_lpVB, NULL ) ) )
	{
		return E_FAIL;
	}

	/// �������۸� ������ ä���. 
	VOID* pVertices;
	if( FAILED( m_lpVB->Lock( 0, sizeof(MiniVB), (void**)&pVertices, 0 ) ) )
		return E_FAIL;
	memcpy( pVertices, MiniVB, sizeof(MiniVB) );
	m_lpVB->Unlock();
	

	return S_OK;
}

void CMini::Render(D3DXVECTOR3 *vPos, MINIMAPTEXTURE iNumber)
{

	if(-1 == iNumber || m_lpVB == NULL)
		return;

//	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
//	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
//	m_lpDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
//	m_lpDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);


	D3DXMATRIXA16 matWorld;
	D3DXMatrixIdentity(&matWorld);
	D3DXMatrixTranslation(&matWorld, vPos->x, vPos->y, vPos->z);
	
	m_lpDevice->SetTexture(0, m_lpMiniTex[iNumber]);
	m_lpDevice->SetTransform(D3DTS_WORLD, &matWorld);
	m_lpDevice->SetStreamSource( 0, m_lpVB, 0, sizeof(MiniVERTEX) );
	m_lpDevice->SetFVF( MiniVERTEX::FVF );
	m_lpDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, 0, 2 );


//	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
//	m_lpDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_DISABLE);

	m_lpDevice->SetTexture(0, NULL);

}


void CMini::PreOption()
{



	m_lpDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_lpDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_lpDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);

}

void CMini::PostOption()
{

	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTOP_DISABLE);

	m_lpDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
}













