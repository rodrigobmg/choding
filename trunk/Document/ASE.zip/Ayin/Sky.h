
// ��ī�̵� ����ü
#pragma once


#include "define.h"

class CStage;

class CSky
{
private:

	/*
	// ��ī�̵� �ð��� �㳷��ȭ ����ü
	struct SkyDomeTime{
		int Minute, Hour, seconds;
		D3DXCOLOR Fog;
		float Weight;
	};
*/

	ID3DXMesh* m_Sphere;
	float m_fRadius;
	IDirect3DCubeTexture9* m_pEnvMap;
	LPDIRECT3DTEXTURE9 m_lpCloudTex;
	LPDIRECT3DTEXTURE9 m_lpCloudTex2;

	LPDIRECT3DDEVICE9 m_lpDeviece;

	D3DXVECTOR4		  m_uvScaleOffset;
	float	m_fColor;
	int     m_iFlag;
	int  	m_iChange;


	LPD3DXEFFECT m_skyFX;
	D3DXHANDLE   m_hTech;
	D3DXHANDLE   m_hEnvMap;
	D3DXHANDLE   m_hCloudMap;
	D3DXHANDLE   m_hCloudMap2;
	D3DXHANDLE   m_hWVP;

	// Sky always centered about camera's position.
	D3DXMATRIX	m_VP;
	D3DXMATRIX  m_W;
	D3DXMATRIX  m_S;
	D3DXVECTOR3 m_p;


	// �ð�����
	D3DXVECTOR4  m_vDiffuse[6];
	D3DXCOLOR    m_cFog[6];
	DWORD        m_dwTime;
	D3DXVECTOR4	 m_vSkyDiffuse; 	

	SkyDomeTime  m_sdt;
	int m_iAngle;

	CStage      *m_stage;

public:
	CSky();
	~CSky();

	float Linear(float v0, float v1, float t)
	{

		//return v0 + (1.0f - t) * v1 * t;
		return v0 + (v1 - v0)*t;

	}
	
	void SkyInit(char *envmapFilename, char* cloudeFilename, float skyRadius, LPDIRECT3DDEVICE9 device);

	IDirect3DCubeTexture9* GetEnvMap();
	float GetRadius();

	DWORD GetNumTriangles();
	DWORD GetNumVertices();

	void OnLostDevice();
	void OnResetDevice();

	void Draw(D3DXPLANE* reflectedW);
	void SkyUpdate(D3DXVECTOR3 pcamera, D3DXMATRIX VP, int elapsed);
	void Variation(int elapsed);

	
	SkyDomeTime* GetTime(){return &m_sdt;}
 	



	
};

