// Camera.h: interface for the CCamera class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CAMERA_H__16DAE17F_6B89_441A_94D5_AE2DAA6E4639__INCLUDED_)
#define AFX_CAMERA_H__16DAE17F_6B89_441A_94D5_AE2DAA6E4639__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CCamera
{
protected:
	LPDIRECT3DDEVICE9		H_pd3dDevice;              

	D3DXMATRIXA16	m_matView;
	D3DXMATRIXA16	m_matInvView; 
	D3DXMATRIXA16	m_matProjection;
	D3DXMATRIX      m_matVP;

	D3DXVECTOR3		m_vLook;	
	D3DXVECTOR3		m_vDir;
	//D3DXVECTOR3		m_vEye;

	float			m_fZoom;            // Zoom
	float			m_fYaw;             // Y
	float			m_fPitch;			// Z 


	D3DXVECTOR3		m_vUp;			/// ī�޶��� ��溤��
	D3DXVECTOR3		m_vView;		/// ī�޶� ���ϴ� �������⺤��
	D3DXVECTOR3		m_vCross;		/// ī������ ���麤�� cross( view, up )


	float			m_fFov;
	DWORD			m_dWidth;
	DWORD			m_dHeight;
	float			m_fNear;
	float			m_fFar;

public:
	D3DXVECTOR3		m_vEye;
	CCamera();
	virtual ~CCamera();
	void SetCamera();
	D3DXMATRIXA16* GetCamera() { return &m_matView; }

	void		 Init( LPDIRECT3DDEVICE9 _pd3dDevice ) {  H_pd3dDevice = _pd3dDevice; }

	// Init 
	virtual void SetView( D3DXVECTOR3 &vLook, float Zoom, float Yaw, float Pitch );
	D3DXVECTOR3* GetCameraLookAt() { return &m_vLook; }
	D3DXVECTOR3* GetCameraEye() { return &m_vEye; }
	D3DXVECTOR3* GetCameraDir() { return &m_vDir; }

	///////////////////////////////////////////////////////////////////////////
	virtual void SetLookAt(D3DXVECTOR3 &vLook, float y = 7.0f );
	virtual void SetZoom( float Zoom );
	virtual void SetYaw( float Yaw ); 
	virtual void SetPitch( float Pitch ); 
	float GetZoom() { return m_fZoom; }
	float GetYaw() { return m_fYaw; }
	float GetPitch() { return m_fPitch; }
 
	D3DXVECTOR3 GetEye() { return m_vEye; }
	
	FLOAT GetXPos(){return m_vEye.x;}
	FLOAT GetYPos(){return m_vEye.y;}
	FLOAT GetZPos(){return m_vEye.z;}


	D3DXVECTOR3 GetDir() { return m_vDir; }
	D3DXVECTOR3 GetLook() { return m_vLook; }
	///////////////////////////////////////////////////////////////////////////	

	virtual void SetProjection(DWORD Width, DWORD Height, float Near, float Far);
	virtual void SetProjectionFOV( float Fov );
	virtual void SetProjectionFar( float Far );
	virtual void SetProjectionNear( float Near );
	virtual void SetProjectionHeight( DWORD Height );
	virtual void SetProjectionWidth( DWORD Width );
	DWORD GetProjectionWidth() { return m_dWidth; }
	DWORD GetProjectionHeight() { return m_dHeight; }
	float GetProjectionNear() { return m_fNear; }
	float GetProjectionFar() { return m_fFar; }
	float GetProjectionFOV() { return m_fFov; }
	///////////////////////////////////////////////////////////////////////////

	D3DXMATRIXA16*	GetView()		{ return &m_matView; }
	D3DXMATRIXA16*	GetInvView()	{ return &m_matInvView; }
	D3DXMATRIXA16*	GetProjection()	{ return &m_matProjection; }

	D3DXMATRIX*		GetViewProj()	{m_matVP = m_matView*m_matProjection;
									return &m_matVP;}
	
	///////////////////////////////////////////////////////////////////////////
	/// ī�޶� ��ǥ���� X��������� dist��ŭ �����Ѵ�.(������ -dist�� ������ �ȴ�.)
	void	MoveLocalX( float dist );

	/// ī�޶� ��ǥ���� Y��������� dist��ŭ �����Ѵ�.(������ -dist�� ������ �ȴ�.)
	void	MoveLocalY( float dist );

	/// ī�޶� ��ǥ���� Z��������� dist��ŭ �����Ѵ�.(������ -dist�� ������ �ȴ�.)
	void	MoveLocalZ( float dist );
	/// ������ǥ���� *pv���� ��ġ�� �̵��Ѵ�.
	void	MoveTo( D3DXVECTOR3* pv );

	void    RotateLocalX( float angle );
	void	RotateLocalY( float angle );
};

#endif 
