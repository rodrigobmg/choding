#pragma once

class CSprite
{
public:
	bool LoadTexture(LPDIRECT3DDEVICE9 pd3dDevice, LPD3DXSPRITE pSprite, const char *szFilename, DWORD Transparent = 0);
	void Shutdown();

	void Draw(int DestX, int DestY, int SrcX, int SrcY, int SrcWidth, int SrcHeight, DWORD Color = 0xFFFFFFFF);

	CSprite();
	~CSprite();

private:
	LPD3DXSPRITE m_pSprite;
	IDirect3DTexture9 *m_pTexture;
};