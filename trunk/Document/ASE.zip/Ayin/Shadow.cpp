#include "_Stdafx.h"
#include "DrawTex2D.h"
#include "Mesh.h"
#include "Frustum.h"
#include "TerrainManager.h"
#include "Ase.h"
#include "AseManager.h"
#include "Stage.h"
#include "Shadow.h"

CShadow::CShadow()
{
	m_lpDevice = NULL;
	m_shadowTex = NULL;
	m_FX = NULL;
	D3DXMatrixIdentity(&m_view);
	D3DXMatrixIdentity(&m_Proj);
}

CShadow::~CShadow()
{
	 

}

void CShadow::ShutDown()
{

//	D3DXSaveTextureToFile( "Image/Shadow.bmp", D3DXIFF_BMP, m_shadowTex->GetD3dTex(), NULL );

	if(m_shadowTex != NULL)
	{
		m_shadowTex->ShutDown();
		delete m_shadowTex;
	}

	SAFE_RELEASE(m_FX);
}

HRESULT CShadow::InitShadow(LPDIRECT3DDEVICE9 lpDevice)
{

	m_lpDevice = lpDevice;

	if(m_lpDevice == NULL)
		return E_FAIL;


	D3DVIEWPORT9 vp = {0, 0, 1024, 1024, 0.0f, 1.0f};
	m_shadowTex = new CDrawTex2D(1024, 1024, 0, D3DFMT_X8R8G8B8, true, D3DFMT_D24X8, vp);

	m_shadowTex->InitTaget(m_lpDevice);
	
	// ������������ �ؽ�ó�������� ��ȯ(������ǥ�� �ؽ�ó��ǥ�� ��ȯ)
	 m_T = D3DXMATRIX( 0.5f, 0.0f, 0.0f, 0.0f,
					   0.0f, -0.5f, 0.0f, 0.0f,
					   0.0f, 0.0f, 1.0f, 0.0f,
					   0.5f, 0.5f, 0.0f, 1.0f);

	 BuildFX();

	
	 m_stage = CStage::GetInstance();

	return S_OK;
}

void CShadow::BuildFX()
{
	LPD3DXBUFFER errors = NULL;
	D3DXCreateEffectFromFile(m_lpDevice, "./Fx/map.fx", 0, 0, D3DXSHADER_DEBUG, 0, &m_FX, &errors);

	if(errors)
		MessageBoxA(0, (char*)errors->GetBufferPointer(), 0, 0);

	m_hMatWorldViewProj = m_FX->GetTechniqueByName("matWorldViewProj");
	m_hWVPT = m_FX->GetTechniqueByName("m_hWVPT");
	m_hIdMap = m_FX->GetTechniqueByName("IdMap");

	SAFE_RELEASE(errors);

}


void CShadow::Update(float cameraX, float cameraY, float cameraZ)
{
	//ī�޶� �����϶����� ������Ʈ. �׸��ڴ� ī�޶� �߽����� �ؼ� �׷�����.
	m_vShadowLookAt = D3DXVECTOR3(cameraX, cameraY, cameraZ);
	m_vShadowEye = m_vShadowLookAt + D3DXVECTOR3(50.0f, 200.0f, 50.0f);
	D3DXMatrixLookAtLH(&m_view, &m_vShadowEye, &m_vShadowLookAt, &D3DXVECTOR3(0.0f, 1.0f, 0.0f));
	m_lpDevice->GetTransform(D3DTS_PROJECTION, &m_Proj);

	//���� Effect�� ���� �־��ش�.
	m_FX->SetMatrix("mWVPT", &(m_view*m_Proj*m_T));
	m_FX->SetTexture("IdMap", m_shadowTex->GetD3dTex());

}

void CShadow::ShadowRender(CSMeshManager *meshManager, CTerrainManager *terrainManager,CSMeshManager *shaderMeshManager,
						   CAseManager *aseManager,CAseManager *aseBoss, CSMeshManager *shaderNPCMesh, D3DXMATRIXA16* getView, int elapsed)
{
	shaderMeshManager->GetEffect()->SetMatrix("matWorldViewProj", &(m_view*m_Proj));

	m_shadowTex->SaveOldTaget();
	m_shadowTex->BeginScene();
	

	//�׸��� �� Ŭ����
	m_lpDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);
	m_lpDevice->Clear(0L, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0xFF000000, 1.0f, 0L);
	m_lpDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_lpDevice->SetRenderState(D3DRS_ZENABLE, D3DZB_FALSE);
	m_lpDevice->SetTexture(0, NULL);

	//���� ���� ���� ��ο� ����.
	m_lpDevice->SetRenderState(D3DRS_TEXTUREFACTOR, D3DCOLOR_ARGB(255, 255, 255, 255));
	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TFACTOR);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
	m_lpDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );	// 0�� �ؽ�ó ���������� Ȯ�� ����
	

	//������� �������ش�.
	m_lpDevice->SetTransform(D3DTS_VIEW, &m_view);


	//���� ������Ʈ ������
	for(int i=0; i < terrainManager->GetMapNum(); i++)
	{
		if(terrainManager->GetCheck()[i] == TRUE)
		{
			meshManager->ShadowMeshRender(i);
		}
	}
		
	m_stage = CStage::GetInstance();

	if(m_stage->GetStage() == 1.3f)
	{
		//���̴� �̿� ���� ������Ʈ ������
		for(int i=0; i < terrainManager->GetMapNum(); i++)
		{
			if(terrainManager->GetCheck()[i] == TRUE)
				shaderMeshManager->RenderShaderMesh(i);
		}
	}


	//���̴� NPC ������Ʈ ����
	for(int i=0; i < terrainManager->GetMapNum(); i++)
		if(terrainManager->GetCheck()[i] == TRUE)
			shaderNPCMesh->RenderShaderMesh(i);	

	aseManager->RenderShadowModel();

	if(m_stage->GetStage() >= 6.0f && m_stage->GetStage() < 7.0f)
		aseManager->RenderShadowStage2(elapsed);

	
	if(m_stage->GetStage() == 11.0f)
	aseBoss->RenderShadowStage2(elapsed);


	m_lpDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_lpDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	m_lpDevice->SetRenderState(D3DRS_ZENABLE, D3DZB_TRUE);
	m_lpDevice->SetRenderState(D3DRS_FOGENABLE, FOGENABLE);
	m_lpDevice->SetTexture(0, NULL);

	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTOP_DISABLE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTOP_DISABLE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_DISABLE);

	//m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	//m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	//m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
	//m_lpDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	//m_lpDevice->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	//m_lpDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);

	// ��� �������ǵ� ����
	m_lpDevice->SetTransform(D3DTS_VIEW, getView);

	m_shadowTex->EndScene();
}


