#include "_Stdafx.h"
#include "Sprite.h"

bool CSprite::LoadTexture(LPDIRECT3DDEVICE9 pd3dDevice, LPD3DXSPRITE pSprite, const char *szFilename, DWORD Transparent)
{
	if ((m_pSprite = pSprite) == NULL)
		return false;

	if(FAILED(D3DXCreateTextureFromFileEx(pd3dDevice,
		szFilename, D3DX_DEFAULT, D3DX_DEFAULT, 1,
		0, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, 
		D3DX_FILTER_NONE, D3DX_FILTER_NONE, Transparent, NULL, NULL, &m_pTexture)))
		return false;


	return true;
}

void CSprite::Shutdown()
{
	SAFE_RELEASE(m_pTexture);
}

void CSprite::Draw(int DestX, int DestY, int SrcX, int SrcY, int SrcWidth, int SrcHeight, DWORD Color)
{
	if(m_pTexture == NULL)
		return;

	RECT Rect;
	Rect.left = SrcX;
	Rect.top  = SrcY;
	Rect.right = Rect.left + SrcWidth;
	Rect.bottom = Rect.top + SrcHeight;
 
	m_pSprite->Draw(m_pTexture, &Rect, &D3DXVECTOR3((float)0.0f, (float)0.0f, (float)0.0f),
		&D3DXVECTOR3((float)DestX, (float)DestY, (float)0.0f), Color);
}

CSprite::CSprite()
{
	m_pSprite = NULL;
	m_pTexture = NULL;
}

CSprite::~CSprite()
{
	Shutdown();
}