#include "_Stdafx.h"
#include "DrawTex2D.h"
#include "water.h"

IDirect3DVertexDeclaration9* VertexPT::Decl  = 0;


CWater::CWater(InitInfo& initInfo, LPDIRECT3DDEVICE9 device):m_Reflect(NULL), m_Refract(NULL),m_FX(NULL),m_Mesh(NULL)
{
	m_Reflect = NULL;
	m_Refract = NULL;

	m_device = device;

	m_InitInfo = initInfo;

	m_fWidth = (initInfo.vertCols-1)*initInfo.dx;
	m_fDepth = (initInfo.vertRows-1)*initInfo.dz;

	m_WaveMapOffset0 = D3DXVECTOR2(2.0f, 0.0f);
	m_WaveMapOffset1 = D3DXVECTOR2(2.0f, 0.0f);


	DWORD numTris  = (initInfo.vertRows-1)*(initInfo.vertCols-1)*2;
	DWORD numVerts = initInfo.vertRows*initInfo.vertCols;

	//===============================================================
	// Allocate the mesh.

	D3DVERTEXELEMENT9 VertexPTElements[] = 
	{
		{0, 0,  D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
		{0, 12, D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},
		D3DDECL_END()
	};	
	m_device->CreateVertexDeclaration(VertexPTElements, &VertexPT::Decl);

	D3DVERTEXELEMENT9 elems[MAX_FVF_DECL_SIZE];
	UINT numElems = 0;
	VertexPT::Decl->GetDeclaration(elems, &numElems);


	D3DXCreateMesh(numTris, numVerts, 
		D3DXMESH_MANAGED, elems, m_device, &m_Mesh);

	//===============================================================
	// Write the grid vertices and triangles to the mesh.

	VertexPT* v = 0;
	m_Mesh->LockVertexBuffer(0, (void**)&v);

	std::vector<D3DXVECTOR3> verts;
	std::vector<DWORD> indices;


	GenTriGrid(m_InitInfo.vertRows, m_InitInfo.vertCols, m_InitInfo.dx, 
		m_InitInfo.dz, D3DXVECTOR3(0.0f, 0.0f, 0.0f), verts, indices);


	for(int i = 0; i < m_InitInfo.vertRows; ++i)
	{
		for(int j = 0; j < m_InitInfo.vertCols; ++j)
		{
			DWORD index   = i * m_InitInfo.vertCols + j;
			v[index].pos  = verts[index];
			v[index].tex0 = D3DXVECTOR2((float)j/m_InitInfo.vertCols, 
				(float)i/m_InitInfo.vertRows)
				* initInfo.texScale;
		}
	}
	m_Mesh->UnlockVertexBuffer();

	//===============================================================
	// Write triangle data so we can compute normals.

	WORD* indexBuffPtr = 0;
	m_Mesh->LockIndexBuffer(0, (void**)&indexBuffPtr);
	DWORD* attBuff = 0;
	m_Mesh->LockAttributeBuffer(0, &attBuff);
	for(UINT i = 0; i < m_Mesh->GetNumFaces(); ++i)
	{
		indexBuffPtr[i*3+0] = (WORD)indices[i*3+0];
		indexBuffPtr[i*3+1] = (WORD)indices[i*3+1];
		indexBuffPtr[i*3+2] = (WORD)indices[i*3+2];

		attBuff[i] = 0; // All in subset 0.
	}
	m_Mesh->UnlockIndexBuffer();
	m_Mesh->UnlockAttributeBuffer();
 
	//===============================================================
	// Optimize for the vertex cache and build attribute table.

	const float EPSILON = 0.0001f;

	DWORD* adj = new DWORD[m_Mesh->GetNumFaces()*3];
	m_Mesh->GenerateAdjacency(EPSILON, adj);
	m_Mesh->OptimizeInplace(D3DXMESHOPT_VERTEXCACHE|D3DXMESHOPT_ATTRSORT,
		adj, 0, 0, 0);
	delete[] adj;


	//===============================================================
	// Create textures/effect.

	D3DXCreateTextureFromFile(m_device, "./Image/Water/wave0.dds",  &m_pWaveMap0);
	D3DXCreateTextureFromFile(m_device, "./Image/Water/wave1.dds",  &m_pWaveMap1);


					 //x  y  width height minz  maxz
	D3DVIEWPORT9 vp = {0, 0, 1024, 768, 0.0f, 1.0f};
	m_Refract = new CDrawTex2D(128, 128, 0, D3DFMT_X8R8G8B8, true, D3DFMT_D24X8, vp);
	m_Reflect = new CDrawTex2D(128, 128, 0, D3DFMT_X8R8G8B8, true, D3DFMT_D24X8, vp);


	BuildFX();

}

CWater::~CWater()
{
}


DWORD CWater::GetNumTringles()
{
	return m_Mesh->GetNumFaces();
}


DWORD CWater::GetNumVertices()
{
	return m_Mesh->GetNumVertices();
}

void CWater::ShutDown()
{

//	D3DXSaveTextureToFile( "Image/refract.bmp", D3DXIFF_BMP, m_Refract->GetD3dTex(), NULL );
//	D3DXSaveTextureToFile( "Image/reflect.bmp", D3DXIFF_BMP, m_Reflect->GetD3dTex(), NULL );

	m_FX->OnLostDevice();

	m_Reflect->ShutDown();
	m_Refract->ShutDown();

	SAFE_RELEASE(m_Mesh);
	SAFE_RELEASE(m_FX);
	SAFE_RELEASE(m_pWaveMap0);
	SAFE_RELEASE(m_pWaveMap1);
	delete m_Refract;
	delete m_Reflect;
}

void CWater::InitWater()
{
	m_FX->OnResetDevice();
	m_Reflect->InitTaget(m_device);
	m_Refract->InitTaget(m_device);
}

void CWater::Update(float dt)
{
	m_WaveMapOffset0 += m_InitInfo.waveMapVelocity0 * dt;
	m_WaveMapOffset1 += m_InitInfo.waveMapVelocity1 * dt;
}

void CWater::Draw(D3DXVECTOR3 *cameraPos, D3DXMATRIX *vp)
{
/*
	D3DXMATRIXA16 matView;
	m_device->GetTransform(D3DTS_VIEW, &matView);

	D3DXMatrixTranspose(&matView, &matView);
	matView._41 = matView._42 = matView._43 = matView._14 = matView._24 = matView._34 = 0.0f;

	D3DXMATRIXA16 matTrans;
	D3DXMATRIXA16 matRotate;

	D3DXMatrixTranslation(&matTrans, cameraPos->x, cameraPos->y+10.0f, cameraPos->z-3);
	D3DXMatrixRotationX(&matRotate, -D3DX_PI/2);
	D3DXMatrixMultiply(&matRotate, &matRotate, &matView);

	D3DXMatrixMultiply(&matRotate, &matRotate, &matTrans);
*/
	m_FX->SetMatrix(m_hWVP, &((m_InitInfo.toWorld * (*vp))));
//	m_FX->SetMatrix(m_hWVP, &((matRotate * (*vp))));
	m_FX->SetValue(m_hEyePosW, cameraPos, sizeof(D3DXVECTOR3));
	m_FX->SetValue(m_hWaveMapOffset0, &m_WaveMapOffset0, sizeof(D3DXVECTOR2));
	m_FX->SetValue(m_hWaveMapOffset1, &m_WaveMapOffset1, sizeof(D3DXVECTOR2));
	m_FX->SetTexture(m_hReflectMap, m_Reflect->GetD3dTex());
	m_FX->SetTexture(m_hRefractMap, m_Refract->GetD3dTex());

	UINT numPasses = 0;
	m_FX->Begin(&numPasses, 0);
	m_FX->BeginPass(0);

	m_Mesh->DrawSubset(0);

	m_FX->EndPass();
	m_FX->End();
}


void CWater::BuildFX()
{
	ID3DXBuffer* errors = 0;
	D3DXCreateEffectFromFile(m_device, "./Fx/Water.fx",
		0, 0, D3DXSHADER_DEBUG, 0, &m_FX, &errors);
	
	if( errors )
		MessageBoxA(0, (char*)errors->GetBufferPointer(), 0, 0);

	SAFE_RELEASE(errors);

	m_hTech           = m_FX->GetTechniqueByName("WaterTech");
	m_hWorld          = m_FX->GetParameterByName(0, "gWorld");
	m_hWorldInv       = m_FX->GetParameterByName(0, "gWorldInv");
	m_hWVP            = m_FX->GetParameterByName(0, "gWVP");
	m_hEyePosW        = m_FX->GetParameterByName(0, "gEyePosW");
	m_hLight          = m_FX->GetParameterByName(0, "gLight");
	m_hMtrl           = m_FX->GetParameterByName(0, "gMtrl");
	m_hWaveMap0       = m_FX->GetParameterByName(0, "gWaveMap0");
	m_hWaveMap1       = m_FX->GetParameterByName(0, "gWaveMap1");
	m_hWaveMapOffset0 = m_FX->GetParameterByName(0, "gWaveMapOffset0");
	m_hWaveMapOffset1 = m_FX->GetParameterByName(0, "gWaveMapOffset1");
	m_hRefractBias    = m_FX->GetParameterByName(0, "gRefractBias");
	m_hRefractPower   = m_FX->GetParameterByName(0, "gRefractPower");
	m_hRippleScale    = m_FX->GetParameterByName(0, "gRippleScale");
	m_hReflectMap     = m_FX->GetParameterByName(0, "gReflectMap");
	m_hRefractMap     = m_FX->GetParameterByName(0, "gRefractMap");


	// We don't need to set these every frame since they do not change.
	m_FX->SetMatrix(m_hWorld, &m_InitInfo.toWorld);
	D3DXMATRIX worldInv;
	D3DXMatrixInverse(&worldInv, 0, &m_InitInfo.toWorld);
	m_FX->SetMatrix(m_hWorldInv, &worldInv);
	m_FX->SetTechnique(m_hTech);
	m_FX->SetTexture(m_hWaveMap0, m_pWaveMap0);
	m_FX->SetTexture(m_hWaveMap1, m_pWaveMap1);
	m_FX->SetValue(m_hLight, &m_InitInfo.dirLight, sizeof(DirLight));
	m_FX->SetValue(m_hMtrl, &m_InitInfo.mtrl, sizeof(Mtrl));
	m_FX->SetValue(m_hRefractBias, &m_InitInfo.refracBias, sizeof(float));
	m_FX->SetValue(m_hRefractPower, &m_InitInfo.refractPower, sizeof(float));
	m_FX->SetValue(m_hRippleScale, &m_InitInfo.rippleScale, sizeof(D3DXVECTOR2));

}


void CWater::GenTriGrid(int numVertRows, int numVertCols,
				float dx, float dz, 
				const D3DXVECTOR3& center, 
				std::vector<D3DXVECTOR3>& verts,
				std::vector<DWORD>& indices)
{

	int numVertices = numVertRows*numVertCols;
	int numCellRows = numVertRows-1;
	int numCellCols = numVertCols-1;

	int numTris = numCellRows*numCellCols*2;

	float width = (float)numCellCols * dx;
	float depth = (float)numCellRows * dz;

	//===========================================
	// Build vertices.

	// We first build the grid geometry centered about the origin and on
	// the xz-plane, row-by-row and in a top-down fashion.  We then translate
	// the grid vertices so that they are centered about the specified 
	// parameter 'center'.

	verts.resize( numVertices );

	// Offsets to translate grid from quadrant 4 to center of 
	// coordinate system.
	float xOffset = -width * 0.5f; 
	float zOffset =  depth * 0.5f;

	int k = 0;
	for(float i = 0; i < numVertRows; ++i)
	{
		for(float j = 0; j < numVertCols; ++j)
		{
			// Negate the depth coordinate to put in quadrant four.  
			// Then offset to center about coordinate system.
			verts[k].x =  j * dx + xOffset;
			verts[k].z = -i * dz + zOffset;
			verts[k].y =  0.0f;

			// Translate so that the center of the grid is at the
			// specified 'center' parameter.
			D3DXMATRIX T;
			D3DXMatrixTranslation(&T, center.x, center.y, center.z);
			D3DXVec3TransformCoord(&verts[k], &verts[k], &T);

			++k; // Next vertex
		}
	}

	//===========================================
	// Build indices.

	indices.resize(numTris * 3);

	// Generate indices for each quad.
	k = 0;
	for(DWORD i = 0; i < (DWORD)numCellRows; ++i)
	{
		for(DWORD j = 0; j < (DWORD)numCellCols; ++j)
		{
			indices[k]     =   i   * numVertCols + j;
			indices[k + 1] =   i   * numVertCols + j + 1;
			indices[k + 2] = (i+1) * numVertCols + j;

			indices[k + 3] = (i+1) * numVertCols + j;
			indices[k + 4] =   i   * numVertCols + j + 1;
			indices[k + 5] = (i+1) * numVertCols + j + 1;

			// next quad
			k += 6;
		}
	}
}