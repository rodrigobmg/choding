#include "_Stdafx.h"

#include "Mesh.h"

#include "Sky.h"

#include "Frustum.h"
#include "TerrainManager.h"

#include "DrawTex2D.h"
#include "Water.h"
#include "WaterMannager.h"


CWaterMannager::CWaterMannager()
{
	m_Water = NULL;
	m_reflectMap = NULL;
	m_refractMap = NULL;
}

CWaterMannager::~CWaterMannager()
{
	SAFE_DELETE(m_Water);
}

void CWaterMannager::InitWater(LPDIRECT3DDEVICE9 device)
{
	DirLight m_light;

	m_lpDevice = device;

	//����Ʈ ����
	m_light.dirW = D3DXVECTOR3(-1.0f, -1.0f, -3.0f);
	D3DXVec3Normalize(&m_light.dirW, &m_light.dirW);
	m_light.ambient = D3DXCOLOR(0.8f, 0.8f, 0.8f, 1.0f);
	m_light.diffuse = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);
	m_light.spec = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);


	D3DXMatrixIdentity(&m_WaterWorld);
	//�� ���� ��ġ

	
	D3DXMatrixTranslation(&m_WaterWorld, 200.0f, -2.0f, 320.0f);

//	D3DXMatrixTranslation(&m_WaterWorld, 200.0f, 5.0f, 320.0f);

	//���� ���� ����
	Mtrl waterMtrl;
	waterMtrl.ambient = D3DXCOLOR(0.4f, 0.4f, 0.4f, 1.0f);
	waterMtrl.diffuse = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);
	//���ϱ� �Ҷ� 0.6* D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f)...�� ������ �߻�..0.6f�� ���־�� �Ѵ�. ����..
	waterMtrl.spec = 0.6f * D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);
	waterMtrl.specPower = 200.0f;


	//Water �ʱ�ȭ
	CWater::InitInfo waterInitInfo;
	waterInitInfo.dirLight = m_light;
	waterInitInfo.mtrl = waterMtrl;
	waterInitInfo.vertRows = 94;		
	waterInitInfo.vertCols = 90;		
	waterInitInfo.dx = 1.0f;
	waterInitInfo.dz = 1.0f;
	waterInitInfo.waveFileName0 = "wave0.dds";
	waterInitInfo.waveFileName1 = "wave1.dds";
	waterInitInfo.waveMapVelocity0 = D3DXVECTOR2(0.09f, 0.06f);
	waterInitInfo.waveMapVelocity1 = D3DXVECTOR2(-0.05f, 0.08f);
	waterInitInfo.texScale = 10.0f;
	waterInitInfo.refracBias = 0.1f;
	waterInitInfo.refractPower = 2.0f;
	waterInitInfo.rippleScale = D3DXVECTOR2(0.1f, 0.1f);
	waterInitInfo.toWorld = m_WaterWorld;

	m_Water = new CWater(waterInitInfo, device);

	m_reflectMap = m_Water->m_Reflect;
	m_refractMap = m_Water->m_Refract;

}


void CWaterMannager::InitWaterManager()
{
	m_Water->InitWater();
}


void CWaterMannager::WaterRLRF(CSMeshManager *meshManager, CSky *Sky, CTerrainManager *terrainManager, D3DXMATRIX _VP)
{

	D3DXMATRIX VP;
	VP = _VP;
	
	D3DXMATRIXA16 view, proj, wvp;

	m_lpDevice->GetTransform(D3DTS_VIEW, &view);
	m_lpDevice->GetTransform(D3DTS_PROJECTION, &proj);


	wvp = view*proj;
	//�ݻ� ���
	D3DXPLANE waterPlaneL(0.0f, -1.0f, 0.0f, 0.0f);

	//�ݻ������ �� ������ĸ�ŭ ��ȯ
	D3DXMATRIX wInvTrans;
	D3DXMatrixInverse(&wInvTrans, 0, &(m_WaterWorld));
	D3DXMatrixTranspose(&wInvTrans, &wInvTrans);
	D3DXPLANE waterPlaneW;
	D3DXPlaneTransform(&waterPlaneW, &waterPlaneL, &wInvTrans);

	//�ݻ������ ������������ ��ȯ
	D3DXMATRIX wvpInvTrans;
	D3DXMatrixInverse(&wvpInvTrans, 0, &(m_WaterWorld*wvp));
	D3DXMatrixTranspose(&wvpInvTrans, &wvpInvTrans);
	D3DXPLANE waterPlaneH;
	D3DXPlaneTransform(&waterPlaneH, &waterPlaneL, &wvpInvTrans);

	//��� �ݻ� ���
	D3DXMATRIX RefMtx;
	D3DXMatrixIdentity(&RefMtx);
	D3DXMatrixReflect(&RefMtx, &waterPlaneW);
	float f[4] = {waterPlaneH.a, waterPlaneH.b, waterPlaneH.c, waterPlaneH.d};


	m_reflectMap->SaveOldTaget();
	m_reflectMap->BeginScene();
//	
	//�ݻ�
	m_lpDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_ARGB(1, 1, 1, 1), 1.0f, 0);
	m_lpDevice->SetClipPlane(0, (float*)f);
	m_lpDevice->SetRenderState(D3DRS_CLIPPLANEENABLE,TRUE);
	m_lpDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);


//  ��ī�̵�(�ϴ�) ������
	Sky->Draw(&waterPlaneW);

	//���� ������Ʈ ������
	for(int i=0; i < terrainManager->GetMapNum(); i++)
	{
		if(terrainManager->GetCheck()[i] == TRUE)
		{
			meshManager->ReflectMeshRender(i, RefMtx);
		}
	}

	m_lpDevice->SetRenderState(D3DRS_CLIPPLANEENABLE,FALSE);
	m_reflectMap->EndScene();



	m_refractMap->SaveOldTaget();
	//����
	m_refractMap->BeginScene();
	m_lpDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_ARGB(1,1,1,1), 1.0f, 0);
	m_lpDevice->SetRenderState(D3DRS_CLIPPLANEENABLE,TRUE);
	m_lpDevice->SetClipPlane(0, (float*)f);
	m_lpDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

	terrainManager->DrawWaterTerrain();

	m_refractMap->EndScene();
	m_lpDevice->SetRenderState(D3DRS_CLIPPLANEENABLE, 0);

}

void CWaterMannager::ShutDown()
{
	m_Water->ShutDown();
}


void CWaterMannager::UpdateScene(float dt)
{
	m_Water->Update(dt);
}


void CWaterMannager::DrawWater(D3DXVECTOR3 *cameraPos,  D3DXMATRIX *vp)
{
	m_Water->Draw(cameraPos, vp);
}

