#include "_Stdafx.h"
#include "Ase.h"



void TRIANGLE::Init()
{
	for(int i=0; i < 3; i++)
	{
		VertexIndex[i] = 0;
		VertexColor[i] = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);
		VertexNormal[i] = D3DXVECTOR3(0, 0, 0);
		FaceNormal = D3DXVECTOR3(0, 0, 0);
		VertexTexture[i].u = 0;
		VertexTexture[i].v = 0;
	}

	MaterialID = 0;

	bView = true;
}

POS_TRACK* ANIMATION::GetPosTrack(float Frame)
{
	POS_TRACK* Ret = NULL;
	float TFrame=0;
	float CFrame;
	POS_TRACK* CurPos = m_Pos;
	if(CurPos == NULL)return NULL;
	if(CurPos->Index > Frame)return NULL;
	while(CurPos)
	{
		CFrame = (float)CurPos->Index;
		if(Ret==NULL)
		{
			TFrame = CFrame;
			Ret = CurPos;
		}
		else
		{
			if(fabs(TFrame - Frame) > fabs(CFrame - Frame) && CFrame <= Frame)
			{
				TFrame = CFrame;
				Ret = CurPos;
			}
		}

		CurPos = CurPos->m_pNext;
	}
	return Ret;
}

ROT_TRACK* ANIMATION::GetRotTrack(float Frame)
{
	ROT_TRACK* Ret = NULL;
	float TFrame=0;
	float CFrame;
	ROT_TRACK* CurPos = m_Rot;
	if(CurPos == NULL)return NULL;
	if(CurPos->index > Frame)return NULL;
	while(CurPos)
	{
		CFrame = (float)CurPos->index;
		if(Ret==NULL)
		{
			TFrame = CFrame;
			Ret = CurPos;
		}
		else
		{
			if(fabs(TFrame - Frame) > fabs(CFrame - Frame) && CFrame <= Frame)
			{
				TFrame = CFrame;
				Ret = CurPos;
			}
		}

		CurPos = CurPos->m_pNext;
	}
	return Ret;
}

SCALE_TRACK* ANIMATION::GetScaleTrack(float Frame)
{
	SCALE_TRACK* Ret = NULL;
	float TFrame=0;
	float CFrame;
	SCALE_TRACK* CurPos = m_Scale;
	while(CurPos)
	{
		CFrame = (float)CurPos->Index;
		if(Ret==NULL)
		{
			TFrame = CFrame;
			Ret = CurPos;
		}
		else
		{
			if(fabs(TFrame - Frame) > fabs(CFrame - Frame))
			{
				TFrame = CFrame;
				Ret = CurPos;
			}
		}

		CurPos = CurPos->m_pNext;
	}
	return Ret;
}

///////////////////////////////////////////////////////////////////////////////

void MESH::AnimateMatrix(D3DXMATRIX* matParents, float CurFrame)
{
	D3DXMatrixIdentity(&m_CalcMatrix);
	D3DXQUATERNION qR;
	D3DXQUATERNION qR1;
	D3DXVECTOR3 Trans;
	D3DXVECTOR3 Trans1;
	D3DXMATRIX mat2, mat3;
	ROT_TRACK* Rt = m_Animation.GetRotTrack(CurFrame);


	if(Rt)
	{
		qR = Rt->qR;
		if(Rt->m_pNext)
		{
			qR1 = Rt->m_pNext->qR;
			D3DXQuaternionSlerp(&qR, &qR, &qR1,
					(CurFrame - (float)Rt->index)/(float)(Rt->m_pNext->index - Rt->index));
		}

		D3DXMatrixIdentity(&mat2);
		D3DXMatrixRotationQuaternion(&mat2, &qR);
	}
	else
	{
		if(m_pParents)
		{
			D3DXMatrixMultiply(&mat2, &m_TmMatrix, &m_pParents->m_InvTm);
			mat2._41 = 0;
			mat2._42 = 0;
			mat2._43 = 0;
			mat2._44 = 1.0f;
		}
		else
		{
			mat2 = m_TmMatrix;
			mat2._41 = 0;
			mat2._42 = 0;
			mat2._43 = 0;
			mat2._44 = 1.0f;
		}
	}

	POS_TRACK* Pt = m_Animation.GetPosTrack(CurFrame);

	if(Pt)
	{
		Trans = Pt->Pos;

		if(Pt->m_pNext)
		{
			Trans1 = Pt->m_pNext->Pos;
			Trans1 = (Trans1 - Trans)*((CurFrame - (float)Pt->Index)/(float)(Pt->m_pNext->Index - Pt->Index));
		}
	}
	else
	{
		if(m_pParents)
		{
			D3DXMatrixMultiply(&mat3, &m_TmMatrix, &m_pParents->m_InvTm);

			Trans.x = mat3._41;
			Trans.y = mat3._42;
			Trans.z = mat3._43;
		}
		else
		{
			Trans = m_TmPos;
		}
	}


	mat2._41 = Trans.x;
	mat2._42 = Trans.y;
	mat2._43 = Trans.z;


	D3DXMatrixMultiply(&m_CalcMatrix, &mat2, matParents);
	MeshContainer* pTemp = m_pChilds;
	while(pTemp)
	{
		pTemp->pData->AnimateMatrix(&m_CalcMatrix, CurFrame);
		pTemp = pTemp->m_pNext;
	}


}


void MESH::AddChild(MESH* pMesh)
{
	MeshContainer* pTemp;
	pTemp = new MeshContainer;
	pTemp->pData = pMesh;
	if(m_pChilds == NULL)
	{
		m_pChilds = pTemp;
	}
	else
	{
		m_pChilds->Add(pTemp);
	}
}


void MESH::MakeIndex(Material* MaterialList)
{
	m_pMaterial = &MaterialList[m_iMaterialRef];

	if(m_TVert)delete[] m_TVert;
	m_TVert = NULL;
	if(m_ColorList)delete[] m_ColorList;
	
	int* num2;


	if(MaterialList && MaterialList[m_iMaterialRef].SubMaterialCount>0)
	{
		num2 = new int[MaterialList[m_iMaterialRef].SubMaterialCount];
		for(int i=0; i < MaterialList[m_iMaterialRef].SubMaterialCount; ++i)
		{
			for(int j=0; j < MaterialList[m_iMaterialRef].SubMaterialCount; ++i)
			{
				if(_stricmp(MaterialList[m_iMaterialRef].SubMaterial[i].TextureName,
					MaterialList[m_iMaterialRef].SubMaterial[j].TextureName) == 0)
				{
					num2[i] = j;
					break;
				}
			}
		}
		
		for(int i=0; i < MaterialList[m_iMaterialRef].SubMaterialCount; ++i)
		{
			for(int j=0; j < m_iNumTriagnle; ++j)
			{
				if(m_TriangleList[j].MaterialID != num2[i])
					m_TriangleList[j].MaterialID = num2[i];
				if(m_TriangleList[j].MaterialID >= m_pMaterial->SubMaterialCount)
					m_TriangleList[j].MaterialID = 0;
			}

		}
		delete[] num2;

	}
	else
	{
		for(int j=0; j < m_iNumTriagnle; ++j)
		{
			m_TriangleList[j].MaterialID = 0;
		}
	}

	if(m_pMaterial->SubMaterialCount > 0)
		if(m_pRenderMaterialSize==NULL)
		{
			m_pRenderMaterialSize = new int[m_pMaterial->SubMaterialCount];
			for(int i=0; m_pMaterial->SubMaterialCount; ++i)
				m_pRenderMaterialSize[i] = 0;
		}

}

void MESH::MakeVERTEX()
{
	D3DXMATRIX mat2;

	if(m_pParents)
	{
		D3DXMatrixMultiply(&mat2, &m_TmMatrix, &m_pParents->m_InvTm);
		D3DXMatrixMultiply(&m_CalcMatrix, &mat2, &m_pParents->m_CalcMatrix);
	}
	else
	{
		m_CalcMatrix = m_TmMatrix;
	}

	if(m_pVertex == NULL) m_pVertex = new sVERTEX[m_iNumTriagnle*3];
	if(m_pRenderIndex == NULL)m_pRenderIndex = new short[m_iNumTriagnle*3];
	if(m_pRenderMaterial == NULL)m_pRenderMaterial = new DWORD[m_iNumTriagnle];


	int k=0;

	for(int j=0; j < m_iNumTriagnle; j++)
	{

		if(m_pMaterial->SubMaterialCount>0)
			m_pRenderMaterial[j] = m_TriangleList[j].MaterialID;
		else
			m_pRenderMaterial[j] = 0;

		if(m_pRenderMaterialSize)
			m_pRenderMaterialSize[m_TriangleList[j].MaterialID]++;


		m_pVertex[k].p =m_VertexList[m_TriangleList[j].VertexIndex[0]];
//		m_pVertex[k].color = 0xffffffff;// m_TriangleList[j].VertexColor[0];       //0xff0000ff;
		m_pVertex[k].n = m_TriangleList[j].VertexNormal[0];
		m_pVertex[k].u = m_TriangleList[j].VertexTexture[0].u;
		m_pVertex[k].v = m_TriangleList[j].VertexTexture[0].v;
		m_pRenderIndex[k]=k;
		++k;

		m_pVertex[k].p = m_VertexList[m_TriangleList[j].VertexIndex[1]];
//		m_pVertex[k].color =  0xffffffff;//m_TriangleList[j].VertexColor[1];
		m_pVertex[k].n = m_TriangleList[j].VertexNormal[1];
		m_pVertex[k].u = m_TriangleList[j].VertexTexture[1].u;
		m_pVertex[k].v = m_TriangleList[j].VertexTexture[1].v;
		m_pRenderIndex[k]=k;
		++k;

		m_pVertex[k].p = m_VertexList[m_TriangleList[j].VertexIndex[2]];
//		m_pVertex[k].color = 0xffffffff;//m_TriangleList[j].VertexColor[2];
		m_pVertex[k].n = m_TriangleList[j].VertexNormal[2];
		m_pVertex[k].u = m_TriangleList[j].VertexTexture[2].u;
		m_pVertex[k].v = m_TriangleList[j].VertexTexture[2].v;
		m_pRenderIndex[k]=k;
		++k;

	}

	m_iVertexNum = k;
	delete[] m_VertexList;
	m_VertexList = NULL;
	delete[] m_TriangleList;
	m_TriangleList = NULL;


}

HRESULT MESH::CreateVB(LPDIRECT3DDEVICE9 device)
{

	if( FAILED(device->CreateVertexBuffer(m_iVertexNum*sizeof(sVERTEX),0, sVERTEX::FVF,
		D3DPOOL_DEFAULT, &m_pVB, NULL)))
	{
		return E_FAIL;
	}

	VOID* pVertices;
	if(FAILED(m_pVB->Lock(0, m_iVertexNum*sizeof(sVERTEX), (void**)&pVertices,0)))
	{
		return E_FAIL;
	}

	memcpy(pVertices, m_pVertex, m_iVertexNum*sizeof(sVERTEX));

	m_pVB->Unlock();

	return S_OK;

}

void MESH::CalulateBoundingSphere()
{
	m_vMin = m_VertexList[0];
	m_vMax = m_VertexList[0];

	for(int i=0; i < m_iNumVertex; i++)
	{
		if(m_VertexList[i].x < m_vMin.x) m_vMin.x = m_VertexList[i].x;
		if(m_VertexList[i].y < m_vMin.y) m_vMin.y = m_VertexList[i].y;
		if(m_VertexList[i].z < m_vMin.z) m_vMin.z = m_VertexList[i].z;

		if(m_VertexList[i].x > m_vMax.x) m_vMax.x = m_VertexList[i].x;
		if(m_VertexList[i].y > m_vMax.y) m_vMax.y = m_VertexList[i].y;
		if(m_VertexList[i].z > m_vMax.z) m_vMax.z = m_VertexList[i].z;
	}

	m_vCenter = (m_vMin + m_vMax)/2;
	D3DXVECTOR3 vTemp = m_vCenter - m_vMin;
	m_fRadius = D3DXVec3Length(&vTemp);
	m_vRadius.x = (float)fabs(m_vCenter.x - m_vMin.x);
	m_vRadius.y = (float)fabs(m_vCenter.y - m_vMin.y);
	m_vRadius.z = (float)fabs(m_vCenter.z - m_vMin.z);


}


void MESH::CreateSphere()
{
	D3DXCreateSphere(m_pDevice, m_fRadius, 20, 20, &m_SphereMesh, 0);

}

void MESH::CreateBox()
{
	D3DXCreateBox(m_pDevice, m_vMax.x - m_vMin.x,
		m_vMax.y - m_vMin.y,
		m_vMax.z - m_vMin.z,
		&m_BoxMesh, 0);

}

void MESH::DrawSphere()
{

	if(NULL == m_SphereMesh )
		return;

	D3DXMATRIX mat;
	D3DMATERIAL9 mtrl;
	D3DXCOLOR BLACK;

	mtrl.Diffuse.r = mtrl.Ambient.r =  mtrl.Specular.r = 0.0f;
	mtrl.Diffuse.g = mtrl.Ambient.g =  mtrl.Specular.g = 0.0f;
	mtrl.Diffuse.b = mtrl.Ambient.b =  mtrl.Specular.b = 1.0f;

	mtrl.Diffuse.a = 0.10f;
	D3DXMatrixIdentity(&mat);

	m_pDevice->SetMaterial(&mtrl);
	m_pDevice->SetTexture(0, 0); // disable texture

	m_pDevice->SetRenderState( D3DRS_LIGHTING, TRUE);
	m_pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, true);
	m_pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	D3DXMatrixTranslation(&mat, m_vCenter.x, m_vCenter.y, m_vCenter.z);

	D3DXMatrixMultiply(&mat, &mat, &m_CalcMatrix);

	m_pDevice->SetTransform(D3DTS_WORLD, &m_CalcMatrix);

	m_SphereMesh->DrawSubset(0);

	m_pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
	m_pDevice->SetRenderState( D3DRS_LIGHTING, false);
}

void MESH::DrawBox()
{
	if(NULL == m_BoxMesh )
		return;


	D3DXMATRIX mat;
	D3DMATERIAL9 mtrl;
	D3DXCOLOR BLACK;

	mtrl.Diffuse.r = mtrl.Ambient.r =  mtrl.Specular.r = 0.0f;
	mtrl.Diffuse.g = mtrl.Ambient.g =  mtrl.Specular.g = 0.0f;
	mtrl.Diffuse.b = mtrl.Ambient.b =  mtrl.Specular.b = 1.0f;

	mtrl.Diffuse.a = 0.10f;
	D3DXMatrixIdentity(&mat);

	m_pDevice->SetMaterial(&mtrl);
	m_pDevice->SetTexture(0, 0); // disable texture

	m_pDevice->SetRenderState( D3DRS_LIGHTING, TRUE);
	m_pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, true);
	m_pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	D3DXMatrixTranslation(&mat, m_vCenter.x, m_vCenter.y, m_vCenter.z);

	D3DXMatrixMultiply(&mat, &mat, &m_CalcMatrix);

	m_pDevice->SetTransform(D3DTS_WORLD, &m_CalcMatrix);

	m_BoxMesh->DrawSubset(0);

	m_pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
	m_pDevice->SetRenderState( D3DRS_LIGHTING, false);
}


CAse::CAse()
{
	m_MeshList = NULL;
	m_BoneList = NULL;
	m_MaterialList = NULL;
	m_iNumMaterial = 0;
	m_iNumMesh = 0;

	Release();
}

CAse::~CAse()
{

	if(m_MeshList)
		delete m_MeshList;
	if(m_BoneList)
		delete m_BoneList;
	if(m_MaterialList)
		delete[] m_MaterialList;
}


void CAse::AddMesh(MESH* Mesh)
{
	MESH* temp;
	if(m_MeshList == NULL)
	{
		m_MeshList = Mesh;
	}
	else
	{
		temp = m_MeshList;
		while(temp)
		{
			if(temp->m_pNext == NULL)
			{
				temp->m_pNext = Mesh;
				break;
			}
			temp = temp->m_pNext;
		}
	}
}

void CAse::AddBoneMesh(MESH* Mesh)
{
	MESH* temp;
	if(m_BoneList == NULL)
	{
		m_BoneList = Mesh;
	}
	else{
		temp = m_BoneList;
		while(temp)
		{
			if(temp->m_pNext == NULL)
			{
				temp->m_pNext = Mesh;
				break;
			}
			temp = temp->m_pNext;
		}
	}
}



BOOL CAse::ReadASE(char *fname)
{
	FILE *fp;
	fp = fopen(fname, "rt");
	if(fp == NULL)
	{
		return FALSE;
	}
	
	m_ilinecount = 0;
	m_bNormalFlag = FALSE;

	if(m_MeshList)
	{
		delete m_MeshList;
		m_MeshList = NULL;
	}

	if(m_MaterialList)
	{
		delete m_MaterialList;
		m_MaterialList = NULL;
	}


	DecodeASE(fp);

	
	if (m_bNormalFlag == FALSE)
	{
//		MakeFaceNormalFromWorldVertex();
//		MakeVertexNormalFromFaceNormal();
	}


	fclose(fp);
	MakeInherite();
	D3DXMATRIX mat;
	D3DXMatrixIdentity(&mat);

	m_CurMesh = m_MeshList;
	
	while(m_CurMesh)
	{
		m_CurMesh->CalulateBoundingSphere();
		D3DXMatrixIdentity(&m_CurMesh->m_CalcMatrix);

		m_CurMesh = m_CurMesh->m_pNext;
	}

	m_CurMesh = m_BoneList;
	while(m_CurMesh)
	{
//		m_CurMesh->CalulateBoundingSphere();
		D3DXMatrixIdentity(&m_CurMesh->m_CalcMatrix);
		 m_CurMesh = m_CurMesh->m_pNext;
	}

	SetAllMesh();
	m_CurMesh = m_MeshList;

	while(m_CurMesh)
	{
		m_CurMesh->MakeIndex(m_MaterialList);
		m_CurMesh->MakeVERTEX();
		m_CurMesh->CreateVB(m_device);
		m_CurMesh = m_CurMesh->m_pNext;
	}


	return TRUE;
}

int CAse::DecodeASE(FILE *fp)
{
	m_ilinecount++;
	fgets(m_line, 256, fp);
	sscanf(m_line,"%s", m_string);

	if(_stricmp(m_string, "*3DSMAX_ASCIIEXPORT") != 0) return -1;


	while(!feof(fp))
	{
		m_ilinecount++;
		fgets(m_line, 256, fp);
		sscanf(m_line, "%s", m_string);

		if(_stricmp(m_string, "*COMMENT") == 0) continue;

		///////////////////////////////////////////////
		if(_stricmp(m_string, "*SCENE") == 0)
			DecodeSCENE(fp);

		if(_stricmp(m_string, "*MATERIAL_LIST") == 0)
			DecodeMATERIAL_LIST(fp);
		
		if(_stricmp(m_string, "*GEOMOBJECT") == 0)
		{
			MESH* Mesh = new MESH;
			m_CurMesh = Mesh;
			DecodeGEOMOBJECT(fp);
	
			if(strstr(m_CurMesh->m_Name , "Bip0") != NULL)
				AddBoneMesh(m_CurMesh);
			else
				AddMesh(m_CurMesh);
		}
		if(_stricmp(m_string, "*HELPEROBJECT") == 0)
		{
			MESH* Mesh = new MESH;
			m_CurMesh = Mesh;
			DecodeGEOMOBJECT(fp);
			AddMesh(Mesh);
		}

	}

	return m_ilinecount;


	
}

int CAse::DecodeSCENE(FILE *fp)
{
	m_ilinecount += 8;

	fgets(m_line, 256, fp);//*SCENE_FILENAME

	fgets(m_line, 256, fp);//*SCENE_FIRSTFRAME
	sscanf(m_line, "%s%f", m_string, &m_FirstFrame);

	fgets(m_line, 256, fp);//*SCENE_LASTFRAME
	sscanf(m_line, "%s%f", m_string, &m_LastFrame);

	fgets(m_line, 256, fp);//*SCENE_FRAMESPEED
	sscanf(m_line, "%s%f", m_string, &m_FrameSpeed);

	fgets(m_line, 256, fp);//*SCENE_TICKSPERFRAME	
	sscanf(m_line,"%s%f",m_string, &m_TickPerFrame);

	fgets(m_line, 256, fp);
	fgets(m_line, 256, fp);
	fgets(m_line, 256, fp);

	return 0;
}

int CAse::DecodeMATERIAL_LIST(FILE *fp)
{
	fgets(m_line, 256, fp);
	int num = 0;
	int Temp;
	sscanf(m_line, "%s%d", m_string, &m_iNumMaterial);
	if(m_MaterialList)delete[] m_MaterialList;
	m_MaterialList = new Material[m_iNumMaterial];

	do{
		m_ilinecount++;
		fgets(m_line, 256, fp);
		sscanf(m_line, "%s%d", m_string, &Temp);
		if(_stricmp(m_string, "*MATERIAL") == 0)
		{
			DecodeMaterial(fp, &m_MaterialList[num]);
			num++;
			continue;
		}
		if(_stricmp(m_string, "}") == 0)
		{
			break;
		}

	}while(1);

	return 0;


}

VOID CAse::D3DUtil_InitMaterial( D3DMATERIAL9& mtrl, FLOAT r, FLOAT g, FLOAT b,FLOAT a )
{
	ZeroMemory( &mtrl, sizeof(D3DMATERIAL9) );
	mtrl.Diffuse.r = mtrl.Ambient.r = r;
	mtrl.Diffuse.g = mtrl.Ambient.g = g;
	mtrl.Diffuse.b = mtrl.Ambient.b = b;
	mtrl.Diffuse.a = mtrl.Ambient.a = a;
}

int CAse::DecodeMaterial(FILE* fp, Material* CurMaterial)
{
	D3DUtil_InitMaterial(CurMaterial->d3dMaterial, 0.0, 0.0, 0.0, 1.0);

	int num;

	do{
		m_ilinecount++;
		fgets(m_line, 256, fp);
		sscanf(m_line, "%s", m_string);

		if(_stricmp(m_string, "*SUBMATERIAL") == 0)
		{
			sscanf(m_line, "%s%d", m_line, &num);
			DecodeMaterial(fp, &(CurMaterial->SubMaterial[num]));
			continue;
		}
		if(_stricmp(m_string, "*NUMSUBMTLS") == 0)
		{
			if(CurMaterial->SubMaterial)
				delete CurMaterial->SubMaterial;
			sscanf(m_line, "%s%d", m_string, &CurMaterial->SubMaterialCount);
			CurMaterial->SubMaterial = new Material[CurMaterial->SubMaterialCount];
			continue;
		}
		if(_stricmp(m_string, "*MATERIAL_AMBIENT") == 0)
		{
			sscanf(m_line, "%s%f%f%f", m_string, &CurMaterial->d3dMaterial.Ambient.r
					,&CurMaterial->d3dMaterial.Ambient.g, &CurMaterial->d3dMaterial.Ambient.b);
		}
		if(_stricmp(m_string, "*MATERIAL_DIFFUSE") == 0)
		{
			sscanf(m_line, "%s%f%f%f",m_string, &CurMaterial->d3dMaterial.Diffuse.r,
					&CurMaterial->d3dMaterial.Diffuse.g, &CurMaterial->d3dMaterial.Diffuse.b);
			continue;
		}
		if(_stricmp(m_string, "*MATERIAL_SPECULAR") == 0) 
		{
			sscanf(m_line, "%s%f%f%f", m_string, &CurMaterial->d3dMaterial.Specular.r,
					&CurMaterial->d3dMaterial.Specular.g, &CurMaterial->d3dMaterial.Specular.b);
			continue;
		}

		if(_stricmp(m_string, "*MAP_DIFFUSE") ==0)
		{
			CurMaterial->bUseTexture = true;
			DecodeMap(fp, CurMaterial);
			continue;
		}
	
		if(_stricmp(m_string, "*MAP_OPACITY")==0)
		{
			CurMaterial->bUseTexture = true;
			CurMaterial->bUseOpacity = true;
			DecodeMap(fp, CurMaterial);
			continue;
		}
		if(_strcmpi(m_string, "*MAP_SELFILLUM")==0)
		{
			DecodeMap(fp, CurMaterial);
			continue;
		}

		if(_strcmpi(m_string, "*MAP_REFLECT")==0)
		{
			DecodeMap(fp, CurMaterial);
			continue;
		}


		if(_strcmpi(m_string, "*MAP_SPECULAR")==0)
		{
			DecodeMap(fp, CurMaterial);
			continue;
		}
		if(_stricmp(m_string, "}")==0)
		{
			break;
		}


	}while(1);


	if(FAILED(D3DXCreateTextureFromFile(m_device, CurMaterial->TextureName, &CurMaterial->pTexture)))
	{
		return -1;
	}


	return 0;
}

int CAse::DecodeMap(FILE *fp, Material* CurMaterail)
{
	bool check;
	int i, j;
	char name[200];

	do{
		m_ilinecount++;
		fgets(m_line, 256, fp);
		sscanf(m_line, "%s", m_string);

		if(_strcmpi(m_string, "*BITMAP")==0)
		{
			sscanf(m_line, "%s%s", m_string, name);
			memset(CurMaterail->TextureName, 0, 256);
			j=0;
			check = false;
			for(i=0; i < 256; i++)
			{
				if(check)
				{
					if(m_line[i] == '"'){check = false; break;}
					CurMaterail->TextureName[j] = m_line[i];
					j++;
				}
				if(m_line[i] == '"')check = true;
			}
	//		GetFileName(CurMaterail->TextureName, 256);
			continue;
		}
		if(_strcmpi(m_string, "}") == 0)
		{
			break;
		}
	}while(1);
	return 0;
}


int  CAse::DecodeGEOMOBJECT(FILE *fp)
{
	int num;
	int i,j;
	bool check;
	do{
		m_ilinecount++;
		fgets(m_line, 256, fp);
		sscanf(m_line, "%s", m_string);
		if(_strcmpi(m_string, "*NODE_NAME")==0)
		{
			j=0;
			check = false;
			memset(m_CurMesh->m_Name, 0, 256);
			for(i = 0 ; i < 256; i++)
			{
				if(check)
				{
					if(m_line[i] == '"'){check=false; break;}
					m_CurMesh->m_Name[j] = m_line[i];
					j++;
				}
				if(m_line[i] == '"')check = true;
			}
			continue;
		}
	

		if(_stricmp(m_string, "*NODE_PARENT") == 0)
		{
			m_CurMesh->m_bParents = true;
			j=0;
			check = false;
			memset(m_CurMesh->m_ParentName, 0, 256);
			
			for(i=0; i < 256; i++)
			{
				if(check)
				{
					if(m_line[i] =='"'){check=false; break;}
					m_CurMesh->m_ParentName[j] = m_line[i];
					j++;
				}
				if(m_line[i]=='"')check = true;
			}
			continue;

		}
		
		if(_stricmp(m_string, "*NODE_TM") == 0)
		{
			DecodeTm(fp);
			continue;
		}
		if(_stricmp(m_string, "*MESH") == 0)
		{
			DecodeMESH(fp);
			continue;
		}
		if(_stricmp(m_string, "*MATERIAL_REF") == 0)
		{
			sscanf(m_line, "%s%d", m_string, &num);
			m_CurMesh->m_iMaterialRef = num;
		}
		if(_stricmp(m_string, "*TM_ANIMATION")==0)
		{

			DecodeANIMATION(&m_CurMesh->m_Animation, fp);
			continue;

		}
		if(_stricmp(m_string, "}") == 0) return 0;
	}while(1);

	return 0;


}

int CAse::DecodeTm(FILE *fp)
{
	float fX, fY, fZ, fW;
	D3DXMatrixIdentity(&(m_CurMesh->m_TmMatrix));
	m_ilinecount +=15;
	fgets(m_line, 256, fp); //NODE_NAME
	fgets(m_line, 256, fp); //*INHERIT_POS
	fgets(m_line, 256, fp); //*INHERIT_ROT
	fgets(m_line, 256, fp); //*INHERIT_SCL
	fgets(m_line, 256, fp); //*TM_ROW0
	sscanf(m_line, "%s%f%f%f", m_string, &(m_CurMesh->m_TmMatrix._11), &(m_CurMesh->m_TmMatrix._13),&(m_CurMesh->m_TmMatrix._12));
	fgets(m_line, 256, fp);//*TM_ROW1
	sscanf(m_line, "%s%f%f%f",m_string, &(m_CurMesh->m_TmMatrix._31), &(m_CurMesh->m_TmMatrix._33), &(m_CurMesh->m_TmMatrix._32));
	fgets(m_line, 256, fp); //TM_ROW2
	sscanf(m_line, "%s%f%f%f",m_string, &(m_CurMesh->m_TmMatrix._21), &(m_CurMesh->m_TmMatrix._23), &(m_CurMesh->m_TmMatrix._22));
	fgets(m_line, 256, fp); //TM_ROW3
	sscanf(m_line, "%s%f%f%f", m_string, &(m_CurMesh->m_TmMatrix._41), &(m_CurMesh->m_TmMatrix._43), &(m_CurMesh->m_TmMatrix._42));
	fgets(m_line, 256, fp); //TM_POS
	sscanf(m_line, "%s%f%f%f",m_string, &(m_CurMesh->m_TmPos.x), &(m_CurMesh->m_TmPos.z), &(m_CurMesh->m_TmPos.y));
	fgets(m_line, 256, fp); //*TM_ROTAXIS
	sscanf(m_line, "%s%f%f%f",m_string, &fX, &fZ, &fY);
	fgets(m_line, 256, fp); //*TM_ROTANGLE
	sscanf(m_line,"%s%f", m_string, &fW);
	//fW = -fW;
	m_CurMesh->m_TmRot.x = (float)sinf(fW / 2.0f) * fX;
	m_CurMesh->m_TmRot.y = (float)sinf(fW / 2.0f) * fY;
	m_CurMesh->m_TmRot.z = (float)sinf(fW / 2.0f) * fZ;
	m_CurMesh->m_TmRot.w = (float)cosf(fW / 2.0f);
	fgets(m_line, 256, fp);//*TM_SCALE
	sscanf(m_line, "%s%f%f%f",m_string, &(m_CurMesh->m_TmScale.x), &(m_CurMesh->m_TmScale.z), &(m_CurMesh->m_TmScale.y));
	fgets(m_line, 256, fp);//*TM_SCALEAXIS
	sscanf(m_line, "%s%f%f%f",m_string, &fX,&fZ,&fY);
	fgets(m_line, 256, fp);//*TM_SCALEAXISANG
	sscanf(m_line, "%s%f",m_string, &fW);
	m_CurMesh->m_TmScaleRot.x = (float)sin(fW / 2.0f) * fX;
	m_CurMesh->m_TmScaleRot.y = (float)sin(fW / 2.0f) * fY;
	m_CurMesh->m_TmScaleRot.z = (float)sin(fW / 2.0f) * fZ;
	m_CurMesh->m_TmScaleRot.w = (float)cos(fW / 2.0f);
	fgets(m_line, 256, fp);//}
	return 0;

}

int CAse::DecodeMESH(FILE *fp)
{
	m_ilinecount++;
	fgets(m_line, 256, fp); //*TIMEVALUE

	int VCOUNT;
	m_ilinecount++;
	fgets(m_line, 256, fp);//*MESH_NUMVERTEX
	sscanf(m_line, "%s%d", m_string, &VCOUNT);
	m_CurMesh->m_iNumVertex = VCOUNT;

	if(m_CurMesh->m_VertexList)
		delete[] m_CurMesh->m_VertexList;

	m_CurMesh->m_VertexList = new D3DXVECTOR3[VCOUNT];

	int TCOUNT;
	m_ilinecount++;
	fgets(m_line, 256, fp);	//*MESH_NUMFACES
	sscanf(m_line, "%s%d",m_string, &TCOUNT);
	
	if(m_CurMesh->m_TriangleList)
		delete[] m_CurMesh->m_TriangleList;

	m_CurMesh->m_TriangleList = new TRIANGLE[TCOUNT];

	for(int i=0; i < TCOUNT; i++)
	{
		m_CurMesh->m_TriangleList[i].Init();
	}

	m_CurMesh->m_iNumTriagnle = TCOUNT;

	m_ilinecount++;
	fgets(m_line, 256, fp);//*MESH_VERTEX_LIST
	sscanf(m_line, "%s", m_string);
	if(_stricmp(m_string, "*MESH_VERTEX_LIST") == 0)
		DecodeMESH_VERTEX_LIST(fp);
	
	m_ilinecount++;
	fgets(m_line, 256, fp);
	sscanf(m_line, "%s", m_string);

	if(_stricmp(m_string, "*MESH_FACE_LIST") == 0)
		DecodeMESH_FACE_LIST(fp);

	
	while(1)
	{
		m_ilinecount++;
		fgets(m_line, 256, fp);
		sscanf(m_line, "%s", m_string);
		if(_stricmp(m_string, "*MESH_NUMTVERTEX") == 0) // *MESH_NUMTVERTEX
		{
			DecodeMESH_TVERTLIST(fp);
			continue;
		}
	
		if(_stricmp(m_string, "*MESH_NUMTVFACES") == 0)
		{
			DecodeMESH_TFACELIST(fp);
			continue;
		}
		if(_stricmp(m_string, "*MESH_NUMCVERTEX") == 0)
		{
			DecodeMESH_CVERTEX(fp);
			continue;
		}
		if(_stricmp(m_string, "*MESH_NORMALS") == 0) //*MESH_NORMALS
		{
			DecodeMESH_NORMALS(fp);
			continue;
		}
		if(_stricmp(m_string, "}") == 0) return 0;

	}

	m_ilinecount++;
	fgets(m_line, 256, fp);//}

	return 0;
}

int CAse::DecodeMESH_VERTEX_LIST(FILE *fp)
{
	int Counter = 0;
	int num;

	while( Counter < m_CurMesh->m_iNumVertex)
	{
		m_ilinecount++;
		fgets(m_line, 256, fp);
		sscanf(m_line, "%s%d%f%f%f", m_string, &num,
			&m_CurMesh->m_VertexList[Counter].x,
			&m_CurMesh->m_VertexList[Counter].z,
			&m_CurMesh->m_VertexList[Counter].y);

		Counter++;
	}
	m_ilinecount++;
	fgets(m_line, 256, fp);

	return 0;
}

int CAse::DecodeMESH_FACE_LIST(FILE *fp)
{
	int num;
	int Counter = 0;
	char Smooth[20];
	char MaterID[20];
	int ID;

	while( Counter < m_CurMesh->m_iNumTriagnle)
	{
		m_ilinecount++;
		fgets(m_line, 256, fp);

		memset(MaterID, 0, 20);
		memset(Smooth, 0, 20);
		sscanf(m_line, "%s%s%s%d%s%d%s%d%s%d%s%d%s%d%s%s%s%d", m_string, m_string,
			m_string, &m_CurMesh->m_TriangleList[Counter].VertexIndex[0], 
			m_string, &m_CurMesh->m_TriangleList[Counter].VertexIndex[2], 
			m_string, &m_CurMesh->m_TriangleList[Counter].VertexIndex[1],
			m_string, &num, m_string, &num, m_string, &num, m_string, Smooth,
			MaterID, &ID);
		if(_stricmp(MaterID, "*MESH_MTLID") == 0)
		{
			m_CurMesh->m_TriangleList[Counter].MaterialID = ID;
		}
		if(_stricmp(MaterID, "*MESH_MTLID") == 0)
		{
			m_CurMesh->m_TriangleList[Counter].MaterialID = atoi(MaterID);
		}

		Counter++;
	}

	m_ilinecount++;
	fgets(m_line, 256, fp);	//}

	return 0;
}

int CAse::DecodeMESH_TVERTLIST(FILE *fp)
{
	int MAXTVERTEX;
	sscanf(m_line, "%s%d", m_string, &MAXTVERTEX);

	if(MAXTVERTEX <= 0)return 0;

	m_CurMesh->m_TVert = new TEXCOORDFLOAT[MAXTVERTEX];
	
	m_ilinecount++;

	float u, v, w;
	fgets(m_line, 256, fp); //*MESH_TVERTLIST

	int counter = 0;
	int num;

	while( counter < MAXTVERTEX )
	{
		m_ilinecount++;
		fgets(m_line, 256, fp); //*MESH_TVERT
		sscanf(m_line, "%s%d%f%f%f", m_string, &num, &u, &v, &w);

		m_CurMesh->m_TVert[num].u = u;
		m_CurMesh->m_TVert[num].v = 1.0f - v;
		counter++;
	}

	m_ilinecount++;
	fgets(m_line, 256, fp); //}

	return 0;
}

int CAse::DecodeMESH_TFACELIST(FILE *fp)
{
	int TIndex[3];

	int TFACECOUNT;
	sscanf(m_line, "%s%d", m_string, &TFACECOUNT);

	if(TFACECOUNT <= 0)return 0;
	m_ilinecount++;
	fgets(m_line, 256, fp); //*MESH_TFACELIST
	int Count = 0;
	int num;

	while( Count < TFACECOUNT)
	{
		m_ilinecount++;
		fgets(m_line, 256, fp); //MESH_TFACE
		sscanf(m_line, "%s%d%d%d%d", m_string, &num, &TIndex[0], &TIndex[2], &TIndex[1]);
		if(m_CurMesh->m_TVert)
		{
			m_CurMesh->m_TriangleList[num].VertexTexture[0].u = m_CurMesh->m_TVert[TIndex[0]].u;
			m_CurMesh->m_TriangleList[num].VertexTexture[0].v = m_CurMesh->m_TVert[TIndex[0]].v;
			m_CurMesh->m_TriangleList[num].VertexTexture[1].u = m_CurMesh->m_TVert[TIndex[1]].u;
			m_CurMesh->m_TriangleList[num].VertexTexture[1].v = m_CurMesh->m_TVert[TIndex[1]].v;
			m_CurMesh->m_TriangleList[num].VertexTexture[2].u = m_CurMesh->m_TVert[TIndex[2]].u;
			m_CurMesh->m_TriangleList[num].VertexTexture[2].v = m_CurMesh->m_TVert[TIndex[2]].v;
		}
		Count++;
	}
	m_ilinecount++;
	fgets(m_line, 256, fp); //}

	return 0;

}
int CAse::DecodeMESH_CVERTEX(FILE *fp)
{
	int i, num;
	sscanf(m_line, "%s%d", m_string, &num);
	if(num <= 0) return 0;
	m_CurMesh->m_ColorList = new D3DXCOLOR[num];
	int colnum;
	float r,g,b;

	m_ilinecount++;
	fgets(m_line, 256, fp);
	for(i = 0; i < num; i++)
	{
		m_ilinecount++;
		fgets(m_line, 256, fp);
		sscanf(m_line, "%s%d%f%f%f", m_string, &colnum, &r, &g, &b);
		m_CurMesh->m_ColorList[colnum].r = r;
		m_CurMesh->m_ColorList[colnum].g = g;
		m_CurMesh->m_ColorList[colnum].b = b;
		m_CurMesh->m_ColorList[colnum].a = 1.0f;
	}
	m_ilinecount++;
	fgets(m_line, 256, fp);

	return 0;
}

int CAse::DecodeMESH_NORMALS(FILE *fp)
{
	int counter = 0;

	m_bNormalFlag = TRUE;
	float x, y, z;
	int num, num2;
	
	while( counter < m_CurMesh->m_iNumTriagnle)
	{
	
		m_ilinecount++;
		fgets(m_line, 256, fp);//*MESH_FACENORMAL
		sscanf(m_line, "%s%d%f%f%f", m_string, &num,	&x,	&z,	&y);
		m_CurMesh->m_TriangleList[num].FaceNormal.x = x;
		m_CurMesh->m_TriangleList[num].FaceNormal.y = y;
		m_CurMesh->m_TriangleList[num].FaceNormal.z = z;

		m_ilinecount++;
		fgets(m_line, 256, fp);//*MESH_VERTEXNORMAL
		sscanf(m_line, "%s%d%f%f%f", m_string, &num2,	&x,	&z,	&y);
		m_CurMesh->m_TriangleList[num].VertexNormal[0].x = x;
		m_CurMesh->m_TriangleList[num].VertexNormal[0].y = y;
		m_CurMesh->m_TriangleList[num].VertexNormal[0].z = z;

		m_ilinecount++;
		fgets(m_line, 256, fp);//*MESH_VERTEXNORMAL
		sscanf(m_line, "%s%d%f%f%f", m_string, &num2,	&x,	&z,	&y);
		m_CurMesh->m_TriangleList[num].VertexNormal[2].x = x;
		m_CurMesh->m_TriangleList[num].VertexNormal[2].y = y;
		m_CurMesh->m_TriangleList[num].VertexNormal[2].z = z;

		m_ilinecount++;
		fgets(m_line, 256, fp);//*MESH_VERTEXNORMAL
		sscanf(m_line, "%s%d%f%f%f", m_string, &num2,	&x,	&z,	&y);
		m_CurMesh->m_TriangleList[num].VertexNormal[1].x = x;
		m_CurMesh->m_TriangleList[num].VertexNormal[1].y = y;
		m_CurMesh->m_TriangleList[num].VertexNormal[1].z = z;

		counter++;
	}
	m_ilinecount++;
	fgets(m_line, 256, fp); //}

	return 0;
}


void CAse::MakeInherite()
{
	MESH* Child;
	MESH* Parents;
	Child = m_MeshList;

	while(Child)
	{
		if(Child->m_bParents)
		{
			Parents = Search(Child->m_ParentName);
			if(Parents)
			{
				Child->m_pParents = Parents;
				Parents->AddChild(Child);
			}
			else
			{
				Parents = SearchBone(Child->m_ParentName);
				Child->m_pParents = Parents;
			}
		}
		Child = Child->m_pNext;
	}

	Child = m_BoneList;
	while(Child)
	{
		if(Child->m_bParents)
		{
			Parents = SearchBone(Child->m_ParentName);
			if(Parents)
			{
				Child->m_pParents = Parents;
				Parents->AddChild(Child);
			}
		}
		Child = Child->m_pNext;
	}

}

MESH* CAse::Search(char* name)
{
	MESH* CMesh = m_MeshList;
	while(CMesh)
	{
		if(_stricmp(name, CMesh->m_Name) == 0) return CMesh;
		CMesh = CMesh->m_pNext;
	}

	return NULL;
}

MESH* CAse::SearchBone(char* name)
{
	MESH* CMesh = m_BoneList;
	while(CMesh)
	{
		if(_stricmp(name, CMesh->m_Name)==0)return CMesh;
		CMesh = CMesh->m_pNext;
	}
	return NULL;
}

void CAse::Release()
{

	for(int i=0; i < m_iNumMaterial; i++)
	{
		if(m_MaterialList[i].bUseTexture)
		{
			if(m_MaterialList[i].pTexture)
				m_MaterialList[i].pTexture->Release();
			m_MaterialList[i].pTexture = NULL;
		}
		for(int j=0; j<m_MaterialList[i].SubMaterialCount; j++)
		{
			if(m_MaterialList[i].SubMaterial[j].bUseTexture)
			{
				if(m_MaterialList[i].SubMaterial[j].pTexture)
					m_MaterialList[i].SubMaterial[j].pTexture->Release();
				m_MaterialList[i].SubMaterial[j].pTexture = NULL;
			}
		}
	}

	MESH* CurMesh = m_MeshList;

	while(CurMesh)
	{
		if(CurMesh->m_pMesh)
			CurMesh->m_pMesh->Release();
		CurMesh->m_pMesh = NULL;
		CurMesh = CurMesh->m_pNext;
	}
}

void CAse::SetAllMesh()
{
	MESH* Mesh = m_MeshList;
	int i;
	D3DXVECTOR3 vTemp;
	D3DXVECTOR3 vTemp2;
	D3DXMATRIX mat;

	while(Mesh)
	{
		D3DXMatrixInverse(&mat, 0, &(Mesh->m_TmMatrix));
		Mesh->m_InvTm = mat;
		for(i = 0; i < Mesh->m_iNumVertex; i++)
		{
			vTemp = Mesh->m_VertexList[i];
			D3DXVec3TransformCoord(&vTemp2,&vTemp, &mat);
			Mesh->m_VertexList[i] = vTemp2;
		}
		Mesh = Mesh->m_pNext;
	}
	
	Mesh = m_BoneList;

	while(Mesh)
	{
		D3DXMatrixInverse(&mat, 0, &(Mesh->m_TmMatrix));
		Mesh->m_InvTm = mat;
		for(i =0; i < Mesh->m_iNumVertex; i++)
		{
			vTemp = Mesh->m_VertexList[i];
			D3DXVec3TransformCoord(&vTemp2,&vTemp, &mat);
			Mesh->m_VertexList[i] = vTemp2;
		}
		Mesh = Mesh->m_pNext;
	}

}

int CAse::DecodeANIMATION(ANIMATION *Animation, FILE *fp)
{

	while(1)
	{
		m_ilinecount++;
		fgets(m_line, 256, fp);
		sscanf(m_line, "%s", m_string);


		if(_stricmp(m_string, "*NODE_NAME") == 0)
		{
			sscanf(m_line, "%s %s", m_string, Animation->m_Name);
			continue;
		}

		if(_stricmp(m_string, "*CONTROL_ROT_TRACK") == 0 || _stricmp(m_string, "*CONTROL_ROT_TCB") == 0
				|| _stricmp(m_string,"*CONTROL_ROT_BEZIER")==0)
		{
			DecodeROT_TRACK(Animation, fp);
			continue;
		}

		if(_stricmp(m_string, "*CONTROL_SCALE_TRACK") == 0 || _stricmp(m_string, "*CONTROL_SCALE_TCB") == 0
			|| _stricmp(m_string,"*CONTROL_SCALE_BEZIER")==0)
		{
			DecodeSCALE_TRACK(Animation,fp);
			continue;
		}

		if(   _stricmp(m_string, "*CONTROL_POS_TRACK")==0  || _stricmp(m_string, "*CONTROL_POS_TCB")==0
			|| _stricmp(m_string,"*CONTROL_POS_BEZIER")==0)
		{
			DecodePOS_TRACK(Animation,fp);
			continue;
		}


		if ( _stricmp(m_string, "}") == 0 ) return 0;
	}

	return 1;

}

int CAse::DecodeROT_TRACK(ANIMATION *Animation, FILE *fp)
{
 	ROT_TRACK* Temp;
	ROT_TRACK* Tail = NULL;
	if(Animation->m_Rot)
		delete Animation->m_Rot;

	Animation->m_Rot = NULL;
	D3DXVECTOR3 ReadRot;

	D3DXQUATERNION TmqR = m_CurMesh->m_TmRot;
	float fW;
	D3DXQUATERNION qR;


	while (1)
	{
		m_ilinecount++;
		fgets(m_line, 256, fp);
		sscanf(m_line, "%s", m_string);
		if ( _stricmp(m_string, "}") == 0 )
		{
			return 0;
		}


		Temp = new ROT_TRACK;
		sscanf(m_line, "%s%d%f%f%f%f", m_string, &(Temp->index), &ReadRot.x, &ReadRot.z, &ReadRot.y, &fW);
		Temp->x = ReadRot.x;
		Temp->y = ReadRot.y;
		Temp->z = ReadRot.z;
		Temp->w = fW;

		qR.x = (float)sinf(fW/2.0f) * ReadRot.x;
		qR.y = (float)sinf(fW/2.0f) * ReadRot.y;
		qR.z = (float)sinf(fW/2.0f) * ReadRot.z;
		qR.w = (float)cosf(fW/2.0f);

		if(Tail == NULL)
		{
			Temp->qR = qR;
			Tail = Temp;
			Animation->m_Rot = Temp;
		}
		else
		{
			D3DXQuaternionMultiply(&Temp->qR, &Tail->qR, &qR);
			Tail->m_pNext = Temp;
			Temp->m_pPrev = Tail;
			Tail = Temp;
		}

	}

	return 1;
}

int CAse::DecodePOS_TRACK(ANIMATION *Animation, FILE *fp)
{
	POS_TRACK* Temp;
	POS_TRACK* Tail=NULL;
	if(Animation->m_Pos)
		delete Animation->m_Pos;
	Animation->m_Pos = NULL;
	D3DXVECTOR3 vTemp;

	while (1)
	{
		m_ilinecount++;
		fgets(m_line, 256, fp);
		sscanf(m_line, "%s", m_string);
		if ( _stricmp(m_string, "}") == 0 ) return 0;
		Temp = new POS_TRACK;
		sscanf(m_line, "%s%d%f%f%f", m_string, &(Temp->Index), &(vTemp.x),&(vTemp.z),&(vTemp.y));
		Temp->Pos = vTemp;
		if(Animation->m_Pos == NULL)
		{
			Animation->m_Pos = Temp;
			Tail = Temp;
		}
		else
		{
			Tail->m_pNext = Temp;
			Temp->m_pPrev = Tail;
			Tail = Temp;
		}
	}

	return 1;
}

int CAse::DecodeSCALE_TRACK(ANIMATION *Animation, FILE *fp)
{
//    SCALE_TRACK* Temp;
	SCALE_TRACK* Tail=NULL;
	if(Animation->m_Scale)
		delete Animation->m_Scale;
	Animation->m_Scale = NULL;

	while (1)
	{
		m_ilinecount++;
		fgets(m_line, 256, fp);
		sscanf(m_line, "%s", m_string);
		if ( _stricmp(m_string, "}") == 0 ) return 0;
	}

	return 1;
}

void CAse::Animation(D3DXMATRIX mat, float frame)
{
	MESH* CurMesh = m_MeshList;

	while(CurMesh)
	{
		if(m_BoneList)
		{
			if(CurMesh->m_bParents)
				CurMesh->AnimateMatrix(&CurMesh->m_pParents->m_CalcMatrix, frame);
		}
		else
		{
			if(!CurMesh->m_bParents)
				CurMesh->AnimateMatrix(&mat, frame);
		}
		CurMesh = CurMesh->m_pNext;
	}
}

void CAse::BoneAnimation(D3DXMATRIX mat, float frame)
{
	MESH* CurMesh = m_BoneList;

	while(CurMesh)
	{
		if(!CurMesh->m_bParents)
			CurMesh->AnimateMatrix(&mat, frame);
		CurMesh = CurMesh->m_pNext;
	}

}



