#include "_Stdafx.h"
#include "define.h"
#include "Terrain.h"
#include "Frustum.h"
#include "Stage.h"
#include "TerrainManager.h"


CTerrainManager::CTerrainManager()		
{
	m_iMaxNum = 0;
	m_iMaxTexNum = 0;
	m_iRepeatNum = 0;
	m_fp = NULL;
	m_lpDevice = NULL;
	m_lpTerrainTex = NULL;
	m_Check = NULL;
	m_IDX = NULL;
	m_IDZ = NULL;
	m_fCameraIDX = 0;
	m_fCameraIDZ = 0;
	m_terrain = NULL;
	m_CheckMini = NULL;
	m_fH = 0.0f;
}

CTerrainManager::~CTerrainManager()
{
	
}

void CTerrainManager::ShutDown()
{

	if(m_fp != NULL)
		fclose(m_fp);

	for(int i = 0; i < m_iMaxTexNum; i++)
		SAFE_RELEASE(m_lpTerrainTex[i]);

	if(m_lpTerrainTex != NULL)
		SAFE_DELETE_ARRAY(m_lpTerrainTex);

	for(int i = 0; i < m_iMaxNum; i++)
	{
		m_terrain[i].ShutDown();
	}

	SAFE_DELETE_ARRAY(m_terrain);

	if(m_Check != NULL)
		SAFE_DELETE_ARRAY(m_Check);

	if(m_CheckMini != NULL)
		SAFE_DELETE_ARRAY(m_CheckMini);

	if(m_IDX != NULL)
		SAFE_DELETE_ARRAY(m_IDX);

	if(m_IDZ != NULL)
		SAFE_DELETE_ARRAY(m_IDZ);

}

void CTerrainManager::SetDevice(LPDIRECT3DDEVICE9 lpD3dDevice)
{
	m_lpDevice = lpD3dDevice;

	m_state = CStage::GetInstance();
}

HRESULT CTerrainManager::ReadMapNum()
{
	if(m_fp == NULL)
	{
		MessageBox(NULL, "�� ���� �б� ����", NULL, NULL);
	}
	char line[200];
	char string[80];

	while(feof(m_fp) == NULL)
	{
		fgets(line, 256, m_fp);			//�� �������� �� �پ� �о�´�.
		sscanf(line, "%s", string);		//�� �ٿ��� �� ó�� ���ڿ��� �о���δ�.
		if(_stricmp(string, "*") == 0)
			continue;

		if(_stricmp(string, "MAXNUM") == 0)
		{
			fgets(line, 256, m_fp);
			sscanf(line, "%d", &m_iMaxNum);
			return S_OK;
		}

		if(_stricmp(string, "MAXTEXNUM") == 0)
		{
			fgets(line, 256, m_fp);
			sscanf(line, "%d", &m_iMaxTexNum);
			return S_OK;
		}

	}

	return S_OK;
}


void CTerrainManager::FileOpen(LPSTR lpFilename)
{
	m_fp = fopen(lpFilename, "rt");
}



void CTerrainManager::FileClose()
{
	fclose(m_fp);
	m_fp = NULL;
}


HRESULT CTerrainManager::ReadMap(LPSTR lpFilename)
{
	
	char line[200];

	fgets(line, 256, m_fp);

	sscanf(line, "%s%d%d%d%d%s%s%d%d%d%d%s", &m_cStrMap, &m_ix, &m_iz, &m_imapIDX, &m_imapIDY
										 , &m_cStrAlphaMap1, &m_cStrAlphaMap2, &m_iMultiTexType[0]
										 , &m_iMultiTexType[1], &m_iMultiTexType[2], &m_iRepeatNum
										 , m_cStrLightMap);

    return S_OK;

}


HRESULT CTerrainManager::ReadMapTexture(LPSTR lpFilename)
{
	FileOpen(lpFilename);
	
	if(m_fp == NULL)
		return E_FAIL;

	ReadMapNum();	
	char line[200];

	m_lpTerrainTex = new LPDIRECT3DTEXTURE9[m_iMaxTexNum];

	for(int i = 0; i < m_iMaxTexNum; i++)
	{


		fgets(line, 256, m_fp);
		sscanf(line, "%s", m_cStrMap);

		if(FAILED(D3DXCreateTextureFromFileEx(m_lpDevice,
			m_cStrMap, 129, 129, 1,
			0, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, 
			D3DX_FILTER_NONE, D3DX_FILTER_NONE, NULL, NULL, NULL,  &m_lpTerrainTex[i])))
			return false;


//		if(FAILED(D3DXCreateTextureFromFile(m_lpDevice, m_cStrMap, &m_lpTerrainTex[i])))
//			return E_FAIL;
	}

	FileClose();

	return S_OK;

}


HRESULT CTerrainManager::MapCreate(float fFar, LPSTR lpFilename)
{

	FileOpen(lpFilename);

	ReadMapNum();
	if(m_fp == NULL)
		return E_FAIL;

	m_terrain = new CTerrain[m_iMaxNum];
	m_Check = new BOOL[m_iMaxNum];
	m_CheckMini = new BOOL[m_iMaxNum];
	m_IDX = new int[m_iMaxNum];
	m_IDZ = new int[m_iMaxNum];


	memset(m_Check, FALSE,sizeof(m_Check));
	memset(m_CheckMini, FALSE,sizeof(m_CheckMini));

	for(int i=0; i < m_iMaxNum; i++)
	{
		ReadMap(lpFilename);
		if( FAILED( m_terrain[i].Create( m_lpDevice, m_ix, m_iz, m_cStrMap, m_imapIDX,m_imapIDY,m_cStrAlphaMap1, m_cStrAlphaMap2,
										m_lpTerrainTex[m_iMultiTexType[0]],m_lpTerrainTex[m_iMultiTexType[1]]
										,m_lpTerrainTex[m_iMultiTexType[2]],m_iRepeatNum,m_cStrLightMap)))
		{
			return E_FAIL;
		}
		m_terrain[i].OperationDistance(fFar);
		m_terrain[i].SetID(m_IDX[i], m_IDZ[i]);

	}

	FileClose();

	return S_OK;
}

void CTerrainManager::DrawMap()
{
	if(m_lpDevice == NULL)
		return;
	
	D3DXMATRIXA16 world;
	D3DXMATRIXA16 view;
	D3DXMATRIXA16 proj;
	D3DXMATRIXA16 vp;
	
	D3DXMatrixIdentity(&world);

	m_lpDevice->GetTransform(D3DTS_VIEW, &view);
	m_lpDevice->GetTransform(D3DTS_PROJECTION, &proj);
	
	vp = view * proj;
	
 	m_frustrum.Construct(&proj, &view);		//���ν����� ���� �Ŀ� ������ �Ѱ��ش�.

//	m_frustrum.Make(&vp);		//���ν����� ���� �Ŀ� ������ �Ѱ��ش�.


	m_lpDevice->SetTransform(D3DTS_WORLD, &world);

	int iCH = 0;
	for(int i=0; i < m_iMaxNum; i++)
	{
		
		if(m_state->GetStage() >= 2.5f && m_state->GetStage() <= 7.0f)
			iCH = 1;

		m_terrain[i].Draw(&m_frustrum, m_Check[i], iCH, 0);
	}

	for(int i =0; i < 5; i++)
	{
		m_lpDevice->SetTexture( i,  NULL );
		m_lpDevice->SetTextureStageState( i, D3DTSS_TEXCOORDINDEX, NULL );
	}

}

void CTerrainManager::DrawMiniMap()
{
	if(m_lpDevice == NULL)
		return;

	D3DXMATRIXA16 world;
	D3DXMATRIXA16 view;
	D3DXMATRIXA16 proj;
	D3DXMATRIXA16 vp;

	D3DXMatrixIdentity(&world);

	m_lpDevice->GetTransform(D3DTS_VIEW, &view);
	m_lpDevice->GetTransform(D3DTS_PROJECTION, &proj);

	vp = view * proj;

	m_frustrum.Construct(&proj, &view);		//���ν����� ���� �Ŀ� ������ �Ѱ��ش�.
//	m_frustrum.Make(&vp);		//���ν����� ���� �Ŀ� ������ �Ѱ��ش�.

	m_lpDevice->SetTransform(D3DTS_WORLD, &world);

 
	int iCH = 0;
	for(int i=0; i < m_iMaxNum; i++)
	{
		if(m_state->GetStage() >= 2.5f && m_state->GetStage() <= 7.0f)
			iCH = 1;

 		m_terrain[i].Draw(&m_frustrum,m_CheckMini[i], iCH, 1);
	}

	for(int i =0; i < 5; i++)
	{
		m_lpDevice->SetTexture( i,  NULL );
		m_lpDevice->SetTextureStageState( i, D3DTSS_TEXCOORDINDEX, NULL );
	}

}

void CTerrainManager::OnShadowOption()
{

	m_lpDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_lpDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_lpDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	m_lpDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
	m_lpDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );

	m_lpDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	m_lpDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_lpDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );

}


void CTerrainManager::DrawShadowMap(LPD3DXEFFECT ShadowEffect)
{
	OnShadowOption();

	D3DXMATRIXA16 world;
	D3DXMatrixIdentity(&world);

	m_lpDevice->SetTransform(D3DTS_WORLD, &world);
	for(int i=0; i < m_iMaxNum; i++)
	{
		if(i != 6 && i != 7 && i != 15)
			m_terrain[i].DrawShadow(ShadowEffect);
	}

	OffShadowOption();
}

void CTerrainManager::OffShadowOption()
{
	m_lpDevice->SetTexture(0, NULL);
	m_lpDevice->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
}


void CTerrainManager::GetSearchTerrainIdx(float x, float z)
{
	float TerrainHeight = 0.0f;
	//ī�޶��� ��ġ�� �޾� �ε����� �˾Ƴ���.
	float sizeX = (float)m_terrain[0].GetCXDIB();
	float sizeZ = (float)m_terrain[0].GetCZDIB();

	m_fCameraIDX = x/(sizeX - 1);
	m_fCameraIDZ = z/(sizeZ - 1);
	
	float col =  x/(sizeX - 1);
	float row =  z/(sizeZ - 1);

	col = floorf(col);
	row = floorf(row);
	int iID = 0;


	//������ �ε����� ���Ͽ� ���� �ε����� ���� ã�´�.
	for(int i = 0; i < m_iMaxNum; i++)
	{
//		if(m_fCameraIDX == m_terrain[i].GetMapIDX() && m_fCameraIDZ == m_terrain[i].GetMapIDZ())
//		{

		if(col == m_terrain[i].GetMapIDX() && row == m_terrain[i].GetMapIDZ())
		{

			iID = i;
			//�ش������� y���� ���´�.
			m_fH = m_terrain[i].GetHeight(x, z) + 0.5f;
			break;

//			return TerrainHeight;
		}
	}

//	return 0.0f;
}


void CTerrainManager::DrawWaterTerrain()
{
	D3DXMATRIXA16 world;
	D3DXMATRIXA16 view;
	D3DXMATRIXA16 proj;
	D3DXMATRIXA16 vp;

	m_lpDevice->GetTransform(D3DTS_VIEW, &view);
	m_lpDevice->GetTransform(D3DTS_PROJECTION, &proj);

	vp = view * proj;

	m_frustrum.Construct(&proj, &view);		//���ν����� ���� �Ŀ� ������ �Ѱ��ش�.
//	m_frustrum.Make(&vp);		//���ν����� ���� �Ŀ� ������ �Ѱ��ش�.

	D3DXMatrixIdentity(&world);

	m_lpDevice->SetTransform(D3DTS_WORLD, &world);
 	m_terrain[13].Draw(&m_frustrum, m_Check[13], 0,  0);
}

