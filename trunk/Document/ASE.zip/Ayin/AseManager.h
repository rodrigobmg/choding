#pragma once


#define Stage2Num 3

class CAseManager
{
private:

	CAse    *m_Model;
	LPDIRECT3DDEVICE9 m_lpDevice;
	float	m_frame;

	D3DXMATRIX m_Scale;
	D3DXMATRIX m_XRotate;
	D3DXMATRIX m_YRotate;

	float m_ft;

	D3DXVECTOR3 m_vPos;
	float m_fRadius;


	//////////////////////////2�������� �� ///////////////////////////////////
	CAse *m_stage2Model;
	CWorld				*m_pWorld;
	UINT				m_uObectNum;		// ���� �޽ÿ����� �������� ����


	list<CWorld*> m_Object;					// ������Ʈ�� �����ϴ� ����Ʈ
	FILE* m_fp;								//���� �б�
	MINIMAPTEXTURE m_miniTex;				//�̴ϸ�
	UINT  m_uWorldNum;						//ase��� ������ ���ΰ�..?

	LPD3DXEFFECT m_FxStage2;
	UINT  m_uCollisionEx;

	D3DXMATRIXA16 m_matVP;
	D3DXVECTOR3 m_vMonsterPos;
	float m_fStage2Frame;


	int  m_iTotallNum;

	BOOL m_bCo;


	D3DXMATRIXA16 m_matTemp;			//�ӽ� ���߿� �����


	int m_life;


	float m_fEnd;
	float m_fEnd2;


	D3DXVECTOR3 m_vPos2;

public:
	CAseManager();
	~CAseManager();

	HRESULT InitAse(LPDIRECT3DDEVICE9 lpDevice);

	void PreOption();
	void PostOption();
	void RenderModel();
	void RenderShadowModel();
	void RenderMesh(MESH *CurMesh);
	void RenderShadow(MESH *CurMesh);

	void Update(int elapased,  D3DXMATRIX *world,float H,   int Key);
	void UpdateEnd(int elapased,  D3DXMATRIX *world, int Key);

	void ShutDown();


	void InitScale(D3DXVECTOR3 *Scale);
	void InitXRotate(float angle);
	void InitYRotate(float angle);
	
	float GetFrame(){return m_frame;}
	D3DXVECTOR3* GetPos(){return &m_vPos;}

	D3DXVECTOR3* GetPos2(){return &m_vPos2;}

	//////////////////////////2�������� ���� ///////////////////////////////////
 
	void AI();
	void RenderStage2(int elapsed);													//�׳� ����� ��
	void RenderStage2Model(MESH *CurMesh, int iPass, D3DXVECTOR4* vColor);

	void RenderShadowStage2(int elapsed);											//�׸��� ����� ��
	void RnderShadowStage2Model(MESH *CurMesh, int iPass, D3DXVECTOR4* vColor);

	void AseData(FILE *fp);
	HRESULT ReadMesh(LPDIRECT3DDEVICE9 pd3dDevice, LPSTR lpstr);
	void FileOpen(LPSTR lpFilename);
	void FileClose();
	HRESULT ReadMaxNum();
	UINT GetCollisionEx(){return m_uCollisionEx;}
	MINIMAPTEXTURE GetMiniMap(){return m_miniTex;}
	void UpdateStage2(CAse* Model, D3DXMATRIXA16* world,BOOL bCollEx, int elapased);
	void BuildFX();							//���̴� 
	UINT GetWorldNum(){return m_uWorldNum;}

	void RenderMinMap(CMini *mini);
	
	list<CWorld*> GetList(){return m_Object;}


	void ObjectCollision(D3DXVECTOR3 *pos, BOOL *bCollisionEx);
	void CollisionBoss(D3DXVECTOR3 *pos, BOOL *bCollisionEx);


	int  GetObjectNum(){return (int)m_Object.size();}

	void SetTotalNum(int i){m_iTotallNum -= i;}
	int GetTotalNum(){return m_iTotallNum;}


	int GetLife(){return m_life;}	
};





