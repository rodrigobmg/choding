#pragma once



//class CStage;

class CGameLogic
{
private:
	LPDIRECT3DDEVICE9 m_lpDevice;
	
	float m_fSumElapsed;
	float m_fSumElapsed2;
	
	CStage *m_stage;

public:
	CGameLogic();
	~CGameLogic();
	void ShutDown();


	void InitLogic(LPDIRECT3DDEVICE9 lpDevice);
	void Logic(CAseManager* aseManager, CTerrainManager *terrainManager, CSMeshManager *meshManager, CSMeshManager *shaderStage2mesh, CInputManager *inputManager,CUIManager *ui, CFont *font, int elapsed);
	void DrawFont(CFont *font, CInputManager *inputManager, int iNum, CAseManager* aseManager);
	void Fog();

}; 