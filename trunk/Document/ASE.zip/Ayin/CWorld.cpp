#include "_Stdafx.h"
#include "CWorld.h"

// ID3DXSPRITE���� begin() �׸��⸦ ������ �� ���� D3DXSprite__BILLBOARD �� D3DXSPRITE_OBJECTSPACE�� �̿��ϸ�
// �� �������� ���ɼ��� �ִ�.(������ �����ʰ�)

CWorld::CWorld()
{
	m_Billboard = FALSE;
	m_matCombine1 = m_matCombine2 = NULL;

	Move(0.0f, 0.0f, 0.0f);
	Rotate(0.0f, 0.0f, 0.0f);
	Scale(1.0f, 1.0f, 1.0f);

	Update();
	D3DXMatrixIdentity(&m_matWorld);

	m_option = 0;
	m_pass = 0; 

	m_InitXPos = m_InitYPos = m_InitZPos = 0.0f;

	m_vCenter = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_fRadius = 0.0f;

	m_SphereMesh = NULL;
	m_BoxMesh = NULL;

	m_vPosCenter = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_vPosition = D3DXVECTOR3(0.0f, 0.0f, 0.0f);


	m_bCollisionEx = FALSE;
 }

CWorld::~CWorld()
{
	SAFE_RELEASE(m_SphereMesh);
	SAFE_RELEASE(m_BoxMesh);
}

BOOL CWorld::Copy(CWorld *DestPos)
{
	DestPos->Move(m_XPos, m_YPos, m_ZPos);
	DestPos->Rotate(m_XRotation, m_YRotation, m_ZRotation);
	DestPos->Scale(m_XScale, m_YScale, m_ZScale);
	DestPos->EnableBillboard(m_Billboard);

	return TRUE;
}

void CWorld::CreateSphere()
{
	D3DXCreateSphere(m_lpDevice, m_fRadius, 20, 20, &m_SphereMesh, 0);
}

void CWorld::CreateBox()
{
	D3DXCreateBox(m_lpDevice, m_vMax.x - m_vMin.x,
		m_vMax.y - m_vMin.y,
		m_vMax.z - m_vMin.z,
		&m_BoxMesh, 0);

}

void CWorld::DrawSphere()
{

	if(NULL == m_SphereMesh )
		return;

	D3DXMATRIX mat;
	D3DMATERIAL9 mtrl;
	D3DXCOLOR BLACK;

	mtrl.Diffuse.r = mtrl.Ambient.r =  mtrl.Specular.r = 1.0f;
	mtrl.Diffuse.g = mtrl.Ambient.g =  mtrl.Specular.g = 0.0f;
	mtrl.Diffuse.b = mtrl.Ambient.b =  mtrl.Specular.b = 0.0f;

	mtrl.Diffuse.a = 0.5f;
	D3DXMatrixIdentity(&mat);


	m_lpDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
//	m_lpDevice->SetMaterial(&mtrl);
//	m_lpDevice->SetTexture(0, 0); // disable texture

//	m_lpDevice->SetRenderState( D3DRS_LIGHTING, TRUE);
//	m_lpDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
//	m_lpDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
//	m_lpDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

//	D3DXMatrixTranslation(&mat, m_vCenter.x, m_vCenter.y, m_vCenter.z);
	
//	D3DXMatrixMultiply(&mat, &mat, &m_matWorld);

	m_lpDevice->SetTransform(D3DTS_WORLD, &m_matWorld);

	m_SphereMesh->DrawSubset(0);

//	m_lpDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
	m_lpDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID );
//	m_lpDevice->SetRenderState( D3DRS_LIGHTING, false);
}

void CWorld::DrawBox()
{
	if(NULL == m_BoxMesh )
		return;


	D3DXMATRIX mat;
	D3DMATERIAL9 mtrl;
	D3DXCOLOR BLACK;

	mtrl.Diffuse.r = mtrl.Ambient.r =  mtrl.Specular.r = 0.0f;
	mtrl.Diffuse.g = mtrl.Ambient.g =  mtrl.Specular.g = 0.0f;
	mtrl.Diffuse.b = mtrl.Ambient.b =  mtrl.Specular.b = 1.0f;

	mtrl.Diffuse.a = 0.10f;
	D3DXMatrixIdentity(&mat);

	m_lpDevice->SetMaterial(&mtrl);
	m_lpDevice->SetTexture(0, 0); // disable texture

	m_lpDevice->SetRenderState( D3DRS_LIGHTING, TRUE);
	m_lpDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, true);
	m_lpDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_lpDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

//	D3DXMatrixTranslation(&mat, m_vCenter.x, m_vCenter.y, m_vCenter.z);

//	D3DXMatrixMultiply(&mat, &mat, &m_matWorld);

	m_lpDevice->SetTransform(D3DTS_WORLD, &m_matWorld);

	m_BoxMesh->DrawSubset(0);

	m_lpDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
	m_lpDevice->SetRenderState( D3DRS_LIGHTING, false);
}

BOOL CWorld::Move(FLOAT XPos, FLOAT YPos, FLOAT ZPos)
{
	m_vPosition.x = m_XPos = XPos;
	m_vPosition.y = m_YPos = YPos;
	m_vPosition.y += 3.0f;
	m_vPosition.z = m_ZPos = ZPos; 

	D3DXMatrixTranslation(&m_matTranslation, m_XPos, m_YPos, m_ZPos);

	return TRUE;
}

BOOL CWorld::MoveRel(FLOAT XAdd, FLOAT YAdd, FLOAT ZAdd)
{
	return Move(m_InitXPos+XAdd, m_InitYPos+YAdd, m_InitZPos+ZAdd);
}

BOOL CWorld::Rotate(FLOAT XRot, FLOAT YRot, FLOAT ZRot)
{
	m_XRotation = XRot;
	m_YRotation = YRot;
	m_ZRotation = ZRot;

	D3DXMatrixRotationYawPitchRoll(&m_matRotation, m_YRotation, m_XRotation, m_ZRotation);
	
	return TRUE;
}

BOOL CWorld::RotateRel(FLOAT XAdd, FLOAT YAdd, FLOAT ZAdd)
{
	return Rotate(m_XRotation+XAdd, m_YRotation+YAdd, m_ZRotation+ZAdd);
}

BOOL CWorld::Scale(FLOAT XSCale, FLOAT YScale, FLOAT ZSCale)
{
	m_XScale = XSCale;
	m_YScale = YScale;
	m_ZScale = ZSCale;

	D3DXMatrixScaling(&m_matScale, m_XScale, m_YScale, m_ZScale);

	return TRUE;
}

BOOL CWorld::ScaleRel(FLOAT XAdd, FLOAT YAdd, FLOAT ZAdd)
{
	return Scale(m_XScale+XAdd, m_YScale+YAdd, m_ZScale+ZAdd);
}

BOOL CWorld::Update(LPDIRECT3DDEVICE9 Graphics)
{
	D3DXMATRIXA16 matView, matTransposed;

	//Setup billboarding matrix
	if(m_Billboard == TRUE)
	{
		if(Graphics != NULL)
		{
			// Y�� ȸ�� 11 13 31 33
			D3DXMATRIXA16 Temp;
			D3DXMatrixIdentity(&Temp);
			Graphics->GetTransform(D3DTS_VIEW, &matView);
			// �̴�� ���� �����̳� �Ʒ��ʿ��� ī�޶����� �ٶ󺸱� ������ �������� ��� ���������� �ȴ�.
			// y�� ������� ��Ű�� y�� ȸ���� ���õǱ� ������ �ذ�ȴ�.
			Temp._11 = matView._11;
			Temp._13 = matView._13;
			Temp._31 = matView._31;
			Temp._33 = matView._33;
			// ������� ����Ͽ� transpose(��ġ) �����ϸ� �ӵ��� ������ �ξ� ����ȭ�� �ȴ�
			D3DXMatrixTranspose(&matTransposed, &Temp);
			matTransposed._41 = matTransposed._42 = matTransposed._43 = matTransposed._14 = matTransposed._24 = matTransposed._34 = 0.0f;
			// 41 42 43 �κ��� ��ü�� �̵��κ��̰�, 14 24 34�� 44�� ���� ������ �����̱⿡ 0�� �ִ´�.

		}
		else
		{
			D3DXMatrixIdentity(&matTransposed);
		}
	}

	//Combine scaling and rotation matrices first
	D3DXMatrixMultiply(&m_matWorld, &m_matScale, &m_matRotation);

	//Apply billboard matrix
	if(m_Billboard == TRUE)  // SRT���� R�� T���̿� �� �����带 ������� �Ѵ�.
		D3DXMatrixMultiply(&m_matWorld, &m_matWorld, &matTransposed);
	
	//Combine with translation matrix
	D3DXMatrixMultiply(&m_matWorld, &m_matWorld, &m_matTranslation);

	//Combine with combined matrices (if any)
	if(m_matCombine1 != NULL)
		D3DXMatrixMultiply(&m_matWorld, &m_matWorld, m_matCombine1);
	if(m_matCombine2 != NULL)
		D3DXMatrixMultiply(&m_matWorld, &m_matWorld, m_matCombine2);

	return TRUE;
}

BOOL CWorld::EnableBillboard(BOOL Enable)
{
	m_Billboard = Enable;
	return TRUE;
}

D3DXMATRIXA16 *CWorld::GetMatrix(LPDIRECT3DDEVICE9 Graphics)
{
	Update(Graphics);
	return &m_matWorld;
}

BOOL CWorld::SetCombineMatrix1(D3DXMATRIXA16 *Matrix)
{
	m_matCombine1 = Matrix;
	return TRUE;
}

BOOL CWorld::SetCombineMatrix2(D3DXMATRIXA16 *Matrix)
{
	m_matCombine2 = Matrix;
	return TRUE;
}

FLOAT CWorld::GetXPos()
{
	return m_XPos;
}

FLOAT CWorld::GetYPos()
{
	return m_YPos;
}



FLOAT CWorld::GetZPos()
{
	return m_ZPos;
}

FLOAT CWorld::GetXRotation()
{
	return m_XRotation;
}

FLOAT CWorld::GetYRotation()
{
	return m_YRotation;
}

FLOAT CWorld::GetZRotation()
{
	return m_ZRotation;
}

FLOAT CWorld::GetXScale()
{
	return m_XScale;
}

FLOAT CWorld::GetYScale()
{
	return m_YScale;
}

FLOAT CWorld::GetZScale()
{
	return m_ZScale;
}