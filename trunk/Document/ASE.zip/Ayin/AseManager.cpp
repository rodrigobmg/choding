#include "_Stdafx.h"
#include "Stage.h"
#include "define.h"
#include "CWorld.h"
#include "Ase.h"
#include "Mini.h"
#include "AseManager.h"


CAseManager::CAseManager()
{
	m_Model = NULL;

	m_frame = 1374.0f;
	m_ft = 0.0f;


	D3DXMatrixIdentity(&m_Scale);
	D3DXMatrixIdentity(&m_XRotate);
	D3DXMatrixIdentity(&m_YRotate);

	m_vPos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		
	//�ɸ����� ������ �뷫 ������.
	m_fRadius =  5.0f;

	m_stage2Model = NULL;
	m_uObectNum = 0;
	m_pWorld = NULL;
	m_uWorldNum= 0;
	m_uCollisionEx = 0;

	m_fStage2Frame = 0.0f;
	m_FxStage2 = NULL;

	m_iTotallNum = 0;

	m_bCo = FALSE;

	m_life = 1;

	m_fEnd = 0.0f;
	m_fEnd2 = 0.0f;
}

CAseManager::~CAseManager()
{

}

HRESULT CAseManager::InitAse(LPDIRECT3DDEVICE9 lpDevice)
{
	m_lpDevice = lpDevice;
	if(m_Model == NULL)
	{
		m_Model = new CAse;
		BOOL BL;
		m_Model->SetDevice(lpDevice);
		if(!(BL = m_Model->ReadASE("./Image/Ase/woman.ase")))
		{
			return E_FAIL;
		}

	}

	return S_OK;
}

void CAseManager::InitScale(D3DXVECTOR3 *Scale)
{
	D3DXMatrixScaling(&m_Scale, Scale->x, Scale->y, Scale->z);
}

void CAseManager::InitXRotate(float angle)
{
	D3DXMatrixRotationX(&m_XRotate, angle);
}

void CAseManager::InitYRotate(float angle)
{	
	D3DXMatrixRotationY(&m_YRotate, angle);
}

void CAseManager::RenderModel()
{
	MESH* pMesh = m_Model->m_MeshList;

	while(pMesh)
	{
		RenderMesh(pMesh);
		pMesh = pMesh->m_pNext;
	}

}

void CAseManager::Update(int elapased, D3DXMATRIX *world, float H, int Key)
{

	//�ɸ����� ��ġ�� ��´�.
	m_vPos = D3DXVECTOR3((*world)._41, (*world)._42, (*world)._43);

	float tempFrame = m_frame;

	
	if(Key == TRUE)
	{

		m_frame += 0.0008f*elapased * m_Model->m_FrameSpeed * m_Model->m_TickPerFrame;
		tempFrame = m_frame;
		if(m_frame >= m_Model->m_LastFrame * m_Model->m_TickPerFrame)m_frame = 0;
		m_ft = 0;

	}
	else
	{
		tempFrame = m_frame + (1374.0f  - m_frame)*m_ft;
		m_ft += 0.07f * elapased;
		if(m_ft > 1.0f)
			m_ft = 1.0f;
	}



	D3DXMATRIX Temp;
	D3DXMatrixIdentity(&Temp);


	(*world)._42 = H-1.0f;
	D3DXMatrixMultiply(&Temp, &m_Scale, &m_YRotate);
//	D3DXMatrixMultiply(&Temp, &m_Scale, &m_XRotate);
	D3DXMatrixMultiply(&Temp, &Temp, &(*world));



	m_Model->BoneAnimation(Temp, tempFrame);
	m_Model->Animation(Temp, tempFrame);

}


void CAseManager::UpdateEnd(int elapased, D3DXMATRIX *world, int Key)
{

	CStage *stage = CStage::GetInstance();

	if(stage->GetStage() == 13.0f)
	{
		m_fEnd += 0.5f;
	
		m_fEnd2 = 1.0f;

		m_vPos = D3DXVECTOR3((*world)._41, (*world)._42 =+m_fEnd, (*world)._43);
	}
	else
	{
		m_fEnd2 = 30.0f;
		//�ɸ����� ��ġ�� ��´�.
		m_vPos = D3DXVECTOR3((*world)._41, (*world)._42, (*world)._43);
	}
	

	float tempFrame = m_frame;
	if(Key == TRUE)
	{

		m_frame += 0.0008f*elapased * m_Model->m_FrameSpeed * m_Model->m_TickPerFrame;
		tempFrame = m_frame;
		if(m_frame >= m_Model->m_LastFrame * m_Model->m_TickPerFrame)m_frame = 0;
		m_ft = 0;

	}
	else
	{
		tempFrame = m_frame + (1374.0f  - m_frame)*m_ft;
		m_ft += 0.07f * elapased;
		if(m_ft > 1.0f)
			m_ft = 1.0f;
	}

	D3DXMATRIX Temp;
	D3DXMatrixIdentity(&Temp);

	D3DXMATRIXA16 Rote;

	D3DXMatrixRotationX(&Rote, -D3DX_PI/2 +m_fEnd2);

	D3DXMatrixMultiply(&Temp, &m_Scale, &m_YRotate);
	D3DXMatrixMultiply(&Temp, &Temp, &Rote);
	//	D3DXMatrixMultiply(&Temp, &m_Scale, &m_XRotate);
	D3DXMatrixMultiply(&Temp, &Temp, &(*world));

	m_Model->BoneAnimation(Temp, tempFrame);
	m_Model->Animation(Temp, tempFrame);

}

void CAseManager::PreOption()
{
	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);

}

void CAseManager::PostOption()
{
	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_DISABLE);
}
void CAseManager::RenderMesh(MESH *CurMesh)
{
	if(NULL == CurMesh)
	{
		MessageBox(0, "RenderMeshError", "Error", MB_OK);
		return;
	}
	
	PreOption();
	m_lpDevice->SetStreamSource(0, CurMesh->GetVertexBuffer(), 0,sizeof(sVERTEX));
	m_lpDevice->SetTransform(D3DTS_WORLD, &CurMesh->m_CalcMatrix);
	m_lpDevice->SetFVF(sVERTEX::FVF);
	m_lpDevice->SetTexture(0, CurMesh->m_pMaterial->pTexture);
	m_lpDevice->SetMaterial(&CurMesh->m_pMaterial->d3dMaterial);
	m_lpDevice->DrawPrimitive(D3DPT_TRIANGLELIST, 0, CurMesh->m_iNumTriagnle );
	PostOption();
}


////////////////////////////////////////////////////////////////////////////////////////////
//�׸��� �׸��� ����ϴ� �Լ���
void CAseManager::RenderShadowModel()
{
	MESH* pMesh = m_Model->m_MeshList;

	while(pMesh)
	{
		RenderShadow(pMesh);
		pMesh = pMesh->m_pNext;
	}

}

void CAseManager::RenderShadow(MESH *CurMesh)
{
	if(NULL == CurMesh)
	{
		MessageBox(0, "RenderMeshError", "Error", MB_OK);
		return;
	}
//	PreOption();

//	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE);
//	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
//	m_lpDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
//	m_lpDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTA_DIFFUSE);


	m_lpDevice->SetStreamSource(0, CurMesh->GetVertexBuffer(), 0,sizeof(sVERTEX));
	m_lpDevice->SetTransform(D3DTS_WORLD, &CurMesh->m_CalcMatrix);
	m_lpDevice->SetFVF(sVERTEX::FVF);
	m_lpDevice->SetTexture(0, CurMesh->m_pMaterial->pTexture);
	m_lpDevice->SetMaterial(&CurMesh->m_pMaterial->d3dMaterial);
	m_lpDevice->DrawPrimitive(D3DPT_TRIANGLELIST, 0, CurMesh->m_iNumTriagnle );

	
//	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
//	m_lpDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_DISABLE);


//	PostOption();
}


void CAseManager::ShutDown()
{
	SAFE_DELETE(m_Model);
	SAFE_DELETE_ARRAY(m_stage2Model);
	SAFE_DELETE_ARRAY(m_pWorld);
	SAFE_RELEASE(m_FxStage2);
}


void CAseManager::RenderStage2(int elapsed)
{

	D3DXMATRIXA16 matView, matProj;
	m_lpDevice->GetTransform(D3DTS_VIEW, &matView);
	m_lpDevice->GetTransform(D3DTS_PROJECTION, &matProj);

	m_matVP = matView * matProj;

	for(UINT i=0; i < m_uObectNum; i++)
	{
		list<CWorld*>::iterator it;

		for(it = m_Object.begin(); it != m_Object.end(); it++)
		{
			m_bCo = (*it)->GetCollision();

			UpdateStage2(&m_stage2Model[i], (*it)->GetMatrix(), (*it)->GetCollision(),elapsed);

			m_matTemp = *(*it)->GetMatrix();

			MESH* pMesh = m_stage2Model[i].m_MeshList;

			while(pMesh)
			{
				RenderStage2Model(pMesh, (*it)->GetPass(), (*it)->GetColor());
				pMesh = pMesh->m_pNext;
			}
		}
	}
}

void CAseManager::RenderStage2Model(MESH *CurMesh, int iPass, D3DXVECTOR4* vColor)
{

	if(NULL == CurMesh)
	{
		MessageBox(0, "RenderMeshError", "Error", MB_OK);
		return;
	}
	
	m_FxStage2->SetTechnique("TShader");
	m_FxStage2->Begin(NULL, 0);

	m_FxStage2->SetTexture("SrcMap",CurMesh->m_pMaterial->pTexture);

	if(m_bCo == FALSE)
		m_FxStage2->SetMatrix("matWVP", &(CurMesh->m_CalcMatrix*m_matVP ));
	else if(m_bCo == TRUE)
		m_FxStage2->SetMatrix("matWVP", &(m_matTemp*m_matVP ));
	

//	m_FxStage2->SetMatrix("matWVP", &(CurMesh->m_CalcMatrix));


//	m_FxStage2->SetVector("fColor", vColor);
	m_FxStage2->SetValue("fColor",vColor, sizeof(D3DXVECTOR4));

	//----------------------------------------------------------------------------
	//�̰����� �ϴ� ���� ���� �ؽ��Ŀ� ���� �ؽ��ĸ� ���� ������ �ϴ� ��.
	//----------------------------------------------------------------------------
	m_FxStage2->BeginPass(iPass);


	PreOption();
	m_lpDevice->SetStreamSource(0, CurMesh->GetVertexBuffer(), 0,sizeof(sVERTEX));
	//m_lpDevice->SetTransform(D3DTS_WORLD, (*it)->GetMatrix());
//	m_lpDevice->SetTransform(D3DTS_WORLD, &(CurMesh->m_CalcMatrix));
	m_lpDevice->SetFVF(sVERTEX::FVF);
//	m_lpDevice->SetTexture(0, CurMesh->m_pMaterial->pTexture);
//	m_lpDevice->SetMaterial(&CurMesh->m_pMaterial->d3dMaterial);
	m_lpDevice->DrawPrimitive(D3DPT_TRIANGLELIST, 0, CurMesh->m_iNumTriagnle );
	PostOption();

	m_FxStage2->EndPass();
	m_FxStage2->End();
	
	
}


void CAseManager::RenderShadowStage2(int elapsed)
{

	D3DXMATRIXA16 matView, matProj;
	m_lpDevice->GetTransform(D3DTS_VIEW, &matView);
	m_lpDevice->GetTransform(D3DTS_PROJECTION, &matProj);

	m_matVP = matView * matProj;

	for(UINT i=0; i < m_uObectNum; i++)
	{
		list<CWorld*>::iterator it;

		for(it = m_Object.begin(); it != m_Object.end(); it++)
		{
			UpdateStage2(&m_stage2Model[i], (*it)->GetMatrix(),(*it)->GetCollision(), elapsed);
			m_matTemp = *(*it)->GetMatrix();
			m_bCo = (*it)->GetCollision();
			MESH* pMesh = m_stage2Model[i].m_MeshList;
			
			while(pMesh)
			{
				RnderShadowStage2Model(pMesh, (*it)->GetPass(), (*it)->GetColor());
				pMesh = pMesh->m_pNext;
			}
		}
	}
}

void CAseManager::RnderShadowStage2Model(MESH *CurMesh, int iPass, D3DXVECTOR4* vColor)
{

	if(NULL == CurMesh)
	{
		MessageBox(0, "RenderMeshError", "Error", MB_OK);
		return;
	}

	m_FxStage2->SetTechnique("TShader");
	m_FxStage2->Begin(NULL, 0);

	m_FxStage2->SetTexture("SrcMap",CurMesh->m_pMaterial->pTexture);

	if(m_bCo == FALSE)
		m_FxStage2->SetMatrix("matWVP", &(CurMesh->m_CalcMatrix*m_matVP ));
	else if(m_bCo == TRUE)
		m_FxStage2->SetMatrix("matWVP", &(m_matTemp*m_matVP ));


	//	m_FxStage2->SetVector("fColor", vColor);
	m_FxStage2->SetValue("fColor",vColor, sizeof(D3DXVECTOR4));

	//----------------------------------------------------------------------------
	//�̰����� �ϴ� ���� ���� �ؽ��Ŀ� ���� �ؽ��ĸ� ���� ������ �ϴ� ��.
	//----------------------------------------------------------------------------
	m_FxStage2->BeginPass(0);

	m_lpDevice->SetStreamSource(0, CurMesh->GetVertexBuffer(), 0,sizeof(sVERTEX));
	//m_lpDevice->SetTransform(D3DTS_WORLD, (*it)->GetMatrix());
	m_lpDevice->SetTransform(D3DTS_WORLD, &(CurMesh->m_CalcMatrix));
	m_lpDevice->SetFVF(sVERTEX::FVF);
	m_lpDevice->DrawPrimitive(D3DPT_TRIANGLELIST, 0, CurMesh->m_iNumTriagnle );
	


	m_FxStage2->EndPass();
	m_FxStage2->End();

}


void CAseManager::UpdateStage2(CAse* Model, D3DXMATRIXA16* world,BOOL bCollEx, int elapased)
{
	
	//�ɸ����� ��ġ�� ��´�.
	m_vPos2 = D3DXVECTOR3((*world)._41, (*world)._42, (*world)._43);


	m_fStage2Frame += 0.0001f*elapased * m_Model->m_FrameSpeed * m_Model->m_TickPerFrame;
	if(m_fStage2Frame >= m_Model->m_LastFrame * m_Model->m_TickPerFrame)m_fStage2Frame = 0;


	D3DXMATRIX Temp;
	D3DXMatrixIdentity(&Temp);
	D3DXMatrixMultiply(&Temp, &Temp, &(*world));



	Model->BoneAnimation(Temp, m_fStage2Frame);
	Model->Animation(Temp, m_fStage2Frame);

}

VOID CAseManager::AseData(FILE *fp)
{
	

	char line[100];
	float sx, sy, sz, rx, ry, rz, tx, ty, tz;
	int iPass;
	float fRMul;
	int iColor;

	m_pWorld = new CWorld[m_uWorldNum];

	for(UINT i = 0; i < m_uWorldNum; i++)
	{

		fgets(line, 256, fp);	
		sscanf(line, "%f%f%f %f%f%f %f%f%f %d%f%d",  &sx, &sy, &sz, &rx, &ry, &rz, &tx, &ty, &tz, &iPass, &fRMul, &iColor);
		m_pWorld[i].SetDevice(m_lpDevice);
		m_pWorld[i].Scale(sx, sy, sz);
		m_pWorld[i].Rotate(rx, ry, rz);
 		m_pWorld[i].Move(tx, ty, tz);
		m_pWorld[i].Update(m_lpDevice); 

//		m_pWorld[i].SetRadius(m_fRadius);
		m_pWorld[i].SetRMul(fRMul);
//		m_pWorld[i].CreateSphere();

		m_pWorld[i].SetPass(iPass);
		m_pWorld[i].SetColor(iColor);
//		m_pWorld[i].SetOption(option);
	

		// �޽��� �����Ǻ��� �з��Ѵ�.
		float col = tx/(128.0f);
		float row = tz/(128.0f);
		m_pWorld[i].m_fIdX = floorf(col);
		m_pWorld[i].m_fIdZ = floorf(row);

		m_Object.push_back(&m_pWorld[i]);

	}

	m_iTotallNum = (int)m_Object.size();

}

// ���� ���� �޽���ŭ �޽�Ŭ������ �����Ѵ�.
HRESULT CAseManager::ReadMesh(LPDIRECT3DDEVICE9 lpDevice, LPSTR lpstr)
{

	if((m_lpDevice = lpDevice) == NULL)
		return E_FAIL;

	FileOpen(lpstr);
	ReadMaxNum();

	if(m_fp == NULL)
		return E_FAIL;

	char line[200];
	char strMeshAddr[50];

	m_stage2Model = new CAse[m_uObectNum];

	for(UINT i = 0; i< m_uObectNum; i++)
	{
		fgets(line, 256, m_fp);		// �� �������� �� �پ� �о�´�.
		sscanf(line, "%s%d%d%d", strMeshAddr, &m_uWorldNum,&m_uCollisionEx, &m_miniTex);
		m_stage2Model[i].SetDevice(lpDevice);

		if(!m_stage2Model[i].ReadASE(strMeshAddr))
			return E_FAIL;
	}

	AseData(m_fp);
	FileClose();

	BuildFX();				//���̴��� �ʱ�ȭ�Ѵ�.
	return S_OK;
}


void	CAseManager::FileOpen(LPSTR lpFilename)
{
	m_fp = fopen(lpFilename, "rt");
}


void	CAseManager::FileClose()
{
	if(m_fp != NULL)
		fclose(m_fp);
}


HRESULT CAseManager::ReadMaxNum()
{
	char line[200];
	char string[80];

	while(feof(m_fp) == NULL)
	{
		fgets(line, 256, m_fp);		// �� �������� �� �پ� �о�´�.
		sscanf(line, "%s", string); // �� �ٿ��� �� ó�� ���ڿ��� �о���δ�.
		if(_stricmp(string, "*") == 0){} // *�� �ּ�
		if(_stricmp(string, "MAXNUM") == 0)
		{
			fgets(line, 256, m_fp);
			sscanf(line, "%d", &m_uObectNum);	
			return S_OK;
		}
	}

	return S_OK;
}


void CAseManager::BuildFX()
{
	ID3DXBuffer* errors = 0;
	D3DXCreateEffectFromFile(m_lpDevice, "./Fx/Ase.fx",
		0, 0, D3DXSHADER_DEBUG, 0, &m_FxStage2, &errors);

	if( errors )
		MessageBoxA(0, (char*)errors->GetBufferPointer(), 0, 0);
}


void CAseManager::RenderMinMap(CMini *mini)
{
	list<CWorld*>::iterator it;

	for(it = m_Object.begin(); it != m_Object.end(); it++)
	{
		if((*it)->GetCollision() == FALSE)
			mini->Render((*it)->GetPosition(), m_miniTex);
	}
}

void CAseManager::ObjectCollision(D3DXVECTOR3 *pos, BOOL *bCollisionEx)
{


	list<CWorld*>::iterator it;

	for(it = m_Object.begin(); it != m_Object.end(); it++)
	{

		if((*it)->GetCollision() == FALSE)
		{
		
			D3DXVECTOR3 vDistance = *(*it)->GetPosition() - (*pos);
			float fDistance = D3DXVec3Length(&vDistance);

			float fRadiusParticl = 2.5f;
			float fRadiusObject = 2.0f;

			if(fDistance <= fRadiusParticl + fRadiusObject)
			{
				*bCollisionEx = TRUE;
				(*it)->SetCollision(*bCollisionEx);
				m_iTotallNum--;
				
	//			it = m_Object.erase(it);
	//			it--;
			}
		}
	}

}

void CAseManager::CollisionBoss(D3DXVECTOR3 *pos, BOOL *bCollisionEx)
{


	list<CWorld*>::iterator it;

	for(it = m_Object.begin(); it != m_Object.end(); it++)
	{

		int size = (int)m_Object.size();
		if((*it)->GetCollision() == FALSE)
		{


			
			D3DXVECTOR3 vt = *(*it)->GetPosition();
			D3DXVECTOR3 vDistance = (D3DXVECTOR3(vt.x , vt.y+5.0f,vt.z) - *pos);
			float fDistance = D3DXVec3Length(&vDistance);

			float fRadiusParticl = 13.5f;
			float fRadiusObject = 13.0f;

			if(fDistance <= fRadiusParticl + fRadiusObject)
			{
				*bCollisionEx = TRUE;
				(*it)->SetCollision(*bCollisionEx);
				m_iTotallNum--;
				m_life--;
	//			it = m_Object.erase(it);
	//			it--;
				CStage *stage = CStage::GetInstance();
				stage->SetStage(11.5f);

			}
		}
	}

}





