#include "_Stdafx.h"
#include "define.h"
#include "Particle.h"
#include "Event.h"

CEvent::CEvent()
{
	m_bCheck =  FALSE;
	m_bStage3Check = FALSE;
	m_bStage3Chek2 = FALSE;

	m_fDistance = 10000000.0f;
	m_vBluePos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_vCharPos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_fSumElapsed = 0.0f;

	m_bBoss = FALSE;
}


CEvent::~CEvent()
{

}


void CEvent::Stage2Event1(CPSystem *fireEffect, D3DXVECTOR3* pos,  int elapsed)
{
	if(m_bCheck == FALSE)
	{
		fireEffect->ParticleReSet();		
		m_bCheck = TRUE;
	}

	BOOL temp = FALSE;
	fireEffect->Update((float)elapsed, D3DXVECTOR3(0, 0, 0), &temp);

	if(!fireEffect->IsEmpty())
	{
		fireEffect->SetPos(&D3DXVECTOR3(pos->x, pos->y, pos->z));
		fireEffect->SetYRotate();
	}

}



//ȸ�� ǥ��
void CEvent::Stage3Event2(CPSystem *blueEffect, D3DXVECTOR3* pos,  int elapsed)
{

	if(m_bStage3Chek2 == FALSE)
	{
		blueEffect->ParticleReSet();		
		m_bStage3Chek2 = TRUE;
	}

	BOOL temp = FALSE;
	blueEffect->Update((float)elapsed, D3DXVECTOR3(0, 0, 0), &temp);

	if(!blueEffect->IsEmpty())
	{
		blueEffect->SetPos(&D3DXVECTOR3(pos->x, pos->y, pos->z));
		blueEffect->SetYRotate();

	}
}


//���ζ� ǥ��
void CEvent::Stage3Event(CPSystem *blueEffect, D3DXVECTOR3* pos,  int elapsed)
{
	if(m_bStage3Check == FALSE)
	{
		blueEffect->ParticleReSet();		
		m_bCheck = TRUE;
	}

	BOOL temp = FALSE;
	blueEffect->Update(float(elapsed * 0.0005f), *pos, &temp);
	

}

void CEvent::ClearBossEvent(CPSystem *fireEffect,D3DXVECTOR3 *vPos,int elapsed)
{

	if(m_bBoss == FALSE)
	{
		fireEffect->ParticleReSet();		
		m_bBoss = TRUE;
	}


	BOOL temp = FALSE;
	fireEffect->Update((float)elapsed, D3DXVECTOR3(0, 0, 0), &temp);

	if(!fireEffect->IsEmpty())
	{
		fireEffect->SetPos(&D3DXVECTOR3(vPos->x, vPos->y+5, vPos->z));
//		fireEffect->SetYRotate();

	}

	fireEffect->Render();

}


void CEvent::RenderStage3Event(CPSystem *blueEffect)
{
	blueEffect->Render();
}


void CEvent::RenderStage3Event2(CPSystem *Effect2)
{
	Effect2->Render();
}


void CEvent::RenderStage2Event1(CPSystem *fireEffect)
{

	fireEffect->Render();
}


void CEvent::CalculationDist(D3DXVECTOR3 *vBluePos, D3DXVECTOR3 *vCharPos)
{
	D3DXVECTOR3 vResult = *vBluePos - *vCharPos;

	m_fDistance = D3DXVec3Length(&vResult);
}






