//=============================================================================
// Sky.cpp by Frank Luna (C) 2004 All Rights Reserved.
//=============================================================================
//


#include "_Stdafx.h"
#include "Stage.h"
#include "Sky.h"



CSky::CSky()
{
	m_uvScaleOffset	= D3DXVECTOR4(0.0f, 0.0f, 0.0f, 0.0f);
	m_Sphere = NULL;
	m_pEnvMap = NULL;
	m_skyFX = NULL;
	m_fColor = 1.0f;
	m_iFlag = 0;
	m_iChange = 0;

	m_dwTime = 0;
}	

CSky::~CSky()
{
	SAFE_RELEASE(m_Sphere);
	SAFE_RELEASE(m_pEnvMap);
	SAFE_RELEASE(m_skyFX);
}

void CSky::SkyInit( char* envmapFilename, char* cloudeFilename, float skyRadius, LPDIRECT3DDEVICE9 device)
{

	m_fRadius = skyRadius;
	m_lpDeviece = device;

	D3DXCreateSphere(m_lpDeviece, skyRadius, 30, 30, &m_Sphere, 0);


	

	if(FAILED(D3DXCreateTextureFromFile(m_lpDeviece, "./Image/SkyDome/clouds.dds", &m_lpCloudTex2)))
		return ;
	
	if(FAILED(D3DXCreateCubeTextureFromFile(m_lpDeviece, envmapFilename, &m_pEnvMap)))
	{
		return;
	}


	ID3DXBuffer* errors = 0;

	D3DXCreateEffectFromFile(m_lpDeviece, "./FX/sky.fx", 0, 0, 0, 0, &m_skyFX, &errors);

	if( errors )
		MessageBox(0, (TCHAR*)errors->GetBufferPointer(), 0, 0);


	m_hTech   = m_skyFX->GetTechniqueByName("SkyTech");
	m_hWVP    = m_skyFX->GetParameterByName(0, "gWVP");
	m_hEnvMap = m_skyFX->GetParameterByName(0, "gEnvMap");
	m_hCloudMap = m_skyFX->GetParameterByName(0, "gCloudMap");
	m_hCloudMap2 = m_skyFX->GetParameterByName(0, "gCloudMap2");

	// Set effect parameters that do not vary.
	m_skyFX->SetTechnique(m_hTech);
	m_skyFX->SetTexture(m_hEnvMap, m_pEnvMap);
	m_skyFX->SetTexture(m_hCloudMap2, m_lpCloudTex2);


	// �ϴ� ����� �Ȱ� ���� ���̺�
	m_vDiffuse[0] =	D3DXVECTOR4(0.06f, 0.1f, 0.19f, 1.0f);	// 0��
	m_vDiffuse[1] = D3DXVECTOR4(0.1f,  0.2f, 0.24f, 1.0f);	// 4��
	m_vDiffuse[2] =	D3DXVECTOR4(0.51f, 0.62f, 0.66f, 1.0f);	// 8��
	m_vDiffuse[3] =	D3DXVECTOR4(0.90f, 0.95f, 0.98f, 1.0f);	// 12��
	m_vDiffuse[4] = D3DXVECTOR4(0.81f, 0.90f, 0.92f, 1.0f);	// 16��
	m_vDiffuse[5] = D3DXVECTOR4(0.54f, 0.36f, 0.42f, 1.0f);	// 20��


	m_cFog[0] = D3DXCOLOR(0.03f, 0.07f, 0.16f, 1.0f);	// 0��
	m_cFog[1] = D3DXCOLOR(0.03f, 0.07f, 0.16f, 1.0f);	// 4��
	m_cFog[2] = D3DXCOLOR(0.51f, 0.63f, 0.81f, 1.0f);	// 8��
	m_cFog[3] = D3DXCOLOR(0.51f, 0.63f, 0.81f, 1.0f);	// 12��
	m_cFog[4] = D3DXCOLOR(0.51f, 0.63f, 0.81f, 1.0f);	// 16��
	m_cFog[5] = D3DXCOLOR(0.8f , 0.47f, 0.39f, 1.0f);	// 20��


	m_stage = CStage::GetInstance();
}
void CSky::Variation(int elapsed)
{
	DWORD maxTime = 86400;									// 24�ð��� �ʷ� ��Ÿ�� �ƽ�ġ

	m_dwTime = m_dwTime + elapsed;							// elapsed ����
	if(m_dwTime > maxTime) m_dwTime = m_dwTime - maxTime;	// maxTime�� �Ѿ�� �׸�ŭ ���� 0 - 86400�� �ݺ�
	int iLevel = int(m_dwTime / 14400);						// 0 - 5������ �������̺��� ���� 4�ð�(14000��) ������
	float fweight;

	// (����ð� - ���ð�)/(�Ľð� - ���ð�)
	if(m_dwTime < 14400)
	{
		fweight = float(m_dwTime / 14400.0f);
	}
	else if(m_dwTime < 28800)
	{
		fweight = ((float)m_dwTime - 14400.0f)/14400.0f;
	}
	else if(m_dwTime < 43200)
	{
		fweight = ((float)m_dwTime - 28800.0f)/14400.0f;
	}
	else if(m_dwTime < 57600)
	{
		fweight = ((float)m_dwTime - 43200.0f)/14400.0f; 
	}
	else if(m_dwTime < 72000)
	{
		fweight = ((float)m_dwTime - 57600.0f)/14400.0f;
	}
	else if(m_dwTime < 86400)
	{
		fweight = ((float)m_dwTime - 72000.0f)/14400.0f;
	}


	m_sdt.Hour = (int)(m_dwTime/3600);
	m_sdt.Minute = (int)(m_dwTime/(60))%60;


	// ���ε����� ���ε��� + 1�� �ϵ��� �ϰ�, 5�� ��� 0���� �����Ѵ�.
	int iBackLevel;
	if(iLevel >= 5) 
		iBackLevel = 0;
	else
		iBackLevel = iLevel + 1;


	D3DXVECTOR4 vSkyDiffuse = D3DXVECTOR4(1, 1, 1, 1);
	D3DXCOLOR resultFog;

	vSkyDiffuse.x = Linear(m_vDiffuse[iLevel].x, m_vDiffuse[iBackLevel].x, fweight);
	vSkyDiffuse.y = Linear(m_vDiffuse[iLevel].y, m_vDiffuse[iBackLevel].y, fweight);
	vSkyDiffuse.z = Linear(m_vDiffuse[iLevel].z, m_vDiffuse[iBackLevel].z, fweight);

	resultFog.r = Linear(m_cFog[iLevel].r, m_cFog[iBackLevel].r, fweight);
	resultFog.g = Linear(m_cFog[iLevel].g, m_cFog[iBackLevel].g, fweight);
	resultFog.b = Linear(m_cFog[iLevel].b, m_cFog[iBackLevel].b, fweight);
	resultFog.a = 1.0f;
	
	m_sdt.Fog = resultFog;


//	m_sdt.Fog = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);
	m_vSkyDiffuse = vSkyDiffuse;
//	m_vSkyDiffuse = D3DXVECTOR4(1.0f, 1.0f, 1.0f, 1.0f);
//	m_skyFX->SetValue("sky_diffuse", m_vSkyDiffuse, D3DX_DEFAULT);

}

void CSky::SkyUpdate( D3DXVECTOR3 pcamera, D3DXMATRIX VP, int elapsed)
{

	if(m_skyFX == NULL)
		return;
		
	m_VP = VP;

//	Variation(elapsed);

	if(m_stage->GetStage() >= 0.0f && m_stage->GetStage() < 2.5f)
	{
		m_vSkyDiffuse = D3DXVECTOR4(1.0f, 1.0f, 1.0f, 1.0f);
		m_skyFX->SetValue("sky_diffuse", m_vSkyDiffuse, D3DX_DEFAULT);
	}
	else if(m_stage->GetStage() >= 2.5f && m_stage->GetStage() <= 7.0f)
	{
		m_vSkyDiffuse = D3DXVECTOR4(0.0f, 0.0f, 0.0f, 1.0f);
		m_skyFX->SetValue("sky_diffuse", m_vSkyDiffuse, D3DX_DEFAULT);

	}
	else if(m_stage->GetStage() >= 7.5f && m_stage->GetStage() < 12.0) 
	{
		m_vSkyDiffuse = D3DXVECTOR4(0.4f, 0.3f, 0.5f, 1.0f);
		m_skyFX->SetValue("sky_diffuse", m_vSkyDiffuse, D3DX_DEFAULT);
	}

	else if(m_stage->GetStage() >= 12.0f) 
	{
		m_vSkyDiffuse = D3DXVECTOR4(1.0f, 1.0f, 1.0f, 1.0f);
		m_skyFX->SetValue("sky_diffuse", m_vSkyDiffuse, D3DX_DEFAULT);
	}
 
	float control;
	control = 0.1f;

	// ������ �����̵��� �ؽ�ó uv�� ��ǥ�� �����δ�.
	m_uvScaleOffset.x += 0.000025f*elapsed*control;
	m_uvScaleOffset.y += 0.000035f*elapsed*control;
	m_uvScaleOffset.z += 0.00004f*elapsed*control;
	m_uvScaleOffset.w += 0.00005f*elapsed*control;

	// ������ ������� ��Ÿ���� �����ϴ� �κ�.
	if(m_iFlag == 0)
	{
		m_fColor -= 0.001f*elapsed*control;
		if(m_fColor < -0.5f)
		{

			m_iFlag = 1;
			m_uvScaleOffset.z += 0.0004f*elapsed*control;
			m_uvScaleOffset.w += 0.0005f*elapsed*control;
		}

	}
	else if(m_iFlag == 1)
	{
		m_fColor += 0.001f*elapsed*control;
		if(m_fColor > 1.0f)
		{
			m_iFlag =0;	

			if(m_iChange == 0)
				m_iChange = 1;
			else if(m_iChange == 1)
				m_iChange = 0;
		}
	}

	m_skyFX->SetValue("uv_data", m_uvScaleOffset, D3DX_DEFAULT);
	m_skyFX->SetValue("color", &m_fColor, D3DX_DEFAULT);
	m_skyFX->SetValue("change", &m_iChange, D3DX_DEFAULT);


	// Sky always centered about camera's position.
	
	m_p = pcamera;//gCamera->pos();

	D3DXMatrixTranslation(&m_W, m_p.x, m_p.y, m_p.z);
	D3DXMatrixScaling(&m_S, 250.0f, 150.0f, 250.0f);

}

void CSky::Draw(D3DXPLANE* reflectedW)
{
	if(m_skyFX == NULL)
		return;

	m_lpDeviece->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	D3DXMATRIX RefMtx;				//Reflect��� �Ű躯�� ���ڰ� 0�̸� ������� 0�� �ƴϸ� ����� �ݻ����
	D3DXMatrixIdentity(&RefMtx);

	if(reflectedW)
		D3DXMatrixReflect(&RefMtx, reflectedW);

	m_skyFX->SetMatrix(m_hWVP, &(m_S*m_W*RefMtx*(m_VP)));

	UINT numPasses = 0;
	m_skyFX->Begin(&numPasses, 0);
	m_skyFX->BeginPass(0);
	m_Sphere->DrawSubset(0);
	m_skyFX->EndPass();
	m_skyFX->End();
	
}

DWORD CSky::GetNumTriangles()
{
	return m_Sphere->GetNumFaces();
}

DWORD CSky::GetNumVertices()
{
	return m_Sphere->GetNumVertices();
}

IDirect3DCubeTexture9* CSky::GetEnvMap()
{
	return m_pEnvMap;
}

float CSky::GetRadius()
{
	return m_fRadius;
}

void CSky::OnLostDevice()
{
	m_skyFX->OnLostDevice();
}

void CSky::OnResetDevice()
{
	m_skyFX->OnResetDevice();
}