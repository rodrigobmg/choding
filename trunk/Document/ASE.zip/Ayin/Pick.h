//////////////////////////////////////////////////////////////////////
//
//	Pick.h : interface for the CPick class.
//
//////////////////////////////////////////////////////////////////////
#pragma once

class CPick
{
private:
	LPDIRECT3DDEVICE9	m_pDevice;
	HWND				m_hWnd;

public:
	D3DXVECTOR3			m_vPickRayOrig;
	D3DXVECTOR3			m_vPickRayDir;
	D3DXVECTOR3			m_vCharToRayvDir;

	
public:
	CPick( LPDIRECT3DDEVICE9 device, HWND hWnd );
	~CPick();

	bool PickInit();
	bool IntersectTriangle( D3DXVECTOR3& v0, D3DXVECTOR3& v1, D3DXVECTOR3& v2, float& dist );
	void CalcDir(D3DXVECTOR3 *pos);
	D3DXVECTOR3* GetDir(){return &m_vCharToRayvDir;} 
	D3DXVECTOR3* GetPickRayDir(){return &m_vPickRayDir;} 
	D3DXVECTOR3* GetPickOrig(){return &m_vPickRayOrig;}

};	

extern CPick *g_pPick;