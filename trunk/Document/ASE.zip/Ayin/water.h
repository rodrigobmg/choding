#pragma once


class CDrawTex2D;

const D3DXCOLOR WHITE(1.0f, 1.0f, 1.0f, 1.0f);

//����
struct Mtrl
{
	Mtrl()
		:ambient(WHITE), diffuse(WHITE), spec(WHITE), specPower(8.0f){}
	Mtrl(const D3DXCOLOR& a, const D3DXCOLOR& d, 
		const D3DXCOLOR& s, float power)
		:ambient(a), diffuse(d), spec(s), specPower(power){} 

		D3DXCOLOR ambient;
		D3DXCOLOR diffuse;
		D3DXCOLOR spec;
		float specPower;
};

//����Ʈ
struct DirLight
{
	D3DXCOLOR ambient;
	D3DXCOLOR diffuse;
	D3DXCOLOR spec;
	D3DXVECTOR3 dirW;
};

//���ؽ� ����
struct VertexPT
{
	VertexPT()
		:pos(0.0f, 0.0f, 0.0f),
		tex0(0.0f, 0.0f){}
	VertexPT(float x, float y, float z, 
		float u, float v):pos(x,y,z), tex0(u,v){}
	VertexPT(const D3DXVECTOR3& v, const D3DXVECTOR2& uv)
		:pos(v), tex0(uv){}

	D3DXVECTOR3 pos;
	D3DXVECTOR2 tex0;

	static IDirect3DVertexDeclaration9* Decl;
};

class CWater
{
public:
	//�� �ʱ�ȭ 
	struct InitInfo
	{
		DirLight dirLight;
		Mtrl	 mtrl;
		int		 vertRows;
		int		 vertCols;
		float    dx;
		float	 dz;
		char* waveFileName0;
		char* waveFileName1;
		D3DXVECTOR2 waveMapVelocity0;
		D3DXVECTOR2 waveMapVelocity1;
		float texScale;
		float refracBias;
		float refractPower;
		D3DXVECTOR2 rippleScale;
		D3DXMATRIX toWorld;
	};

public:

	CWater(InitInfo& InitInf, LPDIRECT3DDEVICE9 device);
	~CWater();

	DWORD GetNumTringles();
	DWORD GetNumVertices();

	void ShutDown();
	void InitWater();

	void Update(float dt);										//wave���� uv�ִϸ��̼� update�Լ�
	void Draw(D3DXVECTOR3 *cameraPos, D3DXMATRIX *vp);			

				
	void GenTriGrid(int numVertRows, int numVertCols,			//���ؽ��� �ε��� ����
		float dx, float dz, 
		const D3DXVECTOR3& center, 
		std::vector<D3DXVECTOR3>& verts,
		std::vector<DWORD>& indices);

private:

	void BuildFX();							//���̴� 

public:


	CDrawTex2D* m_Reflect;					//�ݻ��ؽ���
	CDrawTex2D* m_Refract;					//�����ؽ���


private:

	LPDIRECT3DDEVICE9 m_device;
	ID3DXMesh* m_Mesh;						
	ID3DXEffect* m_FX;					

	LPDIRECT3DTEXTURE9 m_pWaveMap0;			//Wave0�ؽ���
	LPDIRECT3DTEXTURE9 m_pWaveMap1;			//Wave1�ؽ���

	D3DXVECTOR2 m_WaveMapOffset0;			//Wave �ִϸ��̼� 
	D3DXVECTOR2 m_WaveMapOffset1;			//Wave �ִϸ��̼� 

	InitInfo m_InitInfo;					//water �ʱ�ȭ 					
	float m_fWidth;							//����	
	float m_fDepth;							//����

	

	//���̴� �ڵ��
	D3DXHANDLE m_hTech;
	D3DXHANDLE m_hWVP;
	D3DXHANDLE m_hWorld;
	D3DXHANDLE m_hWorldInv;
	D3DXHANDLE m_hLight;
	D3DXHANDLE m_hMtrl;
	D3DXHANDLE m_hEyePosW;
	D3DXHANDLE m_hWaveMap0;
	D3DXHANDLE m_hWaveMap1;
	D3DXHANDLE m_hWaveMapOffset0;
	D3DXHANDLE m_hWaveMapOffset1;
	D3DXHANDLE m_hRefractBias;
	D3DXHANDLE m_hRefractPower;
	D3DXHANDLE m_hRippleScale;
	D3DXHANDLE m_hReflectMap;
	D3DXHANDLE m_hRefractMap;
	

};