#include "_Stdafx.h"
#include "DrawTex2D.h"


CDrawTex2D::CDrawTex2D(UINT width, UINT hegiht, UINT mipLevels,
							D3DFORMAT texFormat, bool useDepthBuffer, 
							D3DFORMAT depthFormat, D3DVIEWPORT9&viewport)
:m_lpTexture(0), m_lpTextureSurf(0), m_lpTextureDeep(0),m_uWidth(width), m_uHeight(hegiht),
m_uMipLevels(mipLevels), m_TexFormat(texFormat),m_bUseDepthBuffer(useDepthBuffer),
m_DepthFormat(depthFormat), m_ViewPort(viewport),m_lpOldBackBuffer(NULL),m_lpOldZBuffer(NULL)
{

}

CDrawTex2D::~CDrawTex2D()
{
	//ShutDown();
}


void CDrawTex2D::SaveOldTaget()
{
	m_pDevie->GetRenderTarget(0, &m_lpOldBackBuffer);
	m_pDevie->GetDepthStencilSurface(&m_lpOldZBuffer);
	m_pDevie->GetViewport(&m_OldViewPort);
}

void CDrawTex2D::InitTaget(LPDIRECT3DDEVICE9 device)
{
	m_pDevie = device;

	if (FAILED(m_pDevie->CreateTexture(m_uWidth, m_uHeight, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_lpTexture, NULL)))
		return ;

	if (FAILED(m_lpTexture->GetSurfaceLevel(0, &m_lpTextureSurf)))
		return ;

	if (FAILED(m_pDevie->CreateDepthStencilSurface(m_uWidth, m_uHeight, 
		D3DFMT_D16, D3DMULTISAMPLE_NONE, 0, TRUE, &m_lpTextureDeep, NULL)))
		return ;

}

void CDrawTex2D::ShutDown()
{
	SAFE_RELEASE(m_lpTexture);
	SAFE_RELEASE(m_lpTextureSurf);
	SAFE_RELEASE(m_lpTextureDeep);
	SAFE_RELEASE(m_lpOldBackBuffer);
	SAFE_RELEASE(m_lpOldZBuffer);

}	


LPDIRECT3DTEXTURE9 CDrawTex2D::GetD3dTex()
{
	return m_lpTexture;
}


void CDrawTex2D::BeginScene()
{

	m_pDevie->SetRenderTarget(0, m_lpTextureSurf);
	m_pDevie->SetDepthStencilSurface(m_lpTextureDeep);
	m_pDevie->SetViewport(&m_ViewPort);						// ����Ʈ ����
	m_pDevie->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0xFF000000, 1.0f, 0 );

}

void CDrawTex2D::EndScene()
{
	m_pDevie->SetRenderTarget(0, m_lpOldBackBuffer);
	m_pDevie->SetDepthStencilSurface(m_lpOldZBuffer);
	m_pDevie->SetViewport(&m_OldViewPort);
	
}