#include"_Stdafx.h"
#include "define.h"
#include "Particle.h"
#include "Fire.h"



CFire::CFire(int numParticles, D3DXVECTOR3* origin, float life, float zRotate, float Scale, BOOL bnotLife)
{

	if(numParticles > 500)
		return;

	m_origin	= *origin;
	m_vbSize = 3000;				// �� ���ؽ� ����
	m_vbParticleNum = 0;
	m_vbCurSize = numParticles*6;	// �������� ���ؽ� ��

	m_vbParticleNum = m_vbCurSize;
	D3DXMatrixIdentity(&m_matWorld);

	m_life = life;
	m_isize = 1.0f;
	m_time = 1.0f;
	
	m_fZRotate =  zRotate;
	m_fScale = Scale;

	m_Rotate = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	m_fElpasedSum = 0.0f;

}


CFire::~CFire()
{
	m_ListParticles.clear();
}

void CFire::ParticleReSet()
{
	m_vbParticleNum = 0;

	std::list<Attribute>::iterator i;

	i = m_ListParticles.begin();

	while(i != m_ListParticles.end())
	{
		// erase�� ���� �ݺ��ڸ� �����ϹǷ� �ݺ��ڸ� ���� ��ų �ʿ䰡 ����.
		i = m_ListParticles.erase(i);
//		i++;	// ���� ���
	}
}


void CFire::PreRender()
{
	m_lpDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);
	m_lpDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_lpDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	m_lpDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);

	// �ؽ�ó�� ���ĸ� �̿�
	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);

	// �̰� �ǹ̰� ��������... (���� �ձ� ��ƼŬ�� ����� ������ �������� ���� ä���� ���� ��� �ؽ�ó�� �̿��ϸ�,
	// �簢���� ��� �ؽ�ó ��ü�� �ƴ� ��� �� ����� ��ƼŬ�� ���� �� �ִ�.)
	m_lpDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_lpDevice->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);

	m_lpDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_ONE);
	m_lpDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);

}


void CFire::PostRender()
{
	m_lpDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_lpDevice->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_lpDevice->SetRenderState(D3DRS_FOGENABLE, FOGENABLE);

}


void CFire::Render()
{
	
//	if(m_vbParticleNum > m_vbCurSize/6)		// �ִ� ��ƼŬ ������ ���� �� ��ƼŬ�� �߰�
//		return;

	if(!m_ListParticles.empty())
	{
	
		// ������ ���¸� ����
		PreRender();

		D3DXMATRIXA16 m;
		D3DXMatrixIdentity(&m);
		m_lpDevice->SetTransform(D3DTS_WORLD, &m);
		m_lpDevice->SetTexture(0, m_pTex);
		m_lpDevice->SetFVF(D3DFVF_PARTICLEVERTEX);
		m_lpDevice->SetStreamSource(0, m_pVB, 0, sizeof(Particle));

		Particle* v = 0;

		m_pVB->Lock(0, 
			m_vbCurSize * sizeof(Particle),
			(void**)&v,
			D3DLOCK_DISCARD);

		// ��� ����ִ� ��ƼŬ�� �������� ������
		int iPoligon = 0;
		std::list<Attribute>::iterator i;
		for(i = m_ListParticles.begin(); i != m_ListParticles.end(); i++)
		{
			if(i->_isAlive)
			{
				v->_position = i->_sParticle[0]._position;
				v->_color    = i->_color;
				v->u = 0.0f; v->v = 1.0f;
				v++;
				v->_position = i->_sParticle[1]._position;
				v->_color    = i->_color;
				v->u = 0.0f; v->v = 0.0f; 
				v++;
				v->_position = i->_sParticle[2]._position;
				v->_color    = i->_color;
				v->u = 1.0f; v->v = 0.0f; 
				v++;
				v->_position = i->_sParticle[3]._position;
				v->_color    = i->_color;
				v->u = 0.0f; v->v = 1.0f; 
				v++;
				v->_position = i->_sParticle[4]._position;
				v->_color    = i->_color;
				v->u = 1.0f; v->v = 0.0f; 
				v++;
				v->_position = i->_sParticle[5]._position;
				v->_color    = i->_color;
				v->u = 1.0f; v->v = 1.0f; 
				v++;

				iPoligon += 2;
			}
		}


		m_pVB->Unlock();
		// ����ִ� �����︸ �׸����� �Ѵ�.
		m_lpDevice->DrawPrimitive(D3DPT_TRIANGLELIST, 0, iPoligon);//m_vbCurSize/3);

		PostRender();
	}

}

void CFire::Transformation(D3DXVECTOR3* sv, D3DXVECTOR3* tv, float zRot, D3DXVECTOR3* oriv)
{

	// ������ ����
	D3DXMATRIXA16 matView,matScale, matRot, matTrans, matBilboard;

	D3DXMatrixIdentity(&matBilboard);
	D3DXMatrixIdentity(&m_matWorld);
	m_lpDevice->GetTransform(D3DTS_VIEW, &matView);
	D3DXMatrixTranspose(&matBilboard, &matView);
	matBilboard._41 = matBilboard._42 = matBilboard._43 = matBilboard._14 = matBilboard._24 = matBilboard._34 = 0.0f;

	D3DXMatrixScaling(&matScale, sv->x, sv->y, sv->z);
	D3DXMatrixRotationZ(&matRot, zRot);
	D3DXMatrixTranslation(&matTrans, tv->x, tv->y, tv->z);

	D3DXMatrixMultiply(&m_matWorld, &matScale, &matRot);
	D3DXMatrixMultiply(&m_matWorld, &m_matWorld, &matBilboard);
	D3DXMatrixMultiply(&m_matWorld, &m_matWorld, &matTrans);


}


void CFire::ResetParticle(Attribute* attribute)
{

	attribute->_isAlive = true;

	// �ʱ�ȭ�� �� ũ�⸦ �����Ѵ�.
	//GetRandomVector(&(attribute->_scale), &(D3DXVECTOR3(1.0f, 1.0f, 1.0f)), &(D3DXVECTOR3(2.0f, 2.0f, 2.0f)));//D3DXVECTOR3(1, 1, 1);
	attribute->_scale.x = attribute->_scale.y = attribute->_scale.z = GetRandomFloat(1.0f, 2.0f);

	attribute->_position = m_origin;

	//attribute->_velocity.x = GetRandomFloat(-1.0f, 1.0f)*m_vVelocity.x;
	//attribute->_velocity.y = GetRandomFloat(0.0f, 1.0f)*m_vVelocity.y;
	//attribute->_velocity.z = GetRandomFloat(0.0f, 1.0f)*m_vVelocity.z;

	attribute->_velocity.x = GetRandomFloat(-1.0f, 1.0f)*m_vVelocity.x;
	attribute->_velocity.y = m_vVelocity.y;
	attribute->_velocity.z = GetRandomFloat(-1.0f, 1.0f)*m_vVelocity.z;


	attribute->_color = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);
	attribute->_age	  = 0.0f;
	attribute->_lifeTime = m_life; // ������ 1��

}

void CFire::RemoveDeadParticles()
{
	std::list<Attribute>::iterator i;

	i = m_ListParticles.begin();

	int iFirst = 0;
	while(i != m_ListParticles.end())
	{
		if(i->_isAlive == false)
		{
			if(iFirst == 0)
			{
				iFirst=1;
				m_vCenter = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
			}
			// erase�� ���� �ݺ��ڸ� �����ϹǷ� �ݺ��ڸ� ���� ��ų �ʿ䰡 ����.
			i = m_ListParticles.erase(i);
//			if(m_vbParticleNum > 0)
//				m_vbParticleNum--;
		}
		else
		{
			i++;	// ���� ���
		}
	}

}

void CFire::Update(float timeDelta, D3DXVECTOR3 pos, BOOL *bCollisionExis)
{
	
	if(*bCollisionExis == TRUE)
	{
		m_vbParticleNum = m_vbCurSize/6;
		*bCollisionExis = FALSE;
//		RemoveAll();
	}

	m_fElpasedSum += (timeDelta*5.0f);

	if(m_fElpasedSum > 80.0f)
	{
		m_fElpasedSum = 0.0f;
		for(int i=0; i < 2; i++)
		{
		 
			if(m_vbParticleNum < m_vbCurSize/6)		// �ִ� ��ƼŬ ������ ���� �� ��ƼŬ�� �߰�
			{
				AddParticle();
				m_vbParticleNum++;
			}
		}

		
	}
	
	if(m_ListParticles.empty())
	{
		bCollisionExis = FALSE;
		return;
	}


	// �簢�� ������ ����Ʈ���� SRT��ȯ �� ���ͷ� �ٲ� �� ���� ��ǥ�� ����
	std::list<Attribute>::iterator i;

	int iFirst = 0;

	for(i = m_ListParticles.begin(); i != m_ListParticles.end(); i++)
	{
//		if(*bCollisionExis != TRUE)
//		{	
			i->_position += (i->_velocity+m_vPickDir) * timeDelta*0.001f;
//		}
		i->_scale *= m_fScale;
		i->_zRot  += m_fZRotate;

		D3DXVECTOR4 vecWorld = D3DXVECTOR4(0.0f, 0.0f, 0.0f, 0.0f);

		Transformation(&(i->_scale), &(pos + i->_position), i->_zRot, &m_vecLocal[0]);
		D3DXVec3Transform(&vecWorld, &m_vecLocal[0], &m_matWorld);
		i->_sParticle[0]._position = D3DXVECTOR3(vecWorld.x, vecWorld.y, vecWorld.z) ;

		D3DXVec3Transform(&vecWorld, &m_vecLocal[1], &m_matWorld);
		i->_sParticle[1]._position = D3DXVECTOR3(vecWorld.x, vecWorld.y, vecWorld.z) ;

		D3DXVec3Transform(&vecWorld, &m_vecLocal[2], &m_matWorld);
		i->_sParticle[2]._position = D3DXVECTOR3(vecWorld.x, vecWorld.y, vecWorld.z) ;

		i->_sParticle[3]._position = i->_sParticle[0]._position;
		i->_sParticle[4]._position = i->_sParticle[2]._position;


		D3DXVec3Transform(&vecWorld, &m_vecLocal[5], &m_matWorld);
		i->_sParticle[5]._position = D3DXVECTOR3(vecWorld.x, vecWorld.y, vecWorld.z) ;


		if(m_bnotLife != TRUE)
		{
			if(i->_isAlive)
			{

				i->_age += (timeDelta*0.0005f)*GetRandomFloat(0.0f, 1.0f);

				if(i->_age > i->_lifeTime) // kill
					i->_isAlive = false;
			}
		}

		if(iFirst == 0)
		{
			m_vCreatePos = i->_position;
 //			m_vCenter = i->_sParticle[0]._position + i->_sParticle[1]._position + i->_sParticle[2]._position + i->_sParticle[5]._position;
//			m_vCenter /= 4;
			iFirst = 1;
		}

	}	

	if(m_bnotLife != TRUE)
	{
		RemoveDeadParticles();
	}
}


void CFire::SetVelocity(D3DXVECTOR3* velocity)
{
	m_vVelocity = *velocity;
}


void CFire::SetPos(D3DXVECTOR3* vOrigin)
{
//	m_origin = *vOrigin; + m_Rotate;
	m_origin = m_Temp = *vOrigin + m_vInitPos;
}

void CFire::SetYRotate()
{
	if(m_time == 0)
		m_Rotate = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	else
	{
		m_Rotate =   D3DXVECTOR3(cosf(timeGetTime()/m_time)*m_isize,1.0f,sinf(timeGetTime()/m_time)*m_isize - m_isize);
	}
	
	m_origin = m_Temp + m_Rotate;
}

void CFire::SetXRotate() 
{
	m_Rotate =  D3DXVECTOR3(cosf(timeGetTime()/m_time)*m_isize, sinf(timeGetTime()/m_time)*m_isize, 1.0f);
//	m_origin = m_Rotate;
}


