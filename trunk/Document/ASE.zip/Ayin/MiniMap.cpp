#include "_Stdafx.h"
#include "DrawTex2D.h"
#include "Mesh.h"
#include "Frustum.h"
#include "TerrainManager.h"
#include "Sprite.h"
#include "Sky.h"
#include "water.h"
#include "WaterMannager.h"
#include "Stage.h"
#include "Ase.h"
#include "AseManager.h"
#include "CWorld.h"
#include "MiniMap.h"


CMiniMap::CMiniMap()
{
	m_lpDevice = NULL;
	m_miniMapTex = NULL;

	D3DXMatrixIdentity(&m_view);
	D3DXMatrixIdentity(&m_preView);

	m_vLookAt = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_vEye = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_vCharPos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	m_lpVB   = NULL;
	m_lpHero = NULL;
	m_Tex = NULL;

	m_Zoom = 200.0f;

	m_fElapsed = 0.0f;

	m_pSprite = NULL;
}

CMiniMap::~CMiniMap()
{


}

void CMiniMap::ShutDown()
{

//	D3DXSaveTextureToFile( "Image/miniMap.bmp", D3DXIFF_BMP, m_miniMapTex->GetD3dTex(), NULL );

	if(m_miniMapTex != NULL)
	{
		m_miniMapTex->ShutDown();
		delete m_miniMapTex;
	}

	SAFE_RELEASE(m_lpVB);
	SAFE_RELEASE(m_lpHero);
	SAFE_RELEASE(m_Tex);

	m_mini.ShutDown();
}

//�̴ϸʰ� ���ΰ��� ������ �ʱ�ȭ�Ѵ�.
HRESULT CMiniMap::InitVB()
{
	//�̴ϸ� ����
	MinMapVERTEX vertices[] =
	{
		{ 820.0f, -10.0f ,0.0f, 1.0f, 0.0f, 0.0f,},
		{1040.0f, -10.0f, 0.0f, 1.0f, 1.0f, 0.0f,},
		{ 820.0f, 220.0f,0.0f, 1.0f, 0.0f, 1.0f,},
		{1040.0f, 220.0f,0.0f, 1.0f, 1.0f, 1.0f,},
	
	};

	if(FAILED(m_lpDevice->CreateVertexBuffer(4*sizeof(MinMapVERTEX), 0, MinMapVERTEX::FVF, D3DPOOL_DEFAULT, &m_lpVB, NULL)))
		return E_FAIL;


	VOID* pVertices;
	if(FAILED(m_lpVB->Lock(0, sizeof(vertices), (void**)&pVertices, 0)))
		return E_FAIL;

	memcpy(pVertices, vertices, sizeof(vertices));

	m_lpVB->Unlock();

	//���ΰ��� �׸��� ���ؼ� ���� ����

	float fSize = 7.0f;
	/// �ﰢ���� �������ϱ����� ������ ������ ����
	HeroVERTEX HeroVB[] =
	{
		{ -fSize, 0.0f, -fSize, 0xffffffff, },
		{  0.0f, 0.0f, fSize, 0xff0000cc, },
		{  fSize, 0.0f, -fSize, 0xffffffff, },
	};

	/// �������� ����
	if( FAILED( m_lpDevice->CreateVertexBuffer( 3*sizeof(HeroVERTEX),
		0, HeroVERTEX::FVF,
		D3DPOOL_DEFAULT, &m_lpHero, NULL ) ) )
	{
		return E_FAIL;
	}

	/// �������۸� ������ ä���. 
	VOID* pVertices2;
	if( FAILED( m_lpHero->Lock( 0, sizeof(HeroVB), (void**)&pVertices2, 0 ) ) )
		return E_FAIL;
	memcpy( pVertices2, HeroVB, sizeof(HeroVB) );
	m_lpHero->Unlock();


	return S_OK;
}


//�̴ϸ��� ���� �ؽ��Ŀ� +,-�ؽ��ĸ� �ε��Ѵ�.
HRESULT CMiniMap::InitMinMap(LPDIRECT3DDEVICE9 lpDevice, LPCSTR filename, LPD3DXSPRITE lpSprite)
{
	m_lpDevice = lpDevice;

	if(m_lpDevice == NULL)
		return E_FAIL;

	
	if((m_pSprite = lpSprite) == NULL)
		return E_FAIL;


	InitVB();		//�������� �ʱ�ȭ
	 
	D3DVIEWPORT9 vp = {0, 0, 1024, 1024, 0.0f, 1.0f};
	m_miniMapTex = new CDrawTex2D(384, 384, 0, D3DFMT_X8R8G8B8, true, D3DFMT_D24X8, vp);
	m_miniMapTex->InitTaget(m_lpDevice);



	if(FAILED(D3DXCreateTextureFromFile(m_lpDevice, filename, &m_Tex)))			//�̴ϸ��� �ձ׷��� ����ϱ� ���� ����ϴ� �ؽ���
		return E_FAIL;


	m_zoomSprite.LoadTexture(m_lpDevice, m_pSprite, "./Image/UI/Zoom.png", 0xffffffff);


	m_mini.InitMini(m_lpDevice, "./DataInfo/MiniMap.txt");			//�̴ϸʿ� �ִ� �ؽ��ĵ��� �����Ѵ�.
	

	m_stage = CStage::GetInstance();
	return S_OK;
}


//������Ʈ
void CMiniMap::Update(D3DXVECTOR3* pos, int *iZoom, int iMouseXPos, int iMouseYPos, int iElapsed)
{
	if(m_lpDevice == NULL)
		return;

	if(*iZoom == 1)
	{
		if(m_Zoom > 100.0f)
		{
			m_Zoom -= 20.0f;
			*iZoom = 0;
		}
	}
	else if(*iZoom == 2)
	{
		if(m_Zoom < 300.0f)
		{
			m_Zoom += 20.0f;
			*iZoom = 0;
		}	
	}

//	PlusPos(iZoom, iMouseXPos, iMouseYPos);
//	MinusPos(iZoom,iMouseXPos, iMouseYPos);


	m_fElapsed += iElapsed*0.01f;
	//���� �並 ��´�.
	m_vCharPos = *pos;
	m_lpDevice->GetTransform(D3DTS_VIEW, &m_preView);

	//ī�޶� �����϶����� �̴ϸ��� ������Ʈ.
	m_vLookAt = *pos;
	m_vEye = m_vLookAt + D3DXVECTOR3(0.01f, m_Zoom, 0.01f);
	D3DXMatrixLookAtLH(&m_view, &m_vEye, &m_vLookAt, &D3DXVECTOR3(0.0f, 1.0f, 0.0f));
	D3DXMATRIX matRotate;
	D3DXMatrixRotationZ(&matRotate, D3DX_PI);
	D3DXMatrixMultiply(&m_view, &m_view, &matRotate);

}
//m_ZoomSprite.Draw(986, 45, 0, 0, 38, 55,  0xffFFFFFF);
//+�� ������ �̴ϸ��� Ȯ��



BOOL CMiniMap::PlusPos(BOOL *Lock,int iMouseXPos, int iMouseYPos)
{
	if (iMouseXPos > (985) && iMouseXPos < (1000))
	{
		if (iMouseYPos > (46) && iMouseYPos < (57))
		{
			*Lock = TRUE;			//TRUE�� �Ǹ� ��ƼŬ�� �ߵ� ���� �ʴ´�.
			if(m_Zoom > 100.0f)
			{
				m_Zoom -= 20.0f;
				return TRUE;
			}

		}
	}

	return TRUE;
}

//-�� ������ �̴ϸ��� ���
BOOL CMiniMap::MinusPos(BOOL *Lock,int iMouseXPos, int iMouseYPos)
{
	if (iMouseXPos > (996) && iMouseXPos < (1012))
	{
		if (iMouseYPos > (73) && iMouseYPos < (86))
		{
			*Lock = TRUE;			//TRUE�� �Ǹ� ��ƼŬ�� �ߵ� ���� �ʴ´�.
			if(m_Zoom < 300.0f)
			{
				m_Zoom += 20.0f;
				return TRUE;
			}

		}
	}

	return TRUE;
	
}
void CMiniMap::MakeMiniMap(CAseManager *ase,CAseManager *Boss,  CWaterMannager *watermanager,CSMeshManager *meshManager,  CTerrainManager *terrainManager,
						   CSMeshManager *shaderMeshManager,CSMeshManager *shdaderStage2,CSMeshManager *shaderNPC,  D3DXVECTOR3 *vHeroPos, D3DXMATRIX *matWorld)
{
	if(m_lpDevice == NULL)
		return;


	m_miniMapTex->SaveOldTaget();
	m_miniMapTex->BeginScene();


	////�̴ϸ� Ŭ���� �ʷϻ����� �Ѵ�.
	m_lpDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);
	m_lpDevice->Clear(0L, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0xffffffff, 1.0f, 0L);
	m_lpDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_lpDevice->SetRenderState(D3DRS_ZENABLE, D3DZB_FALSE);
	m_lpDevice->SetTexture(0, NULL);

	//������� �������ش�.
	m_lpDevice->SetTransform(D3DTS_VIEW, &m_view);

	

/*
	D3DXMATRIX matPreProj;
	m_lpDevice->GetTransform(D3DTS_PROJECTION, &matPreProj);

	D3DXMATRIX matProj;
	D3DXMatrixOrthoLH(&matProj,850.0f, 850.0f, 0.0f, 1000.0f);
	m_lpDevice->SetTransform(D3DTS_PROJECTION, &matProj);

*/

	////���� ����
	terrainManager->DrawMiniMap();

	
	m_mini.PreOption();


	if(terrainManager->GetCheckMini()[13] == TRUE)
		m_mini.Render(&D3DXVECTOR3(watermanager->GetWaterWold()._41, watermanager->GetWaterWold()._42,watermanager->GetWaterWold()._43), POND);


	//���� ������Ʈ �̴��ؽ��� ����
	for(int i=0; i < terrainManager->GetMapNum(); i++)
	{
		if(terrainManager->GetCheckMini()[i] == TRUE)
		{
			meshManager->RenderSMiniMap(i, &m_mini);
		}
	}


	if(m_stage->GetStage() == 1.3f)
	{
		//���� ������Ʈ ���̴� �̴��ؽ��� ����
		for(int i=0; i < terrainManager->GetMapNum(); i++)
		{                  
			if(terrainManager->GetCheckMini()[i] == TRUE)
				shaderMeshManager->RenderShaderMiniMap(i, &m_mini);
		}
	}


	if(m_stage->GetStage() >= 4.0f && m_stage->GetStage() <= 7.5f)
	{
		//���� ������Ʈ ���̴� �̴��ؽ��� ����
		for(int i=0; i < terrainManager->GetMapNum(); i++)
		{                  
			if(terrainManager->GetCheckMini()[i] == TRUE)
				shdaderStage2->RenderShaderMiniMap(i, &m_mini);
		}
	}



	//���� ������Ʈ ���̴� �̴��ؽ��� ����
	for(int i=0; i < terrainManager->GetMapNum(); i++)
	{                  
		if(terrainManager->GetCheckMini()[i] == TRUE)
			shaderNPC->RenderShaderMiniMap(i, &m_mini);
	}


	if(m_stage->GetStage() >= 6.0f && m_stage->GetStage() < 7.0f)
		ase->RenderMinMap(&m_mini);

	
	if(m_stage->GetStage() == 11.0f)
		Boss->RenderMinMap(&m_mini);

	//�̺κ� ��¥ �̻��ϴ�...
/*
	for(int i=0; i < (int)ase->GetList().size(); i++)
	{
		ase->GetList()[i]->GetPosition();
// 		m_mini.Render((*ase->GetList())[i]->GetPosition(), ase->GetMiniMap());
	}
*/

	m_mini.PostOption();

	//���ΰ� �̴ϸ� ����.
	HeroDraw(vHeroPos, matWorld);
	

	m_lpDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	m_lpDevice->SetRenderState(D3DRS_ZENABLE, D3DZB_TRUE);
	m_lpDevice->SetRenderState(D3DRS_FOGENABLE, FOGENABLE);
	

	m_miniMapTex->EndScene();
	// ��� �������ǵ� ����
	m_lpDevice->SetTransform(D3DTS_VIEW, &m_preView);


}


void CMiniMap::HeroDraw(D3DXVECTOR3 *vPos,D3DXMATRIX *_matWorld)
{

	//���ΰ� ���� �̰� 
	if(m_fElapsed < 10.0f)
	{

		m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE);
		m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
		m_lpDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_DIFFUSE);
		m_lpDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);


		D3DXMATRIX matWorld = *_matWorld;

		m_lpDevice->SetTransform(D3DTS_WORLD, &matWorld);
		m_lpDevice->SetStreamSource( 0, m_lpHero, 0, sizeof(HeroVERTEX) );
		m_lpDevice->SetFVF( HeroVERTEX::FVF );
		m_lpDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, 0, 1 );
	}
	else if(m_fElapsed < 13.0f)
		;
	else 
		m_fElapsed = 0.0f;

	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_DISABLE);
}

void CMiniMap::Draw()
{

	//�̴ϸ� Ŭ���� �ʷϻ����� �Ѵ�.
	m_lpDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);

	m_lpDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_lpDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_lpDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);

	
	m_lpDevice->SetTextureStageState(1, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_lpDevice->SetTextureStageState(1, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
	m_lpDevice->SetTextureStageState(1, D3DTSS_ALPHAARG2, D3DTA_CURRENT);

	m_lpDevice->SetTextureStageState(1, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_lpDevice->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_MODULATE);
	m_lpDevice->SetTextureStageState(1, D3DTSS_COLORARG2, D3DTA_CURRENT);



	m_lpDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX, 0 );		
	m_lpDevice->SetTextureStageState( 1, D3DTSS_TEXCOORDINDEX, 0 );


	m_lpDevice->SetStreamSource(0, m_lpVB, 0, sizeof(MinMapVERTEX));
	m_lpDevice->SetFVF(MinMapVERTEX::FVF);
	m_lpDevice->SetTexture(0, m_Tex);
	m_lpDevice->SetTexture(1, m_miniMapTex->GetD3dTex());
	
	m_lpDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2);
	m_lpDevice->SetTexture(0, NULL);
	m_lpDevice->SetTexture(1, NULL);


	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_DISABLE);
	m_lpDevice->SetTextureStageState(1, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	m_lpDevice->SetTextureStageState(1 , D3DTSS_COLOROP, D3DTOP_DISABLE);
	m_lpDevice->SetRenderState(D3DRS_FOGENABLE, FOGENABLE);

	m_lpDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);

	m_pSprite->Begin(D3DXSPRITE_ALPHABLEND);
	m_zoomSprite.Draw(986, 45, 0, 0, 38, 55,  0xffffffff);			//���� +, -
	m_zoomSprite.Draw(917, 6, 0, 59, 38, 33,  0xffffffff);			//N
	m_pSprite->End();

}








