#include "_Stdafx.h"
#include "DrawTex2D.h"
#include "define.h"
#include "Mesh.h"

#include "Sky.h"

#include "Frustum.h"
#include "TerrainManager.h"

#include "Water.h"
#include "WaterMannager.h"

#include "Camera.h"

#include "CWorld.h"
#include "Grass.h"
#include "GrassManager.h"

#include "Ase.h"
#include "AseManager.h"

#include "Blur.h"

CBlur::CBlur()
{
	m_id = FALSE;	
//	m_BlurTex = NULL;
	m_cnt = 0;
	m_FX = NULL;
	m_lpDevice = NULL;

	m_pZ = NULL;

	for(int i =0; i < 2; i++)
	{
		m_pSurf[i] = NULL;
		m_pTex[i] = NULL;
	}

	m_test = 0;

	m_waveMapVelocity0 = D3DXVECTOR2(0.09f, 0.06f);
	m_waveMapVelocity1 = D3DXVECTOR2(-0.05f, 0.08f);

	m_ftemp = 0.0f;
}

CBlur::~CBlur()
{

}


HRESULT CBlur::InitBlur(LPDIRECT3DDEVICE9 lpDevice)
{

	m_lpDevice = lpDevice;

	if(m_lpDevice == NULL)
		return E_FAIL;
	

	//���� �ؽ��� �ʱ�ȭ 
	if (FAILED(m_lpDevice->CreateDepthStencilSurface(
		1024, 768, D3DFMT_D16,
		D3DMULTISAMPLE_NONE, 0, TRUE, &m_pZ, NULL)))
	{
		return E_FAIL;
	}


	for(int i=0; i<2; i++){
		if (FAILED(m_lpDevice->CreateTexture(
			1024, 768, 1,
			D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8,
			D3DPOOL_DEFAULT, &m_pTex[i], NULL)))
			return E_FAIL;

		if (FAILED(m_pTex[i]->GetSurfaceLevel(0, &m_pSurf[i])))
			return E_FAIL;
	}


//	D3DXCreateTextureFromFile(m_lpDevice, "./Image/UI/waring.png", &m_pTex[0]);


	D3DXCreateTextureFromFile(m_lpDevice, "./Image/Water/wave0.dds",  &m_pWaveMap0);
	D3DXCreateTextureFromFile(m_lpDevice, "./Image/Water/wave1.dds",  &m_pWaveMap1);

	rippleScale = D3DXVECTOR2(0.1f, 0.1f);
	//m_FX->SetValue("gRippleScale", &rippleScale, sizeof(D3DXVECTOR2));


	BuildFX();

	return S_OK;

}

void CBlur::Update(float dt)
{

	m_ftemp += 0.01f;

	m_waveMapOffset0 += (m_waveMapVelocity0* dt);
	m_waveMapOffset1 += (m_waveMapVelocity1 * dt);


	m_FX->SetTexture("gWaveMap0", m_pWaveMap0);
	m_FX->SetTexture("gWaveMap1", m_pWaveMap1);


	m_FX->SetValue("gWaveMapOffset0", &m_waveMapOffset0, sizeof(D3DXVECTOR2));
	m_FX->SetValue("gWaveMapOffset1", &m_waveMapOffset1, sizeof(D3DXVECTOR2));
	m_FX->SetValue("gRippleScale", &rippleScale, sizeof(D3DXVECTOR2));


	m_FX->SetValue("gSub", &m_ftemp, sizeof(float));
}


void CBlur::BuildFX()
{

	ID3DXBuffer* errors = 0;
	D3DXCreateEffectFromFile(m_lpDevice, "./Fx/blur.fx",
		0, 0, D3DXSHADER_DEBUG, 0, &m_FX, &errors);

	if( errors )
		MessageBoxA(0, (char*)errors->GetBufferPointer(), 0, 0);

	SAFE_RELEASE(errors);

	m_FX->SetTexture("gWaveMap0", m_pWaveMap0);
	m_FX->SetTexture("gWaveMap1", m_pWaveMap1);
}



/*
void CBlur::BlurRender(int elpased, CTerrainManager *terrainManager, CWaterMannager *watermanager
					   ,CSky *sky, CSMeshManager *meshManager, CGrassManager *grassManager
					   ,CCamera *camera, LPD3DXEFFECT shadow,CSMeshManager *shaderManager,CAseManager *aseManager,  SkyDomeTime *sdt)
{

	D3DXMATRIX m, mT, mR, mView, mProj;
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;
	static int	cnt = 0;


	

	m_cnt += elpased;


	if(m_cnt > 100){					//50�� �ѹ��� ����

		m_id = 1-m_id;

		//-------------------------------------------------
		// ������Ÿ�� ����
		//-------------------------------------------------
		m_lpDevice->GetRenderTarget(0, &pOldBackBuffer);
		m_lpDevice->GetDepthStencilSurface(&pOldZBuffer);
		m_lpDevice->GetViewport(&oldViewport);

		//-------------------------------------------------
		// ������ ������ �ؽ��ķ� Ÿ�� ��ȯ
		//-------------------------------------------------
		m_lpDevice->SetRenderTarget(0, m_pSurf[1 - m_id]);
		m_lpDevice->SetDepthStencilSurface(m_pZ);


		//����Ʈ����
		D3DVIEWPORT9 viewport = {0,0
			,1024  //��
			,768 //����
			,0.0f, 1.0f};
		m_lpDevice->SetViewport(&viewport);

		//---------------------------------------------------------------------------
		//				ȭ�鿡 ������ �Ǵ� ��� ��ü�� ������ �ϴ� ��
		//---------------------------------------------------------------------------

//		m_lpDevice->SetRenderState(D3DRS_FOGCOLOR, sdt->Fog);
		//������Ÿ�� Ŭ����
//		m_lpDevice->SetRenderState(D3DRS_FOGENABLE, TRUE);
		m_lpDevice->Clear(0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xff0000ff, 1.0f, 0);

		////�ϴ� ����
		sky->Draw(NULL);

		////�� ���� ���� �ִ� ������ ���� �ɶ��� ���� �����Ѵ�.
//		if(terrainManager->GetCheck()[13] == TRUE)
//			watermanager->DrawWater(camera->GetEye(), camera->GetViewProj());

		//���̴� ������Ʈ ����
//		for(int i=0; i < terrainManager->GetMapNum(); i++)
//			if(terrainManager->GetCheck()[i] == TRUE)
//				shaderManager->RenderShaderMesh(i, NULL);	


		////���� ����
//		terrainManager->DrawMap();

//		////������ �׸��� ����
//		terrainManager->DrawShadowMap(shadow);

		////���� ������Ʈ ����
//		for(int i=0; i < terrainManager->GetMapNum(); i++)
//			if(terrainManager->GetCheck()[i] == TRUE)
//				meshManager->MeshRender(i);

		////�ܵ� ����
//		for(int i=0; i < terrainManager->GetMapNum(); i++)
//  			if(terrainManager->GetCheck()[i] == TRUE)
//				grassManager->MeshRender(i, camera->GetEye().x, camera->GetEye().z);

		//Ase����
		aseManager->RenderModel();


//		if(m_test == 1)
//		{

			//������ �����ϱ� ���� Effect ����
			m_FX->SetTechnique("TShader");
			m_FX->Begin(NULL, 0);

			//----------------------------------------------------------------------------
			//�̰����� �ϴ� ���� ���� �ؽ��Ŀ� ���� �ؽ��ĸ� ���� ������ �ϴ� ��.
			//----------------------------------------------------------------------------
			m_FX->BeginPass(0);

		
			if(m_FX != NULL)
			{

				TVERTEX Vertex[4] = {
					{0.0f,				     0.0f,  0.1f, 1.0f, 0, 0,},
					{(float)1024,		     0.0f,  0.1f, 1.0f, 1, 0,},
					{(float)1024,	(float)768, 0.1f, 1.0f, 1, 1,},
					{		0.0f,   (float)768, 0.1f, 1.0f, 0, 1,},
				};


				m_lpDevice->SetTexture(0, m_pTex[1 - m_id]);
				m_lpDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
				m_lpDevice->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, Vertex, sizeof(TVERTEX));
				

				m_FX->EndPass();
				m_FX->End();
			}
		
			

//		}

		//-  ------------------------------------------------
		// ������Ÿ�� ����
		//-------------------------------------------------
		m_lpDevice->SetRenderTarget(0, pOldBackBuffer);
		m_lpDevice->SetDepthStencilSurface(pOldZBuffer);
		m_lpDevice->SetViewport(&oldViewport);

		pOldBackBuffer->Release();
		pOldZBuffer->Release();
 	}
	else
	{
		cnt = 0;
	}

	//-----------------------------------------------------
	// �״�� ���δ�
	//-----------------------------------------------------
	FLOAT w = (FLOAT)oldViewport.Width;
	FLOAT h = (FLOAT)oldViewport.Height;
	TVERTEX Vertex1[4] = {
		//x  y   z    rhw  tu tv
		{ 0, 0, 0.1f, 1.0f, 0, 0,},
		{ w, 0, 0.1f, 1.0f, 1, 0,},
		{ w, h, 0.1f, 1.0f, 1, 1,},
		{ 0, h, 0.1f, 1.0f, 0, 1,},
	};

	m_lpDevice->SetTexture(0, m_pTex[m_id]);
	m_lpDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );


	m_lpDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex1, sizeof( TVERTEX ) );

}
*/

//----------------------------------------------------------------------------
//�̰����� �ϴ� ���� ���� �ؽ��Ŀ� ���� �ؽ��ĸ� ���� ������ �ϴ� ��.
//----------------------------------------------------------------------------
void CBlur::BlurRender(int elpased, CTerrainManager *terrainManager, CWaterMannager *watermanager
					   ,CSky *sky, CSMeshManager *meshManager, CGrassManager *grassManager
					   ,CCamera *camera, LPD3DXEFFECT shadow,CSMeshManager *shaderManager,CAseManager *aseManager,  SkyDomeTime *sdt,int select)
{
	
	D3DXMATRIX m, mT, mR, mView, mProj;
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;
	static int	cnt = 0;


	m_lpDevice->GetViewport(&oldViewport);

	m_cnt += elpased;
	if(m_cnt > 100){					//50�� �ѹ��� ����

		m_id = 1-m_id;

		//-------------------------------------------------
		// ������Ÿ�� ����
		//-------------------------------------------------
		m_lpDevice->GetRenderTarget(0, &pOldBackBuffer);
		m_lpDevice->GetDepthStencilSurface(&pOldZBuffer);


		//-------------------------------------------------
		// ������ ������ �ؽ��ķ� Ÿ�� ��ȯ
		//-------------------------------------------------

		if(select == 0)
			m_lpDevice->SetRenderTarget(0, m_pSurf[m_id]);
		else if(select == 1)
			m_lpDevice->SetRenderTarget(0, m_pSurf[0]);

		m_lpDevice->SetDepthStencilSurface(m_pZ);


		//����Ʈ����
		D3DVIEWPORT9 viewport = {0,0
			,1024  //��
			,768 //����
			,0.0f, 1.0f};
		m_lpDevice->SetViewport(&viewport);

		//---------------------------------------------------------------------------
		//				ȭ�鿡 ������ �Ǵ� ��� ��ü�� ������ �ϴ� ��
		//---------------------------------------------------------------------------

//		m_lpDevice->SetRenderState(D3DRS_FOGCOLOR, sdt->Fog);
		//������Ÿ�� Ŭ����
		m_lpDevice->SetRenderState(D3DRS_FOGENABLE, FOGENABLE);
		m_lpDevice->Clear(0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xffffffff, 1.0f, 0);
		

		////�ϴ� ����
		sky->Draw(NULL);

		////�� ���� ���� �ִ� ������ ���� �ɶ��� ���� �����Ѵ�.
//		if(terrainManager->GetCheck()[13] == TRUE)
//			watermanager->DrawWater(&camera->GetEye(), camera->GetViewProj());


		//���̴� ������Ʈ ����
		for(int i=0; i < terrainManager->GetMapNum(); i++)
 			if(terrainManager->GetCheck()[i] == TRUE)
				shaderManager->RenderShaderMesh(i, NULL);	

		////���� ����
		terrainManager->DrawMap();


		////������ �׸��� ����
		terrainManager->DrawShadowMap(shadow);


		//////���� ������Ʈ ����
		for(int i=0; i < terrainManager->GetMapNum(); i++)
			if(terrainManager->GetCheck()[i] == TRUE)
				meshManager->MeshRender(i);

		//////�ܵ� ����
		for(int i=0; i < terrainManager->GetMapNum(); i++)
			if(terrainManager->GetCheck()[i] == TRUE)
				grassManager->MeshRender(i, camera->GetEye().x, camera->GetEye().z);

		//Ase����
		aseManager->RenderModel();

		//������ �����ϱ� ���� Effect ����
		m_FX->SetTechnique("TShader");
		m_FX->Begin(NULL, 0);

		//----------------------------------------------------------------------------
		//�̰����� �ϴ� ���� ���� �ؽ��Ŀ� ���� �ؽ��ĸ� ���� ������ �ϴ� ��.
		//----------------------------------------------------------------------------

		if(select == 0)
			m_FX->BeginPass(0);
		else if(select == 1)
			m_FX->BeginPass(1);

		if(m_FX != NULL)
		{

			TVERTEX Vertex[4] = {
				{0.0f,				     0.0f,  0.1f, 1.0f, 0, 0,},
				{(float)1024,		     0.0f,  0.1f, 1.0f, 1, 0,},
				{(float)1024,	(float)768, 0.1f, 1.0f, 1, 1,},
				{		0.0f,   (float)768, 0.1f, 1.0f, 0, 1,},
			};


			if(select == 0)
				m_lpDevice->SetTexture(0, m_pTex[1 - m_id]);
			else if(select == 1)
				m_lpDevice->SetTexture(0, m_pTex[0]);

			m_lpDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
			m_lpDevice->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, Vertex, sizeof(TVERTEX));

			m_FX->EndPass();
			m_FX->End();

		}

		//-------------------------------------------------
		// ������Ÿ�� ����
		//-------------------------------------------------
		m_lpDevice->SetRenderTarget(0, pOldBackBuffer);
		m_lpDevice->SetDepthStencilSurface(pOldZBuffer);
		m_lpDevice->SetViewport(&oldViewport);
		pOldBackBuffer->Release();
		pOldZBuffer->Release();
	}
	else
	{
		cnt = 0;
	}

	//-----------------------------------------------------
	// �״�� ���δ�
	//-----------------------------------------------------
	FLOAT w = (FLOAT)oldViewport.Width;
	FLOAT h = (FLOAT)oldViewport.Height;


	TVERTEX Vertex1[4] = {
		//x  y   z    rhw  tu tv
		{ 0, 0, 0.1f, 1.0f, 0, 0,},
		{ 1024, 0, 0.1f, 1.0f, 1, 0,},
		{ 1024, 786, 0.1f, 1.0f, 1, 1,},
		{ 0, 768, 0.1f, 1.0f, 0, 1,},
	};

	PreOption();
//	m_lpDevice->SetTexture(0, m_pTex[m_id]);

	if(select == 0)
		m_lpDevice->SetTexture(0, m_pTex[m_id]);
	else if(select == 1)
		m_lpDevice->SetTexture(0, m_pTex[0]);
		


	m_lpDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
	m_lpDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex1, sizeof( TVERTEX ) );
	PostOption();


}


void CBlur::ShutDown()
{
	SAFE_RELEASE(m_pZ);

//	D3DXSaveTextureToFile( "Image/s.bmp", D3DXIFF_BMP, m_pTex[0], NULL );
//	D3DXSaveTextureToFile( "Image/r.bmp", D3DXIFF_BMP, m_pTex[1], NULL );
	
	for(int i =0; i < 2; i++)
	{
		SAFE_RELEASE(m_pSurf[i]);
		SAFE_RELEASE(m_pTex[i]);
	}

	SAFE_RELEASE(m_pWaveMap0);
	SAFE_RELEASE(m_pWaveMap1);
}


void CBlur::PreOption()
{
	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
}

void CBlur::PostOption()
{
	m_lpDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	m_lpDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_DISABLE);
}











