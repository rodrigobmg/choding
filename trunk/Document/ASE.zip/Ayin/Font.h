/*****************************************************

*****************************************************/
#pragma once

#include "_Stdafx.h"

class CFont;
class CGraphics;

class CFont
{
  private:
    ID3DXFont *m_Font;

  public:
    CFont();
   // ~CFont();

	ID3DXFont *GetFontCOM() {return m_Font;}
	BOOL fontShutdown();

    BOOL Create(LPDIRECT3DDEVICE9 pd3dDevice, char *Name, long Size = 16, BOOL Bold = FALSE, BOOL Italic = FALSE);
    BOOL Print(char *Text, long XPos, long YPos, long Width = 0, long Height = 0, D3DCOLOR Color = 0xFFFFFFFF, DWORD Format = 0, ID3DXSprite *pSprite = NULL);

};

