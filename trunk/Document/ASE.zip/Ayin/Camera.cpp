// Camera.cpp: implementation of the CCamera class.
//
//////////////////////////////////////////////////////////////////////
#include "_Stdafx.h"
#include "Camera.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCamera::CCamera()
{
	D3DXMatrixIdentity( &m_matView );
	D3DXMatrixIdentity( &m_matInvView );
	D3DXMatrixIdentity( &m_matProjection );
	D3DXMatrixIdentity( &m_matVP );

	m_vLook		= D3DXVECTOR3( 0.0f, 10.0f, 0.0f );
	m_vEye		= D3DXVECTOR3( 0.0f, 0.0f, 0.0f );				
	m_vDir		= D3DXVECTOR3( 0.0f, 0.0f, -1.0f );
	m_vUp		= D3DXVECTOR3( 0.0f, 1.0f, 0.0f );

	m_fFov      = (D3DX_PI/4);
	m_fZoom		= 18.01f;
	m_fYaw		= 0.0f;
	m_fPitch	= 0.0f;

}
//-------------------------------------------------------------------------------------------------------------

CCamera::~CCamera()
{

}
//-------------------------------------------------------------------------------------------------------------

void CCamera::SetCamera()
{
	float	Lock = (D3DX_PI/2) - 0.05f;

	if ( m_fPitch > Lock ) m_fPitch = Lock;
	if ( m_fPitch < (Lock * -1.0f) ) m_fPitch = Lock * -1.0f;

	D3DXMATRIXA16   m;

	D3DXVec3Normalize( &m_vView, &( m_vLook - m_vEye ) );
	D3DXVec3Cross( &m_vCross, &m_vUp, &m_vView );
	
    m_vDir  = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
    D3DXVec3TransformCoord( &m_vDir, &m_vDir, D3DXMatrixRotationX( &m, m_fPitch ) );
    D3DXVec3TransformCoord( &m_vDir, &m_vDir, D3DXMatrixRotationY( &m, m_fYaw ) );

    m_vEye    = m_vLook;
    m_vDir   *= m_fZoom;
    m_vEye   -= m_vDir;

    D3DXMatrixLookAtLH( &m_matView, &m_vEye, &m_vLook, &m_vUp );
	H_pd3dDevice->SetTransform( D3DTS_VIEW, &m_matView );
	D3DXMatrixInverse( &m_matInvView, NULL, &m_matView );
	D3DXVec3Normalize( &m_vDir, &(m_vEye - m_vLook ) );

}
//-------------------------------------------------------------------------------------------------------------

void CCamera::SetView( D3DXVECTOR3 &vLook, float Zoom, float Yaw, float Pitch )
{
	m_vLook  = vLook;				
	m_fZoom  = Zoom;
	m_fYaw   = Yaw;
	m_fPitch = Pitch;
	
    SetCamera();
}
//-------------------------------------------------------------------------------------------------------------

void CCamera::SetLookAt(D3DXVECTOR3 &vLook, float y )
{
	vLook.y += y;
	m_vLook = vLook;
	SetCamera();
}
//-------------------------------------------------------------------------------------------------------------

void CCamera::SetZoom( float Zoom )
{
	//if ( Zoom >= -0.0001f ) Zoom = -0.0001f;
	//if ( Zoom <= -30.0f ) Zoom = -30.0f;
	if ( Zoom <= 3.0f ) Zoom = 3.0f;

	m_fZoom = Zoom;
	SetCamera();
}
//-------------------------------------------------------------------------------------------------------------

void CCamera::SetYaw( float Yaw )
{
	m_fYaw = Yaw;
	SetCamera();
}
//-------------------------------------------------------------------------------------------------------------

void CCamera::SetPitch( float Pitch )
{
	m_fPitch = Pitch;
	SetCamera();
}


//-------------------------------------------------------------------------------------------------------------


void CCamera::SetProjection(DWORD Width, DWORD Height, float Near, float Far)
{
	if ((Width < 0) || (Height < 0)) 
		return;
	
	m_dWidth  = Width;
	m_dHeight = Height;
	m_fNear   = Near;
	m_fFar	  = Far;

	float fAspect = (((float) m_dWidth / (float) m_dHeight));
		
	D3DXMatrixPerspectiveFovLH(&m_matProjection,  m_fFov, fAspect, m_fNear, m_fFar);
		
	H_pd3dDevice->SetTransform(D3DTS_PROJECTION, &m_matProjection);


//	D3DXMATRIX temp;
//	temp = m_matView * m_matProjection;


}

//-------------------------------------------------------------------------------------------------------------

void CCamera::SetProjectionFOV( float Fov )
{
	m_fFov	= Fov;
	SetProjection( m_dWidth, m_dHeight, m_fNear, m_fFar );
}
//-------------------------------------------------------------------------------------------------------------

void CCamera::SetProjectionFar( float Far )
{
	m_fFar = Far;
	SetProjection( m_dWidth, m_dHeight, m_fNear, m_fFar );
}
//-------------------------------------------------------------------------------------------------------------

void CCamera::SetProjectionNear( float Near )
{
	m_fNear = Near;
	SetProjection( m_dWidth, m_dHeight, m_fNear, m_fFar );
}
//-------------------------------------------------------------------------------------------------------------

void CCamera::SetProjectionHeight( DWORD Height )
{
	m_dHeight = Height;
	SetProjection( m_dWidth, m_dHeight, m_fNear, m_fFar );
}
	
//-------------------------------------------------------------------------------------------------------------

void CCamera::SetProjectionWidth( DWORD Width )
{
	m_dWidth = Width;
	SetProjection( m_dWidth, m_dHeight, m_fNear, m_fFar );
}

//-------------------------------------------------------------------------------------------------------------

void CCamera::MoveLocalX( float dist )
{
	D3DXVECTOR3 vNewEye	= m_vEye;
	D3DXVECTOR3 vNewDst	= m_vLook;

	D3DXVECTOR3 vMove;
	D3DXVec3Normalize( &vMove, &m_vCross );
	vMove	*= dist;
	m_vEye += vMove;
	m_vLook  += vMove;

	return SetCamera();

}

/// ī�޶� ��ǥ���� Y��������� dist��ŭ �����Ѵ�.(������ -dist�� ������ �ȴ�.)
void CCamera::MoveLocalY( float dist )
{
	D3DXVECTOR3 vNewEye	= m_vEye;
	D3DXVECTOR3 vNewDst	= m_vLook;

	D3DXVECTOR3 vMove;
	D3DXVec3Normalize( &vMove, &m_vUp );
	vMove	*= dist;
	m_vEye += vMove;
	m_vLook += vMove;

	return SetCamera();
}

/// ī�޶� ��ǥ���� Z��������� dist��ŭ �����Ѵ�.(������ -dist�� ������ �ȴ�.)
void CCamera::MoveLocalZ( float dist )
{
	D3DXVECTOR3 vNewEye	= m_vEye;
	D3DXVECTOR3 vNewDst	= m_vLook;

	D3DXVECTOR3 vMove;
	D3DXVec3Normalize( &vMove, &m_vView );
	
	vMove.y = 0.0f;

	D3DXVec3Normalize( &vMove, &vMove );
	vMove	*= dist;
	
	m_vEye += vMove;
	m_vLook += vMove;

	return SetCamera();
}

/// ������ǥ���� *pv���� ��ġ�� ī�޶� �̵��Ѵ�.
void CCamera::MoveTo( D3DXVECTOR3* pv )
{
	D3DXVECTOR3	dv = *pv - m_vEye;
	m_vEye = *pv;
	m_vLook += dv;
	return SetCamera();
}

void CCamera::RotateLocalX( float angle )
{
	D3DXMATRIXA16 matRot;
	D3DXMatrixRotationAxis( &matRot, &m_vCross, angle );

	D3DXVECTOR3 vNewDst,vNewUp;
	D3DXVec3TransformCoord( &vNewDst, &m_vView, &matRot );	// view * rot�� ���ο� dst vector�� ���Ѵ�.
	//	D3DXVec3Cross( &vNewUp, &vNewDst, &m_vCross );			// cross( dst, x��)���� up vector�� ���Ѵ�.
	//	D3DXVec3Normalize( &vNewUp, &vNewUp );					// up vector�� unit vector��...
	vNewDst += m_vEye;	
	m_vEye = vNewDst;
	// ���� dst position =  eye Position + dst vector

	return SetCamera();
}


void CCamera::RotateLocalY( float angle )
{
	D3DXMATRIXA16 matRot;
	D3DXMatrixRotationAxis( &matRot, &m_vUp, angle );

	D3DXVECTOR3 vNewDst;
	D3DXVec3TransformCoord( &vNewDst, &m_vView, &matRot );	// view * rot�� ���ο� dst vector�� ���Ѵ�.
	vNewDst += m_vEye;	
	m_vEye	= vNewDst;
						// ���� dst position =  eye Position + dst vector

	return SetCamera();
}
//-------------------------------------------------------------------------------------------------------------