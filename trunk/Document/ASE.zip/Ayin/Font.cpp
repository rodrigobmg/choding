/*********************************************************************

*********************************************************************/

#include "_Stdafx.h"
#include "Font.h"
#include "Graphics.h"

CFont::CFont()
{
	m_Font = NULL;
}


BOOL CFont::Create(LPDIRECT3DDEVICE9 pd3dDevice, char *Name, long Size, BOOL Bold, BOOL Italic)
{
	//LOGFONT lf;
	D3DXFONT_DESC font;

	if(pd3dDevice == NULL)
		return FALSE;

	// Clear out the font structure
	ZeroMemory(&font, sizeof(D3DXFONT_DESC));

	// Set the font name and height
	strcpy(font.FaceName, Name);
	font.Height = -Size;
	font.Weight = (Bold == TRUE) ? 700 : 0;
	font.Italic = Italic;
	font.CharSet = HANGUL_CHARSET;
	// Create the font object
	if(FAILED(D3DXCreateFontIndirect(pd3dDevice, &font, &m_Font)))
		return FALSE;
	return TRUE;
}

BOOL CFont::fontShutdown()
{
	SAFE_RELEASE(m_Font);
	return TRUE;
}

BOOL CFont::Print(char *Text, long XPos, long YPos, long Width, long Height, D3DCOLOR Color, DWORD Format, ID3DXSprite *pSprite)
{
	RECT Rect;

	if(m_Font == NULL)
		return FALSE;

	if(!Width)
		Width = 65535;
	if(!Height)
		Height = 65536;

	Rect.left   = XPos;
	Rect.top    = YPos;
	Rect.right  = Rect.left + Width;
	Rect.bottom = Rect.top + Height;
	if(FAILED(m_Font->DrawTextA(NULL, Text, -1, &Rect, Format, Color)))
		return FALSE;
	return TRUE;
}