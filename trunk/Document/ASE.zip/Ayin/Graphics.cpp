#pragma once

#include "_Stdafx.h"
#include "define.h"
#include "Graphics.h"

inline DWORD FtoDW(float f) { return *((DWORD*)&f); }

CGraphics::CGraphics()
{

	m_d3d		  = NULL;
	m_d3dDevice   = NULL;
	m_Sprite	  = NULL;	
	m_dFog        = 0;
}


HRESULT CGraphics::GraphicsInitialize(HWND hWnd, UINT Height, UINT Width)
{

	if(NULL == (m_d3d = Direct3DCreate9(D3D_SDK_VERSION)))
		return E_FAIL;

	ZeroMemory(&m_d3dpp, sizeof(m_d3dpp));

	m_d3dpp.Windowed = TRUE;
	m_d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	m_d3dpp.BackBufferFormat = D3DFMT_A8R8G8B8;;
	m_d3dpp.EnableAutoDepthStencil = TRUE;
	m_d3dpp.BackBufferHeight = Height;
	m_d3dpp.BackBufferWidth = Width;
	m_d3dpp.AutoDepthStencilFormat = D3DFMT_D16;
	m_d3dpp.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;
	m_d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_DEFAULT;
//	m_d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;

	if(FAILED(m_d3d->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd, D3DCREATE_HARDWARE_VERTEXPROCESSING, &m_d3dpp, &m_d3dDevice)))
	{
		return E_FAIL;
	}


	//m_d3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

	m_d3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	m_d3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
		

	D3DXCreateSprite(m_d3dDevice, &m_Sprite);

	return S_OK;


}

BOOL CGraphics::EnableAlphaBlending(BOOL Enable, DWORD Src, DWORD Dest)
{
	if(m_d3dDevice == NULL)
		return FALSE;

	// Enable or disable
	if(FAILED(m_d3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, Enable)))
		return FALSE;

	// Set blend type
	if(Enable == TRUE) {
		m_d3dDevice->SetRenderState(D3DRS_SRCBLEND,  Src);
		m_d3dDevice->SetRenderState(D3DRS_DESTBLEND, Dest);
	}

	return TRUE;
}

BOOL CGraphics::EnableAlphaTesting(BOOL Enable)
{
	if(m_d3dDevice == NULL)
		return FALSE;

	if(FAILED(m_d3dDevice->SetRenderState(D3DRS_ALPHATESTENABLE, Enable)))
		return FALSE;

	// Set test type
	if(Enable == TRUE) {
		m_d3dDevice->SetRenderState(D3DRS_ALPHAREF, 0x08);
		m_d3dDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);
	}
	return TRUE;
}

VOID CGraphics::SetWorld(D3DXMATRIX *matrix)
{
	m_d3dDevice->SetTransform(D3DTS_WORLD, matrix);
}

void CGraphics::InitFog()
{
	DWORD dFog;
	dFog =D3DXCOLOR(0.7f, 0.5f, 0.5f, 1.0f);
	
	m_dFog = dFog;

	float fStart = 10.0f;
	float fEnd = 250.0f;

	//���Ͼ� �Ȱ��� Ư¡�� ���� �����ϱ�
	m_d3dDevice->SetRenderState(D3DRS_FOGENABLE, TRUE);
	m_d3dDevice->SetRenderState(D3DRS_FOGTABLEMODE, D3DFOG_LINEAR);
	m_d3dDevice->SetRenderState(D3DRS_FOGCOLOR, dFog);
	m_d3dDevice->SetRenderState(D3DRS_FOGSTART, FtoDW(fStart));
	m_d3dDevice->SetRenderState(D3DRS_FOGEND, FtoDW(fEnd));

}


BOOL CGraphics::GraphicsShutdown()
{

	SAFE_RELEASE(m_d3dDevice);
	SAFE_RELEASE(m_d3d);
	SAFE_RELEASE(m_Sprite);
	
	return 0;

}