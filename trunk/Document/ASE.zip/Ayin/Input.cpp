/**************************************************
Input.cpp

Programming by hayan
**************************************************/

#include "_Stdafx.h"
#include "input.h"

CInput::CInput()
{
	m_hWnd = NULL;
	m_pDInput = NULL;
	m_pDIKeyboard = NULL;
	m_pDIMouse = NULL;
}
/*
CInput::~CInput()
{
	ReleaseInput();
}
*/
int CInput::InputInitialize(HWND hWnd, HINSTANCE hInst, DWORD Flags)
{
	InputShutdown();
	m_hWnd = hWnd;

	// DInput �ʱ�ȭ
	if (FAILED(DirectInput8Create(hInst, DIRECTINPUT_VERSION, IID_IDirectInput8, (void**)&m_pDInput, NULL)))
		return -1;

	// Ű���� �ʱ�ȭ
	if (FAILED(m_pDInput->CreateDevice(GUID_SysKeyboard, &m_pDIKeyboard, NULL))) 
		return -1;

	if (FAILED(m_pDIKeyboard->SetDataFormat(&c_dfDIKeyboard)))
		return -1;

	if (FAILED(m_pDIKeyboard->SetCooperativeLevel(m_hWnd, Flags))) 
		return -1;

//	if(FAILED(m_pDIKeyboard->Acquire()))
//		return -1;

	// ���콺 �ʱ�ȭ
	if (FAILED(m_pDInput->CreateDevice(GUID_SysMouse, &m_pDIMouse, NULL))) 
		return -1;

	if (FAILED(m_pDIMouse->SetDataFormat(&c_dfDIMouse)))
		return -1;

	if (FAILED(m_pDIMouse->SetCooperativeLevel(m_hWnd, Flags)))
		return -1;

//	if(FAILED(m_pDIMouse->Acquire()))
//		return -1;

	Clear();

	m_PrePosFlag = false;

	return 0;
}

void CInput::InputShutdown()
{
	if(m_pDIKeyboard != NULL)
	{
		m_pDIKeyboard->Unacquire();
		SAFE_RELEASE(m_pDIKeyboard);
	}
	if(m_pDIMouse != NULL)
	{
		m_pDIMouse->Unacquire();
		SAFE_RELEASE(m_pDIMouse);
	}
	SAFE_RELEASE(m_pDInput);
	m_hWnd = NULL;
}

void CInput::Clear()
{
	ZeroMemory(m_CurKeyboard, sizeof(m_CurKeyboard));
	ZeroMemory(m_PreKeyboard, sizeof(m_PreKeyboard));
	ZeroMemory(&m_CurMouse, sizeof(m_CurMouse));
	ZeroMemory(&m_PreMouse, sizeof(m_PreMouse));

	m_XPos = m_YPos = m_ZPos = 0;
	m_PreXPos = m_PreYPos = m_XDelta = m_YDelta = 0;
	m_PrePosFlag = false;
}

int CInput::ReadInput()
{
	if(m_pDIKeyboard == NULL || m_pDIMouse == NULL)
		return -1;

	// ��� �� �����ӿ� Read�ߴ� Cur�� Pre�� �����صθ� Lockó���� �ڵ����� �� �� �ְԵȴ�.
	memcpy(m_PreKeyboard, m_CurKeyboard, sizeof(m_CurKeyboard));
	memcpy(&m_PreMouse, &m_CurMouse, sizeof(m_CurMouse));

	m_pDIKeyboard->Poll();

	if (FAILED(m_pDIKeyboard->GetDeviceState(sizeof(m_CurKeyboard), (LPVOID)m_CurKeyboard)))
	{
		//if(hr != DIERR_INPUTLOST && hr != DIERR_NOTACQUIRED)
		//	return -1;

		if(FAILED(m_pDIKeyboard->Acquire()))
			return -1;

		if (FAILED(m_pDIKeyboard->GetDeviceState(sizeof(m_CurKeyboard), (LPVOID)m_CurKeyboard)))
		{
			return -1;
		}
	}

	m_pDIMouse->Poll();

	if (FAILED(m_pDIMouse->GetDeviceState(sizeof(DIMOUSESTATE), &m_CurMouse)))
	{
		//if(hr != DIERR_INPUTLOST && hr != DIERR_NOTACQUIRED)
		//	return -1;

		if(FAILED(m_pDIMouse->Acquire()))
			return -1;

		if (FAILED(m_pDIMouse->GetDeviceState(sizeof(DIMOUSESTATE), &m_CurMouse)))
		{
			return -1;
		}
	}

	POINT pt;
	GetCursorPos(&pt);
	ScreenToClient(m_hWnd, &pt);

	if (m_PrePosFlag)
	{
		m_XDelta = pt.x - m_PreXPos;
		m_YDelta = pt.y - m_PreYPos;
	}

	// DIMouse�� ����� ��ġ�� �Ǵ��ϴ� �ͺ��� ��Ȯ�ϱ⶧���� ���콺 ��ġ�� ���� ó���Ѵ�.
	// DIMouse�� ��ư�� �Է�ó���� ����� ���̴�.
	m_XPos = pt.x;
	m_YPos = pt.y;
	m_ZPos += m_CurMouse.lZ;

	m_PreXPos = m_XPos;
	m_PreYPos = m_YPos;

	m_PrePosFlag = true;

	return 0;
}

int CInput::Acquire(bool Active)
{
	if (m_pDIKeyboard == NULL || m_pDIMouse == NULL)
		return -1;

	if(Active == true)
	{
		m_pDIKeyboard->Acquire();
		m_pDIMouse->Acquire();
	}
	else
	{
		m_pDIKeyboard->Unacquire();
		m_pDIMouse->Unacquire();
	}

	return 0;
}

bool CInput::GetKeyState(unsigned char Num)
{
	if(m_CurKeyboard[Num] & 0x80 && (m_CurKeyboard[Num] != m_PreKeyboard[Num]))
		return true;
	return false;
}

// 0x80�� ���� �Է½�Ű�� 128�̶� char ������ ����� �Ǿ� ������ �߰� �ȴ�. �׷��� -128�� �Է��ϰڴ�.
void CInput::SetKeyState(unsigned char Num, bool State)
{
	if (State)
		m_CurKeyboard[Num] = -128;
	else
		m_CurKeyboard[Num] = 0;
}

bool CInput::GetPureKeyState(unsigned char Num)
{
	return ((m_CurKeyboard[Num] & 0x80) ? true : false);
}

void CInput::SetKeyLock(unsigned char Num, bool State)
{
	if (State)
		m_PreKeyboard[Num] = -128;
	else
		m_PreKeyboard[Num] = 0;
}

int CInput::GetNumKeyPresses()
{
	int Num = 0;
	for (int i = 0; i < 256; ++i)
	{
		if(m_CurKeyboard[i] & 0x80 && (m_CurKeyboard[Num] != m_PreKeyboard[Num]))
			++Num;
	}
	return Num;
}

int CInput::GetNumPureKeyPresses()
{
	int Num = 0;
	for (int i = 0; i < 256; ++i)
	{
		if(m_CurKeyboard[i] & 0x80)
			++Num;
	}
	return Num;
}

bool CInput::GetButtonState(char Num)
{
	if(m_CurMouse.rgbButtons[Num] && (m_CurMouse.rgbButtons[Num] != m_PreMouse.rgbButtons[Num]))
		return true;

	return false;
}

bool CInput::GetPureButtonState(char Num)
{
	return ((m_CurMouse.rgbButtons[Num]) ? true : false);
}

int CInput::GetNumButtonPresses()
{
	int Num = 0;

	for(int i = 0; i < 4; ++i)
	{
		if(m_CurMouse.rgbButtons[i] && (m_CurMouse.rgbButtons[i] != m_PreMouse.rgbButtons[i]))
			++Num;
	}
	return Num;
}

int CInput::GetNumPureButtonPresses()
{
	int Num = 0;

	for(int i = 0; i < 4; ++i)
	{
		if(m_CurMouse.rgbButtons[i])
			++Num;
	}
	return Num;
}