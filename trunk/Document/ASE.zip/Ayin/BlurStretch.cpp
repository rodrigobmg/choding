#include "_Stdafx.h"
#include "Mesh.h"
#include "CWorld.h"
#include "define.h"
#include "BlurStretch.h"


CBlurStretch::CBlurStretch()
{
	m_lpDevice = NULL;
	m_lpDecl = NULL;
	m_objectDistance = 0;
	m_temp = 0;
	m_time = 0;
	m_blurStretchEffect = 0;
}

CBlurStretch::~CBlurStretch()
{

}

void CBlurStretch::ShutDown()
{
	SAFE_RELEASE(m_lpDecl);
	SAFE_RELEASE(m_blurStretchEffect);
}

HRESULT CBlurStretch::InitBlurStretch(LPDIRECT3DDEVICE9 lpDevice)
{
	m_lpDevice = lpDevice;

	BuildFX();

	return S_OK;
}

void CBlurStretch::BuildFX()
{

	ID3DXBuffer* errors = 0;
	D3DXCreateEffectFromFile(m_lpDevice, "./Fx/blurStretch.fx",
		0, 0, D3DXSHADER_DEBUG, 0, &m_blurStretchEffect, &errors);


	if( errors )
		MessageBoxA(0, (char*)errors->GetBufferPointer(), 0, 0);

	SAFE_RELEASE(errors);

}

HRESULT CBlurStretch::RenderBlurStretch(CMesh *mesh,  int elapsed)
{

	if(m_lpDevice == NULL || m_blurStretchEffect == NULL)
		return E_FAIL;

	D3DMATERIAL9 *pMtrl;
	D3DXVECTOR4 v, light_pos;
	

	m_lpDevice->GetTransform(D3DTS_VIEW, &m_View);
	m_lpDevice->GetTransform(D3DTS_PROJECTION, &m_Proj);


	for(int i=0; i < mesh->GetMatNum(); i++)
	{

		m_blurStretchEffect->SetTechnique("TShader");
		m_blurStretchEffect->Begin(NULL, 0);

		m_time++;

		D3DXMATRIX L;
		D3DXMATRIX WV;
		D3DXMATRIX Scaile;
		D3DXMATRIX Tran;
		D3DXMATRIX LastTran;
		D3DXMATRIX Rotate;

		D3DXMatrixIdentity(&L);
		D3DXMatrixIdentity(&WV);
		D3DXMatrixIdentity(&Scaile);
		D3DXMatrixIdentity(&Tran);
		D3DXMatrixIdentity(&LastTran);
		D3DXMatrixIdentity(&Rotate);

		D3DXMatrixTranslation(&Tran, 0.0f, 5.0f, 0.0f);
		D3DXMatrixScaling(&Scaile, 5.0f, 5.0f, 5.0f);
		D3DXMatrixRotationY(&Rotate, D3DX_PI/180.0f * m_time);

		D3DXMatrixMultiply(&Scaile, &Scaile, &Rotate);
		D3DXMatrixMultiply(&Scaile, &Scaile, &Tran);

		L =  Scaile* *(mesh->GetWorld()[i].GetMatrix());
		WV = L * m_View;

		m_blurStretchEffect->SetMatrix("mWV", &WV);
		m_blurStretchEffect->SetMatrix("mVP", &m_Proj);


		m_temp++;
		if(m_temp > 500)
		{
			m_LastWV = WV;
			// 1������ ���� ���
			m_blurStretchEffect->SetMatrix( "mLastWV", &m_LastWV );
			m_temp = 0;
		}

		for(int pass = 0; pass < 2; pass++)
		{
			m_blurStretchEffect->BeginPass(pass);

			pMtrl = mesh->GetMaterial();

			for(DWORD i=0 ; i < mesh->GetMaterialNum(); i++) 
			{
				v.x = pMtrl->Diffuse.r;
				v.y = pMtrl->Diffuse.g;
				v.z = pMtrl->Diffuse.b;
				v.w = pMtrl->Diffuse.a;
				m_blurStretchEffect->SetVector("vCol", &v);
				mesh->StretchRender(i);
				pMtrl++;
			}

			m_blurStretchEffect->EndPass();
		}

		m_blurStretchEffect->End();
		m_lpDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
		m_lpDevice->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);

}
	return S_OK;

}










