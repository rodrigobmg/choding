#pragma once
#include <stdio.h>
#include <d3dx9.h>
#include <d3d9.h>

class MESH;




struct TEXCOORDFLOAT{
	union{
		float u;
		float uz;
	};
	union{
		float v;
		float vz;
	};
	float oz;
};

struct Material
{
	bool bUseTexture;
	bool bUseOpacity;
	char TextureName[256];
	int  SubMaterialCount;
	Material *SubMaterial;
	LPDIRECT3DTEXTURE9 pTexture;
	D3DMATERIAL9 d3dMaterial;

	Material()
		:bUseTexture(false),
		bUseOpacity(false),
		SubMaterialCount(0),
		SubMaterial(NULL),
		pTexture(NULL)
	{
	}
	~Material()
	{
		if(SubMaterial)
			delete[] SubMaterial;
		if(pTexture)
			pTexture->Release();
	}
};

struct TRIANGLE{
	int VertexIndex[3];
	DWORD VertexColor[3];
	D3DXVECTOR3 VertexNormal[3];
	D3DXVECTOR3 FaceNormal;
	TEXCOORDFLOAT VertexTexture[3];
	int MaterialID;
	bool bView;
	void Init();

};

struct ROT_TRACK
{
	int index;
	D3DXQUATERNION qR;
	float x,y,z,w;

	ROT_TRACK* m_pNext;
	ROT_TRACK* m_pPrev;

	ROT_TRACK()
		:m_pPrev(NULL)
		,m_pNext(NULL)
		,qR(0, 0, 0, 0)
	{
	}
	~ROT_TRACK()
	{
		if(m_pNext)delete m_pNext;
	}
};

struct POS_TRACK
{
	int Index;
	D3DXVECTOR3 Pos;
	POS_TRACK* m_pPrev;
	POS_TRACK* m_pNext;

	POS_TRACK()
		:m_pPrev(NULL),
		m_pNext(NULL)
	{}
	~POS_TRACK()
	{
		if(m_pNext)delete m_pNext;
	}
};

struct SCALE_TRACK
{
	int Index;
	float fX, fY, fZ;
	float aX, aY, aZ;
	float Ang;

	SCALE_TRACK* m_pNext;
	SCALE_TRACK* m_pPrev;

	SCALE_TRACK()
		:m_pPrev(NULL),
		m_pNext(NULL)
	{}

	~SCALE_TRACK()
	{
		if(m_pNext)delete m_pNext;
	}
};


struct ANIMATION
{
	char m_Name[256];
	POS_TRACK* m_Pos;
	ROT_TRACK* m_Rot;
	SCALE_TRACK* m_Scale;

	ANIMATION()
		:m_Pos(NULL),
		m_Rot(NULL),
		m_Scale(NULL)
	{}
	~ANIMATION()
	{
		if(m_Pos)delete m_Pos;
		if(m_Rot)delete m_Rot;
		if(m_Scale)delete m_Scale;
	}
public:
	SCALE_TRACK* GetScaleTrack(float Frame);
	ROT_TRACK* GetRotTrack(float Frame);
	POS_TRACK* GetPosTrack(float Frame);
};

struct MeshContainer
{
	MESH* pData;
	MeshContainer* m_pPrev;
	MeshContainer* m_pNext;
	MeshContainer():
	m_pPrev(NULL),
		m_pNext(NULL)
	{
	}
	~MeshContainer()
	{
		if(m_pNext)delete m_pNext;
	}
	void Add(MeshContainer* pMC)
	{
		if(m_pNext)
			m_pNext->Add(pMC);
		else
		{
			m_pNext = pMC;
			pMC->m_pPrev = this;
		}
	}
};


struct sVERTEX
{

	enum _FVF { FVF= (D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1 ) };

	D3DXVECTOR3 p;
	D3DXVECTOR3 n;
	float u, v;
//	DWORD color;


	sVERTEX():p(0,0,0),n(0,0,0),u(0),v(0)//,color(0xffffffff)
	{
	}

};


class MESH
{
public:
	void CalulateBoundingSphere();

	char m_Name[256];
	bool m_bParents;
	char m_ParentName[256];
	int  m_iNumVertex;
	int  m_iNumTriagnle;
	D3DXVECTOR3* m_VertexList;
	TRIANGLE* m_TriangleList;
	D3DXMATRIX m_TmMatrix;
	D3DXMATRIX m_InvTm;

	D3DXVECTOR3 m_TmPos;
	D3DXQUATERNION m_TmRot;
	D3DXVECTOR3 m_TmScale;
	D3DXQUATERNION m_TmScaleRot;
	TEXCOORDFLOAT* m_TVert;
	MESH* m_pNext;
	MESH* m_pParents;
	int m_iMaterialRef;
	D3DXCOLOR* m_ColorList;
	Material* m_pMaterial;

	ANIMATION m_Animation;
	MeshContainer* m_pChilds;

	D3DXMATRIX m_CalcMatrix;

	D3DXVECTOR3 m_vMin;
	D3DXVECTOR3 m_vMax;
	D3DXVECTOR3 m_vCenter;
	D3DXVECTOR3 m_vRadius;
	float		m_fRadius;

	sVERTEX* m_pVertex;
	short*	 m_pRenderIndex;
	DWORD*	 m_pRenderMaterial;
	int*	 m_pRenderMaterialSize;
	LPD3DXMESH m_pMesh;

	LPDIRECT3DDEVICE9		 m_pDevice;
	LPDIRECT3DVERTEXBUFFER9  m_pVB;

	int m_iVertexNum;

	LPD3DXMESH m_SphereMesh;
	LPD3DXMESH m_BoxMesh; 

	MESH()
		:m_iNumVertex(0),
		m_iVertexNum(0),
		m_iNumTriagnle(0),
		m_VertexList(NULL),
		m_TriangleList(NULL),
		m_pNext(NULL),
		m_iMaterialRef(0),
		m_TVert(NULL),
		m_pChilds(NULL),
		m_vMin(0,0,0),
		m_vMax(0,0,0),
		m_vRadius(0,0,0),
		m_fRadius(0),
		m_bParents(false),
		m_ColorList(NULL),
		m_pParents(NULL),
		m_pRenderMaterialSize(NULL),
		m_pVertex(NULL),
		m_pRenderIndex(NULL),
		m_pRenderMaterial(NULL),
		m_pMaterial(NULL),
		m_pMesh(NULL),
		m_pDevice(NULL),
		m_pVB(NULL)

	{
	}
	~MESH()
	{
		if(m_VertexList)
			delete[] m_VertexList;
		if(m_TriangleList)
			delete[] m_TriangleList;
		if(m_pNext)delete m_pNext;
		if(m_TVert)delete[] m_TVert;
		if(m_ColorList)delete[] m_ColorList;
		if(m_pVertex)delete[] m_pVertex;
		if(m_pRenderIndex)delete[] m_pRenderIndex;
		if(m_pRenderMaterial)delete[] m_pRenderMaterial;
		if(m_pMesh)m_pMesh->Release();
		if(m_pVB)m_pVB->Release();m_pVB = NULL;
		if(m_pDevice)m_pDevice->Release();
		
	}
	
	void AddChild(MESH* pMesh);
	void AnimateMatrix(D3DXMATRIX* mat, float CurFrame);
	void MakeVERTEX();
	void MakeIndex(Material* MaterialList);
	HRESULT CreateVB(LPDIRECT3DDEVICE9 device);
	LPDIRECT3DVERTEXBUFFER9 GetVertexBuffer(){return m_pVB;}

	void CreateSphere();
	void CreateBox();

	void DrawSphere();
	void DrawBox();
};



class CAse
{
public:
	CAse();
	virtual ~CAse();

	char m_line[256];
	char m_string[80];
	int m_ilinecount;
	bool m_bNormalFlag;

	MESH* m_MeshList;
	MESH* m_BoneList;
	Material* m_MaterialList;
	int m_iNumMaterial;

	char m_cName[20];
	int m_iNumMesh;
	MESH* m_CurMesh;

	float m_FirstFrame;
	float m_LastFrame;
	float m_TickPerFrame;
	float m_FrameSpeed;
	LPDIRECT3DDEVICE9 m_device;

public:
	void Release();
	void BoneAnimation(D3DXMATRIX mat, float frame);
	void Animation(D3DXMATRIX mat, float frame);
	MESH* Search(char* name);
	MESH* SearchBone(char* name);
	BOOL ReadASE(char *fname);
	VOID D3DUtil_InitMaterial( D3DMATERIAL9& mtrl, FLOAT r, FLOAT g, FLOAT b,FLOAT a );
	void SetDevice(LPDIRECT3DDEVICE9 device){m_device = device;}
	


protected:
	void MakeInherite();
	void SetAllMesh();
	void AddMesh(MESH* Mesh);
	void AddBoneMesh(MESH* Mesh);
	MESH* GetBoneMesh(D3DXVECTOR3 v1);
	void GetFileName(char* FullDirectory, int Strlength);
	int DecodeASE(FILE *fp);
	int DecodeSCENE(FILE *fp);
	int DecodeMATERIAL_LIST(FILE *fp);
	int DecodeGEOMOBJECT(FILE *fp);
	int DecodeMESH(FILE *fp);
	int DecodeMESH_VERTEX_LIST(FILE *fp);
	int DecodeMESH_FACE_LIST(FILE *fp);
	int DecodeMESH_TVERTLIST(FILE *fp);
	int DecodeMESH_TFACELIST(FILE *fp);
	int	DecodeMESH_CVERTEX(FILE *fp);
	int	DecodeMESH_CFACELIST(FILE *fp);
	int DecodeMESH_NORMALS(FILE *fp);
	int DecodeMaterial(FILE* fp, Material* CurMaterial);
	int DecodeMap(FILE* fp, Material* CurMaterial);
	int DecodeTm(FILE* fp);
	int DecodeSCALE_TRACK(ANIMATION *Animation,FILE *fp);
	int DecodePOS_TRACK(ANIMATION *Animation,FILE *fp);
	int DecodeROT_TRACK(ANIMATION* Animation,FILE *fp);
	int DecodeANIMATION(ANIMATION* Animation,FILE *fp);
	void MakeVertexNormalFromFaceNormal(void);
	void MakeFaceNormalFromWorldVertex(void);

};












































