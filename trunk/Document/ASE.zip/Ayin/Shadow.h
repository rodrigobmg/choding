#pragma once

class CDrawTex2D;
class CAseManager;
//class CStage;

class CShadow
{
private:

	CDrawTex2D *m_shadowTex;
	LPDIRECT3DDEVICE9 m_lpDevice;
	LPD3DXEFFECT m_FX;

	D3DXMATRIX m_view;				//�׸��� ��
	D3DXMATRIX m_Proj;				//�׸��� ����
	D3DXMATRIX m_T;					//-1~1�� 0~1�� �ٲ��ִ� ���

	D3DXVECTOR3 m_vShadowLookAt;
	D3DXVECTOR3 m_vShadowEye;

	CStage *m_stage;

public:
	CShadow();
	~CShadow();
	HRESULT InitShadow(LPDIRECT3DDEVICE9 lpDevice);
	void Update(float cameraX, float cameraY, float cameraZ);
	void BuildFX();
	void ShadowRender(CSMeshManager *meshManager, CTerrainManager *terrain, 
					CSMeshManager *shaderMeshManager,CAseManager *aseManager,CAseManager *aseBoss, CSMeshManager *shaderNPCMesh,D3DXMATRIXA16* getView, int elapsed);

	void ShutDown();
		
	LPD3DXEFFECT GetEffect(){return m_FX;}

private:

	//���̴� �ڵ��
	D3DXHANDLE m_hMatWorldViewProj;
	D3DXHANDLE m_hWVPT;
	D3DXHANDLE m_hIdMap;

};