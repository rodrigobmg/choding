#include "_Stdafx.h"
#include "Stage.h"


CStage CStage::m_stage;