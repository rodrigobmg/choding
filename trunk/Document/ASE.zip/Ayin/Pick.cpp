//////////////////////////////////////////////////////////////////////
//
//	Pick.cpp: implementation of the CPick class.
//
//////////////////////////////////////////////////////////////////////
#include "_Stdafx.h"
#include "Pick.h"

CPick::CPick( LPDIRECT3DDEVICE9 device, HWND hWnd )
{
	m_pDevice	= device;
	m_hWnd		= hWnd;


	m_vCharToRayvDir = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_vPickRayOrig	 = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_vPickRayDir	 = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

}

CPick::~CPick()
{
}

void CPick::CalcDir(D3DXVECTOR3 *pos)
{
	

	D3DXVECTOR3 vRayEnd = m_vPickRayOrig + m_vPickRayDir * 80.0f;
	D3DXVECTOR3 vDir = vRayEnd - (*pos);

	m_vCharToRayvDir = vDir;
	D3DXVec3Normalize(&m_vCharToRayvDir, &m_vCharToRayvDir);
	m_vCharToRayvDir *= 80.0f;
//	m_vCharToRayvDir.y += 15.5f;


}

bool CPick::PickInit()
{


	D3DXMATRIX mat;
	D3DXMatrixIdentity(&mat);

	m_pDevice->SetTransform(D3DTS_WORLD, &mat);


	D3DVIEWPORT9 vp;
	m_pDevice->GetViewport( &vp );
	
	POINT ptCursor;
	GetCursorPos( &ptCursor );
	ScreenToClient( m_hWnd, &ptCursor );
	m_pDevice->SetCursorPosition( ptCursor.x, ptCursor.y, 0L );

	RECT rect;
	GetClientRect( m_hWnd, &rect );

	if( (rect.left > ptCursor.x || rect.right < ptCursor.x) ||
		(rect.top > ptCursor.y || rect.bottom < ptCursor.y) )
	{
		return false;
	}

	D3DXVECTOR3	v;
	D3DXMATRIX matProj;
	D3DXMatrixIdentity(&matProj);
	m_pDevice->GetTransform( D3DTS_PROJECTION, &matProj );
	v.x = ((  (((ptCursor.x-vp.X)*2.0f/vp.Width ) - 1.0f)) - matProj._31 ) / matProj._11;
	v.y = ((- (((ptCursor.y-vp.Y)*2.0f/vp.Height) - 1.0f)) - matProj._32 ) / matProj._22;
	v.z =  1.0f;

	D3DXMATRIXA16 matView;
	D3DXMatrixIdentity(&matView);
	m_pDevice->GetTransform(D3DTS_VIEW, &matView);
	D3DXMatrixInverse( &matView, NULL, &matView );

	m_vPickRayDir.x  = v.x * matView._11 + v.y * matView._21 + v.z * matView._31;
	m_vPickRayDir.y  = v.x * matView._12 + v.y * matView._22 + v.z * matView._32;
	m_vPickRayDir.z  = v.x * matView._13 + v.y * matView._23 + v.z * matView._33;
	m_vPickRayOrig.x = matView._41;
	m_vPickRayOrig.y = matView._42;
	m_vPickRayOrig.z = matView._43;

	D3DXMATRIX matWorld;
	D3DXMatrixIdentity(&matWorld);
	m_pDevice->GetTransform( D3DTS_WORLD, &matWorld );
	D3DXMatrixInverse( &matWorld, NULL, &matWorld );
	D3DXVec3TransformCoord( &m_vPickRayDir, &m_vPickRayDir, &matWorld );
	D3DXVec3TransformCoord( &m_vPickRayOrig, &m_vPickRayOrig, &matWorld );


	return true;

}

bool CPick::IntersectTriangle( D3DXVECTOR3& v0, D3DXVECTOR3& v1, D3DXVECTOR3& v2, float& dist )
{
	float det, u, v;
	D3DXVECTOR3 pvec, tvec, qvec;
    D3DXVECTOR3 edge1 = v1 - v0;
    D3DXVECTOR3 edge2 = v2 - v0;
	
	D3DXVec3Cross(&pvec, &m_vPickRayDir, &edge2);
	det = D3DXVec3Dot(&edge1, &pvec);
	
    if(det < 0.0001f)
		return false;
	
	tvec = m_vPickRayOrig - v0;
    u = D3DXVec3Dot(&tvec, &pvec);
    if(u < 0.0f || u > det)
        return false;
	
    D3DXVec3Cross(&qvec, &tvec, &edge1);
    v = D3DXVec3Dot(&m_vPickRayDir, &qvec);
    if(v < 0.0f || u + v > det)
        return false;
	
    dist = D3DXVec3Dot(&edge2, &qvec);
	dist *= (1.0f / det);
	
    return true;
}

