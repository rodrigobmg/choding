#pragma once

class CWater;

class CWaterMannager
{
private:
	CWater *m_Water;
	D3DXMATRIX m_WaterWorld;
  	DirLight m_light;
	
	LPDIRECT3DDEVICE9 m_lpDevice;

	D3DXVECTOR3 m_CameraPos;
	D3DXMATRIX m_VP;

	CDrawTex2D* m_reflectMap;		
	CDrawTex2D* m_refractMap;

public:

	CWaterMannager();
	~CWaterMannager();

	void InitWater(LPDIRECT3DDEVICE9 device);				//���� �ʿ��� ��ҵ��� �ʱ�ȭ
			
	void InitWaterManager();								//���� ���Ǵ� �ڿ��� �ʱ�ȭ
	void ShutDown();
	void UpdateScene(float dt);

	void DrawWater(D3DXVECTOR3 *cameraPos,  D3DXMATRIX *vp);
	
	CDrawTex2D* GetRefractMap(){return m_refractMap;}
	CDrawTex2D* GetReflectMap(){return m_reflectMap;}

	D3DXMATRIX GetWaterWold(){return m_WaterWorld;}

	void WaterRLRF(CSMeshManager *mesh, CSky *Sky, CTerrainManager *terrain, D3DXMATRIX _VP);


};