#pragma once


class CGraphics
{

private:

	
	struct MYINDEX
	{
		WORD _0, _1, _2;
	};

	LPDIRECT3D9				m_d3d ;
	LPDIRECT3DDEVICE9		m_d3dDevice ;
	LPD3DXSPRITE			m_Sprite;

	DWORD					m_dFog;

public:
	D3DPRESENT_PARAMETERS	m_d3dpp;

	CGraphics();
	HRESULT GraphicsInitialize(HWND hWnd, UINT Height, UINT Width);

	LPDIRECT3DDEVICE9 GetDevice() { return m_d3dDevice; }
	LPD3DXSPRITE GetSprite() {return m_Sprite;}

	VOID SetWorld(D3DXMATRIX *matrix);

	BOOL EnableAlphaBlending(BOOL Enable, DWORD Src = D3DBLEND_SRCALPHA, DWORD Dest = D3DBLEND_INVSRCALPHA);
	BOOL EnableAlphaTesting(BOOL Enable);

	VOID SetupMatrices();
	VOID SetupLights();
	VOID ExSetTexture();
	
	BOOL  GraphicsShutdown();
	void InitFog();

	void  SetFogColor(DWORD fog){m_dFog = fog;}
	DWORD GetFogColor(){return m_dFog;}

};

//#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1)
