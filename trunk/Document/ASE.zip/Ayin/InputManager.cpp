#include "_Stdafx.h"
#include "define.h"
#include "Input.h"
#include "DrawTex2D.h"
#include "CWorld.h"
#include "Camera.h"
#include "Particle.h"
#include "Snow.h"
#include "Rain.h"
#include "Fire.h"
#include "Pick.h"

#include "Frustum.h"
#include "TerrainManager.h "

#include "Mesh.h"
#include "UIManager.h"

#include "MiniMap.h"


#include "Stage.h"

#include "Ase.h"
#include "AseManager.h"

#include "InputManager.h"


CInputManager::CInputManager()
{
	
	m_bPButten = FALSE;
	m_particleList = SNOW;

	m_bFirButten = FALSE;

	m_pureKey = FALSE;
	m_bMagicKey = FALSE;

	m_lpDevie = NULL;

	m_bProcessingEvent = FALSE;
	m_bProcessingTrigger = FALSE;
	m_bLockParticle = FALSE;
	m_iZoom = 0;

	m_MagicTime = 0.0f;
	m_SumElapsed = 0.0f;
	m_iKey = 0;

	for(int i=0; i < 5; i++)
		m_bEffectMagic[i] = FALSE;


	m_fPich = 0.0f;
	m_fYa = 0.0f;

	m_bChec = FALSE;

	m_fSumE    = 0.0f;

	m_bPasting = FALSE;

	m_iPushKey = 0;

	m_bCollisionExis = FALSE;
}

CInputManager::~CInputManager()
{

}
void CInputManager::ShutDown()
{
	m_input.InputShutdown();
}


HRESULT CInputManager::InitInput(HWND hWnd, HINSTANCE hInst, DWORD Flags, LPDIRECT3DDEVICE9 lpDevie)
{
	m_bButten = FALSE;
	m_input.InputInitialize(hWnd, hInst, Flags );
	m_lpDevie = lpDevie;

	m_stage = CStage::GetInstance();
	return S_OK;
}

void CInputManager::Acquire()
{
	m_input.Acquire();
}

void CInputManager::ReadInput()
{
	m_input.ReadInput();
}

void CInputManager::ControlInput(CWorld *world, CCamera *camera,float Height,CMiniMap* miniMap, int elapsed)
{
	float moveacel = 0.05f;
	float temp = -1.0f;



	// �̺�Ʈ ���̶�� Ű�Է� ó���� ���� �ʴ´�.
	if (m_bProcessingEvent == TRUE)
		return;


	if(m_input.GetPureKeyState(DIK_LSHIFT ) == TRUE)
		moveacel -= 0.04f;


	if(m_input.GetPureKeyState(DIK_A) == TRUE)
	{
		camera->MoveLocalX(-moveacel*(elapsed));
		world->Move(camera->GetLook().x, Height, camera->GetLook().z);
	}
	

	if(m_input.GetPureKeyState(DIK_D) == TRUE)
	{
		camera->MoveLocalX(moveacel*(elapsed));
		world->Move(camera->GetLook().x, Height, camera->GetLook().z);
	}


	if(m_input.GetPureKeyState(DIK_W) == TRUE)
	{
		camera->MoveLocalZ(moveacel*(elapsed));
		world->Move(camera->GetLook().x, Height, camera->GetLook().z);
	}
	

	if(m_input.GetPureKeyState(DIK_S) == TRUE)
	{
		m_pureKey = TRUE;
		camera->MoveLocalZ(-moveacel*(elapsed));
		world->Move(camera->GetLook().x, Height, camera->GetLook().z);
	}
/*	
	if(m_input.GetPureKeyState(DIK_Q) == TRUE)
	{
		camera->MoveLocalY(moveacel*(elapsed));
		world->Move(camera->GetLook().x, camera->GetLook().y, camera->GetLook().z);
	}

	if(m_input.GetPureKeyState(DIK_E) == TRUE)
	{
		camera->MoveLocalY(-moveacel*(elapsed));
		world->Move(camera->GetLook().x, camera->GetLook().y, camera->GetLook().z);
	}
*/	

	/*
	if(m_input.GetKeyState(KEY_1) == TRUE)
	{
		if(m_bButten == FALSE)
			m_bButten = TRUE;
		else
			m_bButten = FALSE;
	}
	
	if(m_input.GetKeyState(KEY_2) == TRUE)
	{
		
		if(m_bPButten == FALSE)
		{
			m_bPButten = TRUE;
			m_particleList = RAIN;
		}
		else
			m_bPButten = FALSE;
	
	}

	if(m_input.GetKeyState(KEY_3) == TRUE)
	{
		if(m_bPButten == FALSE)
		{
			m_bPButten = TRUE;
			m_particleList = SNOW;
		}
		else
			m_bPButten = FALSE;

	}

	if(m_input.GetKeyState(KEY_4) == TRUE)
	{
		m_bFirButten = TRUE;
	}
*/


	if(m_input.GetKeyState(KEY_F1) == TRUE)
		m_iZoom = 1;
	else if(m_input.GetKeyState(KEY_F2) == TRUE)
		m_iZoom = 2;


	if(m_input.GetZDelta() == 120)
		camera->SetZoom(camera->GetZoom() + 2.0f);
	if(m_input.GetZDelta() == -120)
		camera->SetZoom(camera->GetZoom() - 2.0f);


	// ���콺 ������ư�� ����ä ȸ���� �ϸ� ������ ȸ���� ó���Ѵ�.
	if(m_input.GetPureButtonState(MOUSE_RBUTTON) == TRUE)
	{
		camera->SetPitch(camera->GetPitch() + m_input.GetYDeltaFromCPCDI()*0.01f);
		FLOAT Yaw = camera->GetYaw() + m_input.GetXDeltaFromCPCDI()*0.01f;
		camera->SetYaw(Yaw);
		// ĳ������ � ���� �����̴� ���
		world->Rotate(0.0f, Yaw, 0.0f);
	}

	CharacterKey();

	m_bLockParticle = FALSE;
	MiniMapInput(miniMap);

}

void CInputManager::SetPast(CCamera *camera)
{
	camera->SetPitch(m_fPich);
	camera->SetYaw(m_fYa);

}

void CInputManager::RendomCamera(CCamera *camera,CUIManager *ui, int elapsed)
{

	m_stage = m_stage->GetInstance();
	m_fSumE += elapsed;

	if(m_bChec == FALSE)
	{
		m_fPich = camera->GetPitch();
		m_fYa   = camera->GetYaw();
		m_bChec = TRUE;
	}

	float fYawVari = 0.0f;
	float fPitchVari = 0.0f;
	if(m_stage->GetStage() == 2.0f)
	{
		if(m_fSumE < 1000.0f)
			fYawVari = 0.0007f* elapsed;
		else if(m_fSumE < 5000.0f)
			fYawVari = 0.005f* elapsed;
		else if(m_fSumE < 8000.0f)
			fYawVari = 0.02f* elapsed;
		else 
			fYawVari = 0.03f* elapsed;
	}

	if(m_stage->GetStage() == 7.0f)
	{
		if(m_fSumE < 1000.0f)
			fYawVari = 0.0007f* elapsed;
		else if(m_fSumE < 5000.0f)
			fYawVari = 0.005f* elapsed;
		else if(m_fSumE < 8000.0f)
			fYawVari = 0.02f* elapsed;
		else 
			fYawVari = 0.03f* elapsed;


		if(m_fSumE < 1000.0f)
			fPitchVari = 0.0003f* elapsed;
		else if(m_fSumE < 2000.0f)
			fPitchVari = -0.005f* elapsed;
		else if(m_fSumE < 6000.0f)
			fPitchVari = 0.004f* elapsed;
		else if(m_fSumE <  8000.0f)
			fPitchVari =  -0.003f* elapsed;
		else 
			fPitchVari = +0.006f* elapsed;
	}

	if(m_stage->GetStage() > 10.0f)
	{
	
		if(m_fSumE < 1000.0f)
			fYawVari = -0.0004f* elapsed;
		else if(m_fSumE < 5000.0f)
			fYawVari = +0.005f* elapsed;
		else if(m_fSumE < 8000.0f)
			fYawVari = -0.008f* elapsed;
		else 
			fYawVari = +0.06f* elapsed;


		if(m_fSumE < 1000.0f)
			fPitchVari = 0.0003f* elapsed;
		else if(m_fSumE < 2000.0f)
			fPitchVari = -0.005f* elapsed;
		else if(m_fSumE < 6000.0f)
			fPitchVari = 0.004f* elapsed;
		else if(m_fSumE <  8000.0f)
			fPitchVari =  -0.003f* elapsed;
		else 
			fPitchVari = +0.003f* elapsed;

	}


	camera->SetPitch(camera->GetPitch() + fPitchVari);
	camera->SetYaw(camera->GetYaw() + fYawVari);


	if(m_fSumE > 11000.0f)
	{
		m_fSumE = 0.0f;
		ui->SetPast(FALSE);
		SetPast(camera);	

		if(m_stage->GetStage() == 2.0f)
			m_stage->SetStage(2.5f);
		if(m_stage->GetStage() == 7.0f)
			m_stage->SetStage(7.5f); 
		if(m_stage->GetStage() == 12.0f)
		{
			FOGENABLE = FALSE;
			m_stage->SetStage(12.5f);
		}
	}	
 
}

void CInputManager::SceneEnd(CCamera *camera)
{
	
	camera->SetPitch(camera->GetPitch() - 300);
	camera->SetYaw(camera->GetYaw());
}


void CInputManager::MiniMapInput(CMiniMap* miniMap)
{
	if(m_input.GetButtonState(MOUSE_LBUTTON) == TRUE)
	{
		miniMap->PlusPos( &m_bLockParticle, m_input.GetXPos(), m_input.GetYPos());
		miniMap->MinusPos(&m_bLockParticle, m_input.GetXPos(), m_input.GetYPos());
	}
}

void CInputManager::CharacterKey()
{

	if(m_input.GetPureKeyState(DIK_A) == TRUE || m_input.GetPureKeyState(DIK_D) == TRUE 
		|| m_input.GetPureKeyState(DIK_W) == TRUE || m_input.GetPureKeyState(DIK_S) == TRUE)
	{
		m_pureKey = TRUE;
	}
	else
		m_pureKey = FALSE;

}

void CInputManager::MagicInput(CAseManager *aseManager,CAseManager *aseBoss,vector<CPSystem*>* PS, CSMeshManager *shaderMeshManager,CTerrainManager *terrainManger,
											CPick *pick, D3DXVECTOR3 *pos, float fHeight, int elapsed)
{
	// �̺�Ʈ ���̶�� Ű�Է� ó���� ���� �ʴ´�.
	//if (m_bProcessingEvent == TRUE)
	//	return;

	m_pick = pick;

	
	//0���� ���̾�
	for(int i=0; i < (int)PS->size(); i++)
	{
		// �̺�Ʈ ���� �ƴҶ��� �߰��� �� �ִ�.
		if (m_bProcessingEvent == FALSE && m_bProcessingTrigger == FALSE && m_bLockParticle == FALSE && m_stage->GetStage() >= 1.0f)
		{
	//		if((*PS)[i]->IsEmpty())
	//		{
				if(m_input.GetButtonState(MOUSE_LBUTTON) == TRUE && m_MagicTime > 0.0f)
				{

					if(m_iPushKey == 0)
						return;
	
					pick->PickInit();
					pick->CalcDir(&(*pos + D3DXVECTOR3(0.0f, 5.0f, 0.0f)));

					m_vPickDir = *pick->GetDir();

					if(m_iPushKey == 1)
					{					
	
						(*PS)[0]->SetDir(pick->GetDir());
						(*PS)[0]->SetPos(&D3DXVECTOR3(pos->x , fHeight+5.0f, pos->z));
						(*PS)[0]->ParticleReSet();

					}

					if(m_iPushKey == 2 ) 
					{
						if(m_stage->GetStage() >= 4.5f)
						{

							(*PS)[1]->SetDir(pick->GetDir());
							(*PS)[1]->SetPos(&D3DXVECTOR3(pos->x , fHeight+4.0f, pos->z));
							(*PS)[1]->ParticleReSet();
	
						}
					}

					if(m_iPushKey == 3 ) 
					{
						if(m_stage->GetStage() >= 9.5f)
						{

							(*PS)[2]->SetDir(pick->GetDir());
							(*PS)[2]->SetPos(&D3DXVECTOR3(pos->x , fHeight+4.0f, pos->z));
							(*PS)[2]->ParticleReSet();
	
						}
					}
				}
		}


		if(!(*PS)[i]->IsEmpty())
		{

			if(m_stage->GetStage() == 1.3f)
			{
			
				//�̰��� ���̴� ��ü���� �浹 üũ�� �ؾ��Ѵ�.
				for(int n=0; n < terrainManger->GetMapNum(); n++)
					if(terrainManger->GetCheck()[n] == TRUE)	
							shaderMeshManager->ObjectCollision(n, (*PS)[i]->GetCreatePos(), &m_bCollisionExis);	
			}

			//��������2 ���� �浹
			if(m_stage->GetStage() == 6.0f)
			{
				if(i == 1)
					aseManager->ObjectCollision((*PS)[i]->GetCreatePos(), &m_bCollisionExis);
			}

			//��������3 Boss
			if(m_stage->GetStage() >= 11.0f)
			{
				if(i != 0)
					aseBoss->CollisionBoss((*PS)[i]->GetCreatePos(), &m_bCollisionExis);
			}
 		}

		(*PS)[i]->Update((float)elapsed, D3DXVECTOR3(0, 0, 0), &m_bCollisionExis);

	}
	m_bProcessingTrigger = FALSE;
}


void CInputManager::TriggerInput(CSMeshManager *shaderMeshManager, CTerrainManager *terrainManger, CUIManager *uiManager,
								 D3DXVECTOR3 *pos)
{

	m_uiManager = uiManager;



	if(m_input.GetButtonState(MOUSE_LBUTTON) == TRUE)
	{
		// �̺�Ʈ ���� �ƴҶ��� Ʈ���� ó���� �Ѵ�.
		if (m_bProcessingEvent == FALSE)
		{
			PickDirOri			m_PickDirOri;
			m_pick->PickInit();

			m_PickDirOri.vDir = *m_pick->GetPickRayDir();
			m_PickDirOri.vOri = *m_pick->GetPickOrig();

			//���̴� ��ü�߿��� NPC�� �浹 ó���� �Ѵ�.
			for(int n=0; n < terrainManger->GetMapNum(); n++)
				if(terrainManger->GetCheck()[n] == TRUE)
					shaderMeshManager->Trigger(uiManager, n, pos, &m_bProcessingEvent, &m_PickDirOri);
		}

		// �׸��� UI �Է�ó���� �Ѵ�.
		if (uiManager->Update(m_input.GetXPos(), m_input.GetYPos()))
			m_bProcessingTrigger = TRUE;
	}


}

void CInputManager::EffectMaigc(vector<CPSystem*>* PS, int elapsed , D3DXVECTOR3 *pos)
{

	
	if(m_MagicTime > 0.0f)
	{
		

		m_SumElapsed += elapsed;

		if(m_SumElapsed >= 1000.0f)
		{
			m_SumElapsed = 0.0f;
			m_MagicTime -= 1.0f;
		}

		m_uiManager->SetTime(m_MagicTime);
		
	}
	else
	{
		m_iPushKey = 0;
		m_uiManager->SetPicture(0);
	}


	for(int i=0; i < (int)PS->size(); i++)
	{

		if (m_bProcessingEvent == FALSE && m_bProcessingTrigger == FALSE && m_bLockParticle == FALSE && m_stage->GetStage() >= 1.0f)
		{
			if(m_input.GetKeyState(KEY_1) == TRUE && m_uiManager->GetMana() > 0)
			{

				m_iPushKey  = m_iKey = 1;						//��� Ű�� ���ȴ���.
				m_uiManager->SetPicture(m_iKey);
				m_MagicTime = MAGICTIME;	//���� �ߵ� �ð�
	//			m_bEffectMagic[0] = TRUE;			
	//			(*PS)[0]->ParticleReSet();
			}

			else if(m_input.GetKeyState(KEY_2) == TRUE && m_uiManager->GetMana() > 0)
			{
				if(m_stage->GetStage() >= 4.5f)
				{

					m_iPushKey  = m_iKey = 2;						//��� Ű�� ���ȴ���.
					m_uiManager->SetPicture(m_iKey);
					m_MagicTime = MAGICTIME;						//���� �ߵ� �ð�
					(*PS)[1]->ParticleReSet();		

	//				m_uiManager->SetCheckKey(TRUE);
	//				m_iPushKey = m_iKey = 2;
				}
			}

			else if(m_input.GetKeyState(KEY_3) == TRUE && m_uiManager->GetMana() > 0)
			{
				if(m_stage->GetStage() >= 9.5f)
				{
					m_iPushKey  = m_iKey = 3;						//��� Ű�� ���ȴ���.
					m_uiManager->SetPicture(m_iKey);
					m_MagicTime = MAGICTIME;						//���� �ߵ� �ð�
					(*PS)[2]->ParticleReSet();		
				}

//				m_uiManager->SetCheckKey(TRUE && m_uiManager->GetMana() > 0);
//				m_iPushKey = m_iKey = 3; 
			}

			else if(m_input.GetKeyState(KEY_4) == TRUE && m_uiManager->GetMana() > 0)
			{
//				m_uiManager->SetCheckKey(TRUE);
//				m_iPushKey = m_iKey = 4;
			}
			else if(m_input.GetKeyState(KEY_5) == TRUE)
			{
//				m_iPushKey = m_iKey = 5;								//Ű�� �־��ش�.
//				m_bEffectMagic[4] = TRUE;				//������ �ߵ��ϴ� �ð��̴�. ��ƼŬ�� ����������� TRUE
				(*PS)[4]->ParticleReSet();				//��ƼŬ�� �����Ѵ�.
				m_uiManager->SetML(1);


			}

		}

		(*PS)[i]->Update((float)elapsed, D3DXVECTOR3(0, 0, 0), &m_bCollisionExis);

		if(!(*PS)[i]->IsEmpty())
		{
			(*PS)[i]->SetPos(&D3DXVECTOR3(pos->x+1, pos->y, pos->z));
			(*PS)[i]->SetYRotate();
		}

		
	}
	
	m_uiManager->SetKey(m_iKey);
	m_iKey = 0;

	

}







