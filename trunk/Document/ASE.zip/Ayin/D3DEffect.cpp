// ----------------------------------------------------
// D3DEffect.cpp
//
// Programming by hayan
// ----------------------------------------------------

#include "_Stdafx.h"
#include "D3DEffect.h"


CD3DEffect::CD3DEffect()
{
	m_pD3DEffect = NULL;
}


CD3DEffect::~CD3DEffect()
{
	Release();
}


int CD3DEffect::Create(LPDIRECT3DDEVICE9 pDevice, char *filename)
{
	DWORD dwHLSLShaderFlags = D3DXFX_NOT_CLONEABLE;// | D3DXSHADER_USE_LEGACY_D3DX9_31_DLL;

//	DWORD dwHLSLShaderFlags = D3DXSHADER_USE_LEGACY_D3DX9_31_DLL;// | D3DXSHADER_USE_LEGACY_D3DX9_31_DLL;
#ifdef _DEBUG
	dwHLSLShaderFlags = dwHLSLShaderFlags | D3DXSHADER_DEBUG | D3DXSHADER_SKIPOPTIMIZATION;
#endif

	HRESULT hr;

	ID3DXBuffer* errors = 0;

	if (FAILED(hr = D3DXCreateEffectFromFile( pDevice, filename,
			NULL, NULL, dwHLSLShaderFlags, NULL, &m_pD3DEffect, &errors ) ))
	{
//		return -1;
	}

	if( errors )
		MessageBox(0, (TCHAR*)errors->GetBufferPointer(), 0, 0);

	return 0;
}

void CD3DEffect::Release()
{
	if (m_pD3DEffect != NULL)
	{
		m_pD3DEffect->Release();
		m_pD3DEffect = NULL;
	}
}