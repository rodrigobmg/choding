#ifndef _ZFFSKINNEDMESH_H_
#define _ZFFSKINNEDMESH_H_

#include <d3d9.h>
#include <d3dx9.h>
#include "define.h"
#include "ZCMesh.h"
#include "zdefine.h"
#include "ZNode.h"
#include "ZTrack.h"
#include "ZMesh.h"
#include "ZSkinnedMesh.h"

/**
 * D3D�� Fixed Function ��Ű�� �޽� Ŭ����
 *
 */
class ZFFSkinnedMesh : public ZSkinnedMesh
{
protected:
	int		_CreateVIB( ZCMesh* pMesh );
	void	_ApplyPalette( D3DXMATRIX* pTM );
public:
	ZFFSkinnedMesh( LPDIRECT3DDEVICE9 pDev, ZCMesh* pMesh );
	~ZFFSkinnedMesh();

	virtual int	Draw( D3DXMATRIX* pTM );
};


#endif // _ZFFSKINNEDMESH_H_