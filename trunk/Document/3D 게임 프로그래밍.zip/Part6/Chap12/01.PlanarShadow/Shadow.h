//-----------------------------------------------------------------------------
// File: Shadow.h
//
// Desc: Header file Shadow sample app
//-----------------------------------------------------------------------------
#pragma once




//-----------------------------------------------------------------------------
// Defines, and constants
//-----------------------------------------------------------------------------
// TODO: change "DirectX AppWizard Apps" to your name or the company name
#define DXAPP_KEY        TEXT("Software\\DirectX AppWizard Apps\\Shadow")

// Struct to store the current input state
struct UserInput
{
    // TODO: change as needed
    BOOL bRotateUp;
    BOOL bRotateDown;
    BOOL bRotateLeft;
    BOOL bRotateRight;
};


//-----------------------------------------------------------------------------
// Name: class CMyD3DApplication
// Desc: Application class. The base class (CD3DApplication) provides the 
//       generic functionality needed in all Direct3D samples. CMyD3DApplication 
//       adds functionality specific to this sample program.
//-----------------------------------------------------------------------------
class CMyD3DApplication : public CD3DApplication
{
    BOOL                    m_bLoadingApp;          // TRUE, if the app is loading
    CD3DFont*               m_pFont;                // Font for drawing text
    ID3DXMesh*              m_pMeshOcc;				// D3DX mesh
	D3DMATERIAL9			m_matOcc;
	LPDIRECT3DTEXTURE9		m_ptexOcc;
    
	ID3DXMesh*              m_pMeshFloor;			// D3DX mesh
	D3DMATERIAL9			m_matFloor;
	LPDIRECT3DTEXTURE9		m_ptexFloor;
	
	D3DXVECTOR4				m_vLightPos;			// �׸��ڸ� ���� ����
	D3DXPLANE				m_planeFloor;			// �׸��ڰ� �׷��� ����� ������
	D3DXMATRIXA16			m_matWorld;

    UserInput               m_UserInput;            // Struct for storing user input 

    FLOAT                   m_fWorldRotX;           // World rotation state X-axis
    FLOAT                   m_fWorldRotY;           // World rotation state Y-axis
	BOOL					m_bWireframe;
	BOOL					m_bShadow;
protected:
    virtual HRESULT OneTimeSceneInit();
    virtual HRESULT InitDeviceObjects();
    virtual HRESULT RestoreDeviceObjects();
    virtual HRESULT InvalidateDeviceObjects();
    virtual HRESULT DeleteDeviceObjects();
    virtual HRESULT Render();
    virtual HRESULT FrameMove();
    virtual HRESULT FinalCleanup();
    virtual HRESULT ConfirmDevice( D3DCAPS9*, DWORD, D3DFORMAT );

    HRESULT RenderText();

    void    UpdateInput( UserInput* pUserInput );
	void	DrawFloor();
	void	DrawOcc();
	void	DrawShadow();
	void	DrawStencil();

public:
    LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
    CMyD3DApplication();
    virtual ~CMyD3DApplication();
};

