// Active3DPpg.cpp : Implementation of the CActive3DPropPage property page class.

#include "stdafx.h"
#include "Active3D.h"
#include "Active3DPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CActive3DPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CActive3DPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CActive3DPropPage)
	ON_WM_TIMER()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CActive3DPropPage, "ACTIVE3D.Active3DPropPage.1",
	0xcd03c90c, 0xa0ee, 0x464d, 0xb7, 0xca, 0xc2, 0xe5, 0xc7, 0xdc, 0xe, 0x22)


/////////////////////////////////////////////////////////////////////////////
// CActive3DPropPage::CActive3DPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CActive3DPropPage

BOOL CActive3DPropPage::CActive3DPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_ACTIVE3D_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CActive3DPropPage::CActive3DPropPage - Constructor

CActive3DPropPage::CActive3DPropPage() :
	COlePropertyPage(IDD, IDS_ACTIVE3D_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CActive3DPropPage)
	// NOTE: ClassWizard will add member initialization here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CActive3DPropPage::DoDataExchange - Moves data between page and properties

void CActive3DPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CActive3DPropPage)
	// NOTE: ClassWizard will add DDP, DDX, and DDV calls here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CActive3DPropPage message handlers

void CActive3DPropPage::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	
	COlePropertyPage::OnTimer(nIDEvent);
}

void CActive3DPropPage::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	COlePropertyPage::OnLButtonDown(nFlags, point);
}

void CActive3DPropPage::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	COlePropertyPage::OnRButtonDown(nFlags, point);
}
