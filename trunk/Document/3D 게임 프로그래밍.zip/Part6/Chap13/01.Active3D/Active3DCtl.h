#if !defined(AFX_ACTIVE3DCTL_H__0FF664B3_9FD5_42BF_B7DE_6FEC2A4DC6A7__INCLUDED_)
#define AFX_ACTIVE3DCTL_H__0FF664B3_9FD5_42BF_B7DE_6FEC2A4DC6A7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Active3DCtl.h : Declaration of the CActive3DCtrl ActiveX Control class.

/////////////////////////////////////////////////////////////////////////////
// CActive3DCtrl : See Active3DCtl.cpp for implementation.

#include <d3d9.h>
#include <d3dx9.h>
#include "ZCamera.h"
#include "ZFLog.h"
#include "ZCParser.h"
#include "ZCParsedData.h"
#include "ZDefine.h"
#include "ZNodeMgr.h"
#include "ZShaderMgr.h"

#define FNAME_XML		"D:\\temp\\Active3D\\guard.xml"
#define DEF_SKINMETHOD	ZNodeMgr::SKINMETHOD_SW

class CActive3DCtrl : public COleControl
{
	DECLARE_DYNCREATE(CActive3DCtrl)

// Constructor
public:
	CActive3DCtrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CActive3DCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	virtual BOOL DestroyWindow();
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

protected:
	LPDIRECT3D9             m_pD3D;
	LPDIRECT3DDEVICE9       m_pd3dDevice;
	D3DXMATRIXA16			m_matWorld;
	D3DXMATRIXA16			m_matView;
	D3DXMATRIXA16			m_matProj;
	float					m_xRot;
	float					m_yRot;
	DWORD					m_dwMouseX;			// ���콺�� ��ǥ
	DWORD					m_dwMouseY;			// ���콺�� ��ǥ
	BOOL					m_bWireframe;	// ���̾����������� �׸����ΰ�?
	int						m_nDrawMode;		// 0 = all, 1 = bone, 2 = mesh
	BOOL					m_bBBox;
	BOOL					m_bActive;
	BOOL					m_bLight;
	BOOL					m_bAnimate;
	float					m_fFrames;
	ZCamera*				m_pCamera;	// Camera Ŭ����
	ZNodeMgr*				m_pNodeMgr;	// ��带 �����ϴ� Node ManagerŬ����
	ZShaderMgr*				m_pShaderMgr;// ���̴��� �����ϴ� Ŭ����
protected:
	HRESULT	InitD3D( HWND hwnd );
	void InitMatrix();
	HRESULT InitGeometry();
	HRESULT InitShader();
	HRESULT LoadXML( char* fname );
	HRESULT InitObjects();
	void DeleteObjects();
	VOID Cleanup();
	VOID SetupLights();
	void LogStatus( void );
	void LogFPS(void);
	void ProcessMouse( void );
	void ProcessKey( void );
	void ProcessInputs( void );
	VOID Animate();
	VOID Render();

// Implementation
protected:
	~CActive3DCtrl();

	DECLARE_OLECREATE_EX(CActive3DCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CActive3DCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CActive3DCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CActive3DCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CActive3DCtrl)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CActive3DCtrl)
	afx_msg void OnLoad(LPCTSTR fname);
	afx_msg void OnPlay();
	afx_msg void OnStop();
	afx_msg void OnWire();
	afx_msg void OnMode();
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

// Event maps
	//{{AFX_EVENT(CActive3DCtrl)
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CActive3DCtrl)
	dispidOnLoad = 1L,
	dispidOnPlay = 2L,
	dispidOnStop = 3L,
	dispidOnWire = 4L,
	dispidOnMode = 5L,
	//}}AFX_DISP_ID
	};
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ACTIVE3DCTL_H__0FF664B3_9FD5_42BF_B7DE_6FEC2A4DC6A7__INCLUDED)
