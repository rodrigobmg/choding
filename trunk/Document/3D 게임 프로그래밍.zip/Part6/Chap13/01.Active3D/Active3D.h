#if !defined(AFX_ACTIVE3D_H__B3954A33_17DE_4ADF_B163_77D981275899__INCLUDED_)
#define AFX_ACTIVE3D_H__B3954A33_17DE_4ADF_B163_77D981275899__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Active3D.h : main header file for ACTIVE3D.DLL

#if !defined( __AFXCTL_H__ )
	#error include 'afxctl.h' before including this file
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CActive3DApp : See Active3D.cpp for implementation.

class CActive3DApp : public COleControlModule
{
public:
	BOOL InitInstance();
	int ExitInstance();
};

extern const GUID CDECL _tlid;
extern const WORD _wVerMajor;
extern const WORD _wVerMinor;

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ACTIVE3D_H__B3954A33_17DE_4ADF_B163_77D981275899__INCLUDED)
