#if !defined(AFX_ACTIVE3DPPG_H__81B03219_127E_4D8C_913A_64B49B80EA0C__INCLUDED_)
#define AFX_ACTIVE3DPPG_H__81B03219_127E_4D8C_913A_64B49B80EA0C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Active3DPpg.h : Declaration of the CActive3DPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CActive3DPropPage : See Active3DPpg.cpp.cpp for implementation.

class CActive3DPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CActive3DPropPage)
	DECLARE_OLECREATE_EX(CActive3DPropPage)

// Constructor
public:
	CActive3DPropPage();

// Dialog Data
	//{{AFX_DATA(CActive3DPropPage)
	enum { IDD = IDD_PROPPAGE_ACTIVE3D };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CActive3DPropPage)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ACTIVE3DPPG_H__81B03219_127E_4D8C_913A_64B49B80EA0C__INCLUDED)
