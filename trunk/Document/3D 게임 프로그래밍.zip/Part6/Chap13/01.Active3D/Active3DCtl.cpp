// Active3DCtl.cpp : Implementation of the CActive3DCtrl ActiveX Control class.

#include "stdafx.h"
#include "Active3D.h"
#include "Active3DCtl.h"
#include "Active3DPpg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define MAINBODY
ZFLog*	g_pLog = NULL;


IMPLEMENT_DYNCREATE(CActive3DCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CActive3DCtrl, COleControl)
	//{{AFX_MSG_MAP(CActive3DCtrl)
	ON_WM_CREATE()
	ON_WM_TIMER()
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CActive3DCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CActive3DCtrl)
	DISP_FUNCTION(CActive3DCtrl, "OnLoad", OnLoad, VT_EMPTY, VTS_BSTR)
	DISP_FUNCTION(CActive3DCtrl, "OnPlay", OnPlay, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION(CActive3DCtrl, "OnStop", OnStop, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION(CActive3DCtrl, "OnWire", OnWire, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION(CActive3DCtrl, "OnMode", OnMode, VT_EMPTY, VTS_NONE)
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CActive3DCtrl, COleControl)
	//{{AFX_EVENT_MAP(CActive3DCtrl)
	// NOTE - ClassWizard will add and remove event map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CActive3DCtrl, 1)
	PROPPAGEID(CActive3DPropPage::guid)
END_PROPPAGEIDS(CActive3DCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CActive3DCtrl, "ACTIVE3D.Active3DCtrl.1",
	0xf7fcf96a, 0xa68b, 0x4627, 0xa2, 0x90, 0x8b, 0x81, 0, 0xa7, 0x7f, 0x19)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CActive3DCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DActive3D =
		{ 0xca6bc09e, 0x3f5f, 0x4cee, { 0x87, 0xae, 0x87, 0xb5, 0x7a, 0x46, 0x97, 0x9d } };
const IID BASED_CODE IID_DActive3DEvents =
		{ 0x35472623, 0x9ff4, 0x4af7, { 0xa7, 0x18, 0x33, 0x49, 0xa3, 0x13, 0x4c, 0x8c } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwActive3DOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CActive3DCtrl, IDS_ACTIVE3D, _dwActive3DOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CActive3DCtrl::CActive3DCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CActive3DCtrl

BOOL CActive3DCtrl::CActive3DCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_ACTIVE3D,
			IDB_ACTIVE3D,
			afxRegApartmentThreading,
			_dwActive3DOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// CActive3DCtrl::CActive3DCtrl - Constructor

CActive3DCtrl::CActive3DCtrl()
{
	InitializeIIDs(&IID_DActive3D, &IID_DActive3DEvents);

	// TODO: Initialize your control's instance data here.
}


/////////////////////////////////////////////////////////////////////////////
// CActive3DCtrl::~CActive3DCtrl - Destructor

CActive3DCtrl::~CActive3DCtrl()
{
	// TODO: Cleanup your control's instance data here.
}


/////////////////////////////////////////////////////////////////////////////
// CActive3DCtrl::OnDraw - Drawing function

void CActive3DCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	// TODO: Replace the following code with your own drawing code.
	pdc->FillRect(rcBounds, CBrush::FromHandle((HBRUSH)GetStockObject(WHITE_BRUSH)));
	pdc->DrawText( "Ready for rendering active3D", (LPRECT)&rcBounds, DT_CENTER | DT_VCENTER );
//	pdc->Ellipse(rcBounds);
}


/////////////////////////////////////////////////////////////////////////////
// CActive3DCtrl::DoPropExchange - Persistence support

void CActive3DCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	// TODO: Call PX_ functions for each persistent custom property.

}


/////////////////////////////////////////////////////////////////////////////
// CActive3DCtrl::OnResetState - Reset control to default state

void CActive3DCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}


/////////////////////////////////////////////////////////////////////////////
// CActive3DCtrl message handlers

int CActive3DCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (COleControl::OnCreate(lpCreateStruct) == -1)
		return -1;
	// TODO: Add your specialized creation code here
	m_pCamera = NULL;
	m_pNodeMgr = NULL;
	m_pShaderMgr = NULL;

	InitD3D( GetSafeHwnd() );
	InitObjects();
	InitGeometry();
	return 0;
}

void CActive3DCtrl::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	KillTimer( 10 );
	DeleteObjects();
	Cleanup();
	
	CWnd::OnClose();
}

void CActive3DCtrl::OnFinalRelease() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	COleControl::OnFinalRelease();
}

BOOL CActive3DCtrl::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	return COleControl::DestroyWindow();
}

void CActive3DCtrl::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	Render();
	COleControl::OnTimer(nIDEvent);
}

HRESULT CActive3DCtrl::InitD3D( HWND hWnd )
{
    // ����̽��� �����ϱ����� D3D��ü ����
    if( NULL == ( m_pD3D = Direct3DCreate9( D3D_SDK_VERSION ) ) )
        return E_FAIL;

    // ����̽��� ������ ����ü
    // ������ ������Ʈ�� �׸����̱⶧����, �̹����� Z���۰� �ʿ��ϴ�.
    D3DPRESENT_PARAMETERS d3dpp;
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.Windowed = TRUE;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;
    d3dpp.EnableAutoDepthStencil = TRUE;
    d3dpp.AutoDepthStencilFormat = D3DFMT_D16;

	D3DCAPS9 caps;
	DWORD dwVSProcess;
	// ����̽��� �ɷ°�(caps)�� �о�´�
	m_pD3D->GetDeviceCaps( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, &caps );

	// �����ϴ� �������̴� ������ 1.0���϶�� SW���̴���, 1.0�̻��̸� HW���̴��� �����Ѵ�.
	dwVSProcess = ( caps.VertexShaderVersion < D3DVS_VERSION(1,0) ) ? D3DCREATE_SOFTWARE_VERTEXPROCESSING : D3DCREATE_HARDWARE_VERTEXPROCESSING;

    /// ����̽� ����
    if( FAILED( m_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
                                      dwVSProcess, 
                                      &d3dpp, &m_pd3dDevice ) ) )
    {
        return E_FAIL;
    }

    // �⺻�ø�, CCW
	m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );

    // Z���۱���� �Ҵ�.
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );

    return S_OK;
}

/**-----------------------------------------------------------------------------
 * ��� ����
 *------------------------------------------------------------------------------
 */
void CActive3DCtrl::InitMatrix()
{
	/// ���� ��� ����
	D3DXMatrixIdentity( &m_matWorld );
    m_pd3dDevice->SetTransform( D3DTS_WORLD, &m_matWorld );

    /// �� ����� ����
    D3DXVECTOR3 vEyePt( 0.0f, 100.0f, -(float)250.0f );
    D3DXVECTOR3 vLookatPt( 0.0f, 100.0f, 0.0f );
    D3DXVECTOR3 vUpVec( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_matView, &vEyePt, &vLookatPt, &vUpVec );
    m_pd3dDevice->SetTransform( D3DTS_VIEW, &m_matView );

    /// ���� �������� ���
	D3DXMatrixPerspectiveFovLH( &m_matProj, D3DX_PI/4, 1.0f, 1.0f, 1000.0f );
    m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &m_matProj );

	/// ī�޶� �ʱ�ȭ
	m_pCamera->SetView( &vEyePt, &vLookatPt, &vUpVec );
}

/**-----------------------------------------------------------------------------
 * �������� �ʱ�ȭ
 *------------------------------------------------------------------------------
 */
HRESULT CActive3DCtrl::InitGeometry()
{
	InitMatrix();

	// ������ ���콺 ��ġ ����
	POINT	pt;
	GetCursorPos( &pt );
	m_dwMouseX = pt.x;
	m_dwMouseY = pt.y;
	m_xRot = 0.0f;
	m_yRot = 0.0f;
	return S_OK;
}

HRESULT CActive3DCtrl::InitShader()
{
	// ���̴� �Ŵ��� ��ü ����
	m_pShaderMgr = new ZShaderMgr( m_pd3dDevice );

	return S_OK;
}

HRESULT CActive3DCtrl::LoadXML( char* fname )
{
	ZCParser*		pParser = NULL;		// �ļ���ü
	ZCParsedData*	pData = NULL;		// �Ľ̵����� ��ü

	pParser = new ZCParser();			// �ļ� �ʱ�ȭ
	pData = new ZCParsedData();			// �Ľ̵����� �ʱ�ȭ

	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char filename[_MAX_FNAME];
	char ext[_MAX_EXT];
	string str;
	_splitpath( fname, drive, dir, filename, ext ); str = drive; str+=dir; SetCurrentDirectory( str.c_str() );

	if( !pParser->Parse( pData, fname ) ) return E_FAIL;	// �ļ� �۵�!

	S_DEL( m_pNodeMgr );
	m_pNodeMgr = new ZNodeMgr( m_pd3dDevice, pData, DEF_SKINMETHOD, m_pShaderMgr );	//��� �Ŵ��� ����

	m_fFrames = m_pNodeMgr->GetInfo()->fAnimationStart;

	S_DEL( pData );		// �ļ���ü ����
	S_DEL( pParser );	// �Ľ̵����� ��ü ����

	InitGeometry();

	m_bWireframe = FALSE;	// ���̾����������� �׸����ΰ�?
	m_nDrawMode = 2;		// 0 = all, 1 = bone, 2 = mesh
	m_bBBox = FALSE;
	m_bActive = TRUE;
	m_bLight = FALSE;
	m_bAnimate = TRUE;
	return S_OK;
}

HRESULT CActive3DCtrl::InitObjects()
{
	S_DEL( m_pCamera );
	S_DEL( g_pLog );

	m_pCamera = new ZCamera;			// ī�޶� �ʱ�ȭ
	g_pLog = new ZFLog( ZF_LOG_TARGET_WINDOW );	// �α밴ü �ʱ�ȭ
	if( FAILED( InitShader() ) ) return E_FAIL;

	return S_OK;
}

void CActive3DCtrl::DeleteObjects()
{
	/// ��ϵ� Ŭ���� �Ұ�
	S_DEL( m_pNodeMgr );
	S_DEL( m_pCamera );
	S_DEL( g_pLog );
	S_DEL( m_pShaderMgr );
}

/**-----------------------------------------------------------------------------
 * �ʱ�ȭ ��ü�� �Ұ�
 *------------------------------------------------------------------------------
 */
VOID CActive3DCtrl::Cleanup()
{
    if( m_pd3dDevice != NULL ) 
        m_pd3dDevice->Release();

    if( m_pD3D != NULL )       
        m_pD3D->Release();
}


/**-----------------------------------------------------------------------------
 * ���� ����
 *------------------------------------------------------------------------------
 */
VOID CActive3DCtrl::SetupLights()
{
	D3DXVECTOR3 vecDir;									/// ���⼺ ����(directional light)�� ���� ���� ����
	D3DLIGHT9 light;									/// ���� ����ü
	/// ���� ����
	if( m_bLight )
	{
		ZeroMemory( &light, sizeof(D3DLIGHT9) );			/// ����ü�� 0���� �����.
		light.Type       = D3DLIGHT_DIRECTIONAL;			/// ������ ����(�� ����,���⼺ ����,����Ʈ����Ʈ)
		light.Diffuse.r  = 1.0f;							/// ������ ����� ���
		light.Diffuse.g  = 1.0f;
		light.Diffuse.b  = 1.0f;
		vecDir = D3DXVECTOR3( 0, 0, -1 );
		D3DXVec3Normalize( (D3DXVECTOR3*)&light.Direction, &vecDir );	/// ������ ������ �������ͷ� �����.
		light.Range       = 1000.0f;									/// ������ �ٴٸ��� �ִ� �ִ�Ÿ�
		m_pd3dDevice->SetLight( 0, &light );							/// ����̽��� 0�� ���� ��ġ
		m_pd3dDevice->LightEnable( 0, TRUE );							/// 0�� ������ �Ҵ�
		m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );			/// ���������� �Ҵ�
		m_pd3dDevice->SetRenderState( D3DRS_AMBIENT, 0x00a0a0a0 );		/// ȯ�汤��(ambient light)�� �� ����
	}
	else
	{
		m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE );
		m_pd3dDevice->SetRenderState( D3DRS_AMBIENT, 0x00ffffff );		/// ȯ�汤��(ambient light)�� �� ����
	}

	// ������ skin���̴��� 200��°�� ����(projection)����� �ʿ��ϴ�.
	D3DXMATRIXA16	m;
	D3DXMatrixTranspose( &m, &m_matProj );
	m_pd3dDevice->SetVertexShaderConstantF( 200, (float*)&m, 4 );

	// ������ skin���̴��� 204��°�� ī�޶�(view)����� �ʿ��ϴ�.
	D3DXMatrixTranspose( &m, &m_matView );
	m_pd3dDevice->SetVertexShaderConstantF( 204, (float*)&m, 3 );
	
	// ������ skin���̴��� 207��°�� �������Ͱ� �ʿ��ϴ�.(������ ����Ʈ ���̵�)
	m_pd3dDevice->SetVertexShaderConstantF( 207, (float*)&vecDir, 1 );
}
/**-----------------------------------------------------------------------------
 * Status���� ���
 *------------------------------------------------------------------------------
 */
void CActive3DCtrl::LogStatus( void )
{
	g_pLog->Log( "FillMode:%s", m_bWireframe ? "wireframe" : "Solid");
	g_pLog->Log( "Animation:%s", m_bAnimate ? "On" : "Off" );
	g_pLog->Log( "DrawMode:%s", m_nDrawMode == 0 ? "All" : m_nDrawMode == 1 ? "Bone" : "Mesh" );
	g_pLog->Log( "BoundingBox:%s", m_bBBox ? "On" : "Off" );
}


/**-----------------------------------------------------------------------------
 * FPS(Frame Per Second)���
 *------------------------------------------------------------------------------
 */
void CActive3DCtrl::LogFPS(void)
{
	static DWORD	nTick = 0;
	static DWORD	nFPS = 0;

	/// 1�ʰ� �����°�?
	if( GetTickCount() - nTick > 1000 )
	{
		nTick = GetTickCount();
		/// FPS�� ���
		g_pLog->Log("FPS:%d", nFPS );

		nFPS = 0;
		LogStatus();	/// ���������� ���⼭ ���(1�ʿ� �ѹ�)
		return;
	}
	nFPS++;
}


/**-----------------------------------------------------------------------------
 * ���콺 �Է� ó��
 *------------------------------------------------------------------------------
 */
void CActive3DCtrl::ProcessMouse( void )
{
}

/**-----------------------------------------------------------------------------
 * Ű���� �Է� ó��
 *------------------------------------------------------------------------------
 */
void CActive3DCtrl::ProcessKey( void )
{
}

/**-----------------------------------------------------------------------------
 * �Է� ó��
 *------------------------------------------------------------------------------
 */
void CActive3DCtrl::ProcessInputs( void )
{
	ProcessMouse();
	ProcessKey();
}

/**-----------------------------------------------------------------------------
 * �ִϸ��̼� ����
 *------------------------------------------------------------------------------
 */
VOID CActive3DCtrl::Animate()
{
	D3DXMATRIXA16	matTM;
	D3DXMATRIXA16	matX;
	D3DXMATRIXA16	matY;

	ZObjectInfo*	pInfo = m_pNodeMgr->GetInfo();

	ProcessInputs();				// �Է�ó��
	SetupLights();					// ��������
	D3DXMatrixRotationX( &matX, m_xRot );
	D3DXMatrixRotationY( &matY, m_yRot );
	matTM = matX * matY;
//	D3DXMatrixScaling( &matTM, 0.1f, 0.1f, 0.1f );
	m_pNodeMgr->SetTM( &matTM );
	m_pNodeMgr->Animate( m_fFrames );		// ��� �ִϸ��̼� ��Ű��
	if( m_bAnimate )
	{
		m_fFrames += 1.0f;
		if( m_fFrames > pInfo->fAnimationEnd ) m_fFrames = pInfo->fAnimationStart;
	}

	LogFPS();						// �α�
}


/**-----------------------------------------------------------------------------
 * ȭ�� �׸���
 *------------------------------------------------------------------------------
 */
VOID CActive3DCtrl::Render()
{
    /// �ĸ���ۿ� Z���� �ʱ�ȭ
    m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(200,200,200), 1.0f, 0 );
	m_pd3dDevice->SetRenderState( D3DRS_FILLMODE, m_bWireframe ? D3DFILL_WIREFRAME : D3DFILL_SOLID );

	if( !m_pNodeMgr ) return;
	/// �ִϸ��̼� ��ļ���
	Animate();
    /// ������ ����
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		if( m_nDrawMode != 4 )
		{
			m_pNodeMgr->Draw( m_nDrawMode );		// ��� �׸���
		}
		
		if( m_bBBox )
			m_pNodeMgr->DrawBBox( m_nDrawMode );	// ������ �׸���

		m_pd3dDevice->EndScene();
    }

    /// �ĸ���۸� ���̴� ȭ������!
    m_pd3dDevice->Present( NULL, NULL, NULL, NULL );
}




void CActive3DCtrl::OnLoad(LPCTSTR fname) 
{
	// TODO: Add your dispatch handler code here
	LoadXML( (char*)fname );
}

void CActive3DCtrl::OnPlay() 
{
	// TODO: Add your dispatch handler code here
	KillTimer( 10 );
	SetTimer( 10, 10, NULL );
	m_bAnimate = TRUE;
}

void CActive3DCtrl::OnStop() 
{
	// TODO: Add your dispatch handler code here
	m_bAnimate = FALSE;
}

void CActive3DCtrl::OnWire() 
{
	// TODO: Add your dispatch handler code here
	m_bWireframe = !m_bWireframe;
}

void CActive3DCtrl::OnMode() 
{
	// TODO: Add your dispatch handler code here
	++m_nDrawMode;
	m_nDrawMode %= 3;
}

