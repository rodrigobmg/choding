/**-----------------------------------------------------------------------------
 * \brief �鿭(GLOW)ȿ��
 * ����: main.cpp
 *
 * ����: GLOWȿ���� ����� ����
 *       
 *------------------------------------------------------------------------------
 */

#define MAINBODY
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <d3d9.h>
#include <d3dx9.h>
#include "ZCamera.h"
#include "ZFrustum.h"
#include "ZFLog.h"
#include "d3dfile.h"
#include "resource.h"

#define WINDOW_W		512
#define WINDOW_H		512
#define TEX_SIZE		64

#define WINDOW_TITLE	"GLOW Effect Tutorial"

#define FNAME_CUBE		"lobby_skybox.x"
#define	SCALE_CUBE		10.0f
#define FNAME_MESH		"skullocc.x"
#define	SCALE_MESH		1.0f
#define POS_X_MESH		0.0f
#define POS_Y_MESH		0.0f
#define POS_Z_MESH		20.0f

#define FNAME_TEX_MESH		"white.jpg"
#define FNAME_TEX_ENV		"LobbyCube.dds"
#define FNAME_VS_REFRACT	"VS_Refract.vs"
#define FNAME_PS_REFRACT	"PS_Refract.ps"
#define FNAME_PS_GBLUR_X	"PS_GBlur_X.ps"
#define FNAME_PS_GBLUR_Y	"PS_GBlur_Y.ps"
#define FNAME_PS_POWER		"PS_Power.ps"
#define FNAME_PS_FINAL		"PS_Final.ps"

 /**-----------------------------------------------------------------------------
 *  ��������
 *------------------------------------------------------------------------------
 */
HWND					g_hwnd = NULL;
HWND					g_hdlg = NULL;

LPDIRECT3D9             g_pD3D       = NULL;	/// D3D ����̽��� ������ D3D��ü����
LPDIRECT3DDEVICE9       g_pd3dDevice = NULL;	/// �������� ���� D3D����̽�
LPDIRECT3DTEXTURE9      g_pTexMesh = NULL;		/// �޽� �ؽ�ó
LPDIRECT3DCUBETEXTURE9	g_pTexEnv = NULL;		/// ȯ�� �ؽ�ó
LPDIRECT3DTEXTURE9      g_pTexTarget1 = NULL;	/// ���� Ÿ�� �ؽ�ó 
LPDIRECT3DSURFACE9      g_pSurTarget1 = NULL;	/// �ؽ�ó�� ���ǽ�
LPDIRECT3DTEXTURE9      g_pTexTarget2 = NULL;	/// ���� Ÿ�� �ؽ�ó 
LPDIRECT3DSURFACE9      g_pSurTarget2 = NULL;	/// �ؽ�ó�� ���ǽ�
LPDIRECT3DTEXTURE9      g_pTexFinal = NULL;		/// ���� Ÿ�� �ؽ�ó 
LPDIRECT3DSURFACE9      g_pSurFinal = NULL;		/// �ؽ�ó�� ���ǽ�

LPDIRECT3DVERTEXSHADER9	g_pVSRefract = NULL;			/// ���� ���� ���̴�
LPDIRECT3DPIXELSHADER9	g_pPSRefract = NULL;			/// ���� �ȼ� ���̴�

LPDIRECT3DPIXELSHADER9	g_pPSGBlurX = NULL;			/// X���� ���� �ȼ� ���̴�
LPDIRECT3DPIXELSHADER9	g_pPSGBlurY = NULL;			/// Y���� ���� �ȼ� ���̴�
LPDIRECT3DPIXELSHADER9	g_pPSPower = NULL;			/// �����κи� �����ϴ� �ȼ� ���̴�
LPDIRECT3DPIXELSHADER9	g_pPSFinal = NULL;			/// ���� �̹����� ������ �̹����� �ռ��ϴ� �ȼ� ���̴�
LPDIRECT3DVERTEXDECLARATION9	g_pDecl = NULL;	/// ������ ��������

D3DXMATRIXA16			g_matWorld;
D3DXMATRIXA16			g_matMesh;
D3DXMATRIXA16			g_matCube;
D3DXMATRIXA16			g_matView;
D3DXMATRIXA16			g_matProj;
D3DXVECTOR4				g_vLightPos;

float					g_xRot = 0.0f;
float					g_yRot = 0.0f;
int						g_dwMouseX = 0;			// ���콺�� ��ǥ
int						g_dwMouseY = 0;			// ���콺�� ��ǥ
BOOL					g_bDrawTexture = FALSE;	// �ؽ�ó�� �׸����ΰ�?
BOOL					g_bLight = TRUE;
BOOL					g_bActive = TRUE;
BOOL					g_bBlend = FALSE;

ZCamera*				g_pCamera = NULL;	// Camera Ŭ����
CD3DMesh*				g_pMesh = NULL;
CD3DMesh*				g_pCube = NULL;
float					g_fRefractRatio = 2.0f;	// 0.5 ~ 2.0
float					g_fTransmittance= 1.0f;	// 0.0 ~ 1.0
int						g_nGaussian		= 10;	// 0 ~ 10

int				g_nMaterial = 0;

// diffuse material
D3DXVECTOR4		g_material_D[10] =
{
	D3DXVECTOR4( 1, 0, 0, 0 ),
	D3DXVECTOR4( 0, 1, 0, 0 ),
	D3DXVECTOR4( 0, 0, 1, 0 ),
	D3DXVECTOR4( 1, 1, 0, 0 ),
	D3DXVECTOR4( 1, 0, 1, 0 ),
	D3DXVECTOR4( 0, 1, 1, 0 ),
	D3DXVECTOR4( 1, 1, 1, 0 ),
	D3DXVECTOR4( 145/255.0f, 131/255.0f, 0, 0 ),
	D3DXVECTOR4( 0, 0, 0, 0 ),
	D3DXVECTOR4( 0.87f, 0.60f, 0.32f, 0 )
};

// specular material
D3DXVECTOR4		g_material_S[10] =
{
	D3DXVECTOR4( 1, 0, 0, 0 ),
	D3DXVECTOR4( 0, 1, 0, 0 ),
	D3DXVECTOR4( 0, 0, 1, 0 ),
	D3DXVECTOR4( 1, 1, 0, 0 ),
	D3DXVECTOR4( 1, 0, 1, 0 ),
	D3DXVECTOR4( 0, 1, 1, 0 ),
	D3DXVECTOR4( 1, 1, 1, 0 ),
	D3DXVECTOR4( 1, 1, 0, 0 ),
	D3DXVECTOR4( 0, 0, 0, 0 ),
	D3DXVECTOR4( 0.85f, 0.76f, 0.65f, 0 )
};

/// ����� ������ ������ ����ü
struct MYVERTEX
{
	enum { FVF = (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX2) };
    float	px, py, pz;		/// ������ ��ȯ�� ��ǥ
	float	nx, ny, nz;		/// ������ ����
	float	tx, ty;		/// �ؽ�ó ��ǥ
};

// �ؽ�ó ��¿�
struct TEXVERTEX
{
	enum { FVF=D3DFVF_XYZRHW|D3DFVF_TEX1 };
	float px, py, pz, pw;
	float tx, ty;
};

TEXVERTEX g_vtx[4] =
{
	{		 0-0.5,	TEX_SIZE-0.5, 0, 1, 0, 1 },
	{		 0-0.5,		   0-0.5, 0, 1, 0, 0 },
	{ TEX_SIZE-0.5, TEX_SIZE-0.5, 0, 1, 1, 1 },
	{ TEX_SIZE-0.5,		   0-0.5, 0, 1, 1, 0 }
};

/**-----------------------------------------------------------------------------
 * Direct3D �ʱ�ȭ
 *------------------------------------------------------------------------------
 */
HRESULT InitD3D( HWND hWnd )
{
    // ����̽��� �����ϱ����� D3D��ü ����
    if( NULL == ( g_pD3D = Direct3DCreate9( D3D_SDK_VERSION ) ) )
        return E_FAIL;

    // ����̽��� ������ ����ü
    // ������ ������Ʈ�� �׸����̱⶧����, �̹����� Z���۰� �ʿ��ϴ�.
    D3DPRESENT_PARAMETERS d3dpp;
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.Windowed = TRUE;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;
    d3dpp.EnableAutoDepthStencil = TRUE;
    d3dpp.AutoDepthStencilFormat = D3DFMT_D16;

	D3DCAPS9 caps;
	DWORD dwVSProcess;
	// ����̽��� �ɷ°�(caps)�� �о�´�
	g_pD3D->GetDeviceCaps( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, &caps );

	// �����ϴ� �������̴� ������ 1.0���϶�� SW���̴���, 1.0�̻��̸� HW���̴��� �����Ѵ�.
	dwVSProcess = ( caps.VertexShaderVersion < D3DVS_VERSION(1,0) ) ? D3DCREATE_SOFTWARE_VERTEXPROCESSING : D3DCREATE_HARDWARE_VERTEXPROCESSING;

    /// ����̽� ����
    if( FAILED( g_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
                                      dwVSProcess, 
                                      &d3dpp, &g_pd3dDevice ) ) )
    {
        return E_FAIL;
    }

    // �⺻�ø�, CCW
	g_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );

    // Z���۱���� �Ҵ�.
    g_pd3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );

	g_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
	g_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );
	g_pd3dDevice->SetSamplerState( 1, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
	g_pd3dDevice->SetSamplerState( 1, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );
	g_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	g_pd3dDevice->SetSamplerState( 1, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	g_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
	g_pd3dDevice->SetSamplerState( 1, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR ); 
	g_pd3dDevice->SetSamplerState( 0, D3DSAMP_MIPFILTER, D3DTEXF_ANISOTROPIC );
	g_pd3dDevice->SetSamplerState( 1, D3DSAMP_MIPFILTER, D3DTEXF_ANISOTROPIC );

    return S_OK;
}

/**-----------------------------------------------------------------------------
 * �������۸� �����ϰ� �������� ä���ִ´�.
 *------------------------------------------------------------------------------
 */
HRESULT InitVB()
{
	return S_OK;
}

/**-----------------------------------------------------------------------------
 * �������̴� ����
 *------------------------------------------------------------------------------
 */
HRESULT InitVS()
{
	D3DVERTEXELEMENT9	decl[MAX_FVF_DECL_SIZE];
	// FVF�� ����ؼ� ���������� �ڵ����� ä���ִ´�
	D3DXDeclaratorFromFVF( MYVERTEX::FVF, decl );
	// ������������ g_pDecl�� �����Ѵ�.
	g_pd3dDevice->CreateVertexDeclaration( decl, &g_pDecl );
	LPD3DXBUFFER pCode;

	if( FAILED( D3DXAssembleShaderFromFile( FNAME_VS_REFRACT, NULL, NULL, 0, &pCode, NULL ) ) )
		return E_FAIL;

	g_pd3dDevice->CreateVertexShader( (DWORD*)pCode->GetBufferPointer(), &g_pVSRefract );

	S_REL( pCode );

	return S_OK;
}

/**-----------------------------------------------------------------------------
 * �ȼ����̴��� ����
 *------------------------------------------------------------------------------
 */
HRESULT InitPS()
{
	LPD3DXBUFFER pCode;

	if( FAILED( D3DXAssembleShaderFromFile( FNAME_PS_REFRACT, NULL, NULL, 0, &pCode, NULL ) ) )
		return E_FAIL;
	g_pd3dDevice->CreatePixelShader( (DWORD*)pCode->GetBufferPointer(), &g_pPSRefract );
	S_REL( pCode );

	if( FAILED( D3DXAssembleShaderFromFile( FNAME_PS_GBLUR_X, NULL, NULL, 0, &pCode, NULL ) ) )
		return E_FAIL;
	g_pd3dDevice->CreatePixelShader( (DWORD*)pCode->GetBufferPointer(), &g_pPSGBlurX );
	S_REL( pCode );

	if( FAILED( D3DXAssembleShaderFromFile( FNAME_PS_GBLUR_Y, NULL, NULL, 0, &pCode, NULL ) ) )
		return E_FAIL;
	g_pd3dDevice->CreatePixelShader( (DWORD*)pCode->GetBufferPointer(), &g_pPSGBlurY );
	S_REL( pCode );

	if( FAILED( D3DXAssembleShaderFromFile( FNAME_PS_POWER, NULL, NULL, 0, &pCode, NULL ) ) )
		return E_FAIL;
	g_pd3dDevice->CreatePixelShader( (DWORD*)pCode->GetBufferPointer(), &g_pPSPower );
	S_REL( pCode );

	if( FAILED( D3DXAssembleShaderFromFile( FNAME_PS_FINAL, NULL, NULL, 0, &pCode, NULL ) ) )
		return E_FAIL;
	g_pd3dDevice->CreatePixelShader( (DWORD*)pCode->GetBufferPointer(), &g_pPSFinal );

	S_REL( pCode );

	return S_OK;
}

/**-----------------------------------------------------------------------------
 * �ؽ�ó �ε�
 *------------------------------------------------------------------------------
 */
void InitTexture()
{
    D3DDISPLAYMODE d3ddm;
	D3DXCreateTextureFromFile( g_pd3dDevice, FNAME_TEX_MESH, &g_pTexMesh );
	D3DXCreateCubeTextureFromFile( g_pd3dDevice, FNAME_TEX_ENV, &g_pTexEnv );
    g_pD3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &d3ddm );
	// RadeOn�迭�� D3DFMT_A32B32G32R32F
	// nVidia�迭�� d3ddm.Format�� ����Ұ�
	D3DXCreateTexture(g_pd3dDevice, TEX_SIZE, TEX_SIZE, 0, D3DUSAGE_RENDERTARGET, D3DFMT_A32B32G32R32F, D3DPOOL_DEFAULT, &g_pTexTarget1 );
	g_pTexTarget1->GetSurfaceLevel( 0, &g_pSurTarget1 );
	D3DXCreateTexture(g_pd3dDevice, TEX_SIZE, TEX_SIZE, 0, D3DUSAGE_RENDERTARGET, D3DFMT_A32B32G32R32F, D3DPOOL_DEFAULT, &g_pTexTarget2 );
	g_pTexTarget2->GetSurfaceLevel( 0, &g_pSurTarget2 );
	D3DXCreateTexture(g_pd3dDevice, WINDOW_W, WINDOW_H, 0, D3DUSAGE_RENDERTARGET, D3DFMT_A32B32G32R32F, D3DPOOL_DEFAULT, &g_pTexFinal );
	g_pTexFinal->GetSurfaceLevel( 0, &g_pSurFinal );
}

/**-----------------------------------------------------------------------------
 * ��� ����
 *------------------------------------------------------------------------------
 */
void InitMatrix()
{
	/// ���� ��� ����
	D3DXMatrixIdentity( &g_matWorld );
    g_pd3dDevice->SetTransform( D3DTS_WORLD, &g_matWorld );

    /// �� ����� ����
    D3DXVECTOR3 vEyePt( 0.0f, 3.0f, -13.0f );
    D3DXVECTOR3 vLookatPt( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &g_matView, &vEyePt, &vLookatPt, &vUpVec );
    g_pd3dDevice->SetTransform( D3DTS_VIEW, &g_matView );

    /// �������� ���
	D3DXMatrixPerspectiveFovLH( &g_matProj, D3DX_PI/4, 1.0f, 1.0f, 1000.0f );
    g_pd3dDevice->SetTransform( D3DTS_PROJECTION, &g_matProj );

	/// ī�޶� �ʱ�ȭ
	g_pCamera->SetView( &vEyePt, &vLookatPt, &vUpVec );
}

void LoadX( char* str )
{
	if( g_pMesh )
	{
		g_pMesh->InvalidateDeviceObjects();
		g_pMesh->Destroy();
		S_DEL( g_pMesh );
		g_pMesh = new CD3DMesh();
		g_pMesh->Create( g_pd3dDevice, str );
		g_pMesh->SetFVF( g_pd3dDevice, MYVERTEX::FVF );
		g_pMesh->RestoreDeviceObjects( g_pd3dDevice );
	}
}

/**-----------------------------------------------------------------------------
 * �������� �ʱ�ȭ
 *------------------------------------------------------------------------------
 */
HRESULT InitObjects()
{
	S_DEL( g_pCamera );
	S_DEL( g_pLog );

	g_pCamera = new ZCamera;			// ī�޶� �ʱ�ȭ
	g_pLog = new ZFLog( ZF_LOG_TARGET_WINDOW );	// �α밴ü �ʱ�ȭ
	g_pMesh = new CD3DMesh();
	g_pMesh->Create( g_pd3dDevice, FNAME_MESH );
	g_pMesh->SetFVF( g_pd3dDevice, MYVERTEX::FVF );
	g_pMesh->RestoreDeviceObjects( g_pd3dDevice );

	g_pCube = new CD3DMesh();
	g_pCube->Create( g_pd3dDevice, FNAME_CUBE );
	g_pCube->SetFVF( g_pd3dDevice, MYVERTEX::FVF );
	g_pCube->RestoreDeviceObjects( g_pd3dDevice );

	InitVB();
	InitVS();
	InitPS();
	InitTexture();

	return S_OK;
}

/**-----------------------------------------------------------------------------
 * �ʱ�ȭ ��ü�� �Ұ�
 *------------------------------------------------------------------------------
 */
void DeleteObjects()
{
	/// ��ϵ� Ŭ���� �Ұ�
	S_DEL( g_pCamera );
	S_DEL( g_pLog );
	g_pMesh->InvalidateDeviceObjects();
	g_pMesh->Destroy();
	S_DEL( g_pMesh );
	g_pCube->InvalidateDeviceObjects();
	g_pCube->Destroy();
	S_DEL( g_pCube );
}

/**-----------------------------------------------------------------------------
 * ��İ� ���� �ʱ�ȭ
 *------------------------------------------------------------------------------
 */
HRESULT InitGeometry()
{
	InitMatrix();

	// ������ ���콺 ��ġ ����
	g_dwMouseX = 0;
	g_dwMouseY = 0;
	g_xRot = 0.0f;
	g_yRot = 0.0f;
	return S_OK;
}


/**-----------------------------------------------------------------------------
 * �ʱ�ȭ ��ü�� �Ұ�
 *------------------------------------------------------------------------------
 */
VOID Cleanup()
{
	S_REL( g_pPSGBlurX );
	S_REL( g_pPSGBlurY );
	S_REL( g_pPSPower );
	S_REL( g_pPSFinal );
	S_REL( g_pPSRefract );
	S_REL( g_pVSRefract );
	S_REL( g_pDecl );
	S_REL( g_pTexMesh );
	S_REL( g_pTexEnv );
	S_REL( g_pSurTarget1 );
	S_REL( g_pTexTarget1 );
	S_REL( g_pSurTarget2 );
	S_REL( g_pTexTarget2 );
	S_REL( g_pSurFinal );
	S_REL( g_pTexFinal );
	S_REL( g_pd3dDevice );
	S_REL( g_pD3D );
}


/**-----------------------------------------------------------------------------
 * ���� ����
 *------------------------------------------------------------------------------
 */
VOID SetupLights()
{
	g_vLightPos = D3DXVECTOR4( -10,  10, -10, 0 );

	/// ���� ����
	if( g_bLight )
	{
		D3DLIGHT9	l;
		ZeroMemory( &l, sizeof l );
		l.Type = D3DLIGHT_POINT;
		l.Position = D3DXVECTOR3( -10,  10, -10 );
		D3DCOLORVALUE c = { 1.0, 1.0, 1.0, 0 };
		l.Diffuse = l.Specular = l.Ambient = c;
		l.Attenuation0 = 0.7f;
		l.Range = 100;
		g_pd3dDevice->SetLight( 0, &l );
		g_pd3dDevice->LightEnable( 0, TRUE );
		g_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );			/// ���������� �Ҵ�
	}
	else
	{
		g_pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE );			/// ���������� ����
		g_pd3dDevice->SetRenderState( D3DRS_AMBIENT, 0x00a0a0a0 );		/// ȯ�汤��(ambient light)�� �� ����
	}
}
/**-----------------------------------------------------------------------------
 * Status���� ���
 *------------------------------------------------------------------------------
 */
void LogStatus( void )
{
	g_pLog->Log( "X:[%d], Y:[%d]", g_dwMouseX, g_dwMouseY );
}


/**-----------------------------------------------------------------------------
 * FPS(Frame Per Second)���
 *------------------------------------------------------------------------------
 */
void LogFPS(void)
{
	static DWORD	nTick = 0;
	static DWORD	nFPS = 0;

	/// 1�ʰ� �����°�?
	if( GetTickCount() - nTick > 1000 )
	{
		nTick = GetTickCount();
		/// FPS�� ���
		g_pLog->Log("FPS:%d", nFPS );

		nFPS = 0;
		LogStatus();	/// ���������� ���⼭ ���(1�ʿ� �ѹ�)
		return;
	}
	nFPS++;
}


/**-----------------------------------------------------------------------------
 * ���콺 �Է� ó��
 *------------------------------------------------------------------------------
 */
void ProcessMouse( void )
{
	float	fDelta = 0.001f;	// ���콺�� �ΰ���, �� ���� Ŀ������ ���� �����δ�.

	g_pCamera->RotateLocalX( g_dwMouseY * fDelta );	// ���콺�� Y�� ȸ������ 3D world��  X�� ȸ����
	g_pCamera->RotateLocalY( g_dwMouseX * fDelta );	// ���콺�� X�� ȸ������ 3D world��  Y�� ȸ����
	D3DXMATRIXA16*	pmatView = g_pCamera->GetViewMatrix();		// ī�޶� ����� ��´�.
	g_pd3dDevice->SetTransform( D3DTS_VIEW, pmatView );			// ī�޶� ��� ����
	g_matView = *pmatView;
}

/**-----------------------------------------------------------------------------
 * Ű���� �Է� ó��
 *------------------------------------------------------------------------------
 */
void ProcessKey( void )
{
	if( GetAsyncKeyState( 'A' ) ) g_pCamera->MoveLocalZ( 0.5f );	// ī�޶� ����!
	if( GetAsyncKeyState( 'Z' ) ) g_pCamera->MoveLocalZ( -0.5f );	// ī�޶� ����!
}

/**-----------------------------------------------------------------------------
 * �Է� ó��
 *------------------------------------------------------------------------------
 */
void ProcessInputs( void )
{
	ProcessMouse();
	ProcessKey();
}

/**-----------------------------------------------------------------------------
 * �ִϸ��̼� ����
 *------------------------------------------------------------------------------
 */
VOID Animate()
{
	D3DXMATRIXA16	matTM;
	D3DXMATRIXA16	matX;
	D3DXMATRIXA16	matY;
	D3DXMATRIXA16	matScale;
	SetupLights();					// ��������
	ProcessInputs();				// �Է�ó��

	D3DXMatrixRotationX( &matX, g_xRot );
	D3DXMatrixRotationY( &matY, g_yRot );
	D3DXMatrixScaling( &matScale, SCALE_MESH, SCALE_MESH, SCALE_MESH );
	g_matMesh = matScale * matX * matY;
	g_matMesh._41 = POS_X_MESH; g_matWorld._42 = POS_Y_MESH; g_matWorld._41 = POS_Z_MESH;

	D3DXMatrixScaling( &matScale, SCALE_CUBE, SCALE_CUBE, SCALE_CUBE );
	g_matCube = matScale;
	LogFPS();						// �α�
}

/**-----------------------------------------------------------------------------
 * �������̴� ��� ����
 *------------------------------------------------------------------------------
 */
void SetupVSConst( D3DXMATRIXA16 &matWorld )
{
	D3DXMATRIXA16	m;

	m = matWorld;
	D3DXMatrixTranspose( &m, &m );
	g_pd3dDevice->SetVertexShaderConstantF( 0, (float*)&m, 4 );	// matWorld

	m = g_matProj;
	D3DXMatrixTranspose( &m, &m );
	g_pd3dDevice->SetVertexShaderConstantF( 4, (float*)&m, 4 );	// matProjection

	m = g_matView;
	D3DXMatrixTranspose( &m, &m );
	g_pd3dDevice->SetVertexShaderConstantF( 8, (float*)&m, 3 );	// matView

	D3DXVECTOR4 v = D3DXVECTOR4( g_pCamera->GetEye()->x, g_pCamera->GetEye()->y, g_pCamera->GetEye()->z, 0 );
	g_pd3dDevice->SetVertexShaderConstantF( 11, (float*)&v, 1 );	// Camera Pos

	v = g_material_D[g_nMaterial];
	g_pd3dDevice->SetVertexShaderConstantF( 12, (float*)&v, 1 );	// diffuse material

	v = g_material_S[g_nMaterial];
	g_pd3dDevice->SetVertexShaderConstantF( 13, (float*)&v, 1 );	// specular material

	v = g_vLightPos;
	g_pd3dDevice->SetVertexShaderConstantF( 14, (float*)&v, 1 );	// light position

	v = D3DXVECTOR4( g_fRefractRatio, g_fRefractRatio, g_fRefractRatio, g_fRefractRatio );
	g_pd3dDevice->SetVertexShaderConstantF( 15, (float*)&v, 1 );	// ������
}


/**-----------------------------------------------------------------------------
 * ���̴��� ������� �ʰ� �޽� ���
 *------------------------------------------------------------------------------
 */
void DrawSolidMesh()
{
    g_pd3dDevice->SetTransform( D3DTS_WORLD, &g_matCube );
	g_pCube->Render( g_pd3dDevice );

    g_pd3dDevice->SetTransform( D3DTS_WORLD, &g_matMesh );

	g_pMesh->Render( g_pd3dDevice );
}

/**-----------------------------------------------------------------------------
 * ���� ���̴��� ����Ͽ� �޽� ���
 *------------------------------------------------------------------------------
 */
void DrawBlendMesh()
{
	D3DXVECTOR4	v = D3DXVECTOR4( g_fTransmittance, 0, 0, 0 );	// �޽��� �������� �������� �ռ�����

    g_pd3dDevice->SetTransform( D3DTS_WORLD, &g_matCube );
	g_pCube->Render( g_pd3dDevice );

	SetupVSConst( g_matMesh );
	g_pd3dDevice->SetPixelShaderConstantF( 0, (float*)v, 1 );

	g_pd3dDevice->SetVertexDeclaration( g_pDecl );
	g_pd3dDevice->SetVertexShader( g_pVSRefract );
	g_pd3dDevice->SetPixelShader( g_pPSRefract );
	g_pd3dDevice->SetTexture( 0, g_pTexMesh );
	g_pd3dDevice->SetTexture( 1, g_pTexEnv );
	g_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
	g_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
	g_pd3dDevice->SetSamplerState( 1, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
	g_pd3dDevice->SetSamplerState( 1, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
	g_pMesh->Render( g_pd3dDevice );
	g_pd3dDevice->SetVertexDeclaration( NULL );
	g_pd3dDevice->SetVertexShader( NULL );
	g_pd3dDevice->SetPixelShader( NULL );
	g_pd3dDevice->SetTexture( 0, NULL );
	g_pd3dDevice->SetTexture( 1, NULL );
	g_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
	g_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );
	g_pd3dDevice->SetSamplerState( 1, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
	g_pd3dDevice->SetSamplerState( 1, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );
}

/**-----------------------------------------------------------------------------
 * �޽ø� �׸���.
 *------------------------------------------------------------------------------
 */
void DrawMesh()
{
	DrawBlendMesh();
//	DrawSolidMesh();
}

/**-----------------------------------------------------------------------------
 * ���� �ռ��� �ϱ����ؼ� g_pTexFinal�̹����� �����.
 *------------------------------------------------------------------------------
 */
void DrawToFinal()
{
	LPDIRECT3DSURFACE9	p = NULL;
	g_pd3dDevice->GetRenderTarget( 0, &p );

	g_pd3dDevice->SetRenderTarget( 0, g_pSurFinal );
	g_pd3dDevice->BeginScene();
    g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(255,255,255), 1.0f, 0 );
	DrawMesh();
	g_pd3dDevice->EndScene();
	g_pd3dDevice->SetRenderTarget( 0, p );
	S_REL( p );
}

/**-----------------------------------------------------------------------------
 * g_pTexTarget2�� ���� �̹����� �������Ѵ�.
 * g_pTexTarget1�� g_pTexTarget2�̹������� ���� �κи��� �̾Ƽ� �������Ѵ�.
 *------------------------------------------------------------------------------
 */
void DrawToTexture()
{
	LPDIRECT3DSURFACE9	p = NULL;
	g_pd3dDevice->GetRenderTarget( 0, &p );

	g_pd3dDevice->SetRenderTarget( 0, g_pSurTarget2 );
	g_pd3dDevice->BeginScene();
    g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(255,255,255), 1.0f, 0 );
	DrawMesh();
	g_pd3dDevice->EndScene();
	
	g_pd3dDevice->SetRenderTarget( 0, g_pSurTarget1 );
	g_pd3dDevice->BeginScene();
    g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(255,255,255), 1.0f, 0 );
	g_pd3dDevice->SetTexture( 0, g_pTexTarget2 );
	g_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	g_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1 );
	g_pd3dDevice->SetFVF( TEXVERTEX::FVF );
	g_pd3dDevice->SetPixelShader( g_pPSPower );
	g_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, g_vtx, sizeof(TEXVERTEX) );
	g_pd3dDevice->EndScene();

	g_pd3dDevice->SetRenderTarget( 0, p );
	g_pd3dDevice->SetPixelShader( NULL );
	S_REL( p );
}

/**-----------------------------------------------------------------------------
 * ���콺 �Լ��� ����ؼ� �������� �̹����� �����.
 * g_pTexTarget2�� x���� �����̹����� �����.
 * g_pTexTarget1�� g_pTexTarget2�� �̹����� y�������� �����Ѵ�.
 * ��������� g_pTexTarget1���� x,y�������� ������ �̹����� �ִ�.
 *------------------------------------------------------------------------------
 */
void DoGaussianBlur()
{
	LPDIRECT3DSURFACE9	p = NULL;
	g_pd3dDevice->GetRenderTarget( 0, &p );

	// x���� ����
	g_pd3dDevice->SetRenderTarget( 0, g_pSurTarget2 );
	g_pd3dDevice->BeginScene();
    g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(255,255,255), 1.0f, 0 );
	g_pd3dDevice->SetTexture( 0, g_pTexTarget1 );
	g_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	g_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1 );
	g_pd3dDevice->SetFVF( TEXVERTEX::FVF );
	
	// TEX_SIZE�� �ؽ�ó�� ����,���� ũ��
	D3DXVECTOR4	v = D3DXVECTOR4( TEX_SIZE, TEX_SIZE, TEX_SIZE, TEX_SIZE );
	g_pd3dDevice->SetPixelShaderConstantF( 0, (float*)v, 1 );
	g_pd3dDevice->SetPixelShader( g_pPSGBlurX );
	g_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, g_vtx, sizeof(TEXVERTEX) );
	g_pd3dDevice->EndScene();

	// y���� ����
	g_pd3dDevice->SetRenderTarget( 0, g_pSurTarget1 );
	g_pd3dDevice->BeginScene();
    g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(255,255,255), 1.0f, 0 );
	g_pd3dDevice->SetTexture( 0, g_pTexTarget2 );
	g_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	g_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1 );
	g_pd3dDevice->SetFVF( TEXVERTEX::FVF );
	g_pd3dDevice->SetPixelShader( g_pPSGBlurY );
	g_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, g_vtx, sizeof(TEXVERTEX) );
	g_pd3dDevice->EndScene();

	g_pd3dDevice->SetRenderTarget( 0, p );
	S_REL( p );

	g_pd3dDevice->SetTexture( 0, NULL );
	g_pd3dDevice->SetPixelShader( NULL );
}

/**-----------------------------------------------------------------------------
 * ������ �̹��� �ؽ�ó�� ȭ�鿡 �����ش�.
 *------------------------------------------------------------------------------
 */
void DrawTexture()
{
	g_pd3dDevice->SetTexture( 0, g_pTexTarget1 );
	g_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	g_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1 );
	g_pd3dDevice->SetFVF( TEXVERTEX::FVF );
	g_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, g_vtx, sizeof(TEXVERTEX) );
	g_pd3dDevice->SetTexture( 0, NULL );
	g_pd3dDevice->SetTexture( 1, NULL );
	g_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE );
}

/**-----------------------------------------------------------------------------
 * ������ �̹����� �⺻ �̹����� ���ļ� ���� �̹����� �����.
 *------------------------------------------------------------------------------
 */
void DrawFinal()
{
	TEXVERTEX vtx[4] =
	{
		{        0-0.5f, WINDOW_H-0.5f, 0, 1, 0, 1 },
		{        0-0.5f,        0-0.5f, 0, 1, 0, 0 },
		{ WINDOW_W-0.5f, WINDOW_H-0.5f, 0, 1, 1, 1 },
		{ WINDOW_W-0.5f,        0-0.5f, 0, 1, 1, 0 }
	};
	g_pd3dDevice->SetTexture( 0, g_pTexTarget1 );
	g_pd3dDevice->SetTexture( 1, g_pTexFinal );

	g_pd3dDevice->SetFVF( TEXVERTEX::FVF );
	g_pd3dDevice->SetPixelShader( g_pPSFinal );
	g_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, vtx, sizeof(TEXVERTEX) );
	g_pd3dDevice->SetTexture( 0, NULL );
	g_pd3dDevice->SetTexture( 1, NULL );
	g_pd3dDevice->SetPixelShader( NULL );
	g_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE );
}


/**-----------------------------------------------------------------------------
 * ȭ�� �׸���
 *------------------------------------------------------------------------------
 */
VOID Render()
{
    /// �ĸ���ۿ� Z���� �ʱ�ȭ
    g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(200,200,200), 1.0f, 0 );

	/// �ִϸ��̼� ��ļ���
	Animate();

	// �ؽ�ó�� �޽ø� �׸���.
	DrawToTexture();

	// �ؽ�ó�� ���콺 �����Ѵ�.
	for( int i = 0 ; i < g_nGaussian ; i++ )
		DoGaussianBlur();
	
	// �ռ��� ���� �⺻ �޽ø� �׸���.
	DrawToFinal();

    /// ������ ����
    if( SUCCEEDED( g_pd3dDevice->BeginScene() ) )
    {
		// �⺻�޽� + �����ؽ�ó�� ����Ѵ�.
		DrawFinal();

		// �����ؽ�ó�� ȭ�鿡 �׸���?
		if( g_bDrawTexture ) DrawTexture();

		g_pd3dDevice->EndScene();
    }

    /// �ĸ���۸� ���̴� ȭ������!
    g_pd3dDevice->Present( NULL, NULL, NULL, NULL );
}




/**-----------------------------------------------------------------------------
 * ������ ���ν���
 *------------------------------------------------------------------------------
 */
LRESULT WINAPI MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	static	int s_x = 0, s_y = 0, s_move = 0;
    switch( msg )
    {
		case WM_CLOSE :
			DestroyWindow( g_hdlg );
			g_hdlg = NULL;
			break;

        case WM_DESTROY :
            Cleanup();
            PostQuitMessage( 0 );
            return 0;

		case WM_RBUTTONDOWN :
		{
		}
			break;
		case WM_LBUTTONDOWN :
			SetCapture( hWnd );
			s_x = GET_X_LPARAM(lParam);
			s_y = GET_Y_LPARAM(lParam);
			s_move = 1;
			break;
		case WM_LBUTTONUP :
			ReleaseCapture();
			g_dwMouseX = g_dwMouseY = 0;
			s_move = 0;
			break;
		case WM_MOUSEMOVE :
			if( s_move )
			{
				g_dwMouseX = GET_X_LPARAM(lParam) - s_x; 
				g_dwMouseY = GET_Y_LPARAM(lParam) - s_y;
				s_x = GET_X_LPARAM(lParam);
				s_y = GET_Y_LPARAM(lParam);
			}
			break;
		case WM_KEYDOWN : 
			switch( wParam )
			{
				case VK_ESCAPE :
					PostMessage( hWnd, WM_DESTROY, 0, 0L );
					break;
				case VK_LEFT : g_yRot -= 0.1f; break;
				case VK_RIGHT : g_yRot += 0.1f; break;
				case VK_UP : g_xRot -= 0.1f; break;
				case VK_DOWN : g_xRot += 0.1f; break;
				case '1' :
					g_bDrawTexture = !g_bDrawTexture;
					break;
				case '2' :
					g_nMaterial++;
					g_nMaterial %= 10;
					break;
				case 'l' :
				case 'L' :
				{
					g_bActive = FALSE;

					char	str[512];
					OPENFILENAME ofn = { sizeof(OPENFILENAME), hWnd, NULL,
										 "Mesh Files(*.x)\0*.x\0\0",
										 NULL, 0, 1, NULL, 512, str, 512,
										 NULL, "Open X-File", OFN_FILEMUSTEXIST, 0, 1,
										 ".x", 0, NULL, NULL };

					if( GetOpenFileName( &ofn ) )
						LoadX( str );

					g_bActive = TRUE;
					break;
				}

			}
			break;
    }

    return DefWindowProc( hWnd, msg, wParam, lParam );
}

// ��帮�� ���̾�α� 
INT CALLBACK DlgProc( HWND hdlg, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	int	nID[] = { IDC_SLIDER_REFRACTRATIO, IDC_SLIDER_TRANSMITTENCE, IDC_SLIDER_GAUSSIAN };
	static int	nPos[3] = { 0, 0, 0 };

	switch( uMsg )
	{
		case WM_INITDIALOG :
		{
			for( int i = 0 ; i < 3 ; i++ )
			{
				HWND hitem = GetDlgItem( hdlg, nID[i] );
				SendMessage( hitem, TBM_SETRANGEMAX, 0, 100 );
				SendMessage( hitem, TBM_SETRANGEMIN, 0, 0 );
				SendMessage( hitem, TBM_SETPOS, TRUE, 100 );
			}
			return 1;
		}

		case WM_HSCROLL :
		{
			for( int i = 0 ; i < 3 ; i++ )
			{
				HWND hitem = GetDlgItem( hdlg, nID[i] );
				nPos[i] = SendMessage( hitem, TBM_GETPOS, 0, 0 );
			}
			g_fRefractRatio = nPos[0] *( 1.5f / 100.0f ) + 0.5;	// 0.5 ~ 2.0 , ������
			g_fTransmittance = nPos[1] / 100.0f;				// 0.0 ~ 1.0 , �ռ���
			g_nGaussian = nPos[2] / 10;							// 0 ~ 10 , �������� ȸ��
			return 1;
		}
	}

	return 0;
}


/**-----------------------------------------------------------------------------
 * ���α׷� ������
 *------------------------------------------------------------------------------
 */
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    /// ������ Ŭ���� ���
    WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC, MsgProc, 0L, 0L,
                      GetModuleHandle(NULL), NULL, NULL, NULL, NULL,
                      "BasicFrame", NULL };
    RegisterClassEx( &wc );

    /// ������ ����
	RECT	rc = { 0, 0, WINDOW_W, WINDOW_H };
	AdjustWindowRect( &rc, WS_OVERLAPPEDWINDOW, FALSE );
    HWND hWnd = CreateWindow( "BasicFrame", WINDOW_TITLE,
                              WS_OVERLAPPEDWINDOW, 100, 100, rc.right - rc.left, rc.bottom - rc.top,
                              GetDesktopWindow(), NULL, wc.hInstance, NULL );

	g_hwnd = hWnd;

	g_hdlg = CreateDialog( hInst, MAKEINTRESOURCE( IDD_VALUECONTROL ), g_hwnd, (DLGPROC)DlgProc );
	ShowWindow( g_hdlg, SW_SHOW );
	GetClientRect( g_hdlg, &rc );
	MoveWindow( g_hdlg, 640, 480, rc.right, rc.bottom, TRUE );

    /// Direct3D �ʱ�ȭ
    if( SUCCEEDED( InitD3D( hWnd ) ) )
    {
		if( SUCCEEDED( InitObjects() ) )
		{
			if( SUCCEEDED( InitGeometry() ) )
			{
        		/// ������ ���
				ShowWindow( hWnd, SW_SHOWDEFAULT );
				UpdateWindow( hWnd );

        		/// �޽��� ����
				MSG msg;
				ZeroMemory( &msg, sizeof(msg) );
				while( msg.message!=WM_QUIT )
				{
            		/// �޽���ť�� �޽����� ������ �޽��� ó��
					if( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) )
					{
						TranslateMessage( &msg );
						DispatchMessage( &msg );
					}
					else /// ó���� �޽����� ������ Render()�Լ� ȣ��
					{
						if( g_bActive ) Render();
					}
				}
			}
		}
    }

	if( g_hdlg )
	{
		DestroyWindow( g_hdlg );
		g_hdlg = NULL;
	}

	DeleteObjects();
    UnregisterClass( "BasicFrame", wc.hInstance );
    return 0;
}
