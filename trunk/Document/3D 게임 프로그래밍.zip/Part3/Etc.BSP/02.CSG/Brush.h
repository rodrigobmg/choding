// Brush.h: interface for the CBrush class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BRUSH_H__E096ACC3_CD2F_42E6_8E34_2960BC89CC61__INCLUDED_)
#define AFX_BRUSH_H__E096ACC3_CD2F_42E6_8E34_2960BC89CC61__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <d3dx8.h>
#include "bspnode.h"
#define	MAX_BRUSH_PLANES		32

#define SIDE_ON					0
#define SIDE_FRONT				1
#define SIDE_BACK				2
#define SIDE_SPLIT				3

#define BOUND_INSIDE			0
#define BOUND_OUTSIDE			1

#define EPSILON					0.001f


class CBrush  
{
public:
	D3DXPLANE		m_Planes[MAX_BRUSH_PLANES];
	CFace*			m_pFaceList;
	int				m_nTotalPlane;

public:
	CBrush*				Subtraction( CBrush* pB );
	BOOL				SplitContactFace( int* pPlane, int nPlane, CFace** pList, CBrush * pBrush );
	BOOL				FaceCopy( CFace* pOrig, CFace* pCopy );
	BOOL				DivideFrontBack( D3DXPLANE &plane, CFace* f, CFace** fr, CFace** bk, BOOL &bSplit, BOOL bIsUnion );
	BOOL				ComparePlane( D3DXPLANE & a, D3DXPLANE & b );
	int					FindSamePlane( D3DXPLANE &plane );
	BOOL				Create( D3DXVECTOR3 * pList, int n );
	BOOL				Create( CFace * pList );
	BOOL				Render( LPDIRECT3DDEVICE8 pd3dDevice, CD3DFont* pFont );
	CBrush*				Union( CBrush* pB );
	int					Classify( D3DXPLANE *plane, D3DXVECTOR3 *v, int num );
	int					ClassifyPoint( D3DXPLANE * plane, D3DXVECTOR3 * v );
	void				Split(D3DXPLANE *plane, CFace *f, CFace **a, CFace **b);
	BOOL				IntersectLine( D3DXVECTOR3* vOut, D3DXPLANE &plane, D3DXVECTOR3 &vA, D3DXVECTOR3 &vB );
//	void				GetSortedFaceList( D3DXPLANE *plane, CFace *f, CFace **fr, CFace **bk );
	int					SizeOfFace ( CFace * pFace );
	CBrush();
	virtual ~CBrush();
};

#endif // !defined(AFX_BRUSH_H__E096ACC3_CD2F_42E6_8E34_2960BC89CC61__INCLUDED_)
