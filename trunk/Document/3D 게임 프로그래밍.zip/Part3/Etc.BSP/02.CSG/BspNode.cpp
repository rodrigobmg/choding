// BspNode.cpp: implementation of the CBspNode class.
//
//////////////////////////////////////////////////////////////////////

#include "d3dfont.h"
#include "BspNode.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CFace::CFace()
{
	m_bUsed		= FALSE;
	m_nNum		= 0;
	m_pNext		= NULL;
	m_vList		= NULL;
}

CFace*	CFace::CreateFace()
{
	CFace* p = new CFace();
	return p;
}

BOOL	CFace::MakePlane( D3DXVECTOR3* v, int n )
{
	if( n < 3 )
		return FALSE;

//	D3DXPlaneFromPoints( &m_facePlane, &v[0], &v[2], &v[1] );
	
	m_vList = v;
	m_nNum = n;
	return TRUE;
}

BOOL CFace::AddNext(CFace *pNext)
{
	m_pNext = pNext;
	return TRUE;
}

BOOL CFace::AddTail(CFace *pTail)
{
	if( m_pNext )
		m_pNext->AddTail( pTail );
	else
	{
		m_pNext = pTail;
		return TRUE;
	}
	return FALSE;
}
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBspNode::CBspNode()
{
	m_bIsSolid		= FALSE;
	m_bIsLeaf		= FALSE;
	m_pBack			= NULL;
	m_pFront		= NULL;
	m_pFaceList		= NULL;
	m_vMax			= D3DXVECTOR3( BSP_BOGUS, BSP_BOGUS, BSP_BOGUS );
	m_vMin			= D3DXVECTOR3( -BSP_BOGUS, -BSP_BOGUS, -BSP_BOGUS );
}

CBspNode::~CBspNode()
{

}


BOOL CBspNode::Render(LPDIRECT3DDEVICE8 pd3dDevice,  CD3DFont* pFont )
{
	if( m_bIsLeaf && !m_bIsSolid )
	{
		CFace * f;
		for( f = m_pFaceList; f ; f = f->m_pNext )
		{
			if( pFont )
			{
				for( int i = 0; i < f->m_nNum ; i++ )
				{
					D3DXMATRIX	mW, mV, mP, mO;
					pd3dDevice->GetTransform( D3DTS_WORLD, &mW );
					pd3dDevice->GetTransform( D3DTS_VIEW, &mV );
					pd3dDevice->GetTransform( D3DTS_PROJECTION, &mP );
					mO = mW * mV * mP;
					D3DXVECTOR3 vI = f->m_vList[i];
					D3DXVECTOR3 vO;
					D3DXVec3TransformCoord( &vO, &vI, &mO );
					char	str[16];
					wsprintf( str, "( %d, %d, %d )", (int)f->m_vList[i].x, (int)f->m_vList[i].y,(int)f->m_vList[i].z );
					pFont->DrawText(400.0f * (vO.x+1.0f), 600 - 300.0f * (vO.y+1.0f), 0xff000000, str );
				}
			}
			else
				pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 1,f->m_vList, sizeof( D3DXVECTOR3 )  );
		}
	}
	if( m_pBack )
		m_pBack->Render( pd3dDevice, pFont );
	if( m_pFront )
		m_pFront->Render( pd3dDevice, pFont );
	return TRUE;
}

BOOL CBspNode::SetFrontNode(CBspNode *pNode)
{
	m_pFront = pNode;
	return TRUE;
}

BOOL CBspNode::SetBackNode(CBspNode *pNode)
{
	m_pBack = pNode;
	return TRUE;
}

BOOL CBspNode::SetFaceList(CFace *pFace)
{
	m_pFaceList = pFace;
	return TRUE;
}

void CBspNode::Destroy()
{
	
}


