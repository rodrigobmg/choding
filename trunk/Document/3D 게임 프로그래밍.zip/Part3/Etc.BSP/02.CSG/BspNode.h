// Bsp.h: interface for the CBspNode class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BSP_H__798749D6_4E89_4C34_8798_B311BEE024B9__INCLUDED_)
#define AFX_BSP_H__798749D6_4E89_4C34_8798_B311BEE024B9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <d3dx8.h>

#define POINT_FRONT 1
#define POINT_BACK  2
#define POINT_ON    3

#define FACE_FRONT      1
#define FACE_BACK       2
#define FACE_ON         3
#define FACE_SPLIT		4

#define EPSILON    0.001f
#define BSP_BOGUS  99999

#define BSP_NODE 0
#define BSP_LEAF 1


struct CUSTOMVERTEX
{
    D3DXVECTOR3 position;       // vertex position
};


#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ)


class CFace
{
public:
	BOOL AddTail( CFace* pTail );
	
	D3DXVECTOR3*	m_vList;
	int				m_nNum;
	int				m_nPlane;
	BOOL			m_bUsed;
	CFace*			m_pNext;
	
	CFace();
	virtual ~CFace(){};
	
	static CFace*		CreateFace();
	BOOL				AddNext( CFace* pNext );
	BOOL				MakePlane( D3DXVECTOR3* v, int n );
};

class CBspNode  
{
public:
	void Destroy();
	BOOL SetFaceList( CFace* pFace );
	// Data for Node
	CBspNode *		m_pFront;
	CBspNode *		m_pBack;
	D3DXPLANE		m_plane;

	// Data for Leaf
	BOOL			m_bIsSolid;
	BOOL			m_bIsLeaf;
	// For The Frustum Culling.
	D3DXVECTOR3		m_vMin;
	D3DXVECTOR3		m_vMax;
	CFace*			m_pFaceList;

	CBspNode();
	virtual ~CBspNode();
	BOOL			SetFrontNode( CBspNode* pNode );
	BOOL			SetBackNode( CBspNode* pNode );
	BOOL			Render(LPDIRECT3DDEVICE8 pd3dDevice, CD3DFont* pFont );
};

#endif // !defined(AFX_BSP_H__798749D6_4E89_4C34_8798_B311BEE024B9__INCLUDED_)
