// Csg1.h: interface for the CCsg class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CSG1_H__0252645E_DCDB_4A3A_A18F_A7A19ABC5BF9__INCLUDED_)
#define AFX_CSG1_H__0252645E_DCDB_4A3A_A18F_A7A19ABC5BF9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <d3dx8.h>
#include "bspnode.h"

#define	MAX_PLANES		8192

class CCsg  
{
public:
	D3DXPLANE		m_Plane[MAX_PLANES];
	int				m_nTotalPlane;
	
public:
	CCsg();
	virtual ~CCsg();

};

#endif // !defined(AFX_CSG1_H__0252645E_DCDB_4A3A_A18F_A7A19ABC5BF9__INCLUDED_)
