// Brush.cpp: implementation of the CBrush class.
//
//////////////////////////////////////////////////////////////////////

#include "d3dfont.h"
#include "Brush.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBrush::CBrush()
{
	m_pFaceList			= NULL;
	m_nTotalPlane		= 0;
}

CBrush::~CBrush()
{

}

BOOL CBrush::Create( D3DXVECTOR3 *pList, int n )
{
	for( int i = 0 ; i < n/3 ; i++ )
	{
		CFace* f = CFace::CreateFace();
		f->m_vList = &pList[i*3];
		f->m_nNum = 3;
		D3DXPLANE plane;
		D3DXPlaneFromPoints( &plane, &pList[i*3], &pList[i*3+1], &pList[i*3+2]);
		int res = FindSamePlane( plane );
		if( res == -1 )
		{
			m_Planes[m_nTotalPlane] = plane;
			f->m_nPlane = m_nTotalPlane++;
		}
		else
			f->m_nPlane = res;

		f->AddNext( m_pFaceList );
		m_pFaceList = f;
	}
	return TRUE;
}

BOOL CBrush::Create( CFace * pList )
{
	CFace * f = NULL;
	for( f = pList ; f ; f = f->m_pNext )
	{
		D3DXPLANE plane;
		D3DXPlaneFromPoints( &plane, &f->m_vList[0], &f->m_vList[1], &f->m_vList[2] );
		int res = FindSamePlane( plane );
		if( res == -1 )
		{
			m_Planes[m_nTotalPlane] = plane;
			f->m_nPlane = m_nTotalPlane++;
		}
		else
			f->m_nPlane = res;
	}
	m_pFaceList = pList;
	return TRUE;
}

int CBrush::FindSamePlane(D3DXPLANE &plane)
{
	for( int i = 0 ; i < m_nTotalPlane ; i++ )
	{
		if( ComparePlane( m_Planes[i], plane ) )
			return i;
	}
	return -1;
}

BOOL CBrush::ComparePlane(D3DXPLANE &a, D3DXPLANE &b)
{
	if( a.a == b.a && a.b == b.b && a.c == b.c && a.d == b.d )
		return TRUE;
	return FALSE;
}

BOOL CBrush::Render( LPDIRECT3DDEVICE8 pd3dDevice, CD3DFont* pFont )
{
	pd3dDevice->SetVertexShader( D3DFVF_CUSTOMVERTEX );
	pd3dDevice->SetStreamSource( 0, NULL, 0 );
	pd3dDevice->SetIndices( NULL, 0 );
	pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE );
	
	CFace * f = NULL;
	for( f = m_pFaceList ; f ; f = f->m_pNext )
	{
		if( pFont )
		{
			for( int i = 0; i < f->m_nNum ; i++ )
			{
				D3DXMATRIX	mW, mV, mP, mO;
				pd3dDevice->GetTransform( D3DTS_WORLD, &mW );
				pd3dDevice->GetTransform( D3DTS_VIEW, &mV );
				pd3dDevice->GetTransform( D3DTS_PROJECTION, &mP );
				mO = mW * mV * mP;
				D3DXVECTOR3 vI = f->m_vList[i];
				D3DXVECTOR3 vO;
				D3DXVec3TransformCoord( &vO, &vI, &mO );
				char	str[16];
				wsprintf( str, "( %d, %d, %d )", (int)f->m_vList[i].x, (int)f->m_vList[i].y,(int)f->m_vList[i].z );
				pFont->DrawText(400.0f * (vO.x+1.0f), 600 - 300.0f * (vO.y+1.0f), 0xff000000, str );
			}
		}
		pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLELIST, 1, f->m_vList, sizeof( CUSTOMVERTEX )  );
	}

	if( pFont )
	{
		char s[16];
		wsprintf( s, "NUMBER OF FACE : %d", SizeOfFace( m_pFaceList ) );
		pFont->DrawText( 400, 10, 0xff000000, s );
	}

	return TRUE;
}


CBrush* CBrush::Subtraction(CBrush *pB)
{
	CFace * bk_root = NULL;
	CFace * f = NULL, *front = NULL, *back = NULL, *pNext = NULL, *pCurr;
	int plane_split[10] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 }, num_split = 0;
	
	f = pB->m_pFaceList;
	for( pCurr = f ; pCurr ; pCurr = f )
	{
		f = f->m_pNext;
		for( int i = 0 ; i < m_nTotalPlane ; i++ )
		{
			front = NULL;
			back = NULL;
			BOOL bSplit = FALSE;
			DivideFrontBack( m_Planes[i], pCurr, &front, &back, bSplit, FALSE );
			if( back )
			{
				if( bSplit )
				{
					BOOL bSearch = FALSE;
					for( int j = 0 ; j < num_split ; j++ )
					{
						if( plane_split[j] == i )
						{
							bSearch = TRUE;
							break;
						}
					}
					if( !bSearch )
					{
						plane_split[num_split++] = i;
					}
				}
				if( back->m_pNext )
					back->m_pNext->AddNext( bk_root );
				else
					back->AddNext( bk_root );
				bk_root = back;
			}
		}
	}

	int i_fr = SizeOfFace( bk_root );
	if( bk_root )
	{
		SplitContactFace( plane_split, num_split, &bk_root, pB );
		
		CBrush * pNew = new CBrush();
		pNew->Create( bk_root );
		return pNew;
	}

	return NULL;
}

CBrush* CBrush::Union( CBrush* pB )
{
	CFace * fr_root = NULL;
	CFace * f = NULL, *front = NULL, *back = NULL, *pNext = NULL, *pCurr;
	int plane_split[10] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 }, num_split = 0;
	
	f = pB->m_pFaceList;
	for( pCurr = f ; pCurr ; pCurr = f )
	{
		f = f->m_pNext;
		for( int i = 0 ; i < m_nTotalPlane ; i++ )
		{
			front = NULL;
			back = NULL;
			BOOL bSplit = FALSE;
			DivideFrontBack( m_Planes[i], pCurr, &front, &back, bSplit, TRUE );
			if( bSplit )
			{
				BOOL bSearch = FALSE;
				for( int j = 0 ; j < num_split ; j++ )
				{
					if( plane_split[j] == i )
					{
						bSearch = TRUE;
						break;
					}
				}
				if( !bSearch )
				{
					plane_split[num_split++] = i;
				}
			}
			if( front )
			{
				if( front->m_pNext )
					front->m_pNext->AddNext( fr_root );
				else
					front->AddNext( fr_root );
				fr_root = front;
			}
		}
	}

	int i_fr = SizeOfFace( fr_root );
	if( fr_root )
	{
		SplitContactFace( plane_split, num_split, &fr_root, pB );
		
		CBrush * pNew = new CBrush();
		pNew->Create( fr_root );
		return pNew;
	}

	return NULL;
}

BOOL CBrush::SplitContactFace( int *pPlane, int nPlane, CFace** pList, CBrush * pBrush )
{
	CFace * cface = NULL;
	if( nPlane <= 0 )
		return FALSE;

	CFace * fr_root = NULL, * fr = NULL, * bk = NULL;

	BOOL bTmp = FALSE; //DivideFrontBack�� ȣ���ϱ� ���� �ִ� �ƹ� ���þ��� ����

	for( int i = 0; i < nPlane ; i++ )
	{
		cface = NULL;
		for( cface = m_pFaceList ; cface ; cface = cface->m_pNext )
		{
			if( cface->m_nPlane == pPlane[i] )
			{
				for( int n = 0 ; n < pBrush->m_nTotalPlane ; n++ )
				{
					fr = NULL;
					bk = NULL;
					DivideFrontBack( pBrush->m_Planes[n], cface, &fr, &bk, bTmp, TRUE );
					if( fr )
					{
						if( fr->m_pNext )
							fr->m_pNext->AddNext( fr_root );
						else
							fr->AddNext( fr_root );
						fr_root = fr;
					}
				}
			}
			else
			{
				BOOL bCheck = FALSE;
				for( int cnt = 0 ; cnt < nPlane ; cnt++ )
				{
					if( cface->m_nPlane == pPlane[cnt] )
						bCheck = TRUE;
				}

				if( cface && !bCheck )
				{
					CFace * new_face = CFace::CreateFace();
					FaceCopy( cface, new_face );
					new_face->AddNext( fr_root );
					fr_root = new_face;
				}
			}
		}
	}
	
	CFace * tail = NULL;
	for( tail = fr_root ; tail->m_pNext ; tail = tail->m_pNext )
		;
	tail->AddNext( *pList );
	*pList = fr_root;
	return TRUE;
}

BOOL CBrush::DivideFrontBack(D3DXPLANE &plane, CFace *f, CFace **fr, CFace **bk, BOOL &bSplit, BOOL bIsUnion )
{
	CFace * nf = CFace::CreateFace();
	FaceCopy( f, nf );
	int res = Classify( &plane, nf->m_vList, nf->m_nNum );
	D3DXVECTOR3 plane_normal( plane.a, plane.b, plane.c );
	D3DXVECTOR3 vBA = nf->m_vList[1] - nf->m_vList[0];
	D3DXVECTOR3 vCA = nf->m_vList[2] - nf->m_vList[0];
	D3DXVECTOR3 vCross, face_normal;
	float dot = 0;
	switch( res )
	{
		case SIDE_ON:
			if( bIsUnion )
			{
				nf->AddNext( *bk );
				*bk = nf;
			}
			else
			{
				nf->AddNext( *fr );
				*fr = nf;
			}
			vBA = nf->m_vList[1] - nf->m_vList[0];
			vCA = nf->m_vList[2] - nf->m_vList[0];
			D3DXVec3Cross( &vCross, &vBA, &vCA );
			D3DXVec3Normalize( &face_normal, &vCross );
			
			dot = D3DXVec3Dot( &plane_normal, &face_normal );
			
			if( dot < 0 )
				bSplit = TRUE;
			break;
		case SIDE_FRONT:
			nf->AddNext( *fr );
			*fr = nf;
			break;
		case SIDE_BACK:
			nf->AddNext( *bk );
			*bk = nf;
			break;
		case SIDE_SPLIT:
			CFace * front = NULL, * back = NULL;
			Split( &plane, f, &front, &back );
			if( !front && !back )
				break;
			if( front->m_pNext )
			{
				if( bIsUnion )
				{
					front->m_pNext->AddNext( *fr );
					*fr = front;
				}
				else
				{
					front->m_pNext->AddNext( *bk );
					*bk = front;
				}
			}
			else 
			{
				if( bIsUnion )
				{
					front->AddNext( *fr );
					*fr = front;
				}
				else
				{
					front->AddNext( *bk );
					*bk = front;
				}
			}
			if( back->m_pNext )
			{
				if( bIsUnion )
				{
					back->m_pNext->AddNext( *bk );
					*bk = back;
				}
				else
				{
					back->m_pNext->AddNext( *fr );
					*fr = back;
				}
			}
			else
			{
				if( bIsUnion )
				{
					back->AddNext( *bk );
					*bk = back;
				}
				else
				{
					back->AddNext( *fr );
					*fr = back;
				}
			}
			bSplit = TRUE;
			break;
	}	
	return FALSE;
}

BOOL CBrush::FaceCopy(CFace *pOrig, CFace *pCopy)
{
	pCopy->m_nNum = pOrig->m_nNum;
	D3DXVECTOR3 * copy = new D3DXVECTOR3[pOrig->m_nNum];
	for( int i = 0; i < pOrig->m_nNum ; i++ )
	{
		copy[i] = pOrig->m_vList[i];
	}
	pCopy->m_vList = copy;
	return TRUE;
}

int CBrush::Classify( D3DXPLANE *plane, D3DXVECTOR3 *v, int num )
{
	int front = 0, back = 0, on = 0;
	float res = 0;

	for (int cnt = 0; cnt < num; cnt++)
	{
		res = D3DXPlaneDotCoord( plane, &v[cnt] );

		if ( res > EPSILON )
			front++;
		else if ( res < -EPSILON )
			back++;
		else
		{
			front++;
			back++;
			on++;
		}
	}
   
	if (on == num)
		return SIDE_ON;
	else if (front == num)
		return SIDE_FRONT;
	else if (back == num)
		return SIDE_BACK;
	else
		return SIDE_SPLIT;
}

int CBrush::ClassifyPoint( D3DXPLANE * plane, D3DXVECTOR3 * v )
{
	float res = D3DXPlaneDotCoord( plane, v);
	if( res > EPSILON )
		return SIDE_FRONT;
	else if( res < -EPSILON )
		return SIDE_BACK;
	else 
		return SIDE_ON;
}

void CBrush::Split(D3DXPLANE *plane, CFace *f, CFace **a, CFace **b)
{
	CFace * frontList, * backList;
	D3DXVECTOR3 vFrontList[20], vBackList[20], vFirst;
	D3DXVECTOR3 vIntersectPoint, vPointA, vPointB;
	WORD wFrontCnt = 0, wBackCnt = 0, wCnt = 0, wCurrentVec = 0;

	vFirst = f->m_vList[0];

	switch( ClassifyPoint( plane, &vFirst ))
	{
		case SIDE_FRONT:
			vFrontList[wFrontCnt++] = vFirst;
			break;
		case SIDE_BACK:
			vBackList[wBackCnt++] = vFirst;
			break;
		case SIDE_ON:
			vFrontList[wFrontCnt++] = vFirst;
			vBackList[wBackCnt++] = vFirst;
			break;
		default:
			break;
	}

	for( wCnt = 1 ; wCnt < f->m_nNum + 1; wCnt++ )
	{
		if( wCnt == f->m_nNum )
			wCurrentVec = 0;
		else
			wCurrentVec = wCnt;

		vPointA = f->m_vList[wCnt-1];
		vPointB = f->m_vList[wCurrentVec];

		int result = ClassifyPoint( plane, &vPointB );
		if( result == SIDE_ON )
		{
			vBackList[wBackCnt++] = f->m_vList[wCurrentVec];
			vFrontList[wFrontCnt++] = f->m_vList[wCurrentVec];
		}
		else
		{
			if( IntersectLine( &vIntersectPoint, *plane, vPointA, vPointB ))
			{
				if( result == SIDE_FRONT )
				{
					vBackList[wBackCnt++] = vIntersectPoint;
					vFrontList[wFrontCnt++] = vIntersectPoint;
					if( wCurrentVec )
						vFrontList[wFrontCnt++] = f->m_vList[wCurrentVec];
				}
				if( result == SIDE_BACK )
				{
					vFrontList[wFrontCnt++] = vIntersectPoint;
					vBackList[wBackCnt++] = vIntersectPoint;
					if( wCurrentVec )
						vBackList[wBackCnt++] = f->m_vList[wCurrentVec];
				}
			}// end - if( IntersectLine() )
			else
			{
				if( result == SIDE_FRONT )
				{
					if( wCurrentVec )
						vFrontList[wFrontCnt++] = f->m_vList[wCurrentVec];
				}
				if( result == SIDE_BACK )
				{
					if( wCurrentVec )
						vBackList[wBackCnt++] = f->m_vList[wCurrentVec];
				}
			}// end - else( IntersectLine() )
		}// end - else( result == SIDE_ON )
	}// end - for(;;)
	
	if( wFrontCnt == wBackCnt )
	{
		frontList = CFace::CreateFace();
		frontList->MakePlane( vFrontList, 3 );
		backList = CFace::CreateFace();
		backList->MakePlane( vBackList, 3 );
	}
	else if( wFrontCnt > wBackCnt )
	{
		frontList = CFace::CreateFace();
		D3DXVECTOR3* tmp1 = new D3DXVECTOR3[3];
		tmp1[0] = vFrontList[0];
		tmp1[1] = vFrontList[1];
		tmp1[2] = vFrontList[2];
		frontList->MakePlane( tmp1, 3 );

		CFace * next = CFace::CreateFace();
		D3DXVECTOR3* tmp2 = new D3DXVECTOR3[3];
		tmp2[0] = vFrontList[0];
		tmp2[1] = vFrontList[2];
		tmp2[2] = vFrontList[3];
		next->MakePlane( tmp2, 3 );

		frontList->AddNext( next );

		backList = CFace::CreateFace();
		D3DXVECTOR3* tmp3 = new D3DXVECTOR3[3];
		tmp3[0] = vFrontList[0];
		tmp3[1] = vFrontList[1];
		tmp3[2] = vFrontList[2];

		backList->MakePlane( tmp3, 3 );
	}
	else if( wBackCnt > wFrontCnt )
	{
		backList = CFace::CreateFace();
		D3DXVECTOR3* tmp1 = new D3DXVECTOR3[3];
		tmp1[0] = vBackList[0];
		tmp1[1] = vBackList[1];
		tmp1[2] = vBackList[2];
		backList->MakePlane( tmp1, 3 );

		CFace * next = CFace::CreateFace();
		D3DXVECTOR3* tmp2 = new D3DXVECTOR3[3];
		tmp2[0] = vBackList[0];
		tmp2[1] = vBackList[2];
		tmp2[2] = vBackList[3];
		next->MakePlane( tmp2, 3 );

		backList->AddNext( next );

		frontList = CFace::CreateFace();
		D3DXVECTOR3* tmp3 = new D3DXVECTOR3[3];
		tmp3[0] = vFrontList[0];
		tmp3[1] = vFrontList[1];
		tmp3[2] = vFrontList[2];

		frontList->MakePlane( tmp3, 3 );
	}

	*a = frontList;
	*b = backList;
}

BOOL CBrush::IntersectLine( D3DXVECTOR3* vOut, D3DXPLANE &plane, D3DXVECTOR3 &vA, D3DXVECTOR3 &vB )
{
	int res = ClassifyPoint( &plane, &vA );
	if( res == SIDE_ON )
		return FALSE;
	res = ClassifyPoint( &plane, &vB );
	if( res == SIDE_ON )
		return FALSE;
	
	D3DXVECTOR3 n( plane.a, plane.b, plane.c );
	float lineLength = D3DXVec3Dot( &(vB - vA), &n );
	if( fabsf( lineLength ) < 0.0001 )
		return FALSE;

	float aDot = D3DXVec3Dot( &vA, &n );
	float bDot = D3DXVec3Dot( &vB, &n );
	float scale = ( -(plane.d) - aDot ) / ( bDot - aDot );
	
	if( scale < 0.0f )
		return FALSE;
	if( scale > 1.0f )
		return FALSE;

	*vOut = vA + ( scale * ( vB - vA ) );
	return TRUE;
}

int CBrush::SizeOfFace ( CFace * pFace )
{
	CFace * temp = pFace;
	int i=0;
	while(temp)
	{
		i++;
		temp = temp->m_pNext;
	}
	return i;
}

