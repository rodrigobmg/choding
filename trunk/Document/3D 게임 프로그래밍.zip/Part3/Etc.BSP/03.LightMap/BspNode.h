// Bsp.h: interface for the CBspNode class.
//
//////////////////////////////////////////////////////////////////////


#if !defined(AFX_BSP_H__798749D6_4E89_4C34_8798_B311BEE024B9__INCLUDED_)
#define AFX_BSP_H__798749D6_4E89_4C34_8798_B311BEE024B9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <d3dx8.h>
#include "d3dfont.h"
#include "portal.h"

#define POINT_FRONT 1
#define POINT_BACK  2
#define POINT_ON    3

#define FACE_FRONT      1
#define FACE_BACK       2
#define FACE_ON         3
#define FACE_SPLIT		4

#define EPSILON    0.001f
#define BSP_BOGUS  99999

#define BSP_NODE 0
#define BSP_LEAF 1

#define		STR_MAX			200

#define	MAX_PORTALS_ON_LEAF		128

struct BSPVERTEX
{
    D3DXVECTOR3 pos;       // vertex position
	float		u, v;
};

typedef struct
{
	LPDIRECT3DTEXTURE8	texture;
	char				name[STR_MAX];
} TEXTUREDATA;

typedef struct tagTRIANGLEINDEX
{
	WORD	_0, _1, _2;
} TRIANGLEINDEX, *PTRIANGLEINDEX, *LPTRIANGLEINDEX;


#define D3DFVF_BSPVERTEX (D3DFVF_XYZ | D3DFVF_TEX1)

class CFace
{
public:
	BOOL m_bInside;
	
	
	BSPVERTEX*		m_vList;
	int				m_nNum;
	int				m_nPlane;
	BOOL			m_bUsed;
	BOOL			m_bCollision;
	BOOL			m_bDelete;
	CFace*			m_pNext;
	CFace*			m_pPrev;
	int				m_nTexture;
	int				m_nLightMap;
	
	CFace();
	virtual ~CFace();
	
	static CFace*		CreateFace();
	BOOL				AddNext( CFace* pNext );
	BOOL				MakePlane( BSPVERTEX* v, int n );
	BOOL				SetVertexList( BSPVERTEX* pList );
	BOOL				AddTail( CFace* pTail );
};

class CThing
{
public:
	BSPVERTEX*		m_pFaceList;
	int				m_nObjectType;
	BSPVERTEX*		m_pVertex;
	int				m_nVertexCount;
	TRIANGLEINDEX*	m_pTriangleIndex;
	TRIANGLEINDEX*	m_pTIndex;
	int				m_nFaceCount;
	TEXTUREDATA*	m_pTXData;
	int				m_nTexCnt;
	D3DXVECTOR3*	m_pTVtx;
	int				m_nTCount;
	int				m_nTFCount;
	D3DXPLANE		m_planes[32];
	int				m_nTotalPlane;

	CThing()
	{
		m_nTotalPlane		= 0;
		m_nTCount			= 0;
		m_nTFCount			= 0;
		m_pTVtx				= NULL;
		m_pTXData			= NULL;
		m_pTriangleIndex	= NULL;
		m_pTIndex			= NULL;
		m_nFaceCount		= 0;	
		m_pVertex			= NULL;
		m_nVertexCount		= 0;
		m_pFaceList			= NULL;
		m_nObjectType		= -1;
		m_nTexCnt			= 0;
	};
	virtual ~CThing()
	{
/*		CFace* curr = NULL, * next = NULL;
		for( curr = m_pFaceList ; curr ; curr = next )
		{
			next = curr->m_pNext;
			delete curr;
		}*/
		delete[] m_pFaceList;
		if( m_pTXData )
			delete[] m_pTXData;
	};

	int GetTextureIndex( LPSTR szName )
	{
		if( m_nTexCnt <= 0 )
		return -1;

		for( int i = 0 ; i < m_nTexCnt ; i++ )
		{
			if( !strcmp( m_pTXData[i].name, szName ) )
				return i;
		}

		return -1;
	};
	void		InitThing();
	int			FindSamePlane(D3DXPLANE &plane);
	BOOL		ComparePlane(D3DXPLANE &a, D3DXPLANE &b);
};


class CFrustum  
{
	D3DXVECTOR3	m_vtx[8];
	D3DXPLANE	m_plane[6];
public:
	CFrustum();
	virtual ~CFrustum();
	BOOL	Make( D3DXMATRIX* pmatViewProj );
	int		IsIn( D3DXVECTOR3* pVec );
	BOOL	Draw( LPDIRECT3DDEVICE8 pDev );
};

class CWinding
{
public:
	int				n;
	D3DXVECTOR3		vPoint[8];

public:
	CWinding();
	virtual ~CWinding();
};

class CLight  
{
public:
	D3DXVECTOR3		m_vPosition;
	int				m_radius;

	CLight( ){};
	CLight( int radius )
	{
		m_radius = radius;
	};
	CLight( D3DXVECTOR3 pos, int radius )
	{ 
		m_vPosition = pos;
		m_radius = radius; 
	};
	virtual ~CLight(){};

};


class CBspNode  
{
public:
	class CPortal  
	{
	public:
		CPortal*		m_pNext[2];
		CBspNode*		m_pNode[2];
		CWinding*		m_pWinding;
		D3DXPLANE		m_plane;
		BOOL			m_bRender;
		CPortal*		m_visPortals[MAX_PORTALS_ON_LEAF];
		int				m_nVisCnt;
		int				m_nFaceCnt;
		CFace**			m_ppFaceList;

	public:
		CPortal();
		virtual ~CPortal();

		void		AddPortalToNodes( CBspNode *front, CBspNode *back );
		void		Render( LPDIRECT3DDEVICE8 pd3dDevice );
		void		RemovePortalFromNode ( CBspNode *l );
	};
	
public:
	// Data for Node
	CBspNode *		m_pFront;
	CBspNode *		m_pBack;
	D3DXPLANE		m_plane;

	CPortal*		m_pPortals;

	TEXTUREDATA*	m_pTXData;

	
	// Data for Leaf
	BOOL			m_bIsSolid;
	BOOL			m_bIsLeaf;
	BOOL			m_bRender;


	D3DXVECTOR3		m_vMin;
	D3DXVECTOR3		m_vMax;
	CFace*			m_pFaceList;

	CBspNode();
	virtual ~CBspNode();
	BOOL			SetFaceList( CFace* pFace );
	BOOL			SetFrontNode( CBspNode* pNode );
	BOOL			SetBackNode( CBspNode* pNode );
	BOOL			Render(LPDIRECT3DDEVICE8 pd3dDevice, CD3DFont* pFont );
	BOOL			IsCollision( BOOL &b, D3DXVECTOR3 &v, CBspNode* & render_start);
	int				ClassifyPoint(D3DXVECTOR3 &v);
	int				GetFaceCount();
	void			InitRender();
};



#endif // !defined(AFX_BSP_H__798749D6_4E89_4C34_8798_B311BEE024B9__INCLUDED_)
