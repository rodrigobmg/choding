// Light.h: interface for the CLight class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LIGHT_H__55AD23B6_ABDB_4AED_9FA9_A7A39FA56F6D__INCLUDED_)
#define AFX_LIGHT_H__55AD23B6_ABDB_4AED_9FA9_A7A39FA56F6D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000



#endif // !defined(AFX_LIGHT_H__55AD23B6_ABDB_4AED_9FA9_A7A39FA56F6D__INCLUDED_)
