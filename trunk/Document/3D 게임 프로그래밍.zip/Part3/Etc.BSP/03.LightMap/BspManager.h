// Bsp.h: interface for the CBsp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BSP_H__A470EE83_3FE4_48C3_A23C_963D30C85666__INCLUDED_)
#define AFX_BSP_H__A470EE83_3FE4_48C3_A23C_963D30C85666__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "brush.h"
#include <stdio.h>

#define		START_BRACE		'{'		
#define		END_BRACE		'}'
#define		COMMA			','
#define		START_BRACKET	'['
#define		END_BRACKET		']'
#define		BLANK			' '
#define		MAX_MATERIAL	32

#define		SIDE_SPACE		0

#define VectorCopy(a,b) {b.x=a.x;b.y=a.y;b.z=a.z;}
#define MAX_POINTS_ON_WINDING	64
#define MAX_PORTAL				8192
#define	LIGHTMAP_SIZE			16
#define LIGHT_RADIUS			32
#define	OBJECTTYPE_LIGHT		0

typedef struct
{
	CWinding * source, * pass;
} PVSDATA;

typedef struct
{
	BSPVERTEX v[4];
	LPDIRECT3DTEXTURE8 t;	
} BILLBOARD;

typedef union tagcolor
{
	CHAR  col[4];
	DWORD color;
} COLOR;

class CBspManager  
{
public:
	int					m_nPortalCnt;
	CBspNode::CPortal**	m_ppPortals; 
	int					m_nBrushCount;
	int					m_nTexCnt;
	int					m_nFaceCount;
	int					m_nStaticLight;
	CFace*				m_pFaceRoot;
	CFace*				m_pNewFaceRoot;
	CBspNode*			m_pBspRoot;
	CBrush*				m_pBrushs;
	CBrush*				m_pCSGBrushs;		//CSG�� ���� ���ο� �͵�.
	CBspNode			m_outsideNode;
	CBspNode*			m_pRenderNode;
	TEXTUREDATA*		m_pTXData;

	CThing*				m_pStaticThing;
	CThing*				m_pDynamicThing;

	BILLBOARD			m_billboard;	

//for light map
	CLight*				m_pLight;
	CLight*				m_pDynamicLight;
	LPDIRECT3DTEXTURE8*	m_ppLightMap;

//�����Ż�� ����� ����(makeleaf���� �־���)
	D3DXVECTOR3		m_vMax;
	D3DXVECTOR3		m_vMin;

public:
	
//for Parse
	BOOL			InitBrushs();
	BOOL			ParseMaxFile( LPSTR szFileName );
	void			GetIndex(LPSTR lpszOther, WORD* first, WORD* second, WORD* third);
	void			GetVertex(LPSTR lpszOther, float* x, float* y, float* z);
	void			SetVertices(FILE* fp);
	void			SetTextureVertices(FILE* fp);
	void			SetTextureIndex(FILE *fp);
	void			SetFaceIndex(FILE* fp);
	void			SetMapInfo(FILE* fp);
	void			GetFormerNOther(FILE* fp, LPSTR lpszFormer, LPSTR lpszOther);
	void			GetToken(FILE* fp, LPSTR lpszToken);
	CBrush*			GetBrushFromName( LPSTR szName );
	void			SetTextureName(FILE* fp);
	BOOL			SetMaterial(FILE *fp);
	int				GetTextureIndex( LPSTR lpszName );
	void			SetTexture( LPDIRECT3DDEVICE8 pd3dDevice );
	void			SetLightInfo( FILE* fp );
	void			GetTM(LPSTR lpszOther, D3DXMATRIX* pMat);

//for Potal
	void			CreateHeadPortals( CBspNode* node );
	void			PortalizeWorld();
	void			CutNodePortals( CBspNode *node );
	CWinding*		BaseWindingForPlane( D3DXPLANE *p );
	CWinding *		ClipWinding (CWinding *in, D3DXPLANE *split, boolean keepon);
	void			DivideWinding (CWinding *in, D3DXPLANE *split, CWinding **front, CWinding **back);
	BOOL			RenderPortal( LPDIRECT3DDEVICE8 pd3dDevice, CD3DFont* pFont );
	void			RemovePortalsLinkedSolidLeaf( CBspNode * node );
	void			FreeAllPortals (CBspNode *node);
	void			ClearOutsideFace();
	void			CheckInside( CBspNode * node );
	void			SetPortals();
	void			SetValidPortals( CBspNode * node );
	CWinding*		ClipToSeperators (CWinding *source, CWinding *pass, CWinding *target, BOOL flipclip);
	void			LinkPortals( CBspNode* node );
	CBspNode*		GetLeafIncludeWinding( CWinding* winding , BOOL bFront);
	BOOL			RenderPVS( LPDIRECT3DDEVICE8 pd3dDevice, BOOL bSolid, CD3DFont* pFont );
	BOOL			IsEqualWinding( CWinding* w1, CWinding* w2 );
	void			RecursiveLeafFlow( PVSDATA* pvs, CBspNode::CPortal* target, CBspNode::CPortal* source );
	CWinding*		CopyWinding( CWinding* w );
	void			TryPVS();
	void			PortalFlow( CBspNode::CPortal* portal );


//for CSG
	CBrush*			FindNotUnitedBrush();
	BOOL			CSGBuild();

//for BSP
	CBspNode*		Build(LPSTR szFileName, LPDIRECT3DDEVICE8 pd3dDevice);
	void			SubDivide( CBspNode* pRoot );
	CFace*			FindBestSplitter( CFace* pList );
	void			GetSortedFaceList ( D3DXPLANE * plane , CFace * f, CFace ** a, CFace **b);
	void			MakeLeaf(CBspNode * leaf);

//util
	void			VectorScale (D3DXVECTOR3 & v, double scale, D3DXVECTOR3 & out);
	void			VectorMA (D3DXVECTOR3 & va, double scale, D3DXVECTOR3 & vb, D3DXVECTOR3 & vc);
	int				ClassifyPoint( D3DXPLANE * plane, D3DXVECTOR3 * v );
	int				CompareNormal( D3DXVECTOR3 &a1, D3DXVECTOR3 &b1, D3DXVECTOR3 &c1, D3DXVECTOR3 &a2, D3DXVECTOR3 &b2, D3DXVECTOR3 &c2 );
	BOOL			IntersectLine( BSPVERTEX* vOut, D3DXPLANE &plane, BSPVERTEX &vA, BSPVERTEX &vB );
	void			Split( D3DXPLANE * plane , CFace * f , CFace ** a , CFace ** b );
	int				Classify( D3DXPLANE *plane, BSPVERTEX *v, int num );
	int				SizeOfFace ( CFace * pFace );
	BOOL			Render(LPDIRECT3DDEVICE8 pd3dDevice, CD3DFont* pFont);
	BOOL			IsCollision( D3DXVECTOR3 &v );
	void			CountFace( CBspNode* node );
	D3DXQUATERNION	RotationArc( D3DXVECTOR3 v0, D3DXVECTOR3 v1 );

//for lightmap
	BOOL			CalculateDynamicLight( CFace* face );
	void			CreateLightMap( LPDIRECT3DDEVICE8 pd3dDevice );
	BOOL			RenderLightMap( LPDIRECT3DDEVICE8 pd3dDevice, BOOL bFill, CD3DFont* pFont );
	void			CalculateNodeFlow( CBspNode* node );
	BOOL			CalculateStaticLight( CFace* face );

//for Things
	void			LoadThings( LPDIRECT3DDEVICE8 pd3dDevice );
	void			SetThingInfo( FILE* fp, CThing* &pThing );
	void			SetThingVertices( FILE* fp, CThing* &pThing );
	void			SetThingFaceIndex( FILE* fp, CThing* &pThing );
	void			SetThingMaterial( FILE* fp, CThing* &pThing );
	void			SetThingTXVertices( FILE* fp, CThing* &pThing );
	void			SetThingTXIndex( FILE* fp, CThing* &pThing );
	void			SetThingTXName( FILE* fp, CThing* &pThing );
	BOOL			RenderThings( LPDIRECT3DDEVICE8 pd3dDevice, D3DXVECTOR3 vDir );

//constructor
	CBspManager();
	virtual ~CBspManager();

};

#endif // !defined(AFX_BSP_H__A470EE83_3FE4_48C3_A23C_963D30C85666__INCLUDED_)
