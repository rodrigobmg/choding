// Brush.cpp: implementation of the CBrush class.
//
//////////////////////////////////////////////////////////////////////

#include "d3dfont.h"
#include "Brush.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBrush::CBrush()
{
	m_pFaceList			= NULL;
	m_nTotalPlane		= 0;
	m_nFaceCount		= 0;
	m_nTotalPlane		= 0;
	m_nVertexCount		= 0;
	m_pTriangleIndex	= NULL;
	m_pVertex			= NULL;
	m_szName[0]			= '\0';
	m_pNext				= NULL;
	m_pPrev				= NULL;
	m_bUnited			= FALSE;

	m_nTCount			= 0;
	m_pTVtx				= NULL;

	m_nTFCount			= 0;
	m_pTIndex			= NULL;
	m_nTexture			= 0;
}

CBrush::~CBrush()
{
	if( m_pFaceList )
	{
		CFace * curr = NULL, * next = NULL;
		for(curr = m_pFaceList; curr ; curr = next)
		{
			next = curr->m_pNext;
			delete curr;
		}
	}
/*
	if( m_pNext )
	{
		m_pNext->Destroy();
	}
*/
}

//max ������ �ҷ��� ����Ҷ� brush�����Ҷ� ����ϴ� �Լ�.
BOOL CBrush::InitBrush()
{
	for( int i = 0; i < m_nFaceCount ; i++ )
	{
		CFace *f = CFace::CreateFace();
		BSPVERTEX* ver = new BSPVERTEX[3];
		ver[0] = m_pVertex[m_pTriangleIndex[i]._0];
		ver[1] = m_pVertex[m_pTriangleIndex[i]._1];
		ver[2] = m_pVertex[m_pTriangleIndex[i]._2];
		
		ver[0].u = m_pTVtx[m_pTIndex[i]._0].x;
		ver[0].v = m_pTVtx[m_pTIndex[i]._0].z;
		ver[1].u = m_pTVtx[m_pTIndex[i]._1].x;
		ver[1].v = m_pTVtx[m_pTIndex[i]._1].z;
		ver[2].u = m_pTVtx[m_pTIndex[i]._2].x;
		ver[2].v = m_pTVtx[m_pTIndex[i]._2].z;

		f->m_vList = ver;
		f->m_nNum = 3;
		f->m_nTexture = m_nTexture;

		D3DXPLANE plane;
		D3DXPlaneFromPoints( &plane, &ver[0].pos, &ver[1].pos, &ver[2].pos );
		int res = FindSamePlane( plane );
		if( res == -1 )
		{
			m_Planes[m_nTotalPlane] = plane;
			f->m_nPlane = m_nTotalPlane++;
		}
		else
			f->m_nPlane = res;

		f->AddNext( m_pFaceList );
		m_pFaceList = f;
	}
	delete[] m_pVertex;
	delete[] m_pTriangleIndex;

	delete[] m_pTVtx;
	delete[] m_pTIndex;
	return TRUE;
}

BOOL CBrush::Create( D3DXVECTOR3 *pList, int n )
{
	/*
	for( int i = 0 ; i < n/3 ; i++ )
	{
		CFace* f = CFace::CreateFace();
		f->m_vList = &pList[i*3];
		f->m_nNum = 3;
		D3DXPLANE plane;
		D3DXPlaneFromPoints( &plane, &pList[i*3], &pList[i*3+1], &pList[i*3+2]);
		int res = FindSamePlane( plane );
		if( res == -1 )
		{
			m_Planes[m_nTotalPlane] = plane;
			f->m_nPlane = m_nTotalPlane++;
		}
		else
			f->m_nPlane = res;

		f->AddNext( m_pFaceList );
		m_pFaceList = f;
	}
	*/
	return TRUE;
}

BOOL CBrush::Create( CFace * pList )
{
	CFace * f = NULL;
	int nCount = 0;
	for( f = pList ; f ; f = f->m_pNext, nCount++ )
	{
		D3DXPLANE plane;
		D3DXPlaneFromPoints( &plane, &f->m_vList[0].pos, &f->m_vList[1].pos, &f->m_vList[2].pos );
		int res = FindSamePlane( plane );
		if( res == -1 )
		{
			m_Planes[m_nTotalPlane] = plane;
			f->m_nPlane = m_nTotalPlane++;
		}
		else
			f->m_nPlane = res;
	}
	m_pFaceList = pList;
	m_nFaceCount = nCount;
	return TRUE;
}

int CBrush::FindSamePlane(D3DXPLANE &plane)
{
	for( int i = 0 ; i < m_nTotalPlane ; i++ )
	{
		if( ComparePlane( m_Planes[i], plane ) )
			return i;
	}
	return -1;
}

BOOL CBrush::ComparePlane(D3DXPLANE &a, D3DXPLANE &b)
{
	if( a.a == b.a && a.b == b.b && a.c == b.c && a.d == b.d )
		return TRUE;
	return FALSE;
}

BOOL CBrush::Render( LPDIRECT3DDEVICE8 pd3dDevice, CD3DFont* pFont )
{
	CFace * f = NULL;
	for( f = m_pFaceList ; f ; f = f->m_pNext )
	{
		if( pFont )
		{
			for( int i = 0; i < f->m_nNum ; i++ )
			{
				D3DXMATRIX	mW, mV, mP, mO;
				pd3dDevice->GetTransform( D3DTS_WORLD, &mW );
				pd3dDevice->GetTransform( D3DTS_VIEW, &mV );
				pd3dDevice->GetTransform( D3DTS_PROJECTION, &mP );
				mO = mW * mV * mP;
				D3DXVECTOR3 vI = f->m_vList[i].pos;
				D3DXVECTOR3 vO;
				D3DXVec3TransformCoord( &vO, &vI, &mO );
				char	str[16];
				wsprintf( str, "( %d, %d, %d )", (int)f->m_vList[i].pos.x, (int)f->m_vList[i].pos.y,(int)f->m_vList[i].pos.z );
				pFont->DrawText(400.0f * (vO.x+1.0f), 600 - 300.0f * (vO.y+1.0f), 0xff000000, str );
			}
		}
		pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLELIST, 1, f->m_vList, sizeof( BSPVERTEX )  );
	}

	if( pFont )
	{
		char s[16];
		wsprintf( s, "NUMBER OF FACE : %d", SizeOfFace( m_pFaceList ) );
		pFont->DrawText( 400, 10, 0xff000000, s );
	}

	if( m_pNext )
		m_pNext->Render( pd3dDevice, pFont );

	return TRUE;
}


CBrush* CBrush::Subtraction(CBrush *pB)
{
	CFace * bk_root = NULL;
	CFace * f = NULL, *front = NULL, *back = NULL, *pNext = NULL, *pCurr;
	int plane_split[10] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 }, num_split = 0;
	
	f = pB->m_pFaceList;
	for( pCurr = f ; pCurr ; pCurr = f )
	{
		f = f->m_pNext;
		for( int i = 0 ; i < m_nTotalPlane ; i++ )
		{
			front = NULL;
			back = NULL;
			BOOL bSplit = FALSE;
			DivideFrontBack( m_Planes[i], pCurr, &front, &back, bSplit, FALSE, NULL );
			if( back )
			{
				if( bSplit )
				{
					BOOL bSearch = FALSE;
					for( int j = 0 ; j < num_split ; j++ )
					{
						if( plane_split[j] == i )
						{
							bSearch = TRUE;
							break;
						}
					}
					if( !bSearch )
					{
						plane_split[num_split++] = i;
					}
				}
				if( back->m_pNext )
					back->m_pNext->AddNext( bk_root );
				else
					back->AddNext( bk_root );
				bk_root = back;
			}
		}
	}

	int i_fr = SizeOfFace( bk_root );
	if( bk_root )
	{
		SplitContactFace( plane_split, num_split, &bk_root, pB );
		
		CBrush * pNew = new CBrush();
		pNew->Create( bk_root );
		return pNew;
	}

	return NULL;
}

//������ Union
CBrush* CBrush::operator + ( CBrush &pB )
{
	CFace * fr_root = NULL;
	CFace * f = NULL, *front = NULL, *back = NULL, *pNext = NULL, *pCurr;
	int plane_split[10] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 }, num_split = 0;
	
	f = pB.m_pFaceList;
	for( pCurr = f ; pCurr ; pCurr = f )
	{
		f = f->m_pNext;
		for( int i = 0 ; i < m_nTotalPlane ; i++ )
		{
			front = NULL;
			back = NULL;
			BOOL bSplit = FALSE;
			DivideFrontBack( m_Planes[i], pCurr, &front, &back, bSplit, TRUE, NULL );

			if( bSplit )
			{
				BOOL bSearch = FALSE;
				for( int j = 0 ; j < num_split ; j++ )
				{
					if( plane_split[j] == i )
					{
						bSearch = TRUE;
						break;
					}
				}
				if( !bSearch )
				{
					plane_split[num_split++] = i;
				}
			}
			
			if( front )
			{
				//�ָ����� �鿡 �ִ� face ����.. ���� ������ �귯������ �ָ����� ��ҿ� face�� 
				//�׳� �ִ� ��찡 �����Ƿ�, Ȯ���� �ָ����� �귯���� ����������..
				
				if( front->m_pNext )
					front->m_pNext->AddNext( fr_root );
				else
					front->AddNext( fr_root );
				fr_root = front;
			}
		}
	}

	int i_fr = SizeOfFace( fr_root );
	if( fr_root )
	{
		SplitContactFace( plane_split, num_split, &fr_root, &pB );
		
		CBrush * pNew = new CBrush();
		pNew->Create( fr_root );
		return pNew;
	}
	return NULL;
}

//brush2�� �ȿ� ����ִ� brush1�� face���� ����. 
BOOL CBrush::DeleteInsideFace(CBrush &brush1, CBrush &brush2)
{
	CFace * new_root = NULL;
	CFace * face = NULL, *face1 = brush2.m_pFaceList;
	int nSplit[32], nCnt = 0;


	for( face = brush1.m_pFaceList; face ; face = face->m_pNext )
	{
		for( int i = 0 ; i < brush2.m_nTotalPlane ; i++ )
		{
			CFace * fr = NULL, * bk = NULL;
			if( TrySplit( &brush2, i, face, fr, bk ) )
			{
				face->m_bDelete = TRUE;
				for( CFace * f = fr ; f->m_pNext ; f = f->m_pNext )
					;
				f->m_pNext = new_root;
				new_root = fr;

				for( f = bk ; f->m_pNext ; f = f->m_pNext )
					;
				f->m_pNext = new_root;
				new_root = bk;

				nSplit[nCnt++] = i;
			}
		}
	}

	if( new_root )
	{
		CFace * curr = NULL;
		for( curr = brush1.m_pFaceList ; curr->m_pNext ; curr = curr->m_pNext )
			;
		curr->m_pNext = new_root;
		brush1.Create( brush1.m_pFaceList );
	}
	
	DeleteBackFace( brush2.m_Planes, brush2.m_nTotalPlane, brush1.m_pFaceList );
	
	return TRUE;
}

BOOL CBrush::DeleteBackFace(D3DXPLANE * planes, int num, CFace * &pList)
{
	CFace * curr = NULL;
	int res = 0, back = 0;
	for( curr = pList ; curr ; curr = curr->m_pNext )
	{
		back = 0;
		for( int i = 0 ; i < num ; i++ )
		{
			res = Classify( &planes[i], curr->m_vList, curr->m_nNum );
			switch( res )
			{
				case SIDE_ON:
				case SIDE_BACK:
					back++;
					break;
			}
		}
		if( back == num )
			curr->m_bDelete = TRUE;
	}
	return TRUE;
}


BOOL CBrush::TrySplit( CBrush* brush, int num, CFace * &f, CFace* &fr, CFace* &bk )
{
	BOOL bCheck = FALSE;
	CFace * curr = NULL;
	int res = Classify( &brush->m_Planes[num], f->m_vList, f->m_nNum );

	switch( res )
	{
		case SIDE_ON:
		case SIDE_FRONT:
		case SIDE_BACK:
			break;
		case SIDE_SPLIT:
			for( curr = brush->m_pFaceList ; curr ; curr = curr->m_pNext )
			{
				if( curr->m_nPlane == num )
				{
					if( IsColliedTriangles( f, curr ) )
					{
						bCheck = TRUE;
						break;
					}
				}
			}
			if( !bCheck )
				return FALSE;

			CFace * front = NULL, * back = NULL, * tmp = NULL;
			Split( &brush->m_Planes[num], f, &front, &back );
			
			if( !front && !back )
				break;
			f->m_bDelete = TRUE;

			fr = front;
			bk = back;
			return TRUE;
	}	

	return FALSE;
}

BOOL CBrush::SplitContactFace( int *pPlane, int nPlane, CFace** pList, CBrush * pBrush )
{
	CFace * cface = NULL;
	if( nPlane <= 0 )
		return FALSE;

	CFace * fr_root = NULL, * fr = NULL, * bk = NULL;

	for( int i = 0; i < nPlane ; i++ )
	{
		cface = NULL;
		for( cface = m_pFaceList ; cface ; cface = cface->m_pNext )
		{
			if( cface->m_nPlane == pPlane[i] )
			{
				for( int n = 0 ; n < pBrush->m_nTotalPlane ; n++ )
				{
					fr = NULL;
					bk = NULL;
					//Union�Լ� ���� DivideFrontBack�Լ� 5��° �Ķ���ʹ� �ﰢ����
					//�������� �������� �˱� ���ؼ� ���� ������.
					//���⼭�� TRUE�� ������ dividefrontback�Լ������� cface�� 
					//�浹���������� �˻��ϰ� �Ѵ�.m_collision ������ �˻�..
					BOOL bTmp = TRUE;
					DivideFrontBack( pBrush->m_Planes[n], cface, &fr, &bk, bTmp, TRUE, pBrush );
					if( fr )
					{
						if( fr->m_pNext )
							fr->m_pNext->AddNext( fr_root );
						else
							fr->AddNext( fr_root );
						fr_root = fr;
					}
				}
			}
			else
			{
				BOOL bCheck = FALSE;
				for( int cnt = 0 ; cnt < nPlane ; cnt++ )
				{
					if( cface->m_nPlane == pPlane[cnt] )
						bCheck = TRUE;
				}

				if( cface && !bCheck )
				{
					CFace * new_face = CFace::CreateFace();
					FaceCopy( cface, new_face );
					new_face->AddNext( fr_root );
					fr_root = new_face;
				}
			}
		}
	}
	
	CFace * tail = NULL;
	for( tail = fr_root ; tail->m_pNext ; tail = tail->m_pNext )
		;
	tail->AddNext( *pList );
	*pList = fr_root;
	return TRUE;
}

//pBrush�� ���� ������ SplitContactFace���� ȣ��ǰ�.
//pBrush�� NULL�� ������ Union���� ù��° �Լ� ȣ��Ǵ°�

BOOL CBrush::DivideFrontBack(D3DXPLANE &plane, CFace *f, CFace **fr, CFace **bk, BOOL &bSplit, BOOL bIsUnion, CBrush* pBrush )
{
	CFace * nf = CFace::CreateFace();
	FaceCopy( f, nf );
	int res = Classify( &plane, nf->m_vList, nf->m_nNum );

//	���� ���� �븻�� �ݴ��� ���..(���� �پ��ְ�) ���̴� ������
	D3DXVECTOR3 plane_normal( plane.a, plane.b, plane.c );
	D3DXVECTOR3 vBA, vCA;
	D3DXVECTOR3 vCross, face_normal;

	float dot = 0;


	switch( res )
	{
		case SIDE_ON:
			if( bIsUnion )
			{
/*
				nf->AddNext( *bk );
				*bk = nf;
		%Union�϶��� ���� ������ ���� �ʿ䰡 �����Ƿ� memory leak������ ����..
*/
				delete nf;
			}
			else
			{
				nf->AddNext( *fr );
				*fr = nf;
			}

//	���� ���� �븻�� �ݴ��� ���..(���� �پ��ְ�)
//	bSplit������ TRUE�� �����Ͽ� ���� ���� �ʿ�
			vBA = f->m_vList[1].pos - f->m_vList[0].pos;
			vCA = f->m_vList[2].pos - f->m_vList[0].pos;
			D3DXVec3Cross( &vCross, &vBA, &vCA );
			D3DXVec3Normalize( &face_normal, &vCross );
			
			dot = D3DXVec3Dot( &plane_normal, &face_normal );
			
			if( dot < 0 )
				bSplit = TRUE;

			break;
		case SIDE_FRONT:
			nf->AddNext( *fr );
			*fr = nf;
			break;
		case SIDE_BACK:
			if( bIsUnion )
			{
/*
		%Union�϶��� ���� ������ ���� �ʿ䰡 �����Ƿ� memory leak������ ����..
				nf->AddNext( *bk );
				*bk = nf;
		%%% memory leak ������ ���� %%%
*/
				delete nf;
			}
			break;
		case SIDE_SPLIT:
			CFace * front = NULL, * back = NULL, * pFace = NULL;
//bSplit�� TRUE�� ������ f�Ǵ� ���纻 nf�� �浹���¿��θ� �˻��ؼ�..
//�浹���°� �ƴ϶�� nf�� ����� FALSE�� ��ȯ�Ѵ�.
			if( bSplit )
			{
				if( !nf->m_bCollision )
				{
					nf->AddNext( *fr );
					*fr = nf;
					return FALSE;
				}
				else
				{
					delete nf;
				}
			}
///////////// memory leak ���� /////////
//�����ִ� ����: split �� ���� ���纻nf�� ������� �ʰ� �׳� f�� ������ �����ϸ鼭
//���Ҹ鿡 ���� ���ο� face�� �����ϱ� ������ ���纻�� �ʿ����.
			else
			{
				delete nf;
			}

//brush�� ������ �ִ� face�� �߿��� ���� ���� �ִ�  face�� ��� face
//�� �ﰢ���� �浹�������� �˻��ؼ� �浹 ���°� �ƴϸ� nf�� delete�ϰ� 
//FALSE�� ��ȯ �Ѵ�. �浹�����̸� face�� ������� m_bCollision�� TRUE�� �ϰ� 
//split�� �Ѵ�.
			BOOL bColl = FALSE;
			if( pBrush == NULL )
			{
				for( pFace = m_pFaceList ; pFace ; pFace = pFace->m_pNext )
				{
					if( m_Planes[pFace->m_nPlane] == plane )
					{
	//f�� �ϳ��� cface�� ���� ���� �ڵ��Ǿ� �־ for�� ���� �ʿ䰡 ����.
						if( IsColliedTriangles( pFace, f ) )
						{
							pFace->m_bCollision = TRUE;
							f->m_bCollision = TRUE;
							bColl = TRUE;
						}
					}
				}
				if( !bColl )
				{
					return FALSE;
				}
			}// end if( pBrush == NULL ) Union�Ҷ� ù��° ��쿡���� ȣ���.

			Split( &plane, f, &front, &back );
			if( !front && !back )
				break;
			if( front->m_pNext )
			{
				if( bIsUnion )
				{
					front->m_pNext->AddNext( *fr );
					*fr = front;
				}
				else
				{
					front->m_pNext->AddNext( *bk );
					*bk = front;
				}
			}
			else 
			{
				if( bIsUnion )
				{
					front->AddNext( *fr );
					*fr = front;
				}
				else
				{
					front->AddNext( *bk );
					*bk = front;
				}
			}
			if( back->m_pNext )
			{
				if( bIsUnion )
				{
/*
		%Union�϶��� ���� ������ ���� �ʿ䰡 �����Ƿ� memory leak������ ����..
					back->m_pNext->AddNext( *bk );
					*bk = back;
*/
					delete back->m_pNext;
					delete back;
				}
				else
				{
					back->m_pNext->AddNext( *fr );
					*fr = back;
				}
			}
			else
			{
				if( bIsUnion )
				{
/*
		%Union�϶��� ���� ������ ���� �ʿ䰡 �����Ƿ� memory leak������ ����..
					back->AddNext( *bk );
					*bk = back;
*/
					delete back;
				}
				else
				{
					back->AddNext( *fr );
					*fr = back;
				}
			}
			bSplit = TRUE;
			break;
	}	
	return TRUE;
}

BOOL CBrush::FaceCopy(CFace *pOrig, CFace *pCopy)
{
	pCopy->m_nNum = pOrig->m_nNum;
	pCopy->m_bCollision = pOrig->m_bCollision;
	BSPVERTEX * copy = new BSPVERTEX[pOrig->m_nNum];
	for( int i = 0; i < pOrig->m_nNum ; i++ )
	{
		copy[i] = pOrig->m_vList[i];
	}
	pCopy->m_vList = copy;
	pCopy->m_nTexture = pOrig->m_nTexture;
	pCopy->m_nLightMap = pOrig->m_nLightMap;
	return TRUE;
}

int CBrush::Classify( D3DXPLANE *plane, BSPVERTEX *v, int num )
{
	int front = 0, back = 0, on = 0;
	float res = 0;

	for (int cnt = 0; cnt < num; cnt++)
	{
		res = D3DXPlaneDotCoord( plane, &v[cnt].pos );

		if ( res > EPSILON )
			front++;
		else if ( res < -EPSILON )
			back++;
		else
		{
			front++;
			back++;
			on++;
		}
	}
   
	if (on == num)
		return SIDE_ON;
	else if (front == num)
		return SIDE_FRONT;
	else if (back == num)
		return SIDE_BACK;
	else
		return SIDE_SPLIT;
}

int CBrush::ClassifyPoint( D3DXPLANE * plane, D3DXVECTOR3 * v )
{
	float res = D3DXPlaneDotCoord( plane, v);
	if( res > EPSILON )
		return SIDE_FRONT;
	else if( res < -EPSILON )
		return SIDE_BACK;
	else 
		return SIDE_ON;
}

void CBrush::Split(D3DXPLANE *plane, CFace *f, CFace **a, CFace **b)
{
	CFace * frontList, * backList;
	BSPVERTEX vFrontList[20], vBackList[20], vFirst;
	BSPVERTEX vIntersectPoint, vPointA, vPointB;
	WORD wFrontCnt = 0, wBackCnt = 0, wCnt = 0, wCurrentVec = 0;

	vFirst = f->m_vList[0];

	switch( ClassifyPoint( plane, &vFirst.pos ))
	{
		case SIDE_FRONT:
			vFrontList[wFrontCnt++] = vFirst;
			break;
		case SIDE_BACK:
			vBackList[wBackCnt++] = vFirst;
			break;
		case SIDE_ON:
			vFrontList[wFrontCnt++] = vFirst;
			vBackList[wBackCnt++] = vFirst;
			break;
		default:
			break;
	}

	for( wCnt = 1 ; wCnt < f->m_nNum + 1; wCnt++ )
	{
		if( wCnt == f->m_nNum )
			wCurrentVec = 0;
		else
			wCurrentVec = wCnt;

		vPointA = f->m_vList[wCnt-1];
		vPointB = f->m_vList[wCurrentVec];

		int result = ClassifyPoint( plane, &vPointB.pos );
		if( result == SIDE_ON )
		{
			vBackList[wBackCnt++] = f->m_vList[wCurrentVec];
			vFrontList[wFrontCnt++] = f->m_vList[wCurrentVec];
		}
		else
		{
			if( IntersectLine( &vIntersectPoint, *plane, vPointA, vPointB ))
			{
				if( result == SIDE_FRONT )
				{
					vBackList[wBackCnt++] = vIntersectPoint;
					vFrontList[wFrontCnt++] = vIntersectPoint;
					if( wCurrentVec )
						vFrontList[wFrontCnt++] = f->m_vList[wCurrentVec];
				}
				if( result == SIDE_BACK )
				{
					vFrontList[wFrontCnt++] = vIntersectPoint;
					vBackList[wBackCnt++] = vIntersectPoint;
					if( wCurrentVec )
						vBackList[wBackCnt++] = f->m_vList[wCurrentVec];
				}
			}// end - if( IntersectLine() )
			else
			{
				if( result == SIDE_FRONT )
				{
					if( wCurrentVec )
						vFrontList[wFrontCnt++] = f->m_vList[wCurrentVec];
				}
				if( result == SIDE_BACK )
				{
					if( wCurrentVec )
						vBackList[wBackCnt++] = f->m_vList[wCurrentVec];
				}
			}// end - else( IntersectLine() )
		}// end - else( result == SIDE_ON )
	}// end - for(;;)
	
	if( wFrontCnt == wBackCnt )
	{
		frontList = CFace::CreateFace();
		BSPVERTEX* tmp1 = new BSPVERTEX[3];
		tmp1[0] = vFrontList[0];
		tmp1[1] = vFrontList[1];
		tmp1[2] = vFrontList[2];
		frontList->SetVertexList( tmp1 );
		frontList->m_nNum = 3;
		frontList->m_nTexture = f->m_nTexture;

		backList = CFace::CreateFace();
		BSPVERTEX* tmp2 = new BSPVERTEX[3];
		tmp2[0] = vBackList[0];
		tmp2[1] = vBackList[1];
		tmp2[2] = vBackList[2];
		backList->SetVertexList( tmp2 );
		backList->m_nNum = 3;
		backList->m_nTexture = f->m_nTexture;
	}
	else if( wFrontCnt > wBackCnt )
	{
		frontList = CFace::CreateFace();
		BSPVERTEX* tmp1 = new BSPVERTEX[3];
		tmp1[0] = vFrontList[0];
		tmp1[1] = vFrontList[1];
		tmp1[2] = vFrontList[2];
		frontList->SetVertexList( tmp1 );
		frontList->m_nNum = 3;
		frontList->m_nTexture = f->m_nTexture;

		CFace * next = CFace::CreateFace();
		BSPVERTEX* tmp2 = new BSPVERTEX[3];
		tmp2[0] = vFrontList[0];
		tmp2[1] = vFrontList[2];
		tmp2[2] = vFrontList[3];
		next->SetVertexList( tmp2 );
		next->m_nNum = 3;
		next->m_nTexture = f->m_nTexture;

		frontList->AddNext( next );

		backList = CFace::CreateFace();
		BSPVERTEX* tmp3 = new BSPVERTEX[3];
		tmp3[0] = vBackList[0];
		tmp3[1] = vBackList[1];
		tmp3[2] = vBackList[2];
		backList->SetVertexList( tmp3 );
		backList->m_nNum = 3;
		backList->m_nTexture;
	}
	else if( wBackCnt > wFrontCnt )
	{
		backList = CFace::CreateFace();
		BSPVERTEX* tmp1 = new BSPVERTEX[3];
		tmp1[0] = vBackList[0];
		tmp1[1] = vBackList[1];
		tmp1[2] = vBackList[2];
		backList->SetVertexList( tmp1 );
		backList->m_nNum = 3;
		backList->m_nTexture = f->m_nTexture;

		CFace * next = CFace::CreateFace();
		BSPVERTEX* tmp2 = new BSPVERTEX[3];
		tmp2[0] = vBackList[0];
		tmp2[1] = vBackList[2];
		tmp2[2] = vBackList[3];
		next->SetVertexList( tmp2 );
		next->m_nNum = 3;
		next->m_nTexture = f->m_nTexture;

		backList->AddNext( next );

		frontList = CFace::CreateFace();
		BSPVERTEX* tmp3 = new BSPVERTEX[3];
		tmp3[0] = vFrontList[0];
		tmp3[1] = vFrontList[1];
		tmp3[2] = vFrontList[2];
		frontList->SetVertexList( tmp3 );
		frontList->m_nNum = 3;
		frontList->m_nTexture = f->m_nTexture;
	}

	*a = frontList;
	*b = backList;
}

BOOL CBrush::IntersectLine( BSPVERTEX* vOut, D3DXPLANE &plane, BSPVERTEX &vA, BSPVERTEX &vB )
{
	int res = ClassifyPoint( &plane, &vA.pos );
	if( res == SIDE_ON )
		return FALSE;
	res = ClassifyPoint( &plane, &vB.pos );
	if( res == SIDE_ON )
		return FALSE;
	
	D3DXVECTOR3 n( plane.a, plane.b, plane.c );
	float lineLength = D3DXVec3Dot( &(vB.pos - vA.pos), &n );
	if( fabsf( lineLength ) < 0.0001 )
		return FALSE;

	float aDot = D3DXVec3Dot( &vA.pos, &n );
	float bDot = D3DXVec3Dot( &vB.pos, &n );
	float scale = ( -(plane.d) - aDot ) / ( bDot - aDot );

	if( scale < 0.0f )
		return FALSE;
	if( scale > 1.0f )
		return FALSE;

	(*vOut).pos = vA.pos + ( scale * ( vB.pos - vA.pos ) );

//texture ��ǥ ..
	float deltaU = vB.u - vA.u;
	float deltaV = vB.v - vA.v;
	(*vOut).u = vA.u + deltaU*scale;
	(*vOut).v = vA.v + deltaV*scale;
	return TRUE;
}

int CBrush::SizeOfFace ( CFace * pFace )
{
	CFace * temp = pFace;
	int i=0;
	while(temp)
	{
		i++;
		temp = temp->m_pNext;
	}
	return i;
}


BOOL CBrush::IsColliedBrushs(CBrush *pb)
{
	CFace * brush1 = NULL, * brush2 = NULL;
	int res = 0;

	for( brush2 = pb->m_pFaceList ; brush2 ; brush2 = brush2->m_pNext )
	{
		for( int j = 0 ; j < brush2->m_nNum ; j++ )
		{
			res = 0;
			for( int i = 0 ; i < m_nTotalPlane ; i++ )
			{
				switch( ClassifyPoint( &m_Planes[i], &brush2->m_vList[j].pos ) )
				{
					case SIDE_ON:
					case SIDE_BACK:
						res++;
						break;
				}
			}
			if( res == m_nTotalPlane )
				return TRUE;
		}
	}


	for( brush1 = m_pFaceList ; brush1 ; brush1 = brush1->m_pNext )
	{
		for( int j = 0 ; j < brush1->m_nNum ; j++ )
		{
			res = 0;
			for( int i = 0 ; i < pb->m_nTotalPlane ; i++ )
			{
				switch( ClassifyPoint( &pb->m_Planes[i], &brush1->m_vList[j].pos ) )
				{
					case SIDE_ON:
					case SIDE_BACK:
						res++;
						break;
				}
			}
			if( res == pb->m_nTotalPlane )
				return TRUE;
		}
	}

	for( brush1 = m_pFaceList ; brush1 ; brush1 = brush1->m_pNext )
	{
		for( brush2 = pb->m_pFaceList ; brush2 ; brush2 = brush2->m_pNext )
		{
			if( IsColliedTriangles( brush1, brush2 ) )
			{
				return TRUE;
			}
		}
	}
	return FALSE;
}

//ù��° brush�� face��(f1)�� ����� �������� �ι�° brush�� face��(f2) �浹�˻��Ѵ�.
BOOL CBrush::IsColliedTriangles(CFace* f1, CFace* f2)
{
	BSPVERTEX a[3], b[3];
	a[0] = f1->m_vList[0];
	a[1] = f1->m_vList[1];
	a[2] = f1->m_vList[2];

	b[0] = f2->m_vList[0];
	b[1] = f2->m_vList[1];
	b[2] = f2->m_vList[2];

	D3DXPLANE planeA, planeB;
	D3DXPlaneFromPoints( &planeA, &a[0].pos, &a[1].pos, &a[2].pos );
	D3DXPlaneFromPoints( &planeB, &b[0].pos, &b[1].pos, &b[2].pos );

	BSPVERTEX vPointA, vPointB, vIntersectPoint;
	WORD wCnt, wCurrentVec;
	float a1, b1, a2, b2, a3, b3, a4, b4;	//2���� ��ǥ
	int nEx = 2 ;							//0�� x��ǥ, 1�� y��ǥ, 2�� z��ǥ ����.

// ù��° �ﰢ��(���)�� ��������
	if( (a[1].pos.x - a[0].pos.x == 0) && (a[2].pos.x - a[0].pos.x == 0) )			//x��ǥ ����
	{	
		a1 = a[0].pos.y;
		b1 = a[0].pos.z;

		a2 = a[1].pos.y;
		b2 = a[1].pos.z;

		a3 = a[2].pos.y;
		b3 = a[2].pos.z;

		nEx = 0;
	}
	else if( (a[1].pos.y - a[0].pos.y == 0) && (a[2].pos.y - a[0].pos.y == 0) )	//y��ǥ ����
	{
		a1 = a[0].pos.x;
		b1 = a[0].pos.z;

		a2 = a[1].pos.x;
		b2 = a[1].pos.z;

		a3 = a[2].pos.x;
		b3 = a[2].pos.z;

		nEx = 1;
	}
	else	//z��ǥ ����
	{
		a1 = a[0].pos.x;
		b1 = a[0].pos.y;

		a2 = a[1].pos.x;
		b2 = a[1].pos.y;

		a3 = a[2].pos.x;
		b3 = a[2].pos.y;

		nEx = 2;
	}

	for( wCnt = 1 ; wCnt < f2->m_nNum + 1; wCnt++ )
	{
		if( wCnt == f2->m_nNum )
			wCurrentVec = 0;
		else
			wCurrentVec = wCnt;

		vPointA = f2->m_vList[wCnt-1];
		vPointB = f2->m_vList[wCurrentVec];

		if( IntersectLine( &vIntersectPoint, planeA, vPointA, vPointB ))
		{
			if( nEx == 0 )
			{
				a4 = vIntersectPoint.pos.y;
				b4 = vIntersectPoint.pos.z;
			}
			else if( nEx == 1 )
			{
				a4 = vIntersectPoint.pos.x;
				b4 = vIntersectPoint.pos.z;
			}
			else
			{
				a4 = vIntersectPoint.pos.x;
				b4 = vIntersectPoint.pos.y;
			}

//planeA��.. �� ù��° �ﰢ���� ���
			
			if( IsInsideTriangle( a1, b1, a2, b2, a3, b3, a4, b4, TRUE ) )
			{
				return TRUE;
			}
		}
	}
	
// �ι�° �ﰢ���� ��������
	if( (b[1].pos.x - b[0].pos.x == 0) && (b[2].pos.x - b[0].pos.x == 0) )			//x��ǥ ����
	{	
		a1 = b[0].pos.y;
		b1 = b[0].pos.z;

		a2 = b[1].pos.y;
		b2 = b[1].pos.z;

		a3 = b[2].pos.y;
		b3 = b[2].pos.z;

		nEx = 0;
	}
	else if( (b[1].pos.y - b[0].pos.y == 0) && (b[2].pos.y - b[0].pos.y == 0) )	//y��ǥ ����
	{
		a1 = b[0].pos.x;
		b1 = b[0].pos.z;

		a2 = b[1].pos.x;
		b2 = b[1].pos.z;

		a3 = b[2].pos.x;
		b3 = b[2].pos.z;

		nEx = 1;
	}
	else	//z��ǥ ����
	{
		a1 = b[0].pos.x;
		b1 = b[0].pos.y;

		a2 = b[1].pos.x;
		b2 = b[1].pos.y;

		a3 = b[2].pos.x;
		b3 = b[2].pos.y;

		nEx = 2;
	}


	for( wCnt = 1 ; wCnt < f1->m_nNum + 1; wCnt++ )
	{
		if( wCnt == f1->m_nNum )
			wCurrentVec = 0;
		else
			wCurrentVec = wCnt;

		vPointA = f1->m_vList[wCnt-1];
		vPointB = f1->m_vList[wCurrentVec];

		if( IntersectLine( &vIntersectPoint, planeB, vPointA, vPointB ))
		{
			if( nEx == 0 )
			{
				a4 = vIntersectPoint.pos.y;
				b4 = vIntersectPoint.pos.z;
			}
			else if( nEx == 1 )
			{
				a4 = vIntersectPoint.pos.x;
				b4 = vIntersectPoint.pos.z;
			}
			else
			{
				a4 = vIntersectPoint.pos.x;
				b4 = vIntersectPoint.pos.y;
			}

			if( IsInsideTriangle( a1, b1, a2, b2, a3, b3, a4, b4, TRUE ) )
			{
				return TRUE;
			}
		}
	}
	
	return FALSE;
}

//�Ǹ����� �Ķ���ʹ� ��輱�� �ɷ��� inside�� �����Ұ��ΰ� ���Ұ��ΰ�.
BOOL CBrush::IsInsideTriangle(float &a1, float &b1, float &a2, float &b2, float &a3, float &b3, float &a4, float &b4, BOOL bContact )
{
	BOOL AB_vert = FALSE, BC_vert = FALSE, CA_vert = FALSE;
	BOOL bUp1 = FALSE, bUp2 = FALSE, bUp3 = FALSE;
	float center_x, center_y;				//�ﰢ���� ����.
	float m1, m2, m3, bb1, bb2, bb3;		//�������� ����.
	center_x = center_y = m1 = m2 = m3 = bb1 = bb2 = bb3 = 0.f;

	int inside = 0;

	if( (a2 - a1) != 0 )
	{
		m1 = (b2 - b1)/(a2 - a1);
		bb1 = (b1) - (m1 * a1);
	}
	else if( (a2 - a1) == 0 )
	{
		AB_vert = TRUE;
	}

	if( (a3 - a2) != 0 )
	{
		m2 = (b3 - b2)/(a3 - a2);
		bb2 = (b2) - (m2 * a2);
	}
	else if( (a3 - a2) == 0 )
	{
		BC_vert = TRUE;
	}

	if( (a1 - a3) != 0 )
	{
		m3 = (b1 - b3)/(a1 - a3);
		bb3 = (b3) - (m3 * a3);
	}
	else if( (a1 - a3) == 0 )
	{
		CA_vert = TRUE;
	}

	center_x = (a1+a2+a3)/3;
	center_y = (b1+b2+b3)/3;
	
	if( ( (m1*center_x) + bb1 ) >= center_y )
		bUp1 = TRUE;
	else
		bUp1 = FALSE;

	if( ( (m2*center_x) + bb2 ) >= center_y )
		bUp2 = TRUE;
	else
		bUp2 = FALSE;

	if( ( (m3*center_x) + bb3 ) >= center_y )
		bUp3 = TRUE;
	else
		bUp3 = FALSE;


	if( bContact )		//��輱�� �ɸ��� �͵� inside�� ������ ���ΰ� �� �� ���ΰ�.
	{
	//a->b
		if( AB_vert == TRUE )
		{
			if( (a1 <= a4) && (a1 <= center_x) )
				inside++;
			else if( (a1 >= a4) && (a1 >= center_x) )
				inside++;
		}
		else
		{
			if( bUp1 )
			{
				if( b4 <= ((m1*a4)+bb1) )
					inside++;
			}
			else if( !bUp1 )
			{
				if( b4 >= ((m1*a4)+bb1) )
					inside++;
			}
		}
		
	//b->c
		if( BC_vert == TRUE )
		{
			if( (a2 <= a4) && (a2 <= center_x) )
				inside++;
			else if( (a2 >= a4) && (a2 >= center_x) )
				inside++;
		}
		else
		{
			if( bUp2 )
			{
				if( b4 <= ((m2*a4)+bb2) )
					inside++;
			}
			else if( !bUp2 )
			{
				if( b4 >= ((m2*a4)+bb2) )
					inside++;
			}
		}

	//c->a
		if( CA_vert == TRUE )
		{
			if( (a3 <= a4) && (a3 <= center_x) )
				inside++;
			else if( (a3 >= a4) && (a3 >= center_x) )
				inside++;
		}
		else
		{
			if( bUp3 )
			{
				if( b4 <= ((m3*a4)+bb3) )
					inside++;
			}
			else if( !bUp3 )
			{
				if( b4 >= ((m3*a4)+bb3) )
					inside++;
			}
		}
	}//end if( bContact )  

//��輱�� �ɸ��°� inside�� ���� ���� ���
	else
	{
	//a->b
		if( AB_vert == TRUE )
		{
			if( (a1 < a4) && (a1 < center_x) )
				inside++;
			else if( (a1 > a4) && (a1 > center_x) )
				inside++;
		}
		else
		{
			if( bUp1 )
			{
				if( b4 < ((m1*a4)+bb1) )
					inside++;
			}
			else
			{
				if( b4 > ((m1*a4)+bb1) )
					inside++;
			}
		}
		
	//b->c
		if( BC_vert == TRUE )
		{
			if( (a2 < a4) && (a2 < center_x) )
				inside++;
			else if( (a2 > a4) && (a2 > center_x) )
				inside++;
		}
		else
		{
			if( bUp2 )
			{
				if( b4 < ((m2*a4)+bb2) )
					inside++;
			}
			else
			{
				if( b4 > ((m2*a4)+bb2) )
					inside++;
			}
		}

	//c->a
		if( CA_vert == TRUE )
		{
			if( (a3 < a4) && (a3 < center_x) )
				inside++;
			else if( (a3 > a4) && (a3 > center_x) )
				inside++;
		}
		else
		{
			if( bUp3 )
			{
				if( b4 < ((m3*a4)+bb3) )
					inside++;
			}
			else
			{
				if( b4 > ((m3*a4)+bb3) )
					inside++;
			}
		}
	}

	if( inside == 3 )
		return TRUE;
	else
		return FALSE;
}

BOOL CBrush::BrushCopy(CBrush *pOrig, CBrush*  &pCopy)
{
	pCopy = new CBrush();
	CFace * face_head = NULL,* f1 = NULL;

	for( f1 = pOrig->m_pFaceList ; f1 ; f1 = f1->m_pNext )
	{
		CFace * f2 = CFace::CreateFace();
		FaceCopy( f1, f2 );
		f2->m_pNext = face_head;
		face_head = f2;
	}

	pCopy->m_nFaceCount = pOrig->m_nFaceCount;

	pCopy->m_pFaceList = face_head;

	pCopy->m_nTotalPlane = pOrig->m_nTotalPlane;

	for( int i = 0 ; i < pOrig->m_nTotalPlane ; i++ )
	{
		pCopy->m_Planes[i] = pOrig->m_Planes[i];
	}
	return TRUE;
}

