//-----------------------------------------------------------------------------
// File: GameEngine.cpp
//
// Desc: DirectX window application created by the DirectX AppWizard
//-----------------------------------------------------------------------------
#define STRICT
#define DIRECTINPUT_VERSION 0x0800
#include <windows.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <D3DX8.h>
#include <DXErr8.h>
#include <tchar.h>
#include <dinput.h>
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DUtil.h"
#include "DMUtil.h"
#include "DXUtil.h"
#include "resource.h"
#include "GameEngine.h"



//-----------------------------------------------------------------------------
// Global access to the app (needed for the global WndProc())
//-----------------------------------------------------------------------------
CMyD3DApplication*	g_pApp  = NULL;
HINSTANCE			g_hInst = NULL;
TCHAR				g_strMsg[MAX_PATH];				




//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: Entry point to the program. Initializes everything, and goes into a
//       message-processing loop. Idle time is used to render the scene.
//-----------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




//-----------------------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: Application constructor. Sets attributes for the app.
//-----------------------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
    
    m_strWindowTitle            = TEXT( "GameEngine" );
    m_bUseDepthBuffer           = TRUE;

    // Create a D3D font using d3dfont.cpp
    m_pFont                     = new CD3DFont( _T("Arial"), 8 );
    m_bLoadingApp               = TRUE;
    m_pDI                       = NULL;
    m_pKeyboard                 = NULL;
    m_pMusicManager             = NULL;
    m_pBounceSound              = NULL;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
    m_fWorldRotX                = 0.0f;
    m_fWorldRotY                = 0.0f;

    // Read settings from registry
    ReadSettings();
	
	m_dwCreationWidth           = 800;
    m_dwCreationHeight          = 600;
	m_UserInput.b1				= TRUE;
}




//-----------------------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: Called during initial app startup, this function performs all the
//       permanent initialization.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // TODO: perform one time initialization

    // Drawing loading status message until app finishes loading
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    // Initialize DirectInput
    InitInput( m_hWnd );

    // Initialize audio
    InitAudio( m_hWnd );

    m_bLoadingApp = FALSE;



    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: ReadSettings()
// Desc: Read the app settings from the registry
//-----------------------------------------------------------------------------
VOID CMyD3DApplication::ReadSettings()
{
    HKEY hkey;
    if( ERROR_SUCCESS == RegCreateKeyEx( HKEY_CURRENT_USER, DXAPP_KEY, 
        0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hkey, NULL ) )
    {
        // TODO: change as needed

        // Read the stored window width/height.  This is just an example,
        // of how to use DXUtil_Read*() functions.
        DXUtil_ReadIntRegKey( hkey, TEXT("Width"), &m_dwCreationWidth, m_dwCreationWidth );
        DXUtil_ReadIntRegKey( hkey, TEXT("Height"), &m_dwCreationHeight, m_dwCreationHeight );

        RegCloseKey( hkey );
    }
}




//-----------------------------------------------------------------------------
// Name: WriteSettings()
// Desc: Write the app settings to the registry
//-----------------------------------------------------------------------------
VOID CMyD3DApplication::WriteSettings()
{
    HKEY hkey;
    DWORD dwType = REG_DWORD;
    DWORD dwLength = sizeof(DWORD);

    if( ERROR_SUCCESS == RegCreateKeyEx( HKEY_CURRENT_USER, DXAPP_KEY, 
        0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hkey, NULL ) )
    {
        // TODO: change as needed

        // Write the window width/height.  This is just an example,
        // of how to use DXUtil_Write*() functions.
//        DXUtil_WriteIntRegKey( hkey, TEXT("Width"), m_rcWindowClient.right );
//        DXUtil_WriteIntRegKey( hkey, TEXT("Height"), m_rcWindowClient.bottom );

        RegCloseKey( hkey );
    }
}





//-----------------------------------------------------------------------------
// Name: InitInput()
// Desc: Initialize DirectInput objects
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InitInput( HWND hWnd )
{
    HRESULT hr;

    // Create a IDirectInput8*
    if( FAILED( hr = DirectInput8Create( GetModuleHandle(NULL), DIRECTINPUT_VERSION, 
                                         IID_IDirectInput8, (VOID**)&m_pDI, NULL ) ) )
        return DXTRACE_ERR_NOMSGBOX( "DirectInput8Create", hr );
    
    // Create a IDirectInputDevice8* for the keyboard
    if( FAILED( hr = m_pDI->CreateDevice( GUID_SysKeyboard, &m_pKeyboard, NULL ) ) )
        return DXTRACE_ERR_NOMSGBOX( "CreateDevice", hr );
    
    // Set the keyboard data format
    if( FAILED( hr = m_pKeyboard->SetDataFormat( &c_dfDIKeyboard ) ) )
        return DXTRACE_ERR_NOMSGBOX( "SetDataFormat", hr );
    
    // Set the cooperative level on the keyboard
    if( FAILED( hr = m_pKeyboard->SetCooperativeLevel( hWnd, 
                                            DISCL_NONEXCLUSIVE | 
                                            DISCL_FOREGROUND | 
                                            DISCL_NOWINKEY ) ) )
        return DXTRACE_ERR_NOMSGBOX( "SetCooperativeLevel", hr );

    // Acquire the keyboard
    m_pKeyboard->Acquire();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: InitAudio()
// Desc: Initialize DirectX audio objects
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InitAudio( HWND hWnd )
{
    HRESULT hr;

    // Create the music manager class, used to create the sounds
    m_pMusicManager = new CMusicManager();
    if( FAILED( hr = m_pMusicManager->Initialize( hWnd ) ) )
        return DXTRACE_ERR_NOMSGBOX( "m_pMusicManager->Initialize", hr );

    // Instruct the music manager where to find the files
    // TODO: Set this to the media directory, or use resources
    TCHAR szPath[MAX_PATH];
    GetCurrentDirectory( MAX_PATH, szPath ); 
    m_pMusicManager->SetSearchDirectory( szPath );

    // TODO: load the sounds from resources (or files)
    m_pMusicManager->CreateSegmentFromResource( &m_pBounceSound, _T("BOUNCE"), _T("WAVE") );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: Called during device initialization, this code checks the display device
//       for some minimum set of capabilities
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS8* pCaps, DWORD dwBehavior,
                                          D3DFORMAT Format )
{
   if( dwBehavior & D3DCREATE_PUREDEVICE )
        return E_FAIL; // GetTransform doesn't work on PUREDEVICE

    // This sample uses alpha textures and/or straight alpha. Make sure the
    // device supports them
    if( pCaps->TextureCaps & D3DPTEXTURECAPS_ALPHAPALETTE )
        return S_OK;
    if( pCaps->TextureCaps & D3DPTEXTURECAPS_ALPHA )
        return S_OK;

	return E_FAIL;
}




//-----------------------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: Initialize scene objects.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    // TODO: create device objects

    // Init the font
    m_pFont->InitDeviceObjects( m_pd3dDevice );
/*
	CFace * face1, * face2;
	face1 = CFace::CreateFace();
	face2 = CFace::CreateFace();

	BSPVERTEX * v1 = new BSPVERTEX[3];
	BSPVERTEX * v2 = new BSPVERTEX[3];

	v1[0].v = D3DXVECTOR3( -1, 0, 0 );
	v1[1].v = D3DXVECTOR3( 2, 1, 0 );
	v1[2].v = D3DXVECTOR3( 2, 0, 0 );

	v2[0].v = D3DXVECTOR3( 0, 0, -2 );
	v2[1].v = D3DXVECTOR3( 0, 2, 2 );
	v2[2].v = D3DXVECTOR3( 0, 0, 2 );

	face1->SetVertexList( v1 );
	face2->SetVertexList( v2 );

	face1->m_nNum = 3;
	face2->m_nNum = 3;

	CBrush brush1, brush2;
	brush1.Create( face1 );
	brush2.Create( face2 );
	
	BOOL result = brush1.IsCollisionTriangles( face1, face2 );
*/ // Begin the scene
    

//	BOOL check = m_bspManager.m_pBrushs[0].IsColliedBrushs( &m_bspManager.m_pBrushs[1] );
	
/*
	CBrush * new_brush = NULL;
	new_brush = m_bspManager.m_pBrushs[0] + m_bspManager.m_pBrushs[1] ;

	m_bspManager.m_pNewBrushs = new_brush;
*/
    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: Restores scene objects.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
    // TODO: setup render states

    // Setup a material
    D3DMATERIAL8 mtrl;
    D3DUtil_InitMaterial( mtrl, 1.0f, 0.0f, 0.0f );
    m_pd3dDevice->SetMaterial( &mtrl );

    // Set up the textures
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_MINFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR );

    // Set miscellaneous render states
    m_pd3dDevice->SetRenderState( D3DRS_DITHERENABLE,   FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,        TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_AMBIENT,        0x000F0F0F );

    // Set the world matrix
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity( &matIdentity );
    m_pd3dDevice->SetTransform( D3DTS_WORLD,  &matIdentity );

    // Set up our view matrix. A view matrix can be defined given an eye point,
    // a point to lookat, and a direction for which way is up. Here, we set the
    // eye five units back along the z-axis and up three units, look at the
    // origin, and define "up" to be in the y-direction.
    D3DXMATRIX matView;
    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 2.0f, 10.0f, 2.0f );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 10.0f, -1.0f );
//	D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 100.0f, 100.0f, 0.0f );
//  D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 10.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &matView, &vFromPt, &vLookatPt, &vUpVec );
    m_pd3dDevice->SetTransform( D3DTS_VIEW, &matView );

    // Set the projection matrix
    D3DXMATRIX matProj;
    FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &matProj, D3DX_PI/4, fAspect, 1.0f, 1000.0f );
    m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &matProj );

    // Set up lighting states
    D3DLIGHT8 light;
    D3DUtil_InitLight( light, D3DLIGHT_DIRECTIONAL, -1.0f, -1.0f, 2.0f );
    m_pd3dDevice->SetLight( 0, &light );
    m_pd3dDevice->LightEnable( 0, TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );

    // Restore the font
    m_pFont->RestoreDeviceObjects();


	m_Camera.SetView( &vFromPt, &vLookatPt, &vUpVec );
	m_Camera.SetMatrices( &matIdentity, &matView, &matProj );

	m_bspManager.Build( "data\\lightmap00", m_pd3dDevice );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: FrameMove()
// Desc: Called once per frame, the call is the entry point for animating
//       the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
// Update user input state
    UpdateInput( &m_UserInput );

	m_Camera.RotateLocalY( m_UserInput.dxMouse );
	m_Camera.RotateLocalX( m_UserInput.dyMouse );

	D3DXVECTOR3 vOrigEye = *(m_Camera.GetEye());
	D3DXVECTOR3 vOrigLookat = *(m_Camera.GetLookat());
	D3DXVECTOR3 vOrigUp = *(m_Camera.GetUp());

	if( m_UserInput.bW )
		m_Camera.MoveLocalZ(  m_fElapsedTime * DEF_SPEED  );
	if( m_UserInput.bS )	
		m_Camera.MoveLocalZ(  -m_fElapsedTime * DEF_SPEED  );
	if( m_UserInput.bD )
		m_Camera.MoveLocalX(  m_fElapsedTime * DEF_SPEED  );
	if( m_UserInput.bA )
		m_Camera.MoveLocalX(  -m_fElapsedTime * DEF_SPEED  );

    // Update the world state according to user input
    D3DXMATRIX matWorld;
    D3DXMATRIX matRotY;
    D3DXMATRIX matRotX;

    if( m_UserInput.fAxisRotateLR )
        m_fWorldRotY += m_fElapsedTime * m_UserInput.fAxisRotateLR;

    if( m_UserInput.fAxisRotateUD )
        m_fWorldRotX += m_fElapsedTime * m_UserInput.fAxisRotateUD;

   

	m_bCollision = FALSE;
	if( m_bspManager.IsCollision( *m_Camera.GetEye() ) )
		m_bCollision = TRUE;
	if( m_bCollision )
		m_Camera.SetView( &vOrigEye, &vOrigLookat, &vOrigUp );
 
	D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
    D3DXMatrixRotationY( &matRotY, m_fWorldRotY );

    D3DXMatrixMultiply( &matWorld, &matRotX, &matRotY );
    m_pd3dDevice->SetTransform( D3DTS_WORLD, &matWorld );

	m_pd3dDevice->SetTransform( D3DTS_VIEW, m_Camera.GetViewMatrix() );
/*
	D3DXMATRIX		m;
	D3DXMATRIX *pW, *pV, *pP;
	m_Camera.GetMatrices( &pW, &pV, &pP );
	
///	if( m_bViewLock )
	{
//		m = m_matViewLocked * *pP;
	}
//	else
	{
		m = (*pV) * (*pP);
//		m_terrainUtil.SetCamera( v.x, v.y, v.z );
	}
	m_bspManager.m_frustum.Make( &m );
*/
    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: UpdateInput()
// Desc: Update the user input.  Called once per frame 
//-----------------------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
	static dwFill = 0, dwPortal =0, dwLight = 0;
    pUserInput->bRButtonDown = ( m_bHasFocus && (GetAsyncKeyState( VK_RBUTTON ) & 0x8000) == 0x8000 );
	pUserInput->bS = ( m_bHasFocus && (GetAsyncKeyState( 'S' ) & 0x8000 ) == 0x8000 );
	pUserInput->bW = ( m_bHasFocus && (GetAsyncKeyState( 'W' ) & 0x8000 ) == 0x8000 );
	pUserInput->bA = ( m_bHasFocus && (GetAsyncKeyState( 'A' ) & 0x8000 ) == 0x8000 );
	pUserInput->bD = ( m_bHasFocus && (GetAsyncKeyState( 'D' ) & 0x8000 ) == 0x8000 );
	if( ( m_bHasFocus && (GetAsyncKeyState( 'P' ) & 0x8000 ) == 0x8000 ) &&
		GetTickCount() - dwPortal > 300 )
	{
		pUserInput->bP = !pUserInput->bP;
		dwPortal = GetTickCount();
	}

	if( ( m_bHasFocus && (GetAsyncKeyState( 'L' ) & 0x8000 ) == 0x8000 ) &&
		GetTickCount() - dwLight > 300 )
	{
		pUserInput->bL = !pUserInput->bL;
		dwLight = GetTickCount();
	}

	if( ( m_bHasFocus && (GetAsyncKeyState( '1' ) & 0x8000 ) == 0x8000 ) &&
		GetTickCount() - dwFill > 300 )
	{
		pUserInput->b1 = !pUserInput->b1;
		dwFill = GetTickCount();
	}
	
	POINT pt;
	GetCursorPos( &pt );

	if(	pUserInput->bRButtonDown )
	{
		pUserInput->dxMouse = ( pt.x - pUserInput->ptMouse.x ) * m_fElapsedTime * 0.2f;
		pUserInput->dyMouse = ( pt.y - pUserInput->ptMouse.y ) * m_fElapsedTime * 0.2f;
		SetCursorPos( pUserInput->ptMouse.x, pUserInput->ptMouse.y );
	}
	else
		GetCursorPos( &pUserInput->ptMouse );
}




//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Called once per frame, the call is the entry point for 3d
//       rendering. This function sets up render states, clears the
//       viewport, and renders the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
    // Clear the viewport
    m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,
                         0xffffffff, 1.0f, 0L );

    // Begin the scene
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
        // TODO: render world
        
        // Render stats and help text 
//		
		
//		else
//		m_bspManager.Render( m_pd3dDevice, NULL );
//		m_bspManager.RenderByPortals( m_pd3dDevice );
		if( m_UserInput.bL )
		{
			m_bspManager.RenderLightMap( m_pd3dDevice, m_UserInput.b1, NULL );
//			m_bspManager.RenderLightMap( m_pd3dDevice, m_pFont );
		}
		else
			m_bspManager.RenderPVS( m_pd3dDevice, m_UserInput.b1, m_pFont );

		D3DXVECTOR3 v = m_Camera.m_vLookat - m_Camera.m_vEye;
		m_bspManager.RenderThings( m_pd3dDevice, m_Camera.m_vEye );
		
		if( m_UserInput.bP )
		{
			m_bspManager.RenderPortal( m_pd3dDevice, NULL );
//			m_bspManager.RenderPortal( m_pd3dDevice, m_pFont );
		}
		
		
//		m_bspManager.Render( m_pd3dDevice, m_pFont );
		RenderText();

        // End the scene.
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: RenderText()
// Desc: Renders stats and help text to the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{

    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
	if( !m_UserInput.b1 )
		fontColor = D3DCOLOR_ARGB(255, 0, 0, 255);
    D3DCOLOR fontWarningColor = D3DCOLOR_ARGB(255,0,255,255);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    // Output display stats
    FLOAT fNextLine = 2.f; 

    lstrcpy( szMsg, m_strFrameStats );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

//    lstrcpy( szMsg, m_strDeviceStats );
//   fNextLine += 20.0f;
//   m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

	TCHAR* szMove = _T("FORWARD, BACK, LEFT, RIGHT : W, S, A, D ");
	fNextLine += 20.0f;
	m_pFont->DrawText( 2, fNextLine, fontColor, szMove );

	TCHAR* szLook = _T("LOOK : RBUTTONDOWN & MOUSE MOVE ");
	fNextLine += 20.0f;
	m_pFont->DrawText( 2, fNextLine, fontColor, szLook );


    // Output statistics & help
    fNextLine = (FLOAT) m_d3dsdBackBuffer.Height; 
/*
    sprintf( szMsg, TEXT("POS : %0.3f, %0.3f, %0.3f"), 
                    m_Camera.GetEye()->x, m_Camera.GetEye()->y, m_Camera.GetEye()->z );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, TEXT("Use arrow keys to update input") );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, TEXT("Hold 'F5' down to play and repeat a sound") );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, TEXT("Press 'F2' to configure display") );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
*/
	TCHAR* szFill	= ( m_UserInput.b1 ) ? _T("Fill") : _T("Wire");
	TCHAR* szLight	= ( m_UserInput.bL ) ? _T("Render") : _T("");
	TCHAR* szPortal	= ( m_UserInput.bP ) ? _T("Render") : _T("");

	wsprintf( szMsg, _T("FILLMODE[ 1 ] : [ %s ]"), szFill);
	fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
	
	wsprintf( szMsg, _T("PORTAL  [ P ] : [ %s ]"), szPortal);
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

	wsprintf( szMsg, _T("LIGHTMAP[ L ] : [ %s ]"), szLight);
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

	DWORD dwHeight, dwWidth;
	if( m_bCollision )
	{
		
		dwHeight = m_pFont->GetTexHeight();
		dwWidth = m_pFont->GetTexWidth();
		m_pFont->SetTexHeight( dwHeight + 400 );
		m_pFont->SetTexWidth( dwWidth + 400 );

		char str[15] = "collision!";
		m_pFont->DrawText( 350, 280, 0xffff0000, str );
		
		m_pFont->SetTexHeight( dwHeight );
		m_pFont->SetTexWidth( dwWidth );
	}

	if( m_UserInput.bP )
	{
		dwHeight = m_pFont->GetTexHeight();
		dwWidth = m_pFont->GetTexWidth();
		m_pFont->SetTexHeight( dwHeight + 200 );
		m_pFont->SetTexWidth( dwWidth + 200 );
		m_pFont->DrawText( 500, 20, fontWarningColor, _TEXT("Rendering Portal"));
		m_pFont->SetTexHeight( dwHeight );
		m_pFont->SetTexWidth( dwWidth );
	}

	if( m_UserInput.bL )
	{
		dwHeight = m_pFont->GetTexHeight();
		dwWidth = m_pFont->GetTexWidth();
		m_pFont->SetTexHeight( dwHeight + 200 );
		m_pFont->SetTexWidth( dwWidth + 200 );
		m_pFont->DrawText( 500, 40, fontWarningColor, _TEXT("Rendering LightMap"));
		m_pFont->SetTexHeight( dwHeight );
		m_pFont->SetTexWidth( dwWidth );
	}

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: Overrrides the main WndProc, so the sample can do custom message
//       handling (e.g. processing mouse, keyboard, or menu commands).
//-----------------------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,
                                    LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // Draw on the window tell the user that the app is loading
                // TODO: change as needed
                HDC hDC = GetDC( hWnd );
				wsprintf( g_strMsg, TEXT("Loading... Please wait") );
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, g_strMsg, -1, &rct, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-----------------------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: Invalidates device objects.  
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
    // TODO: Cleanup any objects created in RestoreDeviceObjects()
    m_pFont->InvalidateDeviceObjects();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: Called when the app is exiting, or the device is being changed,
//       this function deletes any device dependent objects.  
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
    // TODO: Cleanup any objects created in InitDeviceObjects()
    m_pFont->DeleteDeviceObjects();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: FinalCleanup()
// Desc: Called before the app exits, this function gives the app the chance
//       to cleanup after itself.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
    // TODO: Perform any final cleanup needed
    // Cleanup D3D font
    SAFE_DELETE( m_pFont );

    // Cleanup DirectInput
    CleanupDirectInput();

    // Cleanup DirectX audio objects
    SAFE_DELETE( m_pBounceSound );
    SAFE_DELETE( m_pMusicManager );

    // Write the settings to the registry
    WriteSettings();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: CleanupDirectInput()
// Desc: Cleanup DirectInput 
//-----------------------------------------------------------------------------
VOID CMyD3DApplication::CleanupDirectInput()
{
    // Cleanup DirectX input objects
    SAFE_RELEASE( m_pKeyboard );
    SAFE_RELEASE( m_pDI );

}




