//-----------------------------------------------------------------------------
// File: GameEngine.h
//
// Desc: Header file GameEngine sample app
//-----------------------------------------------------------------------------
#ifndef AFX_GAMEENGINE_H__5EF68C77_D261_40DC_B46D_604735AD46C0__INCLUDED_
#define AFX_GAMEENGINE_H__5EF68C77_D261_40DC_B46D_604735AD46C0__INCLUDED_




//-----------------------------------------------------------------------------
// Defines, and constants
//-----------------------------------------------------------------------------
// TODO: change "DirectX AppWizard Apps" to your name or the company name
#define DXAPP_KEY        TEXT("Software\\DirectX AppWizard Apps\\GameEngine")

// Struct to store the current input state
struct UserInput
{
    // TODO: change as needed
    FLOAT fAxisRotateUD;
    FLOAT fAxisRotateLR;
    BOOL bDoConfigureInput;
    BOOL bDoConfigureDisplay;

	float dxMouse;
	float dyMouse;

	BOOL bW;
	BOOL bS;
	BOOL bA;
	BOOL bD;
	BOOL bP;
	BOOL bL;

	BOOL b1;

	BOOL bRButtonDown;

	POINT ptMouse;
};
#include "bspmanager.h"
#include "Camera.h"

#define DEF_SPEED	20.0f


//-----------------------------------------------------------------------------
// Name: class CMyD3DApplication
// Desc: Application class. The base class (CD3DApplication) provides the 
//       generic functionality needed in all Direct3D samples. CMyD3DApplication 
//       adds functionality specific to this sample program.
//-----------------------------------------------------------------------------
class CMyD3DApplication : public CD3DApplication
{
	CBspManager				m_bspManager;
	CCamera					m_Camera;
	BOOL					m_bCollision;

    BOOL                    m_bLoadingApp;          // TRUE, if the app is loading
    CD3DFont*               m_pFont;                // Font for drawing text
	
	

    LPDIRECTINPUT8          m_pDI;                  // DirectInput object
    LPDIRECTINPUTDEVICE8    m_pKeyboard;            // DirectInput keyboard device
    UserInput               m_UserInput;            // Struct for storing user input 

    FLOAT                   m_fSoundPlayRepeatCountdown; // Sound repeat timer
    CMusicManager*          m_pMusicManager;        // DirectMusic manager class
    CMusicSegment*          m_pBounceSound;         // Bounce sound

    FLOAT                   m_fWorldRotX;           // World rotation state X-axis
    FLOAT                   m_fWorldRotY;           // World rotation state Y-axis

protected:
    HRESULT OneTimeSceneInit();
    HRESULT InitDeviceObjects();
    HRESULT RestoreDeviceObjects();
    HRESULT InvalidateDeviceObjects();
    HRESULT DeleteDeviceObjects();
    HRESULT Render();
    HRESULT FrameMove();
    HRESULT FinalCleanup();
    HRESULT ConfirmDevice( D3DCAPS8*, DWORD, D3DFORMAT );

    HRESULT RenderText();

    HRESULT InitInput( HWND hWnd );
    void    UpdateInput( UserInput* pUserInput );
    void    CleanupDirectInput();

    HRESULT InitAudio( HWND hWnd );

    VOID    ReadSettings();
    VOID    WriteSettings();

public:
    LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
    CMyD3DApplication();
};


#endif // !defined(AFX_GAMEENGINE_H__5EF68C77_D261_40DC_B46D_604735AD46C0__INCLUDED_)
