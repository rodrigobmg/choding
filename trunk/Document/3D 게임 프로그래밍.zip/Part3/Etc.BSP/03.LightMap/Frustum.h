// Frustum.h: interface for the CFrustum class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FRUSTUM_H__F71E127B_A6E0_4E60_9D44_EA689D16A04B__INCLUDED_)
#define AFX_FRUSTUM_H__F71E127B_A6E0_4E60_9D44_EA689D16A04B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "define.h"

class CFrustum  
{
	D3DXVECTOR3	m_vtx[8];
	D3DXPLANE	m_plane[6];
public:
	CFrustum();
	virtual ~CFrustum();
	BOOL	Make( D3DXMATRIX* pmatViewProj );
	int		IsIn( D3DXVECTOR3* pVec );
	BOOL	Draw( LPDIRECT3DDEVICE8 pDev );
};

#endif // !defined(AFX_FRUSTUM_H__F71E127B_A6E0_4E60_9D44_EA689D16A04B__INCLUDED_)
