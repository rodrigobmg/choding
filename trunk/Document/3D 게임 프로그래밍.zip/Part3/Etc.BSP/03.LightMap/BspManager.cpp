// Bsp.cpp: implementation of the CBsp class.
//
//////////////////////////////////////////////////////////////////////

#include "BspManager.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
int			g_count = 0;

CBspManager::CBspManager()
{
	m_nBrushCount			= 0;
	m_nPortalCnt			= 0;
	m_nTexCnt				= 0;
	m_nFaceCount			= 0;
	m_ppPortals				= NULL;
	m_pBrushs				= NULL;
	m_pCSGBrushs			= NULL;
	m_pFaceRoot				= NULL;
	m_pNewFaceRoot			= NULL;
	m_pBspRoot				= NULL;
	m_pRenderNode			= NULL;
	m_pTXData				= NULL;
	m_pLight				= NULL;

	m_vMax					= D3DXVECTOR3( -BSP_BOGUS, -BSP_BOGUS, -BSP_BOGUS );
	m_vMin					= D3DXVECTOR3( BSP_BOGUS, BSP_BOGUS, BSP_BOGUS );

	m_ppLightMap			= NULL;
	m_pStaticThing			= NULL;
	m_pDynamicThing			= NULL;

	m_pDynamicLight			= NULL;
}

CBspManager::~CBspManager()
{
	if( m_pDynamicLight )
		delete m_pDynamicLight;
	if( m_pDynamicThing )
		delete m_pDynamicThing;
	if( m_pStaticThing )
		delete m_pStaticThing;
	if( m_ppLightMap )
		delete[] m_ppLightMap;
	if( m_pLight )
		delete[] m_pLight;
	if( m_nTexCnt == 1 && m_nTexCnt != 0)
		delete m_pTXData;

	if( m_nTexCnt > 1 )
		delete[] m_pTXData;


	if( m_ppPortals )
		delete[] m_ppPortals;
	FreeAllPortals( m_pBspRoot );
	if( m_pBspRoot )
	{
		delete m_pBspRoot;
	}
	if( m_pBrushs )
	{
		if( m_nBrushCount > 1 )
		{
			delete[] m_pBrushs;
		}
		else if( m_nBrushCount > 0 )
		{
			delete m_pBrushs;
		}
	}

	CBrush * next = NULL, * curr = NULL;
	for( curr = m_pCSGBrushs ; curr ; curr = next )
	{
		next = curr->m_pNext;
		delete curr;
	}
	
//	m_pFaceRoot->Destroy();
}

BOOL CBspManager::ParseMaxFile(LPSTR szFileName)
{
	char tmpFileName[STR_MAX];
	FILE* fp;
	//LIGHT ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".tm");
		fp = fopen(tmpFileName, "r");
		SetLightInfo( fp );
		fclose( fp );
		
	//MAP ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".nfo");
		fp = fopen(tmpFileName, "r");
		SetMapInfo( fp );
		fclose( fp );

	//VERTEX ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".vtx");
		fp = fopen(tmpFileName, "r");
		SetVertices( fp );
		fclose( fp );
		
	//FACE INDEX ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".idx");
		fp = fopen(tmpFileName, "r");
		SetFaceIndex( fp );
		fclose( fp );
		
	//MATERIAL ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".mat");
		fp = fopen(tmpFileName, "r");
		SetMaterial( fp );
		fclose( fp );

	//TEXTURE VERTEX����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".vtt");
		fp = fopen(tmpFileName, "r");
		SetTextureVertices( fp );
		fclose( fp );

	//TVERTEX INDEX ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".idt");
		fp = fopen(tmpFileName, "r");
		SetTextureIndex( fp );
		fclose( fp );

	//TEXTURE NAME ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".txn");
		fp = fopen(tmpFileName, "r");
		SetTextureName( fp );
		fclose( fp );

	return TRUE;
}

CBrush* CBspManager::GetBrushFromName( LPSTR szName )
{
	for( int i = 0; i < m_nBrushCount ; i++ )
	{
		if( !strcmp( m_pBrushs[i].m_szName, szName ) )
			return &m_pBrushs[i];
	}
	return NULL;
}

BOOL CBspManager::SetMaterial(FILE *fp)
{
	char lpszFormer[STR_MAX], lpszOther[STR_MAX];
	int num = 0;
	GetToken( fp, lpszFormer );
	if( strcmp( lpszFormer, "MATERIAL") )
		return FALSE;

	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		if(!strcmp(lpszOther, "EOF"))
			break;
		else if(!strcmp(lpszFormer, "TEXTURE"))
		{
			num++;
		}
	}

	if( num <= 0 )
		return FALSE;

	m_nTexCnt = num;

	m_pTXData = new TEXTUREDATA[num];
	num = 0;

	fseek( fp, 0, SEEK_SET );

	GetToken( fp, lpszFormer );
	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		if(!strcmp(lpszOther, "EOF"))
			break;
		else if(!strcmp(lpszFormer, "TEXTURE"))
		{
			strcpy( m_pTXData[num++].name, lpszOther );
		}
	}
	return TRUE;
}

void CBspManager::SetTextureName(FILE* fp)
{
	char lpszFormer[STR_MAX], lpszOther[STR_MAX];
	CBrush* pObj = NULL;
	int num = 0;
	float x, y, z;
	GetToken( fp, lpszFormer );
	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		if(!strcmp(lpszOther, "EOF"))
			break;
		else if(!strcmp(lpszFormer, "NAME"))
			pObj = GetBrushFromName(lpszOther);
		else if(!strcmp(lpszFormer, "TEXTURE"))
		{
			if(pObj)
			{
				pObj->m_nTexture = GetTextureIndex( lpszOther );
			}
		}
	}
}

int CBspManager::GetTextureIndex( LPSTR lpszName )
{
	if( m_nTexCnt <= 0 )
		return -1;

	for( int i = 0 ; i < m_nTexCnt ; i++ )
	{
		if( !strcmp( m_pTXData[i].name, lpszName ) )
			return i;
	}

	return -1;
}

void CBspManager::SetTexture( LPDIRECT3DDEVICE8 pd3dDevice )
{
	for( int i = 0 ; i < m_nTexCnt ; i++ )
	{
		D3DXCreateTextureFromFile( pd3dDevice, m_pTXData[i].name, &m_pTXData[i].texture );
/*		for( int j = 0 ; j < m_nBrushCount ; j++ )
		{
			if( !strcmp( m_pTXData[i].name, m_pBrushs[j].m_szName ) )
				m_pBrushs[j].m_nTexture = i;
		}*/
	}
}

void CBspManager::SetTextureVertices(FILE* fp)
{
	char lpszFormer[STR_MAX], lpszOther[STR_MAX];
	CBrush* pObj = NULL;
	int num = 0;
	float x, y, z;
	GetToken( fp, lpszFormer );
	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		if(!strcmp(lpszOther, "EOF"))
			break;
		else if(!strcmp(lpszFormer, "NAME"))
			pObj = GetBrushFromName(lpszOther);
		else if(!strcmp(lpszFormer, "COUNT"))
		{
			if(pObj)
			{
				pObj->m_nTCount = atoi(lpszOther);
				pObj->m_pTVtx = new D3DXVECTOR3[pObj->m_nTCount];
				num = 0;
			}
		}
		else if(pObj->m_nTCount > 0)
		{
			GetVertex(lpszOther, &x, &y, &z);
			pObj->m_pTVtx[num].x = x;
			pObj->m_pTVtx[num].y = y;
			//max������ v�� �ö���鼭 �����ؼ� 1�̵ǹǷ�
			//D3D�� v�� �������鼭 �����ؼ� 1����
			pObj->m_pTVtx[num].z = 1.f - z;
			num++;
		}
	}
}

void CBspManager::SetTextureIndex(FILE *fp)
{
	char lpszFormer[STR_MAX], lpszOther[STR_MAX];
	CBrush* pObj = NULL;
	int num = 0;
	WORD first, second, third;

	GetToken( fp, lpszFormer );

	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		if(!strcmp(lpszOther, "EOF"))
			break;
		else if(!strcmp(lpszFormer, "NAME"))
			pObj = GetBrushFromName(lpszOther);
		else if(!strcmp(lpszFormer, "COUNT"))
		{
			if(pObj)
			{
				pObj->m_nTFCount = atoi(lpszOther);
				pObj->m_pTIndex = new TRIANGLEINDEX[pObj->m_nTFCount];
				num = 0;
			}
		}
		else if(pObj->m_nTFCount > 0)
		{
			GetIndex(lpszOther, &first, &second, &third);
			pObj->m_pTIndex[num]._0 = first;
			pObj->m_pTIndex[num]._1 = second;
			pObj->m_pTIndex[num++]._2 = third;
		}

	}
}

void CBspManager::SetMapInfo(FILE* fp)
{
	char lpszFormer[STR_MAX], lpszOther[STR_MAX];
	GetToken( fp, lpszFormer );
	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		if(!strcmp(lpszOther, "EOF"))
			break;
		if(!strcmp(lpszFormer, "OBJECTCOUNT"))
		{
			m_nBrushCount = atoi(lpszOther) - m_nStaticLight;
			m_pBrushs = new CBrush[m_nBrushCount];
			break;
		}
	}
}

void CBspManager::GetIndex(LPSTR lpszOther, WORD* first, WORD* second, WORD* third)
{
	char buffer[20];
	while(*lpszOther++ != START_BRACKET);

	for(int index=0, i=0;*lpszOther;lpszOther++)
	{
		if(*lpszOther == END_BRACKET)
			break;
		if(*lpszOther == COMMA)
		{
			buffer[i] = NULL;
			if(index == 0)
				*third = (WORD)(atoi(buffer))-1;
			else if(index == 1)
				*second = (WORD)(atoi(buffer))-1;
			i = 0;
			index++;
		}
		else
			buffer[i++] = *lpszOther;
	}
	buffer[i] = NULL;
	*first = (WORD)(atoi(buffer))-1;
}

void CBspManager::GetVertex(LPSTR lpszOther, float* x, float* y, float* z)
{
	char buffer[20];
	double buf = 0;
	while(*lpszOther++ != START_BRACKET);
	//Max�� yz��ǥ�� D3D�� yz�� �ٲ��ߵ�.
	for(int index=0, i=0;*lpszOther;lpszOther++)
	{
		if(*lpszOther == END_BRACKET)
			break;
		if(*lpszOther == COMMA)
		{
			buffer[i] = NULL;
			if(index == 0)
				*x = (float)atof(buffer);
			else if(index == 1)
				*z = (float)atof(buffer);
			i = 0;
			index++;
		}
		else
			buffer[i++] = *lpszOther;
	}
	buffer[i] = NULL;
	*y = (float)atof(buffer);
}

// D3D�� Matrix				MAX�� Matrix
// _11 _12 _13 _14			_11 _13 _12 0
// _21 _22 _23 _24			_31 _33 _32 0
// _31 _32 _33 _34			_21 _23 _22 0
// _41 _42 _43 _44			_41 _43 _42 1
void CBspManager::GetTM(LPSTR lpszOther, D3DXMATRIX* pMat)
{
	char buffer[STR_MAX];
	int index = 0;
	while(*lpszOther++ != BLANK);
	while(1)
	{
		if(*lpszOther == END_BRACKET)
		{
			buffer[index] = *lpszOther;
			buffer[index+1] = NULL;
			GetVertex(buffer, &pMat->_11, &pMat->_12, &pMat->_13);
			index = 0;
			break;
		}
		buffer[index++] = *lpszOther++;
	}

	while(*lpszOther++ != BLANK);
	while(1)
	{
		if(*lpszOther == END_BRACKET)
		{
			buffer[index] = *lpszOther;
			buffer[index+1] = NULL;
			GetVertex(buffer, &pMat->_31, &pMat->_32, &pMat->_33);
			index = 0;
			break;
		}
		buffer[index++] = *lpszOther++;
	}

	while(*lpszOther++ != BLANK);
	while(1)
	{
		if(*lpszOther == END_BRACKET)
		{
			buffer[index] = *lpszOther;
			buffer[index+1] = NULL;
			GetVertex(buffer, &pMat->_21, &pMat->_22, &pMat->_23);
			index = 0;
			break;
		}
		buffer[index++] = *lpszOther++;
	}

	while(*lpszOther++ != BLANK);
	while(1)
	{
		if(*lpszOther == END_BRACKET)
		{
			buffer[index] = *lpszOther;
			buffer[index+1] = NULL;
			GetVertex(buffer, &pMat->_41, &pMat->_42, &pMat->_43);
			index = 0;
			break;
		}
		buffer[index++] = *lpszOther++;
	}

	pMat->_14 = pMat->_24 = pMat->_34 = 0.0f;
	pMat->_44 = 1.0f;
}

void CBspManager::SetVertices(FILE* fp)
{
	char lpszFormer[STR_MAX], lpszOther[STR_MAX];
	int index = 0, count = 0;
	CBrush* curr = NULL;
	float x, y, z;
	GetToken( fp, lpszFormer );
	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		if(!strcmp(lpszOther, "EOF"))
			break;
		
		else if(!strcmp(lpszFormer, "NAME"))
		{
			strcpy(m_pBrushs[count].m_szName, lpszOther);
			curr = &m_pBrushs[count];
			index = 0;
			count++;
		}
		
		else if(!strcmp(lpszFormer, "COUNT"))
		{
			curr->m_nVertexCount = atoi(lpszOther);
			curr->m_pVertex = new BSPVERTEX[curr->m_nVertexCount];
		}
		else if( curr )
		{
			if(curr->m_nVertexCount > 0)
			{
				//GetVertex�� yz��ǥ�� �ٲ���
				GetVertex(lpszOther, &x, &y, &z);
				curr->m_pVertex[index].pos.x = x;
				curr->m_pVertex[index].pos.y = y;
				curr->m_pVertex[index].pos.z = z;
				index++;
			}
		}
	}
}

void CBspManager::SetLightInfo( FILE* fp )
{
	char lpszFormer[STR_MAX], lpszOther[STR_MAX];
	int num = 0; 
	WORD first=0, second=0, third=0;
	char ch[6];

	GetToken( fp, lpszFormer );
	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		for( int i = 0 ; i < 5 ; i++ )
		{
			ch[i] = lpszFormer[i];
		}
		ch[5] = '\0';
		if(!strcmp(lpszOther, "EOF"))
			break;
		else if(!strcmp(ch, "Fspot"))
		{
			num++;
		}
	}

	m_pLight = new CLight[num];
	m_nStaticLight = num;
	num = 0;

	fseek( fp, 0, SEEK_SET );
	
	GetToken( fp, lpszFormer );
	
	D3DXMATRIX mat;

	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		for( int i = 0 ; i < 5 ; i++ )
		{
			ch[i] = lpszFormer[i];
		}
		ch[5] = '\0';
		if(!strcmp(lpszOther, "EOF"))
			break;
		else if(!strcmp(ch, "Fspot"))
		{
			GetTM( lpszOther, &mat );
			m_pLight[num].m_radius = LIGHT_RADIUS;
			m_pLight[num++].m_vPosition = D3DXVECTOR3( mat._41, mat._42, mat._43 );
		}
	}
}

void CBspManager::SetFaceIndex(FILE* fp)
{
	char lpszFormer[STR_MAX], lpszOther[STR_MAX];
	int num = 0; 
	CBrush* curr = NULL;
	WORD first=0, second=0, third=0;

	GetToken( fp, lpszFormer );
	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		if(!strcmp(lpszOther, "EOF"))
			break;
	
		else if(!strcmp(lpszFormer, "NAME"))
		{
			curr = GetBrushFromName( lpszOther );
			num = 0;
		}
		else if(!strcmp(lpszFormer, "COUNT"))
		{
			curr->m_nFaceCount = atoi(lpszOther);
			curr->m_pTriangleIndex = new TRIANGLEINDEX[curr->m_nFaceCount];
		}
		else if( curr )
		{
			if(curr->m_nFaceCount > 0)
			{
				//GetIndex���� first�� third�� ���� �ٲ���.
				GetIndex(lpszOther, &first, &second, &third);
				curr->m_pTriangleIndex[num]._0 = first;
				curr->m_pTriangleIndex[num]._1 = second;
				curr->m_pTriangleIndex[num]._2 = third;
				num++;
			}
		}
	}
}

void CBspManager::GetToken(FILE* fp, LPSTR lpszToken)
{
	char ch = 0;
	while( fgetc(fp)!=START_BRACE );
	while(1)
	{
		ch = fgetc(fp);
		if(ch == END_BRACE)
		{	
			*lpszToken = NULL;
			return;
		}
		*lpszToken = ch;
		lpszToken++;
	}
}

void CBspManager::GetFormerNOther(FILE* fp, LPSTR lpszFormer, LPSTR lpszOther)
{
	GetToken(fp, lpszFormer);
	GetToken(fp, lpszOther);
}

BOOL CBspManager::Render(LPDIRECT3DDEVICE8 pd3dDevice , CD3DFont* pFont)
{
	pd3dDevice->SetVertexShader( D3DFVF_BSPVERTEX );
	pd3dDevice->SetStreamSource( 0, NULL, 0 );
	pd3dDevice->SetIndices( NULL, 0 );
	pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE );

//	pd3dDevice->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_nVertexCount,
//				m_nFaceCount, m_pTriangleIndex, D3DFMT_INDEX16, m_pPos, sizeof( BSPVERTEX )  );

//	if( m_pCSGBrushs )
//	{
//		m_pCSGBrushs->Render( pd3dDevice, pFont );
//	}


	m_pBspRoot->Render( pd3dDevice, pFont );
	return TRUE;
}

BOOL CBspManager::RenderPVS( LPDIRECT3DDEVICE8 pd3dDevice, BOOL bSolid, CD3DFont* pFont )
{
	pd3dDevice->SetVertexShader( D3DFVF_BSPVERTEX );
	pd3dDevice->SetStreamSource( 0, NULL, 0 );
	pd3dDevice->SetIndices( NULL, 0 );
	if( bSolid )
		pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	else	
		pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW );
	
	m_pBspRoot->InitRender();

	CBspNode::CPortal* portal = m_pRenderNode->m_pPortals;

	for( int i = 0 ; i < portal->m_nFaceCnt ; i++ )
	{
		pd3dDevice->SetRenderState(D3DRS_LIGHTING,FALSE);
		pd3dDevice->SetTexture( 0, m_pTXData[portal->m_ppFaceList[i]->m_nTexture].texture);
		pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLELIST, 1, 
				portal->m_ppFaceList[i]->m_vList, sizeof( BSPVERTEX ) ) ;
	}
	if( pFont )
	{
		D3DXMATRIX	mW, mV, mP, mO;
		pd3dDevice->GetTransform( D3DTS_WORLD, &mW );
		pd3dDevice->GetTransform( D3DTS_VIEW, &mV );
		pd3dDevice->GetTransform( D3DTS_PROJECTION, &mP );
		mO = mW * mV * mP;
		char	str[32];
		wsprintf( str, "COUNT FACE( %d )", portal->m_nFaceCnt );
		pFont->DrawText(400.0f, 20.0f, 0xffffff00, str );
	}
		
/*
	for( portal = m_pRenderNode->m_pPortals ; portal ; portal = portal->m_pNext[0] )
	{
		CFace* f = NULL;
		if( !portal->m_pNode[0]->m_bRender )
		{
			portal->m_pNode[0]->m_bRender = TRUE;
			portal->m_pNode[0]->Render( pd3dDevice, NULL );
		}

		if( portal->m_pNode[1] && !portal->m_pNode[1]->m_bRender )	
		{
			portal->m_pNode[1]->m_bRender = TRUE;
			f = portal->m_pNode[1]->m_pFaceList;
			portal->m_pNode[1]->Render( pd3dDevice, NULL );
		}

		for( int i = 0 ; i < portal->m_nVisCnt ; i++ )
		{
			if( !portal->m_visPortals[i]->m_pNode[0]->m_bRender )
			{
				portal->m_visPortals[i]->m_pNode[0]->m_bRender = TRUE;
				portal->m_visPortals[i]->m_pNode[0]->Render( pd3dDevice, NULL );
			}

			if( portal->m_visPortals[i]->m_pNode[1] && !portal->m_visPortals[i]->m_pNode[1]->m_bRender )
			{
				portal->m_visPortals[i]->m_pNode[1]->m_bRender = TRUE;
				portal->m_visPortals[i]->m_pNode[1]->Render( pd3dDevice, NULL );
			}
				
		}
	}
*/
	return TRUE;
}
void CBspManager::TryPVS()
{
	for( int i = 0 ; i < m_nPortalCnt ; i++ )
	{
		PortalFlow( m_ppPortals[i] );
	}

	for( i = 0 ; i < m_nPortalCnt ; i++ )
	{
		m_pBspRoot->InitRender();
		CBspNode::CPortal* portal = m_ppPortals[i];
		m_ppPortals[i]->m_nFaceCnt = 0;
		for( ; portal ; portal = portal->m_pNext[0] )
		{
			CFace* f = NULL;
			if( !portal->m_pNode[0]->m_bRender )
			{
				portal->m_pNode[0]->m_bRender = TRUE;
				for( f = portal->m_pNode[0]->m_pFaceList ; f ; f = f->m_pNext )
					m_ppPortals[i]->m_nFaceCnt++;
			}

			if( portal->m_pNode[1] && !portal->m_pNode[1]->m_bRender )	
			{
				portal->m_pNode[1]->m_bRender = TRUE;
				for( f = portal->m_pNode[1]->m_pFaceList ; f ; f = f->m_pNext )
					m_ppPortals[i]->m_nFaceCnt++;
			}
			for( int j = 0 ; j < portal->m_nVisCnt ; j++ )
			{
				if( !portal->m_visPortals[j]->m_pNode[0]->m_bRender )
				{
					portal->m_visPortals[j]->m_pNode[0]->m_bRender = TRUE;
					for( f = portal->m_visPortals[j]->m_pNode[0]->m_pFaceList; f ; f = f->m_pNext )
						m_ppPortals[i]->m_nFaceCnt++;
				}

				if( portal->m_visPortals[j]->m_pNode[1] && !portal->m_visPortals[j]->m_pNode[1]->m_bRender )
				{
					portal->m_visPortals[j]->m_pNode[1]->m_bRender = TRUE;
					for( f = portal->m_visPortals[j]->m_pNode[1]->m_pFaceList; f ; f = f->m_pNext )
						m_ppPortals[i]->m_nFaceCnt++;
				}
			}
		}
	}

	for( i = 0 ; i < m_nPortalCnt ; i++ )
	{
		m_pBspRoot->InitRender();
		CBspNode::CPortal* portal = m_ppPortals[i];
		portal->m_ppFaceList = new CFace*[portal->m_nFaceCnt];
		int fCount = 0 ;
		for( ; portal ; portal = portal->m_pNext[0] )
		{
			CFace* f = NULL;
			if( !portal->m_pNode[0]->m_bRender )
			{
				portal->m_pNode[0]->m_bRender = TRUE;
				for( f = portal->m_pNode[0]->m_pFaceList ; f ; f = f->m_pNext )
					m_ppPortals[i]->m_ppFaceList[fCount++] = f;
			}

			if( portal->m_pNode[1] && !portal->m_pNode[1]->m_bRender )	
			{
				portal->m_pNode[1]->m_bRender = TRUE;
				for( f = portal->m_pNode[1]->m_pFaceList ; f ; f = f->m_pNext )
					m_ppPortals[i]->m_ppFaceList[fCount++] = f;
			}
			for( int j = 0 ; j < portal->m_nVisCnt ; j++ )
			{
				if( !portal->m_visPortals[j]->m_pNode[0]->m_bRender )
				{
					portal->m_visPortals[j]->m_pNode[0]->m_bRender = TRUE;
					for( f = portal->m_visPortals[j]->m_pNode[0]->m_pFaceList; f ; f = f->m_pNext )
						m_ppPortals[i]->m_ppFaceList[fCount++] = f;
				}

				if( portal->m_visPortals[j]->m_pNode[1] && !portal->m_visPortals[j]->m_pNode[1]->m_bRender )
				{
					portal->m_visPortals[j]->m_pNode[1]->m_bRender = TRUE;
					for( f = portal->m_visPortals[j]->m_pNode[1]->m_pFaceList; f ; f = f->m_pNext )
						m_ppPortals[i]->m_ppFaceList[fCount++] = f;
				}
			}
		}
	}

}

void CBspManager::PortalFlow( CBspNode::CPortal* portal )
{
	PVSDATA pvs;
	int faceCnt = 0;

	CBspNode::CPortal* p = portal;
	
	pvs.source = portal->m_pWinding;
	portal->m_nFaceCnt += portal->m_pNode[0]->GetFaceCount();	//for Render 

	if( !portal->m_pNode[1] )
		return;

	portal->m_nFaceCnt += portal->m_pNode[1]->GetFaceCount();	//for Render 

	CBspNode::CPortal* p1 = portal->m_pNode[1]->m_pPortals;
	for( ; p1 ; p1 = p1->m_pNext[0] )
	{
		D3DXPLANE plane;
		D3DXPlaneFromPoints( &plane, &portal->m_pWinding->vPoint[0],
							&portal->m_pWinding->vPoint[1],
							&portal->m_pWinding->vPoint[2] );
		BSPVERTEX winding[8];
		for( int k = 0; k < p1->m_pWinding->n; k++ )
		{
			winding[k].pos = p1->m_pWinding->vPoint[k];
		}
		if( FACE_ON == Classify( &plane, winding, p1->m_pWinding->n ) )
			continue;
		
		if( !IsEqualWinding( portal->m_pWinding, p1->m_pWinding ) )
		{
			portal->m_visPortals[portal->m_nVisCnt++] = p1;

			portal->m_nFaceCnt += p1->m_pNode[0]->GetFaceCount();	//for Render 
			
			pvs.pass = p1->m_pWinding;
			if( !p1->m_pNode[1] )
				continue;

			portal->m_nFaceCnt += p1->m_pNode[1]->GetFaceCount();	//for Render 

			CBspNode::CPortal * p2 = p1->m_pNode[1]->m_pPortals;
			for( ; p2 ; p2 = p2->m_pNext[0] )
			{
				if( !IsEqualWinding( p1->m_pWinding, p2->m_pWinding ) )
				{
					RecursiveLeafFlow( &pvs, p2 , portal );
				}
			}
		}
	}
}

void CBspManager::RecursiveLeafFlow( PVSDATA* pvs, CBspNode::CPortal* target, CBspNode::CPortal* source )
{
	D3DXPLANE plane;
	D3DXPlaneFromPoints( &plane, &pvs->source->vPoint[0],
						&pvs->source->vPoint[1],
						&pvs->source->vPoint[2] );
	
	BSPVERTEX winding[8];
	for( int k = 0; k < pvs->pass->n; k++ )
	{
		winding[k].pos = pvs->pass->vPoint[k];
	}

	if( FACE_ON == Classify( &plane, winding, pvs->pass->n ) )
		return;

	PVSDATA pvsdata;
	pvsdata.pass = pvs->pass;
	pvsdata.source = pvs->source;
	CWinding * w = CopyWinding( target->m_pWinding ), * tmp = NULL;
	tmp = ClipToSeperators( pvsdata.source, pvsdata.pass, w, FALSE );
	if( tmp )
	{
		source->m_nFaceCnt += target->m_pNode[0]->GetFaceCount();

		if( target->m_pNode[1] )
			source->m_nFaceCnt += target->m_pNode[1]->GetFaceCount();

		source->m_visPortals[source->m_nVisCnt++] = target;

		pvsdata.source = pvsdata.pass;
		pvsdata.pass = tmp;
		CBspNode::CPortal* p = target->m_pNode[1]->m_pPortals;
		for( ; p ; p = p->m_pNext[0] )
		{
			if( !IsEqualWinding( target->m_pWinding, p->m_pWinding ) )
			{
				RecursiveLeafFlow( &pvsdata, p, source );
			}
		}
	}
	if( w )
		delete w;
}

CWinding* CBspManager::CopyWinding( CWinding* w )
{
	CWinding* neww = new CWinding();
	neww->n = w->n;
	for( int i = 0 ; i < w->n ; i++ )
		neww->vPoint[i] = w->vPoint[i];
	return neww;
}

BOOL CBspManager::IsEqualWinding( CWinding* w1, CWinding* w2 )
{
	if( w1->n != w2->n )
		return FALSE;
	
	for( int i = 0 ; i < w1->n ; i++ )
	{
		BOOL bCheck = FALSE;
		for( int k = 0 ; k < w2->n ; k++ )
		{
			int con = 0;
			if( fabs(w1->vPoint[i].x - w2->vPoint[k].x) > EPSILON )
				con++;
			if( fabs(w1->vPoint[i].y - w2->vPoint[k].y) > EPSILON )
				con++;
			if( fabs(w1->vPoint[i].z - w2->vPoint[k].z) > EPSILON )
				con++;

			if( !con )
				bCheck = TRUE;
		}
		if( !bCheck )
			return FALSE;
	}
	return TRUE;
}

CWinding * CBspManager::ClipToSeperators (CWinding *source, CWinding *pass, CWinding *target, BOOL flipclip)
{
	int			i, j, k, l;
	D3DXPLANE	plane;
	D3DXVECTOR3	v1, v2;
	float		d;
	float		length;
	int			counts[3];
	bool		fliptest;
	D3DXVECTOR3 vec3_origin = D3DXVECTOR3( 0, 0, 0 );

// check all combinations	
	for (i=0 ; i<source->n ; i++)
	{
		l = (i+1)%source->n;
		v1 = source->vPoint[l] - source->vPoint[i];

	// fing a vertex of pass that makes a plane that puts all of the
	// vertexes of pass on the front side and all of the vertexes of
	// source on the back side
		for (j=0 ; j<pass->n ; j++)
		{
			v2 = pass->vPoint[j] - source->vPoint[i];

			plane.a = v1.y*v2.z - v1.z*v2.y;
			plane.b = v1.z*v2.x - v1.x*v2.z;
			plane.c = v1.x*v2.y - v1.y*v2.x;
			
		// if points don't make a valid plane, skip it

			length = plane.a * plane.a + plane.b * plane.b + plane.c * plane.c;
			
			if (length < EPSILON)
				continue;

			length = 1/sqrt(length);
			
			plane.a *= length;
			plane.b *= length;
			plane.c *= length;

			D3DXVECTOR3 normal = D3DXVECTOR3( plane.a, plane.b, plane.c );

			plane.d = (-1)*D3DXVec3Dot( &pass->vPoint[j], &normal);

		//
		// find out which side of the generated seperating plane has the
		// source portal
		//
			fliptest = false;
			for (k=0 ; k<source->n ; k++)
			{
				if (k == i || k == l)
					continue;
				d = D3DXVec3Dot( &source->vPoint[k], &normal) + plane.d;
				if (d < -EPSILON)
				{	// source is on the negative side, so we want all
					// pass and target on the positive side
					fliptest = false;
					break;
				}
				else if (d > EPSILON)
				{	// source is on the positive side, so we want all
					// pass and target on the negative side
					fliptest = true;
					break;
				}
			}
			if (k == source->n)
				continue;		// planar with source portal

		//
		// flip the normal if the source portal is backwards
		//
			if (fliptest)
			{
				normal = vec3_origin - normal;
				plane.a = normal.x;
				plane.b = normal.y;
				plane.c = normal.z;
				plane.d = -plane.d;
			}
			
		//
		// if all of the pass portal points are now on the positive side,
		// this is the seperating plane
		//
			counts[0] = counts[1] = counts[2] = 0;
			for (k=0 ; k<pass->n ; k++)
			{
				if (k==j)
					continue;
				d = D3DXVec3Dot ( &pass->vPoint[k], &normal) + plane.d;
				if (d < -EPSILON)
					break;
				else if (d > EPSILON)
					counts[0]++;
				else
					counts[2]++;
			}
			if (k != pass->n)
				continue;	// points on negative side, not a seperating plane
				
			if (!counts[0])
			{
				continue;	// planar with seperating plane
			}
		
		//
		// flip the normal if we want the back side
		//
			if (flipclip)
			{
				normal = vec3_origin - normal;
				plane.a = normal.x;
				plane.b = normal.y;
				plane.c = normal.z;
				plane.d = -plane.d;
			}
			
		//
		// clip target by the seperating plane
		//
			CWinding* t = new CWinding();
			t->n = target->n;
			for( int i = 0 ; i < t->n ; i++ )
			{
				t->vPoint[i] = target->vPoint[i];
			}
			
			t = ClipWinding (t, &plane, false);
			if (!t)
			{
				return NULL;	// target is not visible
			}
			delete t;
		}
	}
	
	return target;
}

void CBspManager::CreateHeadPortals( CBspNode* node )
{
	CBspNode::CPortal *portal[6];
	D3DXPLANE plane;

	m_outsideNode.m_bIsLeaf = TRUE;
	m_outsideNode.m_bIsSolid = TRUE;
	m_outsideNode.m_pPortals = NULL;
/*
	for( int i = 0; i < 6 ; i++ )
	{
		portal[i] = new CBspNode::CPortal();
	}
	portal[0]->m_plane = D3DXPLANE( 1, 0, 0, 100 );
	portal[1]->m_plane = D3DXPLANE( 0, 0, 1, 100 );
	portal[2]->m_plane = D3DXPLANE( -1, 0, 0, 100 );
	portal[3]->m_plane = D3DXPLANE( 0, 0, -1, 100 );
	portal[4]->m_plane = D3DXPLANE( 0, -1, 0, 100 );
	portal[5]->m_plane = D3DXPLANE( 0, 1, 0, 100 );

	for( i = 0 ; i < 6 ; i++ )
	{
		portal[i]->m_pWinding = BaseWindingForPlane( &portal[i]->m_plane );
		portal[i]->AddPortalToNodes( node, &m_outsideNode );
	}
*/	

//near front side (o)
	portal[0] = new CBspNode::CPortal();
	portal[0]->m_pWinding = new CWinding();
	portal[0]->m_pWinding->vPoint[0] = D3DXVECTOR3( m_vMin.x - SIDE_SPACE, m_vMax.y + SIDE_SPACE, m_vMin.z - SIDE_SPACE );
	portal[0]->m_pWinding->vPoint[1] = D3DXVECTOR3( m_vMin.x - SIDE_SPACE, m_vMin.y - SIDE_SPACE, m_vMin.z - SIDE_SPACE );
	portal[0]->m_pWinding->vPoint[2] = D3DXVECTOR3( m_vMax.x + SIDE_SPACE, m_vMin.y - SIDE_SPACE, m_vMin.z - SIDE_SPACE );
	portal[0]->m_pWinding->vPoint[3] = D3DXVECTOR3( m_vMax.x + SIDE_SPACE, m_vMax.y + SIDE_SPACE, m_vMin.z - SIDE_SPACE );
	portal[0]->m_pWinding->n = 4;
	D3DXPlaneFromPoints( &plane, &portal[0]->m_pWinding->vPoint[0], &portal[0]->m_pWinding->vPoint[1], &portal[0]->m_pWinding->vPoint[2]);
	portal[0]->m_plane = plane;
	portal[0]->AddPortalToNodes( node, &m_outsideNode );

//far front side (o)
	portal[1] = new CBspNode::CPortal();
	portal[1]->m_pWinding = new CWinding();
	portal[1]->m_pWinding->vPoint[0] = D3DXVECTOR3( m_vMin.x - SIDE_SPACE, m_vMin.y - SIDE_SPACE, m_vMax.z + SIDE_SPACE );
	portal[1]->m_pWinding->vPoint[1] = D3DXVECTOR3( m_vMin.x - SIDE_SPACE, m_vMax.y + SIDE_SPACE, m_vMax.z + SIDE_SPACE );
	portal[1]->m_pWinding->vPoint[2] = D3DXVECTOR3( m_vMax.x + SIDE_SPACE, m_vMax.y + SIDE_SPACE, m_vMax.z + SIDE_SPACE );
	portal[1]->m_pWinding->vPoint[3] = D3DXVECTOR3( m_vMax.x + SIDE_SPACE, m_vMin.y - SIDE_SPACE, m_vMax.z + SIDE_SPACE );
	portal[1]->m_pWinding->n = 4;
	D3DXPlaneFromPoints( &plane, &portal[1]->m_pWinding->vPoint[0], &portal[1]->m_pWinding->vPoint[1],&portal[1]->m_pWinding->vPoint[2]);
	portal[1]->m_plane = plane;
	portal[1]->AddPortalToNodes( node, &m_outsideNode );

//left side(o)
	portal[2] = new CBspNode::CPortal();
	portal[2]->m_pWinding = new CWinding();
	portal[2]->m_pWinding->vPoint[0] = D3DXVECTOR3( m_vMin.x - SIDE_SPACE, m_vMin.y - SIDE_SPACE, m_vMin.z - SIDE_SPACE );
	portal[2]->m_pWinding->vPoint[1] = D3DXVECTOR3( m_vMin.x - SIDE_SPACE, m_vMax.y + SIDE_SPACE, m_vMin.z - SIDE_SPACE );
	portal[2]->m_pWinding->vPoint[2] = D3DXVECTOR3( m_vMin.x - SIDE_SPACE, m_vMax.y + SIDE_SPACE, m_vMax.z + SIDE_SPACE );
	portal[2]->m_pWinding->vPoint[3] = D3DXVECTOR3( m_vMin.x - SIDE_SPACE, m_vMin.y - SIDE_SPACE, m_vMax.z + SIDE_SPACE );
	portal[2]->m_pWinding->n = 4;
	D3DXPlaneFromPoints( &plane, &portal[2]->m_pWinding->vPoint[0], &portal[2]->m_pWinding->vPoint[1],&portal[2]->m_pWinding->vPoint[2]);
	portal[2]->m_plane = plane;
	portal[2]->AddPortalToNodes( node, &m_outsideNode );

//right side(o)
	portal[3] = new CBspNode::CPortal();
	portal[3]->m_pWinding = new CWinding();
	portal[3]->m_pWinding->vPoint[0] = D3DXVECTOR3( m_vMax.x + SIDE_SPACE, m_vMin.y - SIDE_SPACE, m_vMin.z - SIDE_SPACE );
	portal[3]->m_pWinding->vPoint[1] = D3DXVECTOR3( m_vMax.x + SIDE_SPACE, m_vMin.y - SIDE_SPACE, m_vMax.z + SIDE_SPACE );
	portal[3]->m_pWinding->vPoint[2] = D3DXVECTOR3( m_vMax.x + SIDE_SPACE, m_vMax.y + SIDE_SPACE, m_vMax.z + SIDE_SPACE );
	portal[3]->m_pWinding->vPoint[3] = D3DXVECTOR3( m_vMax.x + SIDE_SPACE, m_vMax.y + SIDE_SPACE, m_vMin.z - SIDE_SPACE );
	portal[3]->m_pWinding->n = 4;
	D3DXPlaneFromPoints( &plane, &portal[3]->m_pWinding->vPoint[0], &portal[3]->m_pWinding->vPoint[1],&portal[3]->m_pWinding->vPoint[2]);
	portal[3]->m_plane = plane;
	portal[3]->AddPortalToNodes( node, &m_outsideNode );

//up side(o)
	portal[4] = new CBspNode::CPortal();
	portal[4]->m_pWinding = new CWinding();
	portal[4]->m_pWinding->vPoint[0] = D3DXVECTOR3( m_vMax.x + SIDE_SPACE, m_vMax.y + SIDE_SPACE, m_vMin.z - SIDE_SPACE );
	portal[4]->m_pWinding->vPoint[1] = D3DXVECTOR3( m_vMax.x + SIDE_SPACE, m_vMax.y + SIDE_SPACE, m_vMax.z + SIDE_SPACE );
	portal[4]->m_pWinding->vPoint[2] = D3DXVECTOR3( m_vMin.x - SIDE_SPACE, m_vMax.y + SIDE_SPACE, m_vMax.z + SIDE_SPACE );
	portal[4]->m_pWinding->vPoint[3] = D3DXVECTOR3( m_vMin.x - SIDE_SPACE, m_vMax.y + SIDE_SPACE, m_vMin.z - SIDE_SPACE );
	portal[4]->m_pWinding->n = 4;
	D3DXPlaneFromPoints( &plane, &portal[4]->m_pWinding->vPoint[0], &portal[4]->m_pWinding->vPoint[1],&portal[4]->m_pWinding->vPoint[2]);
	portal[4]->m_plane = plane;
	portal[4]->AddPortalToNodes( node, &m_outsideNode );

//down side(o)
	portal[5] = new CBspNode::CPortal();
	portal[5]->m_pWinding = new CWinding();
	portal[5]->m_pWinding->vPoint[0] = D3DXVECTOR3( m_vMin.x - SIDE_SPACE, m_vMin.y - SIDE_SPACE, m_vMin.z - SIDE_SPACE );
	portal[5]->m_pWinding->vPoint[1] = D3DXVECTOR3( m_vMin.x - SIDE_SPACE, m_vMin.y - SIDE_SPACE, m_vMax.z + SIDE_SPACE );
	portal[5]->m_pWinding->vPoint[2] = D3DXVECTOR3( m_vMax.x + SIDE_SPACE, m_vMin.y - SIDE_SPACE, m_vMax.z + SIDE_SPACE );
	portal[5]->m_pWinding->vPoint[3] = D3DXVECTOR3( m_vMax.x + SIDE_SPACE, m_vMin.y - SIDE_SPACE, m_vMin.z - SIDE_SPACE );
	portal[5]->m_pWinding->n = 4;
	D3DXPlaneFromPoints( &plane, &portal[5]->m_pWinding->vPoint[0], &portal[5]->m_pWinding->vPoint[1],&portal[5]->m_pWinding->vPoint[2]);
	portal[5]->m_plane = plane;
	portal[5]->AddPortalToNodes( node, &m_outsideNode );
}

void CBspManager::VectorMA (D3DXVECTOR3 & va, double scale, D3DXVECTOR3 & vb, D3DXVECTOR3 & vc)
{
	vc.x = va.x + scale*vb.x;
	vc.y = va.y + scale*vb.y;
	vc.z = va.z + scale*vb.z;
}
void CBspManager::VectorScale (D3DXVECTOR3 & v, double scale, D3DXVECTOR3 & out)
{
	out.x = v.x * scale;
	out.y = v.y * scale;
	out.z = v.z * scale;
}

void CBspManager::PortalizeWorld()
{
	CreateHeadPortals( m_pBspRoot );
	CutNodePortals( m_pBspRoot );
	RemovePortalsLinkedSolidLeaf( m_pBspRoot );
}

void CBspManager::RemovePortalsLinkedSolidLeaf( CBspNode * node )
{
	CBspNode::CPortal	*p, *nextp;
	if( !node->m_bIsLeaf )
	{
		RemovePortalsLinkedSolidLeaf ( node->m_pFront );
		RemovePortalsLinkedSolidLeaf ( node->m_pBack );	
	}
	
	for (p=node->m_pPortals ; p ; p=nextp)
	{
		if (p->m_pNode[0] == node)
			nextp = p->m_pNext[0];
		else
			nextp = p->m_pNext[1];

		if( p->m_pNode[1]->m_bIsSolid || p->m_pNode[0]->m_bIsSolid )
		{
			p->m_bRender = FALSE;
		}
	}
}

void CBspManager::FreeAllPortals (CBspNode *node)
{
	CBspNode::CPortal	*p, *nextp, *prev = NULL;
	
	if ( !node->m_bIsLeaf )
	{
		FreeAllPortals ( node->m_pFront );
		FreeAllPortals ( node->m_pBack );
	}
	
	for (p=node->m_pPortals ; p ; p=nextp)
	{
		if (p->m_pNode[0] == node)
			nextp = p->m_pNext[0];
		else
			nextp = p->m_pNext[1];

		p->RemovePortalFromNode ( p->m_pNode[0]);
		p->RemovePortalFromNode ( p->m_pNode[1]);
		delete p->m_pWinding;
		p->m_pWinding = NULL;
		delete p;
	}
	node->m_pPortals = NULL;
}

BOOL CBspManager::RenderPortal( LPDIRECT3DDEVICE8 pd3dDevice, CD3DFont * pFont )
{
/*
	pd3dDevice->SetVertexShader( D3DFVF_BSPVERTEX );
	pd3dDevice->SetStreamSource( 0, NULL, 0 );
	pd3dDevice->SetIndices( NULL, 0 );
	pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE );
	
	for( int i = 7; i < m_nPortalCnt ; i++ )
	{
		if( pFont )
		{
			D3DXMATRIX	mW, mV, mP, mO;
			pd3dDevice->GetTransform( D3DTS_WORLD, &mW );
			pd3dDevice->GetTransform( D3DTS_VIEW, &mV );
			pd3dDevice->GetTransform( D3DTS_PROJECTION, &mP );
			mO = mW * mV * mP;
			float x, y, z;
			x = ( m_ppPortals[i]->m_pWinding->vPoint[0].x + m_ppPortals[i]->m_pWinding->vPoint[1].x
				+ m_ppPortals[i]->m_pWinding->vPoint[2].x + m_ppPortals[i]->m_pWinding->vPoint[3].x ) / 4;
			y = ( m_ppPortals[i]->m_pWinding->vPoint[0].y + m_ppPortals[i]->m_pWinding->vPoint[1].y
				+ m_ppPortals[i]->m_pWinding->vPoint[2].y + m_ppPortals[i]->m_pWinding->vPoint[3].y ) / 4;
			z = ( m_ppPortals[i]->m_pWinding->vPoint[0].z + m_ppPortals[i]->m_pWinding->vPoint[1].z
				+ m_ppPortals[i]->m_pWinding->vPoint[2].z + m_ppPortals[i]->m_pWinding->vPoint[3].z ) / 4;

			D3DXVECTOR3 vI = D3DXVECTOR3( x, y, z );
			D3DXVECTOR3 vO;
			D3DXVec3TransformCoord( &vO, &vI, &mO );
			char	str[16];
			wsprintf( str, "( %d )", i );
			pFont->DrawText(400.0f * (vO.x+1.0f), 600 - 300.0f * (vO.y+1.0f), 0xff000000, str );
		}
		else
			pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_ppPortals[i]->m_pWinding->vPoint ,sizeof( D3DXVECTOR3 ));
	}
*/

	typedef struct tagVTX
	{
		D3DXVECTOR3	p;
		DWORD		diffuse;
	} VTX;

	pd3dDevice->SetVertexShader( D3DFVF_XYZ|D3DFVF_DIFFUSE );
	pd3dDevice->SetStreamSource( 0, NULL, 0 );
	pd3dDevice->SetIndices( NULL, 0 );
	pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE);
	pd3dDevice->SetRenderState( D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	pd3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_ONE );
	pd3dDevice->SetTexture( 0, NULL );
	pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

	for( int i = 0 ; i < m_nPortalCnt ; i++ )
	{
		VTX		vtx[8];
		for( int j = 0 ; j < m_ppPortals[i]->m_pWinding->n ; j++ )
		{
			vtx[j].p = m_ppPortals[i]->m_pWinding->vPoint[j];
			vtx[j].diffuse = 0x40ff0000;
		}
		pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, vtx, sizeof( VTX ) );
	}

    pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE );
	return TRUE;
}


CWinding* CBspManager::BaseWindingForPlane( D3DXPLANE *p )
{
	int				i, x;
	float			max, v;
	D3DXVECTOR3		org, vright, vup, normal;
	CWinding		*w;

	vup = D3DXVECTOR3( 0, 0, 0 );
	normal = D3DXVECTOR3( p->a, p->b, p->c );
// find the major axis
	
	max = -BSP_BOGUS;
	x = -1;

	v = fabs( p->a );
	if (v > max)
	{
		x = 0;
		max = v;
	}

	v = fabs( p->b );
	if( v > max )
	{
		x = 1;
		max = v;
	}

	v = fabs( p->c );
	if( v > max )
	{
		x = 2;
		max = v;
	}

	switch (x)
	{
	case 0:
	case 1:
		vup.z = 1;
		break;		
	case 2:
		vup.x = 1;
		break;		
	}

	v = D3DXVec3Dot ( &vup, &normal);
	VectorMA (vup, -v, normal, vup);
	D3DXVec3Normalize( &vup, &vup );
		
	VectorScale ( normal, -(p->d), org);
	
	D3DXVec3Cross( &vright, &normal, &vup );
	
	VectorScale (vup, 8192, vup);
	VectorScale (vright, 8192, vright);

// project a really big	axis aligned box onto the plane
	w = new CWinding();
	
//	VectorSubtract (org, vright, w->points[0]);
	w->vPoint[0] = org - vright;
//	VectorAdd (w->points[0], vup, w->points[0]);
	w->vPoint[0] = w->vPoint[0] + vup;
	
//	VectorAdd (org, vright, w->points[1]);
	w->vPoint[1] = org + vright;
//	VectorAdd (w->points[1], vup, w->points[1]);
	w->vPoint[1] = w->vPoint[1] + vup;
	
//	VectorAdd (org, vright, w->points[2]);
	w->vPoint[2] = org + vright;
//	VectorSubtract (w->points[2], vup, w->points[2]);
	w->vPoint[2] = w->vPoint[2] - vup;
	
//	VectorSubtract (org, vright, w->points[3]);
	w->vPoint[3] = org - vright;
//	VectorSubtract (w->points[3], vup, w->points[3]);
	w->vPoint[3] = w->vPoint[3] - vup;
	
	w->n = 4;
	
	return w;
}

void CBspManager::CutNodePortals( CBspNode *node )
{
	D3DXPLANE			* plane, clipplane;
	CBspNode			* f = NULL, *b = NULL, *other_node = NULL;
	CBspNode::CPortal	* p = NULL, *new_portal = NULL, *next_portal = NULL;
	CWinding			* w = NULL, *frontwinding = NULL, *backwinding = NULL;
	int					side;

	if( node->m_bIsLeaf )
		return;

	plane = &node->m_plane;

	f = node->m_pFront;
	b = node->m_pBack;

	new_portal = new CBspNode::CPortal();
	new_portal->m_plane = node->m_plane;
	
	w = BaseWindingForPlane( &new_portal->m_plane );
	side = 0;

	D3DXVECTOR3 origin = D3DXVECTOR3( 0, 0, 0 );

	for( p = node->m_pPortals ; p ; p = p->m_pNext[side] )
	{
		clipplane = p->m_plane;
		
		//p�� front_node�� node�� ���ٸ� 
		if (p->m_pNode[0] == node)
			side = 0;

		//p�� back_node�� node�� ������ plane�� ������ �ٲٰ� side�� 1(back)���� ������..
		//������ partition plane�� back�� ����Ҷ� ������ ���..
		else if (p->m_pNode[1] == node)
		{
			D3DXVECTOR3 normal = D3DXVECTOR3( clipplane.a, clipplane.b, clipplane.c );
			clipplane.d = -clipplane.d;

			normal = origin - normal;
			clipplane.a = normal.x;
			clipplane.b = normal.y;
			clipplane.c = normal.z;
			
			side = 1;
		}
		else
			;//error

		w = ClipWinding (w, &clipplane, true);
		if (!w)
		{
			printf ("WARNING: CutNodePortals_r:new portal was clipped away\n");
			break;
		}
	}

	if (w)
	{
	// if the plane was not clipped on all sides, there was an error
		new_portal->m_pWinding = w;	
		new_portal->AddPortalToNodes ( f, b );
	}

//
// partition the portals
//
	for (p = node->m_pPortals ; p ; p = next_portal)	
	{
		if (p->m_pNode[0] == node)
			side = 0;
		else if (p->m_pNode[1] == node)
			side = 1;
		else
			;//error
		next_portal = p->m_pNext[side];

		other_node = p->m_pNode[!side];
		p->RemovePortalFromNode( p->m_pNode[0] );
		p->RemovePortalFromNode( p->m_pNode[1] );

//
// cut the portal into two portals, one on each side of the cut plane
//
		DivideWinding (p->m_pWinding, plane, &frontwinding, &backwinding);
		
		if (!frontwinding)
		{
			if (side == 0)
				p->AddPortalToNodes ( b, other_node);
			else
				p->AddPortalToNodes ( other_node, b);
			continue;
		}
		if (!backwinding)
		{
			if (side == 0)
				p->AddPortalToNodes ( f, other_node);
			else
				p->AddPortalToNodes ( other_node, f);
			continue;
		}
		
	// the winding is split
		new_portal = new CBspNode::CPortal ();
		*new_portal = *p;
		new_portal->m_pWinding = backwinding;
		delete p->m_pWinding;
		p->m_pWinding = frontwinding;

		if (side == 0)
		{
			p->AddPortalToNodes ( f, other_node );
			new_portal->AddPortalToNodes ( b, other_node );
		}
		else
		{
			p->AddPortalToNodes ( other_node, f );
			new_portal->AddPortalToNodes ( other_node, b );
		}
	}
	
	CutNodePortals (f);	
	CutNodePortals (b);
}

CWinding * CBspManager::ClipWinding (CWinding *in, D3DXPLANE *split, boolean keepon)
{
	float		dists[MAX_POINTS_ON_WINDING];
	int			sides[MAX_POINTS_ON_WINDING];
	int			counts[3];
	float		dot;
	int			i, j;
	D3DXVECTOR3	p1, p2;
	D3DXVECTOR3	mid;
	CWinding	*neww = NULL;
	int			maxpts;
	
	counts[0] = counts[1] = counts[2] = 0;

// determine sides for each point
	for (i=0 ; i<in->n ; i++)
	{
		D3DXVECTOR3 normal = D3DXVECTOR3( split->a, split->b, split->c );
		dot = D3DXVec3Dot( &in->vPoint[i], &normal );
		dot = dot + split->d;
		dists[i] = dot;
		if (dot > EPSILON)
			sides[i] = SIDE_FRONT;
		else if (dot < -EPSILON)
			sides[i] = SIDE_BACK;
		else
			sides[i] = SIDE_ON;
	
		counts[sides[i]]++;
	}
	sides[i] = sides[0];
	dists[i] = dists[0];
	
	if (keepon && !counts[0] && !counts[1])
		return in;
		
	if (!counts[0])
	{
		delete in;
		return NULL;
	}
	if (!counts[1])
		return in;
	
	maxpts = in->n+4;	// can't use counts[0]+2 because
								// of fp grouping errors
	neww = new CWinding();
		
	for (i=0 ; i<in->n ; i++)
	{
		p1 = in->vPoint[i];
		
		if (sides[i] == SIDE_ON)
		{
			VectorCopy (p1, neww->vPoint[neww->n]);
			neww->n++;
			continue;
		}
	
		if (sides[i] == SIDE_FRONT)
		{
			VectorCopy (p1, neww->vPoint[neww->n]);
			neww->n++;
		}
		
		if (sides[i+1] == SIDE_ON || sides[i+1] == sides[i])
			continue;
			
		// generate a split point
		p2 = in->vPoint[(i+1)%in->n];
		
		dot = dists[i] / (dists[i]-dists[i+1]);

		// avoid round off error when possible
		if (split->a == 1)
			mid.x = -split->d;
		else if (split->a == -1)
			mid.x = split->d;
		else
			mid.x = p1.x + dot*( p2.x - p1.x );

		if (split->b == 1)
			mid.y = -split->d;
		else if (split->b == -1)
			mid.y = split->d;
		else
			mid.y = p1.y + dot*( p2.y - p1.y );

		if (split->c == 1)
			mid.z = -split->d;
		else if (split->c == -1)
			mid.z = split->d;
		else
			mid.z = p1.z + dot*( p2.z - p1.z ) ;
			
		VectorCopy (mid, neww->vPoint[neww->n]);
		neww->n++;
	}
	
	if (neww->n > maxpts)
		;	//error

// free the original winding
	delete in;
	
	return neww;
}

void CBspManager::DivideWinding (CWinding *in, D3DXPLANE *split, CWinding **front, CWinding **back)
{
	float		dists[MAX_POINTS_ON_WINDING];
	int			sides[MAX_POINTS_ON_WINDING];
	int			counts[3];
	float		dot;
	int			i, j;
	D3DXVECTOR3	p1, p2;
	D3DXVECTOR3	mid;
	CWinding	*f, *b;
	int			maxpts;
	
	counts[0] = counts[1] = counts[2] = 0;

// determine sides for each point
	for (i=0 ; i<in->n ; i++)
	{
		D3DXVECTOR3 normal = D3DXVECTOR3( split->a, split->b, split->c );
		dot = D3DXVec3Dot( &in->vPoint[i], &normal );
		dot = dot + split->d;
		dists[i] = dot;
		if (dot > EPSILON)
			sides[i] = SIDE_FRONT;
		else if (dot < -EPSILON)
			sides[i] = SIDE_BACK;
		else
		{
			sides[i] = SIDE_ON;
		}
		counts[sides[i]]++;
	}
	sides[i] = sides[0];
	dists[i] = dists[0];
	
	*front = *back = NULL;

	if (!counts[0])
	{
		*back = in;
		return;
	}
	if (!counts[1])
	{
		*front = in;
		return;
	}

	maxpts = in->n+4;	// can't use counts[0]+2 because
								// of fp grouping errors

	*front = f = new CWinding();
	*back = b = new CWinding();
		
	for (i=0 ; i<in->n ; i++)
	{
		p1 = in->vPoint[i];
		
		if (sides[i] == SIDE_ON)
		{
			VectorCopy (p1, f->vPoint[f->n]);
			f->n++;
			VectorCopy (p1, b->vPoint[b->n]);
			b->n++;
			continue;
		}
	
		if (sides[i] == SIDE_FRONT)
		{
			VectorCopy (p1, f->vPoint[f->n]);
			f->n++;
		}
		if (sides[i] == SIDE_BACK)
		{
			VectorCopy (p1, b->vPoint[b->n]);
			b->n++;
		}

		if (sides[i+1] == SIDE_ON || sides[i+1] == sides[i])
			continue;
			
	// generate a split point
		p2 = in->vPoint[(i+1)%in->n];
		
		dot = dists[i] / (dists[i]-dists[i+1]);

	// avoid round off error when possible
		if (split->a == 1)
			mid.x = -split->d;
		else if (split->a == -1)
			mid.x = split->d;
		else
			mid.x = p1.x + dot*(p2.x - p1.x);

		if (split->b == 1)
			mid.y = -split->d;
		else if (split->b == -1)
			mid.y = split->d;
		else
			mid.y = p1.y + dot*(p2.y - p1.y);

		if (split->c == 1)
			mid.z = -split->d;
		else if (split->c == -1)
			mid.z = split->d;
		else
			mid.z = p1.z + dot*(p2.z - p1.z);

		
			
		VectorCopy (mid, f->vPoint[f->n]);
		f->n++;
		VectorCopy (mid, b->vPoint[b->n]);
		b->n++;
	}
	
	if (f->n > maxpts || b->n > maxpts)
		;	//error

}

void CBspManager::ClearOutsideFace(  )
{
	CheckInside( m_pBspRoot );
}

void CBspManager::CheckInside( CBspNode * node )
{
	CBspNode::CPortal	*p, *nextp, *prev = NULL;
	
	if ( !node->m_bIsLeaf )
	{
		CheckInside ( node->m_pFront );
		CheckInside ( node->m_pBack );
	}
	
	for (p=node->m_pPortals ; p ; p=nextp)
	{
		if (p->m_pNode[0] == node)
			nextp = p->m_pNext[0];
		else
			nextp = p->m_pNext[1];
		
		if( p->m_bRender )
		{
			CFace * curr = NULL, * next = NULL, * copy = NULL;
			for( curr = p->m_pNode[0]->m_pFaceList ; curr ; curr = next )
			{
				next = curr->m_pNext;
				if( !curr->m_bInside )
				{
					curr->m_bInside = TRUE;
					copy = CFace::CreateFace();
					CBrush::FaceCopy( curr, copy );
					copy->m_nPlane = curr->m_nPlane;
					
					copy->m_pNext = m_pNewFaceRoot;
					m_pNewFaceRoot = copy;
				}
			}
			for( curr = p->m_pNode[1]->m_pFaceList ; curr ; curr = next )
			{
				next = curr->m_pNext;
				if( !curr->m_bInside )
				{
					curr->m_bInside = TRUE;
					copy = CFace::CreateFace();
					CBrush::FaceCopy( curr, copy );
					copy->m_nPlane = curr->m_nPlane;
					
					copy->m_pNext = m_pNewFaceRoot;
					m_pNewFaceRoot = copy;
				}
			}
		}
	}
}

void CBspManager::SetThingInfo( FILE* fp, CThing* &pThing )
{
	char lpszFormer[STR_MAX], lpszOther[STR_MAX];
	GetToken( fp, lpszFormer );
	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		if(!strcmp(lpszOther, "EOF"))
			break;
		if(!strcmp(lpszFormer, "OBJECTCOUNT"))
		{
			pThing = new CThing();
			break;
		}
	}
}

void CBspManager::SetThingVertices( FILE* fp, CThing* &pThing )
{
	char lpszFormer[STR_MAX], lpszOther[STR_MAX];
	int index = 0, count = 0;
	float x, y, z;
	GetToken( fp, lpszFormer );
	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		if(!strcmp(lpszOther, "EOF"))
			break;
		
		else if(!strcmp(lpszFormer, "NAME"))
		{
			
		}
		else if(!strcmp(lpszFormer, "COUNT"))
		{
			pThing->m_nVertexCount = atoi(lpszOther);
			pThing->m_pVertex = new BSPVERTEX[pThing->m_nVertexCount];
		}
		else if( pThing->m_nVertexCount > 0 )
		{
			//GetVertex�� yz��ǥ�� �ٲ���
			GetVertex(lpszOther, &x, &y, &z);
			pThing->m_pVertex[index].pos.x = x;
			pThing->m_pVertex[index].pos.y = y;
			pThing->m_pVertex[index].pos.z = z;
			index++;
		}
	}
}

void CBspManager::SetThingFaceIndex( FILE* fp, CThing* &pThing )
{
	char lpszFormer[STR_MAX], lpszOther[STR_MAX];
	int num = 0; 
	WORD first=0, second=0, third=0;

	GetToken( fp, lpszFormer );
	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		if(!strcmp(lpszOther, "EOF"))
			break;
	
		else if(!strcmp(lpszFormer, "NAME"))
		{
			num = 0;
		}
		else if(!strcmp(lpszFormer, "COUNT"))
		{
			pThing->m_nFaceCount = atoi(lpszOther);
			pThing->m_pTriangleIndex = new TRIANGLEINDEX[pThing->m_nFaceCount];
		}
		else if(pThing->m_nFaceCount > 0)
		{
			//GetIndex���� first�� third�� ���� �ٲ���.
			GetIndex(lpszOther, &first, &second, &third);
			pThing->m_pTriangleIndex[num]._0 = first;
			pThing->m_pTriangleIndex[num]._1 = second;
			pThing->m_pTriangleIndex[num]._2 = third;
			num++;
		}
	}
}

void CBspManager::SetThingMaterial( FILE* fp, CThing* &pThing )
{
	char lpszFormer[STR_MAX], lpszOther[STR_MAX];
	int num = 0;
	GetToken( fp, lpszFormer );
	if( strcmp( lpszFormer, "MATERIAL") )
		return;

	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		if(!strcmp(lpszOther, "EOF"))
			break;
		else if(!strcmp(lpszFormer, "TEXTURE"))
		{
			num++;
		}
	}

	if( num <= 0 )
		return;

	pThing->m_nTexCnt = num;

	pThing->m_pTXData = new TEXTUREDATA[num];
	num = 0;

	fseek( fp, 0, SEEK_SET );

	GetToken( fp, lpszFormer );
	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		if(!strcmp(lpszOther, "EOF"))
			break;
		else if(!strcmp(lpszFormer, "TEXTURE"))
		{
			strcpy( pThing->m_pTXData[num++].name, lpszOther );
		}
	}
}

void CBspManager::SetThingTXVertices( FILE* fp, CThing* &pThing )
{
	char lpszFormer[STR_MAX], lpszOther[STR_MAX];
	int num = 0;
	float x, y, z;
	GetToken( fp, lpszFormer );
	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		if(!strcmp(lpszOther, "EOF"))
			break;
		else if(!strcmp(lpszFormer, "NAME"))
			;
		else if(!strcmp(lpszFormer, "COUNT"))
		{
			pThing->m_nTCount = atoi(lpszOther);
			pThing->m_pTVtx = new D3DXVECTOR3[pThing->m_nTCount];
			num = 0;
		}
		else if(pThing->m_nTCount > 0)
		{
			GetVertex(lpszOther, &x, &y, &z);
			pThing->m_pTVtx[num].x = x;
			pThing->m_pTVtx[num].y = y;
			//max������ v�� �ö���鼭 �����ؼ� 1�̵ǹǷ�
			//D3D�� v�� �������鼭 �����ؼ� 1����
			pThing->m_pTVtx[num].z = 1.f - z;
			num++;
		}
	}
}

void CBspManager::SetThingTXIndex( FILE* fp, CThing* &pThing )
{
	char lpszFormer[STR_MAX], lpszOther[STR_MAX];
	int num = 0;
	WORD first, second, third;

	GetToken( fp, lpszFormer );

	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		if(!strcmp(lpszOther, "EOF"))
			break;
		else if(!strcmp(lpszFormer, "NAME"))
			;
		else if(!strcmp(lpszFormer, "COUNT"))
		{
			pThing->m_nTFCount = atoi(lpszOther);
			pThing->m_pTIndex = new TRIANGLEINDEX[pThing->m_nTFCount];
			num = 0;
		}
		else if(pThing->m_nTFCount > 0)
		{
			GetIndex(lpszOther, &first, &second, &third);
			pThing->m_pTIndex[num]._0 = first;
			pThing->m_pTIndex[num]._1 = second;
			pThing->m_pTIndex[num++]._2 = third;
		}

	}
}

void CBspManager::SetThingTXName( FILE* fp, CThing* &pThing )
{
/*
	char lpszFormer[STR_MAX], lpszOther[STR_MAX];
	int num = 0;
	float x, y, z;
	GetToken( fp, lpszFormer );
	while(1)
	{
		GetFormerNOther(fp, lpszFormer, lpszOther);
		if(!strcmp(lpszOther, "EOF"))
			break;
		else if(!strcmp(lpszFormer, "NAME"))
			;
		else if(!strcmp(lpszFormer, "TEXTURE"))
		{
			if( m_pStaticThing )
			{
				m_pStaticThing->m_nTexture = m_pStaticThing->GetTextureIndex( lpszOther );
			}
		}
	}
*/
}

void CBspManager::LoadThings( LPDIRECT3DDEVICE8 pd3dDevice )
{
	char tmpFileName[STR_MAX];
	char* szFileName = "things\\thing_light";
	FILE* fp;
	//Thing ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".nfo");
		fp = fopen(tmpFileName, "r");
		SetThingInfo( fp, m_pStaticThing );
		fclose( fp );

	//VERTEX ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".vtx");
		fp = fopen(tmpFileName, "r");
		SetThingVertices( fp, m_pStaticThing );
		fclose( fp );
		
	//FACE INDEX ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".idx");
		fp = fopen(tmpFileName, "r");
		SetThingFaceIndex( fp, m_pStaticThing );
		fclose( fp );
		
	//MATERIAL ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".mat");
		fp = fopen(tmpFileName, "r");
		SetThingMaterial( fp, m_pStaticThing );
		fclose( fp );

	//TEXTURE VERTEX����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".vtt");
		fp = fopen(tmpFileName, "r");
		SetThingTXVertices( fp, m_pStaticThing );
		fclose( fp );

	//TVERTEX INDEX ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".idt");
		fp = fopen(tmpFileName, "r");
		SetThingTXIndex( fp, m_pStaticThing );
		fclose( fp );
/*
	//TEXTURE NAME ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".txn");
		fp = fopen(tmpFileName, "r");
		SetThingTXName( fp, m_pStaticThing );
		fclose( fp );
*/
	m_pStaticThing->InitThing();
	D3DXCreateTextureFromFile( pd3dDevice, m_pStaticThing->m_pTXData->name, &m_pStaticThing->m_pTXData->texture );

	szFileName = "things\\dynamicthing";
	//Thing ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".nfo");
		fp = fopen(tmpFileName, "r");
		SetThingInfo( fp, m_pDynamicThing );
		fclose( fp );

	//VERTEX ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".vtx");
		fp = fopen(tmpFileName, "r");
		SetThingVertices( fp, m_pDynamicThing );
		fclose( fp );
		
	//FACE INDEX ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".idx");
		fp = fopen(tmpFileName, "r");
		SetThingFaceIndex( fp, m_pDynamicThing );
		fclose( fp );
		
	//MATERIAL ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".mat");
		fp = fopen(tmpFileName, "r");
		SetThingMaterial( fp, m_pDynamicThing );
		fclose( fp );

	//TEXTURE VERTEX����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".vtt");
		fp = fopen(tmpFileName, "r");
		SetThingTXVertices( fp, m_pDynamicThing );
		fclose( fp );

	//TVERTEX INDEX ����
		strcpy(tmpFileName, szFileName);
		strcat(tmpFileName, ".idt");
		fp = fopen(tmpFileName, "r");
		SetThingTXIndex( fp, m_pDynamicThing );
		fclose( fp );

	m_pDynamicThing->InitThing();
	D3DXCreateTextureFromFile( pd3dDevice, m_pDynamicThing->m_pTXData->name, &m_pDynamicThing->m_pTXData->texture );
}

CBspNode* CBspManager::Build(LPSTR szFileName, LPDIRECT3DDEVICE8 pd3dDevice)
{
	m_billboard.v[0].pos = D3DXVECTOR3( -2, 2, 0 );
	m_billboard.v[0].u = 0.f;
	m_billboard.v[0].v = 0.f;

	m_billboard.v[1].pos = D3DXVECTOR3( 2, 2, 0 );
	m_billboard.v[1].u = 1.f;
	m_billboard.v[1].v = 0.f;

	m_billboard.v[2].pos = D3DXVECTOR3( 2, -2, 0 );
	m_billboard.v[2].u = 1.f;
	m_billboard.v[2].v = 1.f;

	m_billboard.v[3].pos = D3DXVECTOR3( -2, -2, 0 );
	m_billboard.v[3].u = 0.f;
	m_billboard.v[3].v = 1.f;

	D3DXCreateTextureFromFile( pd3dDevice, "texture\\billboardlight.tga", &m_billboard.t );
	
	LoadThings( pd3dDevice );
	ParseMaxFile( szFileName );
	SetTexture( pd3dDevice );
	InitBrushs();
	CSGBuild();

	CBspNode* b = new CBspNode();
	b->m_pFaceList = m_pCSGBrushs->m_pFaceList;
	m_pCSGBrushs->m_pFaceList = NULL;
	

	m_pBspRoot = b;
	SubDivide( m_pBspRoot );
	
	PortalizeWorld();
	ClearOutsideFace();
	FreeAllPortals( m_pBspRoot );

	delete m_pBspRoot;

	m_pBspRoot = new CBspNode();
	m_pBspRoot->m_pFaceList = m_pNewFaceRoot;

	CreateLightMap( pd3dDevice );

	SubDivide( m_pBspRoot );
	PortalizeWorld();

	SetPortals();
	
	TryPVS();

	
	
	delete[] m_pBrushs;
	delete m_pCSGBrushs;
	m_pBrushs = NULL;
	m_pCSGBrushs = NULL;
	return b;
}

void CBspManager::SetPortals()
{
	SetValidPortals( m_pBspRoot );
	m_ppPortals = new CBspNode::CPortal*[m_nPortalCnt*2];
	m_nPortalCnt = 0;
	LinkPortals( m_pBspRoot );

	int count = 0;

	for( int i = 0 ; i < m_nPortalCnt ; i++ )
	{
		if( m_ppPortals[i]->m_pNode[1]->m_pPortals != m_ppPortals[i] )
		{
			BOOL check = FALSE;
			CBspNode::CPortal* portal = m_ppPortals[i]->m_pNode[1]->m_pPortals, *prev = NULL;
			for( ; portal ; portal = portal->m_pNext[0] )
			{
				prev = portal;
				if( portal == m_ppPortals[i] )
				{
					check = TRUE;
					break;
				}
			}
			if( !check )
			{
				portal = new CBspNode::CPortal();
				portal->m_pNode[0] = m_ppPortals[i]->m_pNode[1];
				portal->m_pNode[1] = m_ppPortals[i]->m_pNode[0];
				CWinding* w = new CWinding();
				w->n = m_ppPortals[i]->m_pWinding->n;
				for( int j = 0 ; j < w->n; j++ )
					w->vPoint[j] = m_ppPortals[i]->m_pWinding->vPoint[w->n-1-j];
				portal->m_pWinding = w;

				portal->m_plane = D3DXPLANE( 0.f - m_ppPortals[i]->m_plane.a, 
											 0.f - m_ppPortals[i]->m_plane.b,
											 0.f - m_ppPortals[i]->m_plane.c,
											 -m_ppPortals[i]->m_plane.d );
				
				if( prev )
					prev->m_pNext[0] = portal;
				else
					m_ppPortals[i]->m_pNode[1]->m_pPortals = portal;
				m_ppPortals[m_nPortalCnt+count] = portal;
				count++;
			}
		}
	}
	m_nPortalCnt = m_nPortalCnt + count;
}

CBspNode* CBspManager::GetLeafIncludeWinding( CWinding* winding, BOOL bFront )
{
	return NULL;
}

void CBspManager::LinkPortals( CBspNode* node )
{
	CBspNode::CPortal	*p, *nextp, *portals = NULL, * copy = NULL;
	int side = 0;

	if ( !node->m_bIsLeaf )
	{
		LinkPortals ( node->m_pFront );
		LinkPortals ( node->m_pBack );
	}
	
	if( node->m_bIsLeaf )
		for (p=node->m_pPortals ; p ; p=nextp)
		{
			if (p->m_pNode[0] == node)
				side = 0;
			else
				side = 1;
			nextp = p->m_pNext[side];

			m_ppPortals[m_nPortalCnt++] = p;
		}
}

void CBspManager::SetValidPortals( CBspNode * node )
{
	CBspNode::CPortal	*p, *nextp, *portals = NULL, * copy = NULL;
	int side = 0;

	if ( !node->m_bIsLeaf )
	{
		SetValidPortals ( node->m_pFront );
		SetValidPortals ( node->m_pBack );
	}
	
	for (p=node->m_pPortals ; p ; p=nextp)
	{
		if (p->m_pNode[0] == node)
			side = 0;
		else
			side = 1;

		nextp = p->m_pNext[side];
		
		if( p->m_bRender )
		{
			m_nPortalCnt++;
			copy = new CBspNode::CPortal();
			copy->m_plane = p->m_plane;
			copy->m_pNode[0] = p->m_pNode[0];
			copy->m_pNode[1] = p->m_pNode[1];
			copy->m_pWinding = new CWinding();
			copy->m_pWinding->n = p->m_pWinding->n;
			for( int i = 0 ; i < copy->m_pWinding->n ; i++ )
			{
				copy->m_pWinding->vPoint[i] = p->m_pWinding->vPoint[i];
			}
			
			if( portals )
			{
				if ( portals->m_pNode[0] == node )
					side = 0;
				else
					side = 1;
				copy->m_pNext[side] = portals;
				portals = copy;
			}
			else
			{
				copy->m_pNext[0] = portals;
				copy->m_pNext[1] = portals;
				portals = copy;
			}
		}
	}
	if( node->m_bIsLeaf )
	{
		FreeAllPortals( node );

		node->m_pPortals = portals;
	}
}

void CBspManager::SubDivide(CBspNode *pRoot)
{
	pRoot->m_pTXData = m_pTXData;

	CBspNode * front_node = NULL;
	CBspNode * back_node = NULL;

	CFace* bestface = FindBestSplitter( pRoot->m_pFaceList );
	
	if ( bestface == NULL )
	{
		MakeLeaf( pRoot );
		return;
	}

	pRoot->m_plane = m_pCSGBrushs->m_Planes[bestface->m_nPlane];	

	CFace * fr = NULL;
	CFace * bk = NULL;
	
	GetSortedFaceList ( &m_pCSGBrushs->m_Planes[bestface->m_nPlane] , pRoot->m_pFaceList, &fr , &bk );
	int i_fr = SizeOfFace(fr);
	int i_bk = SizeOfFace(bk);

	if ( bk )
	{
		back_node = new CBspNode();
		back_node->SetFaceList( bk );
		pRoot->SetBackNode( back_node );
		SubDivide( pRoot->m_pBack );
	}
	else
	{
		back_node = new CBspNode();
		back_node->SetFaceList( NULL );
		back_node->m_bIsSolid = TRUE;
		back_node->m_bIsLeaf = TRUE;
		pRoot->SetBackNode( back_node );
	}

	if ( fr )
	{
		front_node = new CBspNode();
		front_node->SetFaceList( fr );
		pRoot->SetFrontNode( front_node );
		SubDivide( pRoot->m_pFront );
	}

}

CFace* CBspManager::FindBestSplitter( CFace *pList )
{

	CFace *cface = NULL;
	CFace *curr = NULL;
	CFace *best = NULL; // current best plane
	float bscore = BSP_BOGUS;
	float score = BSP_BOGUS;
	int res = 0;

	// no list
	if (!pList)
		return 0;

	for ( cface = pList; cface; cface = cface->m_pNext )
	{
		if ( cface->m_bUsed )
			continue;

		int f = 0, b = 0, s = 0, o = 0;

		for ( curr = pList; curr; curr = curr->m_pNext )      
		{
			// this face has been used as a split plane, don't consider
			if (curr->m_bUsed)
				continue;

			// don't compare cface to cface
			if (curr != cface)
			{
				res = Classify(&m_pCSGBrushs->m_Planes[cface->m_nPlane], curr->m_vList, curr->m_nNum );
				if (res == FACE_FRONT)
					f++;
				else if (res == FACE_BACK)
					b++;
				else if (res == FACE_ON)
					o++;
				else
					s++;
			}
		}

		// calculate a score for the current plane, this can change
		score = (float)((2*s) + abs(f - b) + o); 
//		score = abs(f - b);
		// this plane is better than what we have, make it the best
		if (score && score < bscore) 
		{
			 bscore = score;
			 best = cface;
		}
	}

	return best;
}

//front back�� ���� �ٸ��߱�
void CBspManager::GetSortedFaceList( D3DXPLANE *plane, CFace *f, CFace **fr, CFace **bk )
{

	CFace * pFront = NULL, * pBack = NULL, * pNext = NULL;
	CFace * pCurrentFace = NULL;
	if( !f )
	{
		*fr = NULL;
		*bk = NULL;
		return;
	}

	for( pCurrentFace = f ; pCurrentFace ; pCurrentFace = pNext )
	{
		pNext = pCurrentFace->m_pNext;
		D3DXVECTOR3 planeNormal( plane->a, plane->b, plane->c );
		D3DXVECTOR3 currentNormal( m_pCSGBrushs->m_Planes[pCurrentFace->m_nPlane].a,  m_pCSGBrushs->m_Planes[pCurrentFace->m_nPlane].b,  m_pCSGBrushs->m_Planes[pCurrentFace->m_nPlane].c );
		float val;
		int res = Classify( plane, pCurrentFace->m_vList, pCurrentFace->m_nNum );
		switch( res )
		{
			case FACE_FRONT:
				pCurrentFace->AddNext( pFront );
				pFront = pCurrentFace;
				break;

			case FACE_BACK:
				pCurrentFace->AddNext( pBack );
				pBack = pCurrentFace;
				break;

			case FACE_ON:
				pCurrentFace->m_bUsed = TRUE;

				val = D3DXVec3Dot( &planeNormal, &currentNormal );
				if( val >= 0 )
				{
					pCurrentFace->AddNext( pFront );
					pFront = pCurrentFace;
				}
				else
				{
					pCurrentFace->AddNext( pBack );
					pBack = pCurrentFace;
				}
				break;

			case FACE_SPLIT:
				CFace * front = NULL, * back = NULL;
				Split( plane, pCurrentFace, &front, &back );
				if( !front && !back )
					break;
				if( front->m_pNext )
				{
					front->m_pNext->AddNext( pFront );
					pFront = front;
				}
				else 
				{
					front->AddNext( pFront );
					pFront = front;
				}
				if( back->m_pNext )
				{
					back->m_pNext->AddNext( pBack );
					pBack = back;
				}
				else
				{
					back->AddNext( pBack );
					pBack = back;
				}
				break;
		}
	}
	*fr = pFront;
	*bk = pBack;

}

int CBspManager::SizeOfFace ( CFace * pFace )
{
	CFace * temp = pFace;
	int i=0;
	while(temp)
	{
		i++;
		temp = temp->m_pNext;
	}
	return i;
}

int CBspManager::ClassifyPoint( D3DXPLANE * plane, D3DXVECTOR3 * v )
{
	float res = D3DXPlaneDotCoord( plane, v);
	if( res > EPSILON )
		return FACE_FRONT;
	else if( res < -EPSILON )
		return FACE_BACK;
	else if( res < EPSILON && res > -EPSILON )
		return FACE_ON;
	return FACE_SPLIT;
}

int CBspManager::Classify( D3DXPLANE *plane, BSPVERTEX *v, int num )
{
	int front = 0, back = 0, on = 0;
	float res = 0;

	for (int cnt = 0; cnt < num; cnt++)
	{
		res = D3DXPlaneDotCoord( plane, &v[cnt].pos );

		if (res > EPSILON)
			front++;
		else if (res < -EPSILON)
			back++;
		else
		{
			front++;
			back++;
			on++;
		}
	}
   
	if (on == num)
		return FACE_ON;
	else if (front == num)
		return FACE_FRONT;
	else if (back == num)
		return FACE_BACK;
	else
		return FACE_SPLIT;
}

void CBspManager::MakeLeaf(CBspNode * leaf)
{
	leaf->m_bIsLeaf = TRUE;
	CFace * faceRoot = leaf->m_pFaceList;
	CFace * tf;
	for ( tf = faceRoot; tf; tf = tf->m_pNext )
	{
		int i;
		for ( i=0; i < tf->m_nNum; i++)
		{
			if ( tf->m_vList[i].pos.x > leaf->m_vMax.x )
				leaf->m_vMax.x = tf->m_vList[i].pos.x;
			if ( tf->m_vList[i].pos.y > leaf->m_vMax.y )
				leaf->m_vMax.y = tf->m_vList[i].pos.y;
			if ( tf->m_vList[i].pos.z > leaf->m_vMax.z )
				leaf->m_vMax.z = tf->m_vList[i].pos.z;


			if ( tf->m_vList[i].pos.x < leaf->m_vMin.x )
				leaf->m_vMin.x = tf->m_vList[i].pos.x;
			if ( tf->m_vList[i].pos.y < leaf->m_vMin.y )
				leaf->m_vMin.y = tf->m_vList[i].pos.y;
			if ( tf->m_vList[i].pos.z < leaf->m_vMin.z )
				leaf->m_vMin.z = tf->m_vList[i].pos.z;

			//�����Ż�� ��������� ������ ���� ���� ��ǥ�� ���� ū ��ǥ�� ���ϱ� ����
			if( m_vMin.x > tf->m_vList[i].pos.x )
				m_vMin.x = tf->m_vList[i].pos.x;
			if( m_vMin.y > tf->m_vList[i].pos.y )
				m_vMin.y = tf->m_vList[i].pos.y;
			if( m_vMin.z > tf->m_vList[i].pos.z )
				m_vMin.z = tf->m_vList[i].pos.z;

			if( m_vMax.x < tf->m_vList[i].pos.x )
				m_vMax.x = tf->m_vList[i].pos.x;
			if( m_vMax.y < tf->m_vList[i].pos.y )
				m_vMax.y = tf->m_vList[i].pos.y;
			if( m_vMax.z < tf->m_vList[i].pos.z )
				m_vMax.z = tf->m_vList[i].pos.z;
		}
	}

	
	
}

void CBspManager::Split(D3DXPLANE *plane, CFace *f, CFace **a, CFace **b)
{
	CFace * frontList, * backList;
	BSPVERTEX vFrontList[20], vBackList[20], vFirst;
	BSPVERTEX vIntersectPoint, vPointA, vPointB;
	WORD wFrontCnt = 0, wBackCnt = 0, wCnt = 0, wCurrentVec = 0;

	vFirst = f->m_vList[0];

	switch( ClassifyPoint( plane, &vFirst.pos ))
	{
		case FACE_FRONT:
			vFrontList[wFrontCnt++] = vFirst;
			break;
		case FACE_BACK:
			vBackList[wBackCnt++] = vFirst;
			break;
		case FACE_ON:
			vFrontList[wFrontCnt++] = vFirst;
			vBackList[wBackCnt++] = vFirst;
			break;
		default:
			break;
	}

	for( wCnt = 1 ; wCnt < f->m_nNum + 1; wCnt++ )
	{
		if( wCnt == f->m_nNum )
			wCurrentVec = 0;
		else
			wCurrentVec = wCnt;

		vPointA = f->m_vList[wCnt-1];
		vPointB = f->m_vList[wCurrentVec];

		int result = ClassifyPoint( plane, &vPointB.pos );
		if( result == FACE_ON )
		{
			vBackList[wBackCnt++] = f->m_vList[wCurrentVec];
			vFrontList[wFrontCnt++] = f->m_vList[wCurrentVec];
		}
		else
		{
			if( IntersectLine( &vIntersectPoint, *plane, vPointA, vPointB ))
			{
				if( result == FACE_FRONT )
				{
					vBackList[wBackCnt++] = vIntersectPoint;
					vFrontList[wFrontCnt++] = vIntersectPoint;
					if( wCurrentVec )
						vFrontList[wFrontCnt++] = f->m_vList[wCurrentVec];
				}
				if( result == FACE_BACK )
				{
					vFrontList[wFrontCnt++] = vIntersectPoint;
					vBackList[wBackCnt++] = vIntersectPoint;
					if( wCurrentVec )
						vBackList[wBackCnt++] = f->m_vList[wCurrentVec];
				}
			}// end - if( IntersectLine() )
			else
			{
				if( result == FACE_FRONT )
				{
					if( wCurrentVec )
						vFrontList[wFrontCnt++] = f->m_vList[wCurrentVec];
				}
				if( result == FACE_BACK )
				{
					if( wCurrentVec )
						vBackList[wBackCnt++] = f->m_vList[wCurrentVec];
				}
			}// end - else( IntersectLine() )
		}// end - else( result == FACE_ON )
	}// end - for(;;)
	
	if( wFrontCnt == wBackCnt )
	{
		D3DXPLANE plane1, plane2;
		frontList = CFace::CreateFace();
		BSPVERTEX* tmp1 = new BSPVERTEX[3];
		tmp1[0] = vFrontList[0];
		tmp1[1] = vFrontList[1];
		tmp1[2] = vFrontList[2];
		D3DXPlaneFromPoints( &plane1, &vFrontList[0].pos, &vFrontList[1].pos, &vFrontList[2].pos );
		frontList->m_nPlane = m_pCSGBrushs->FindSamePlane( plane1 );
		frontList->SetVertexList( tmp1 );
		frontList->m_nTexture = f->m_nTexture;
		frontList->m_nLightMap = f->m_nLightMap;

		backList = CFace::CreateFace();
		BSPVERTEX* tmp2 = new BSPVERTEX[3];
		tmp2[0] = vBackList[0];
		tmp2[1] = vBackList[1];
		tmp2[2] = vBackList[2];
		D3DXPlaneFromPoints( &plane2, &vBackList[0].pos, &vBackList[1].pos, &vBackList[2].pos );
		backList->m_nPlane = m_pCSGBrushs->FindSamePlane( plane2 );
		backList->SetVertexList( tmp2 );
		backList->m_nTexture = f->m_nTexture;
		backList->m_nLightMap = f->m_nLightMap;

		delete f;
	}
	else if( wFrontCnt > wBackCnt )
	{
		D3DXPLANE plane1, plane2, plane3;

		frontList = CFace::CreateFace();
		BSPVERTEX* tmp1 = new BSPVERTEX[3];
		tmp1[0] = vFrontList[0];
		tmp1[1] = vFrontList[1];
		tmp1[2] = vFrontList[2];
		D3DXPlaneFromPoints( &plane1, &tmp1[0].pos, &tmp1[1].pos, &tmp1[2].pos );
		frontList->m_nPlane = m_pCSGBrushs->FindSamePlane( plane1 );
		frontList->SetVertexList( tmp1 );
		frontList->m_nTexture = f->m_nTexture;
		frontList->m_nLightMap = f->m_nLightMap;

		CFace * next = CFace::CreateFace();
		BSPVERTEX* tmp2 = new BSPVERTEX[3];
		tmp2[0] = vFrontList[0];
		tmp2[1] = vFrontList[2];
		tmp2[2] = vFrontList[3];
		D3DXPlaneFromPoints( &plane2, &tmp2[0].pos, &tmp2[1].pos, &tmp2[2].pos );
		next->m_nPlane = m_pCSGBrushs->FindSamePlane( plane2 );
		next->SetVertexList( tmp2 );
		next->m_nTexture = f->m_nTexture;
		next->m_nLightMap = f->m_nLightMap;

		frontList->AddNext( next );

		backList = CFace::CreateFace();
		BSPVERTEX* tmp3 = new BSPVERTEX[3];
		tmp3[0] = vBackList[0];
		tmp3[1] = vBackList[1];
		tmp3[2] = vBackList[2];

		D3DXPlaneFromPoints( &plane3, &tmp3[0].pos, &tmp3[1].pos, &tmp3[2].pos );
		backList->m_nPlane = m_pCSGBrushs->FindSamePlane( plane3 );
		backList->SetVertexList( tmp3 );
		backList->m_nTexture = f->m_nTexture;
		backList->m_nLightMap = f->m_nLightMap;

		delete f;
	}
	else if( wBackCnt > wFrontCnt )
	{
		D3DXPLANE plane1, plane2, plane3;

		backList = CFace::CreateFace();
		BSPVERTEX* tmp1 = new BSPVERTEX[3];
		tmp1[0] = vBackList[0];
		tmp1[1] = vBackList[1];
		tmp1[2] = vBackList[2];
		D3DXPlaneFromPoints( &plane1, &tmp1[0].pos, &tmp1[1].pos, &tmp1[2].pos );
		backList->m_nPlane = m_pCSGBrushs->FindSamePlane( plane1 );
		backList->SetVertexList( tmp1 );
		backList->m_nTexture = f->m_nTexture;
		backList->m_nLightMap = f->m_nLightMap;

		CFace * next = CFace::CreateFace();
		BSPVERTEX* tmp2 = new BSPVERTEX[3];
		tmp2[0] = vBackList[0];
		tmp2[1] = vBackList[2];
		tmp2[2] = vBackList[3];
		D3DXPlaneFromPoints( &plane2, &tmp2[0].pos, &tmp2[1].pos, &tmp2[2].pos );
		next->m_nPlane = m_pCSGBrushs->FindSamePlane( plane2 );
		next->SetVertexList( tmp2 );
		next->m_nTexture = f->m_nTexture;
		next->m_nLightMap = f->m_nLightMap;

		backList->AddNext( next );

		frontList = CFace::CreateFace();
		BSPVERTEX* tmp3 = new BSPVERTEX[3];
		tmp3[0] = vFrontList[0];
		tmp3[1] = vFrontList[1];
		tmp3[2] = vFrontList[2];

		D3DXPlaneFromPoints( &plane3, &tmp3[0].pos, &tmp3[1].pos, &tmp3[2].pos );
		frontList->m_nPlane = m_pCSGBrushs->FindSamePlane( plane3 );
		frontList->SetVertexList( tmp3 );
		frontList->m_nTexture = f->m_nTexture;
		frontList->m_nLightMap = f->m_nLightMap;

		delete f;
	}

	*a = frontList;
	*b = backList;

}

BOOL CBspManager::IntersectLine( BSPVERTEX* vOut, D3DXPLANE &plane, BSPVERTEX &vA, BSPVERTEX &vB )
{
	int res = ClassifyPoint( &plane, &vA.pos );
	if( res == SIDE_ON )
		return FALSE;
	res = ClassifyPoint( &plane, &vB.pos );
	if( res == SIDE_ON )
		return FALSE;
	
	D3DXVECTOR3 n( plane.a, plane.b, plane.c );
	float lineLength = D3DXVec3Dot( &(vB.pos - vA.pos), &n );
	if( fabsf( lineLength ) < 0.0001 )
		return FALSE;

	float aDot = D3DXVec3Dot( &vA.pos, &n );
	float bDot = D3DXVec3Dot( &vB.pos, &n );
	float scale = ( -(plane.d) - aDot ) / ( bDot - aDot );
	
	if( scale < 0.0f )
		return FALSE;
	if( scale > 1.0f )
		return FALSE;

	(*vOut).pos = vA.pos + ( scale * ( vB.pos - vA.pos ) );
//texture ��ǥ ..
	float deltaU = vB.u - vA.u;
	float deltaV = vB.v - vA.v;
	(*vOut).u = vA.u - deltaU*scale;
	(*vOut).v = vB.v - deltaV*scale;
	return TRUE;
}

int CBspManager::CompareNormal( D3DXVECTOR3 &a1, D3DXVECTOR3 &b1, D3DXVECTOR3 &c1, 
							D3DXVECTOR3 &a2, D3DXVECTOR3 &b2, D3DXVECTOR3 &c2 )
{
	D3DXVECTOR3 vNormal1, vNormal2, vCross1, vCross2, vAB1, vAC1, vAB2, vAC2;

	vAB1 = b1 - a1;
	vAC1 = c1 - a1;
	D3DXVec3Cross( &vCross1, &vAB1, &vAC1 );
	D3DXVec3Normalize( &vNormal1, &vCross1 );

	
	vAB2 = b2 - a2;
	vAC2 = c2 - a2;
	D3DXVec3Cross( &vCross2, &vAB2, &vAC2 );
	D3DXVec3Normalize( &vNormal2, &vCross2 );

	if( vNormal1.x == vNormal2.x && vNormal1.y == vNormal2.y && vNormal1.z == vNormal2.z )
		return 1;

	return 0;
}


BOOL CBspManager::InitBrushs()
{
	for( int i = 0 ; i < m_nBrushCount ; i++ )
	{
		m_pBrushs[i].InitBrush();
		if( i > 0 )
			m_pBrushs[i].m_pPrev = &m_pBrushs[i-1];
		if( i != m_nBrushCount-1 )
			m_pBrushs[i].m_pNext = &m_pBrushs[i+1];
	}
	return TRUE;
}

BOOL CBspManager::CSGBuild()
{
	for( int i = 0 ; i < m_nBrushCount ; i++ )
	{
		for( int j = 0 ; j < m_nBrushCount ; j++ )
		{
			if( i == j )
				continue;
			if( m_pBrushs[i].IsColliedBrushs( &m_pBrushs[j] ) )
			{
				CBrush::DeleteInsideFace( m_pBrushs[i], m_pBrushs[j] );
			}
		}
	}

	CFace * f = NULL, * new_root = NULL;
	for( i = 0 ; i < m_nBrushCount ; i++ )
	{
		for( f = m_pBrushs[i].m_pFaceList ; f ; f = f->m_pNext )
		{
			if( f->m_bDelete )
				continue;

			CFace * copy = CFace::CreateFace();
			CBrush::FaceCopy( f, copy );
			copy->m_pNext = new_root;
			new_root = copy;
		}
	}
	m_pCSGBrushs = new CBrush();
	m_pCSGBrushs->Create( new_root );
	return TRUE;
}

CBrush* CBspManager::FindNotUnitedBrush()
{
	for( int i = 0; i < m_nBrushCount ; i++ )
	{
		if( !m_pBrushs[i].m_bUnited )
			return &m_pBrushs[i];

	}
	return NULL;
}

BOOL CBspManager::IsCollision( D3DXVECTOR3 &v )
{
	BOOL b = FALSE;
/*	static float y = 10;
	static BOOL	bUnder = TRUE;
	if( y > 18 )
		bUnder = TRUE;
	else if( y < 2 )
		bUnder = FALSE;

	if( bUnder )
		y = m_pLight->m_vPosition.y -= 0.01f;
	else
		y = m_pLight->m_vPosition.y += 0.01f;
*/
//	m_pLight->m_vPosition = v;
	m_pBspRoot->IsCollision( b, v, m_pRenderNode );
	return b;
}

BOOL CBspManager::CalculateDynamicLight( CFace* face )
{
	if( !m_pDynamicLight )
		return FALSE;

	D3DXPLANE plane;
	D3DXPlaneFromPoints( &plane, &face->m_vList[0].pos, &face->m_vList[1].pos, &face->m_vList[2].pos );
	D3DXVECTOR3 vPlane = D3DXVECTOR3( plane.a * (-plane.d), plane.b * (-plane.d), plane.c * (-plane.d) );
	D3DXVECTOR3 normal = D3DXVECTOR3( plane.a, plane.b, plane.c );
	D3DXVECTOR3 delta_LP = m_pDynamicLight->m_vPosition - vPlane;
	float dot = D3DXVec3Dot( &delta_LP, &normal );
	if( dot <= 0 )
		return FALSE;
	
//	if( FACE_FRONT != ClassifyPoint( &plane, &m_pDynamicLight->m_vPosition) )
//		return FALSE;

	bool bCheck = FALSE;
	int u0v0 = -1, u1v1 = -1, u1v0 = -1, u0v1 = -1;
	float minU = 2, minV = 2;

	for( int i = 0 ; i < face->m_nNum ; i++ )
	{
		float len = (float)sqrt( ( face->m_vList[i].pos.x - m_pDynamicLight->m_vPosition.x ) * ( face->m_vList[i].pos.x - m_pDynamicLight->m_vPosition.x ) +
						( face->m_vList[i].pos.y - m_pDynamicLight->m_vPosition.y ) * ( face->m_vList[i].pos.y - m_pDynamicLight->m_vPosition.y ) +
						( face->m_vList[i].pos.z - m_pDynamicLight->m_vPosition.z ) * ( face->m_vList[i].pos.z - m_pDynamicLight->m_vPosition.z ) );

//		len = fabs( len );
		len = (float)len/(float)m_pDynamicLight->m_radius;
		if( len < 1.1 )
			bCheck = TRUE;
		
		if( face->m_vList[i].u == 0 && face->m_vList[i].v == 0 )
		{
			u0v0 = i;
		}
		else if( face->m_vList[i].u == 1 && face->m_vList[i].v == 1 )
		{
			u1v1 = i;
		}
		else if( face->m_vList[i].u == 1 && face->m_vList[i].v == 0 )
		{
			u1v0 = i;
		}
		else if( face->m_vList[i].u == 0 && face->m_vList[i].v == 1 )
		{
			u0v1 = i;
		}
	}

	if( !bCheck )
		return FALSE;	

	BSPVERTEX ver[4];
	if( u0v0 == -1 )
	{
		ver[0].pos = face->m_vList[u0v1].pos + ( face->m_vList[u1v0].pos - face->m_vList[u1v1].pos );
		ver[0].u = 0;
		ver[0].v = 0;
		ver[1] = face->m_vList[u1v0];
		ver[2] = face->m_vList[u1v1];
		ver[3] = face->m_vList[u0v1];
	}
	else if( u1v0 == -1 )
	{
		ver[0] = face->m_vList[u0v0];
		ver[1].pos = face->m_vList[u0v0].pos + ( face->m_vList[u1v1].pos - face->m_vList[u0v1].pos );
		ver[1].u = 1;
		ver[1].v = 0;
		ver[2] = face->m_vList[u1v1];
		ver[3] = face->m_vList[u0v1];
	}
	else if( u1v1 == -1 )
	{
		ver[0] = face->m_vList[u0v0];
		ver[1] = face->m_vList[u1v0];
		ver[2].pos = face->m_vList[u0v1].pos + ( ver[1].pos - ver[0].pos );
		ver[2].u = ver[2].v = 1;
		ver[3] = face->m_vList[u0v1];
	}
	else if( u0v1 == -1 )
	{
		ver[0] = face->m_vList[u0v0];
		ver[1] = face->m_vList[u1v0];
		ver[2] = face->m_vList[u1v1];
		ver[3].pos = ver[0].pos + ( ver[2].pos - ver[1].pos );
		ver[3].u = 0;
		ver[3].v = 1;
	}
	else
		return FALSE;

	D3DXVECTOR3 edge1 = ver[0].pos;
	D3DXVECTOR3 edge2 = ver[1].pos;
	D3DXVECTOR3 curr = ver[0].pos;

	COLOR color;

	D3DLOCKED_RECT lrt;
	ZeroMemory( &lrt, sizeof(D3DLOCKED_RECT) );
	m_ppLightMap[0]->LockRect( 0, &lrt, NULL, D3DLOCK_NOSYSLOCK );
	LPDWORD p = (LPDWORD)lrt.pBits;

	for( i = 0 ; i < LIGHTMAP_SIZE ; i++ )
	{
		edge1 = ver[0].pos + ((ver[3].pos - ver[0].pos) * ((float)i/LIGHTMAP_SIZE));
		edge2 = ver[1].pos + ((ver[2].pos - ver[1].pos) * ((float)i/LIGHTMAP_SIZE));
		for( int j = 0 ; j < LIGHTMAP_SIZE ; j++ )
		{
			color.color = 0.0;

			color.col[0] = 77;
			color.col[1] = 77;
			color.col[2] = 77;
			color.col[3] = 0;

			curr = edge1 + (( edge2 - edge1 ) * ((float)j/LIGHTMAP_SIZE));
			float len = (float)sqrt( ( curr.x - m_pDynamicLight->m_vPosition.x ) * ( curr.x - m_pDynamicLight->m_vPosition.x ) +
								( curr.y - m_pDynamicLight->m_vPosition.y ) * ( curr.y - m_pDynamicLight->m_vPosition.y ) +
								( curr.z - m_pDynamicLight->m_vPosition.z ) * ( curr.z - m_pDynamicLight->m_vPosition.z ) );

			len = (float)len/(float)m_pDynamicLight->m_radius;
			if( len < 0.65 )
			{
				len = ( 1.f - len ) * 255;
				color.col[0] = 0;
				color.col[1] = len;
				color.col[2] = len;
			}
			
			p[i*LIGHTMAP_SIZE + j] = color.color;
		}
	}

	m_ppLightMap[0]->UnlockRect( 0 );
	
	return TRUE;	

}

void CBspManager::CreateLightMap( LPDIRECT3DDEVICE8 pd3dDevice )
{
	m_pDynamicLight = new CLight( D3DXVECTOR3( 2, 8, -58 ), 16 );
	m_nFaceCount = 0;
//	CountFace( m_ );
	for( CFace * f = m_pNewFaceRoot ; f ; f = f->m_pNext )
		m_nFaceCount++;

	m_ppLightMap = new LPDIRECT3DTEXTURE8[m_nFaceCount];

	int nLightTx = m_nFaceCount;

	for( int i = 0 ; i < m_nFaceCount ; i++ )
	{
		//����Ʈ ���� ���� �ؽ��� ����.
		D3DXCreateTexture( pd3dDevice, LIGHTMAP_SIZE, LIGHTMAP_SIZE, 0, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &m_ppLightMap[i]);
		D3DLOCKED_RECT lrt1;
		ZeroMemory( &lrt1, sizeof(D3DLOCKED_RECT) );

		m_ppLightMap[i]->LockRect( 0, &lrt1, NULL, D3DLOCK_NOSYSLOCK );
	
		LPDWORD p1 = (LPDWORD)lrt1.pBits;
		
		for( int k = 0 ; k < LIGHTMAP_SIZE ; k++ )
		{
			for( int j = 0 ; j < LIGHTMAP_SIZE ; j++ )
			{
				p1[k*(LIGHTMAP_SIZE) + j] = 0x00555555;
			}
		}
		m_ppLightMap[i]->UnlockRect( 0 );
	}

	m_nFaceCount = 2;
	for( f = m_pNewFaceRoot ; f ; f = f->m_pNext )
	{
		if( !CalculateStaticLight( f ) ) 
			f->m_nLightMap = 1;
	}

	for( i = m_nFaceCount ; i < nLightTx ; i++ )
	{
		m_ppLightMap[i]->Release();
	}
	
//	CalculateNodeFlow( m_pBspRoot );
}
void CBspManager::CalculateNodeFlow( CBspNode* node )
{
	if( node->m_bIsLeaf && !node->m_bIsSolid )
	{
		for( CFace* p = node->m_pFaceList ; p ; p = p->m_pNext )
		{
			CalculateStaticLight( p );
		}
	}

	if( node->m_pFront )
		CalculateNodeFlow( node->m_pFront );
	if( node->m_pBack )
		CalculateNodeFlow( node->m_pBack );
}

BOOL CBspManager::CalculateStaticLight( CFace* face )
{
	D3DXPLANE plane;
	D3DXPlaneFromPoints( &plane, &face->m_vList[0].pos, &face->m_vList[1].pos, &face->m_vList[2].pos );
	D3DXVECTOR3 vPlane = D3DXVECTOR3( plane.a * (-plane.d), plane.b * (-plane.d), plane.c * (-plane.d) );
	D3DXVECTOR3 normal = D3DXVECTOR3( plane.a, plane.b, plane.c );
	int nCal = 0;

	for( int i = 0 ; i < m_nStaticLight ; i++ )
	{
		D3DXVECTOR3 delta_LP = m_pLight[i].m_vPosition - vPlane;
		float dot = D3DXVec3Dot( &delta_LP, &normal );
		if( dot <= 0 )
			return FALSE;
		
//		if( FACE_FRONT != ClassifyPoint( &plane, &m_pLight[i].m_vPosition ) )
//			return FALSE;

		int u0v0 = -1, u1v1 = -1, u1v0 = -1, u0v1 = -1;
		
		for( int j = 0 ; j < face->m_nNum ; j++ )
		{
			if( face->m_vList[j].u == 0 && face->m_vList[j].v == 0 )
				u0v0 = j;
			else if( face->m_vList[j].u == 1 && face->m_vList[j].v == 1 )
				u1v1 = j;
			else if( face->m_vList[j].u == 1 && face->m_vList[j].v == 0 )
				u1v0 = j;
			else if( face->m_vList[j].u == 0 && face->m_vList[j].v == 1 )
				u0v1 = j;
		}
		
		BSPVERTEX ver[4];

		if( u0v0 == -1 )
		{
			ver[0].pos = face->m_vList[u0v1].pos + ( face->m_vList[u1v0].pos - face->m_vList[u1v1].pos );
			ver[0].u = 0;
			ver[0].v = 0;
			ver[1] = face->m_vList[u1v0];
			ver[2] = face->m_vList[u1v1];
			ver[3] = face->m_vList[u0v1];
		}
		else if( u1v0 == -1 )
		{
			ver[0] = face->m_vList[u0v0];
			ver[1].pos = face->m_vList[u0v0].pos + ( face->m_vList[u1v1].pos - face->m_vList[u0v1].pos );
			ver[1].u = 1;
			ver[1].v = 0;
			ver[2] = face->m_vList[u1v1];
			ver[3] = face->m_vList[u0v1];
		}
		else if( u1v1 == -1 )
		{
			ver[0] = face->m_vList[u0v0];
			ver[1] = face->m_vList[u1v0];
			ver[2].pos = face->m_vList[u0v1].pos + ( face->m_vList[u1v0].pos - face->m_vList[u0v0].pos );
			ver[2].u = 1;
			ver[2].v = 1;
			ver[3] = face->m_vList[u0v1];
		}
		else if( u0v1 == -1 )
		{
			ver[0] = face->m_vList[u0v0];
			ver[1] = face->m_vList[u1v0];
			ver[2] = face->m_vList[u1v1];
			ver[3].pos = face->m_vList[u0v0].pos + ( face->m_vList[u1v1].pos - face->m_vList[u1v0].pos );
			ver[3].u = 0;
			ver[3].v = 1;
		}
		else
			return FALSE;

		BOOL bCheck = FALSE;
		
		for( int n = 0 ; n < 4 ; n++ )
		{
			float len = (float)sqrt( ( ver[n].pos.x - m_pLight[i].m_vPosition.x ) * ( ver[n].pos.x - m_pLight[i].m_vPosition.x ) +
							( ver[n].pos.y - m_pLight[i].m_vPosition.y ) * ( ver[n].pos.y - m_pLight[i].m_vPosition.y ) +
							( ver[n].pos.z - m_pLight[i].m_vPosition.z ) * ( ver[n].pos.z - m_pLight[i].m_vPosition.z ) );

			len = (float)len/(float)m_pLight[i].m_radius;
			if( len < 0.9 )
			{
				bCheck = TRUE;
				break;
			}
		}

		if( !bCheck )
			continue;


		nCal++;

		D3DXVECTOR3 edge1 = ver[0].pos;
		D3DXVECTOR3 edge2 = ver[1].pos;
		D3DXVECTOR3 curr = ver[0].pos;

		COLOR color;

		D3DLOCKED_RECT lrt;
		ZeroMemory( &lrt, sizeof(D3DLOCKED_RECT) );
		m_ppLightMap[m_nFaceCount]->LockRect( 0, &lrt, NULL, D3DLOCK_NOSYSLOCK );
		LPDWORD p = (LPDWORD)lrt.pBits;

		for( int k = 0 ; k <= LIGHTMAP_SIZE ; k++ )
		{
			edge1 = ver[0].pos + ((ver[3].pos - ver[0].pos) * ((float)k/(float)LIGHTMAP_SIZE));
			edge2 = ver[1].pos + ((ver[2].pos - ver[1].pos) * ((float)k/(float)LIGHTMAP_SIZE));
			for( int l = 0 ; l <= LIGHTMAP_SIZE ; l++ )
			{
				color.col[0] = 77;
				color.col[1] = 77;
				color.col[2] = 77;
				color.col[3] = 00;

				curr = edge1 + (( edge2 - edge1 ) * ((float)l/(float)LIGHTMAP_SIZE));
				float len = (float)sqrt( ( curr.x - m_pLight[i].m_vPosition.x ) * ( curr.x - m_pLight[i].m_vPosition.x ) +
									( curr.y - m_pLight[i].m_vPosition.y ) * ( curr.y - m_pLight[i].m_vPosition.y ) +
									( curr.z - m_pLight[i].m_vPosition.z ) * ( curr.z - m_pLight[i].m_vPosition.z ) );
				len = (float)len/(float)m_pLight[i].m_radius;
				if( len < 0.9 )
				{
					len = ( 1.0f - len ) * 255;
					if( len > 77)
					{
						color.col[0] = len;
						color.col[1] = len;
						color.col[2] = len;
					}
					else
					{
						color.col[0] = 77;
						color.col[1] = 77;
						color.col[2] = 77;
					}
				}
				p[k*LIGHTMAP_SIZE + l] = color.color;
			}
		}
/*
		edge1 = ver[0].pos + (ver[3].pos - ver[0].pos);
		edge2 = ver[1].pos + (ver[2].pos - ver[1].pos);
		for( k = 0 ; k < LIGHTMAP_SIZE ; k++ )
		{
			color.col[0] = 77;
			color.col[1] = 77;
			color.col[2] = 77;
			color.col[3] = 00;

			curr = edge1 + (( edge2 - edge1 ) * ((float)k/(float)LIGHTMAP_SIZE));
			float len = (float)sqrt( ( curr.x - m_pLight[i].m_vPosition.x ) * ( curr.x - m_pLight[i].m_vPosition.x ) +
								( curr.y - m_pLight[i].m_vPosition.y ) * ( curr.y - m_pLight[i].m_vPosition.y ) +
								( curr.z - m_pLight[i].m_vPosition.z ) * ( curr.z - m_pLight[i].m_vPosition.z ) );
			len = (float)len/(float)m_pLight[i].m_radius;
			if( len < 0.9 )
			{
				len = ( 1.0f - len ) * 255;
				if( len > 77)
				{
					color.col[0] = len;
					color.col[1] = len;
					color.col[2] = len;
				}
				else
				{
					color.col[0] = 77;
					color.col[1] = 77;
					color.col[2] = 77;
				}
			}
			p[(LIGHTMAP_SIZE-1)*LIGHTMAP_SIZE + k] = color.color;
		}
*/
		m_ppLightMap[m_nFaceCount]->UnlockRect( 0 );
	}
	if( nCal > 0 )
		face->m_nLightMap = m_nFaceCount++;
	else
		return FALSE;

	return TRUE;
}

BOOL CBspManager::RenderThings( LPDIRECT3DDEVICE8 pd3dDevice, D3DXVECTOR3 vDir )
{
	D3DXMATRIX mW, m;
	static BOOL bUp = TRUE;
	pd3dDevice->GetTransform( D3DTS_WORLD, &mW );
	pd3dDevice->SetVertexShader( D3DFVF_BSPVERTEX );
	pd3dDevice->SetStreamSource( 0, NULL, 0 );
	pd3dDevice->SetIndices( NULL, 0 );
	pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW );

	pd3dDevice->SetTexture( 0, m_pStaticThing->m_pTXData->texture );
	if( !m_pStaticThing )
		return FALSE;
	D3DXMatrixIdentity( &m );

	for( int i = 0 ; i < m_nStaticLight ; i++ )
	{
		m._41 = m_pLight[i].m_vPosition.x;
		m._42 = m_pLight[i].m_vPosition.y+2.7f;
		m._43 = m_pLight[i].m_vPosition.z;

		pd3dDevice->SetTransform( D3DTS_WORLD, &m );
		pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLELIST, m_pStaticThing->m_nFaceCount , m_pStaticThing->m_pFaceList, sizeof( BSPVERTEX )  );
	}

	if( m_pDynamicLight->m_vPosition.y < 1 )
		bUp = TRUE;
	if( m_pDynamicLight->m_vPosition.y > 19 )
		bUp = FALSE;

	if( bUp )
		m_pDynamicLight->m_vPosition.y += 0.05f;
	else
		m_pDynamicLight->m_vPosition.y -= 0.05f;

	m._41 = m_pDynamicLight->m_vPosition.x;
	m._42 = m_pDynamicLight->m_vPosition.y;
	m._43 = m_pDynamicLight->m_vPosition.z;
	
	pd3dDevice->SetTransform( D3DTS_WORLD, &m );
	pd3dDevice->SetTexture( 0, m_pDynamicThing->m_pTXData->texture );
	pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLELIST, m_pDynamicThing->m_nFaceCount , m_pDynamicThing->m_pFaceList, sizeof( BSPVERTEX )  );
	
	D3DXMatrixIdentity( &m );
	
//////////////////BILLBOARD/////////////
	D3DXVECTOR3 v0, v1;
	v0 = D3DXVECTOR3( 0, 0, -1 );
	v1 = vDir - m_pDynamicLight->m_vPosition;

	D3DXQUATERNION q = RotationArc( v0 , v1 );

	D3DXMatrixRotationQuaternion( &m, &q );

	m._41 = m_pDynamicLight->m_vPosition.x;
	m._42 = m_pDynamicLight->m_vPosition.y;
	m._43 = m_pDynamicLight->m_vPosition.z;

	pd3dDevice->SetTransform( D3DTS_WORLD, &m );
	pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE);
	pd3dDevice->SetTexture( 0, m_billboard.t );
	pd3dDevice->SetRenderState( D3DRS_SRCBLEND, D3DBLEND_SRCCOLOR);
	pd3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCCOLOR );
//	pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
//	pd3dDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
	
	pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2 , m_billboard.v, sizeof( BSPVERTEX )  );
	pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE );

///////////////////////////////////////////	


	pd3dDevice->SetTransform( D3DTS_WORLD, &mW );
	return TRUE;
}

BOOL CBspManager::RenderLightMap( LPDIRECT3DDEVICE8 pd3dDevice, BOOL bFill, CD3DFont* pFont )
{
	pd3dDevice->SetVertexShader( D3DFVF_BSPVERTEX );
	pd3dDevice->SetStreamSource( 0, NULL, 0 );
	pd3dDevice->SetIndices( NULL, 0 );
	if( bFill )
		pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	else
		pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW );
	
	m_pBspRoot->InitRender();
	CBspNode::CPortal* portal = m_pRenderNode->m_pPortals;
	pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE);

	int nLightMap = 0;

	for( int i = 0 ; i < portal->m_nFaceCnt ; i++ )
	{
		if( CalculateDynamicLight( portal->m_ppFaceList[i] ) )
			nLightMap = 0;
		else
			nLightMap = portal->m_ppFaceList[i]->m_nLightMap;
		pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
		pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1 );
		pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
		pd3dDevice->SetTexture( 0, m_pTXData[portal->m_ppFaceList[i]->m_nTexture].texture );
		pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 1,portal->m_ppFaceList[i]->m_vList, sizeof( BSPVERTEX )  );

		pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE);
		pd3dDevice->SetRenderState( D3DRS_SRCBLEND, D3DBLEND_ZERO );
		pd3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_SRCCOLOR );
		pd3dDevice->SetTexture( 0, m_ppLightMap[nLightMap] );
		pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 1,portal->m_ppFaceList[i]->m_vList, sizeof( BSPVERTEX )  );
	}
	pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
/*
				if( pFont )
				{
					D3DXMATRIX	mW, mV, mP, mO;
					pd3dDevice->GetTransform( D3DTS_WORLD, &mW );
					pd3dDevice->GetTransform( D3DTS_VIEW, &mV );
					pd3dDevice->GetTransform( D3DTS_PROJECTION, &mP );
					mO = mW * mV * mP;
					float x, y, z;
					x = ( f->m_vList[0].pos.x + f->m_vList[1].pos.x + f->m_vList[2].pos.x )/(float)3;
					y = ( f->m_vList[0].pos.y + f->m_vList[1].pos.y + f->m_vList[2].pos.y )/(float)3;
					z = ( f->m_vList[0].pos.z + f->m_vList[1].pos.z + f->m_vList[2].pos.z )/(float)3;

					D3DXVECTOR3 vI = D3DXVECTOR3( x, y, z );
					D3DXVECTOR3 vO;
					D3DXVec3TransformCoord( &vO, &vI, &mO );
					char	str[16];
					wsprintf( str, "( %d )", f->m_nLightMap );
					pFont->DrawText(400.0f * (vO.x+1.0f), 600 - 300.0f * (vO.y+1.0f), 0xffffffff, str );
				}
				else
*/
	return TRUE;
}

void CBspManager::CountFace( CBspNode * node )
{
	if( node->m_bIsLeaf && !node->m_bIsSolid )
		m_nFaceCount += SizeOfFace( node->m_pFaceList );

	if( node->m_pFront )
		CountFace( node->m_pFront );
	if( node->m_pBack )
		CountFace( node->m_pBack );
}

D3DXQUATERNION CBspManager::RotationArc( D3DXVECTOR3 v0, D3DXVECTOR3 v1 )
{
	D3DXQUATERNION q;
	D3DXVECTOR3 normal0, normal1;
	D3DXVec3Normalize( &normal0, &v0 );
	D3DXVec3Normalize( &normal1, &v1 );
	D3DXVECTOR3 c;
	D3DXVec3Cross( &c, &normal0, &normal1 );
	float d = D3DXVec3Dot( &normal0, &normal1 );
	float s = (float)sqrt((1+d)*2);
	q.x = c.x / s;
	q.y = c.y / s;
	q.z = c.z / s;
	q.w = s / 2.0f;

	return q;
}




