// Brush.h: interface for the CBrush class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BRUSH_H__E096ACC3_CD2F_42E6_8E34_2960BC89CC61__INCLUDED_)
#define AFX_BRUSH_H__E096ACC3_CD2F_42E6_8E34_2960BC89CC61__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "bspnode.h"
#define	MAX_BRUSH_PLANES		65535

#define SIDE_FRONT				0
#define SIDE_BACK				1
#define SIDE_ON					2
#define SIDE_SPLIT				3

#define DIRECTION_UP			0
#define DIRECTION_DOWN			1

#define BOUND_INSIDE			0
#define BOUND_OUTSIDE			1

#define EPSILON					0.001f

#define		STR_MAX			200

class CBrush  
{
public:
	D3DXPLANE		m_Planes[MAX_BRUSH_PLANES];
	CFace*			m_pFaceList;
	int				m_nTotalPlane;
	CBrush*			m_pNext;
	CBrush*			m_pPrev;
	TCHAR			m_szName[STR_MAX];
	int				m_nTexture;
	int				m_nVertexCount;
	int				m_nFaceCount;
	BSPVERTEX*		m_pVertex;
	LPTRIANGLEINDEX	m_pTriangleIndex;
	BOOL			m_bUnited;
	D3DXVECTOR3*	m_pTVtx;
	int				m_nTCount;
	int				m_nTFCount;
	LPTRIANGLEINDEX	m_pTIndex;

public:
	
	static BOOL			DeleteBackFace( D3DXPLANE * planes, int num, CFace* &pList );
	static BOOL			TrySplit( CBrush* brush, int num, CFace * &f, CFace* &fr, CFace* &bk );
	static BOOL			DeleteInsideFace(CBrush &brush1, CBrush &brush2);

	static BOOL			BrushCopy( CBrush * pOrig, CBrush*  &pCopy );
	static BOOL			FaceCopy( CFace* pOrig, CFace* pCopy );
	static BOOL			IsColliedTriangles(CFace* f1, CFace* f2);	
	static BOOL			IsInsideTriangle( float & a1, float & b1, float & a2, float & b2, float & a3, float & b3,  float & a4, float & b4, BOOL bContact );
	CBrush*				operator + ( CBrush &pB );
	
	BOOL				IsColliedBrushs( CBrush* pb );
	BOOL				InitBrush();
	CBrush*				Subtraction( CBrush* pB );
	BOOL				SplitContactFace( int* pPlane, int nPlane, CFace** pList, CBrush * pBrush );
	BOOL				DivideFrontBack( D3DXPLANE &plane, CFace* f, CFace** fr, CFace** bk, BOOL &bSplit, BOOL bIsUnion, CBrush * pBrush );
	BOOL				ComparePlane( D3DXPLANE & a, D3DXPLANE & b );
	int					FindSamePlane( D3DXPLANE &plane );
	BOOL				Create( D3DXVECTOR3 * pList, int n );
	BOOL				Create( CFace * pList );
	BOOL				Render( LPDIRECT3DDEVICE8 pd3dDevice, CD3DFont* pFont );

	static int			Classify( D3DXPLANE *plane, BSPVERTEX *v, int num );
	static int			ClassifyPoint( D3DXPLANE * plane, D3DXVECTOR3 * v );
	static void			Split(D3DXPLANE *plane, CFace *f, CFace **a, CFace **b);
	static BOOL			IntersectLine( BSPVERTEX* vOut, D3DXPLANE &plane, BSPVERTEX &vA, BSPVERTEX &vB );
	int					SizeOfFace ( CFace * pFace );

	CBrush();
	virtual ~CBrush();
};

#endif // !defined(AFX_BRUSH_H__E096ACC3_CD2F_42E6_8E34_2960BC89CC61__INCLUDED_)
