// Portal.h: interface for the CPortal class.
//
//////////////////////////////////////////////////////////////////////


#if !defined(AFX_PORTAL_H__04FAD9EF_81A0_4A11_BA2D_1A1F557DABE7__INCLUDED_)
#define AFX_PORTAL_H__04FAD9EF_81A0_4A11_BA2D_1A1F557DABE7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "bspnode.h"




#endif // !defined(AFX_PORTAL_H__04FAD9EF_81A0_4A11_BA2D_1A1F557DABE7__INCLUDED_)
