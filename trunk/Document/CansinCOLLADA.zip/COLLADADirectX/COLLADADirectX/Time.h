#pragma once

//-------------------------------------------------
// Licence
//-------------------------------------------------
//Copyright (c) 2010 Celal Cansin Kayi
//
//This software is provided 'as-is', without any express or implied
//warranty. In no event will the authors be held liable for any damages
//arising from the use of this software.
//
//Permission is granted to anyone to use this software for any purpose,
//including commercial applications, and to alter it and redistribute it
//freely, subject to the following restrictions:
//
//   1. The origin of this software must not be misrepresented; you must not
//   claim that you wrote the original software. If you use this software
//   in a product, an acknowledgment in the product documentation would be
//   appreciated but is not required.
//
//   2. Altered source versions must be plainly marked as such, and must not be
//   misrepresented as being the original software.
//
//   3. This notice may not be removed or altered from any source
//   distribution.
//-------------------------------------------------
//
//-------------------------------------------------

#include <windows.h>
#pragma comment(lib, "Winmm.lib")

class Time
{
private:
	float timeAtGameStart;
	UINT64 ticksPerSecond;
	float fpsUpdateInterval;

	float currentUpdate;
	float lastUpdate;

	UINT numFrames;
	float fps;

	float last;

public:
	float delta;

	Time()
	{
		fpsUpdateInterval = 0.01f;
		lastUpdate = 0;
		currentUpdate = 0;
		numFrames = 0;
		fps = 0;

		last = 0;
		delta = 0;
	}

	float getFps() { return fps; }
	float getSpeedModifier(float ideal) { return (ideal / fps); }

	void InitializeGameTime()
	{
		if(!QueryPerformanceFrequency((LARGE_INTEGER *) &ticksPerSecond)) ticksPerSecond = 1000;
		timeAtGameStart = 0;
		timeAtGameStart = GetGameTime();
		last = 0;
	}

	float GetGameTime()
	{
		UINT64 ticks;
		float time;

		if(!QueryPerformanceCounter((LARGE_INTEGER *) &ticks)) ticks = (UINT64) timeGetTime();

		time = (float)(__int64)ticks/(float)(__int64)ticksPerSecond;
		time -= timeAtGameStart;

		return time;
	}

	void Update()
	{
		numFrames++;

		currentUpdate = GetGameTime();

		if((currentUpdate - lastUpdate) > fpsUpdateInterval)
		{
			delta = currentUpdate - last;
			last = currentUpdate;

			fps = numFrames / (currentUpdate - lastUpdate);
			lastUpdate = currentUpdate;
			numFrames = 0;
		}
		else
		{
			delta = 0;
		}
	}
};
