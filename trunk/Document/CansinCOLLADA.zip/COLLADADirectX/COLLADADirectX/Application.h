#pragma once

//-------------------------------------------------
// Licence
//-------------------------------------------------
//Copyright (c) 2010 Celal Cansin Kayi
//
//This software is provided 'as-is', without any express or implied
//warranty. In no event will the authors be held liable for any damages
//arising from the use of this software.
//
//Permission is granted to anyone to use this software for any purpose,
//including commercial applications, and to alter it and redistribute it
//freely, subject to the following restrictions:
//
//   1. The origin of this software must not be misrepresented; you must not
//   claim that you wrote the original software. If you use this software
//   in a product, an acknowledgment in the product documentation would be
//   appreciated but is not required.
//
//   2. Altered source versions must be plainly marked as such, and must not be
//   misrepresented as being the original software.
//
//   3. This notice may not be removed or altered from any source
//   distribution.
//-------------------------------------------------
//
//-------------------------------------------------

#include "MeshManager.h"
#include "COLLADALoader.h"
#include "DeviceManager.h"
#include "Time.h"
#include <iostream>
#include <vector>
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")
#include "Camera.h"

using namespace std;

namespace Application
{
	//Function definitions
	LRESULT CALLBACK messageHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
	void Clean();
	void onDeviceLost();
	void onDeviceReset();
	void Update();
	void Draw();

	//Base
	Window* window;
	DeviceManager* deviceManager;
	Time* time;

	//Window focus
	bool inputFocus;

	//Screen params
	float Width;
	float Height;
	bool Fullscreen;

	//Camera
	Camera* camera;

	//MeshManager
	MeshManager* meshes;

	//Main
	void Run(MeshManager* Meshes, float width, float height, bool fullscreen)
	{
		//Set each of the namespace variables based on input
		Width = width; Height = height; Fullscreen = fullscreen;
		meshes = Meshes;

		#pragma region //Construction
		//Construct a new Time manager
		time = new Time();

		//Construct a Window
		window = new Window(Application::messageHandler, L"COLLADA DirectX Viewer", 0, 0, (int)Width, (int)Height);

		//Construct a DeviceManager
		deviceManager = new DeviceManager(window->getHandle(), (int)Width, (int)Height, Fullscreen);
		deviceManager->OnDeviceLost = onDeviceLost;
		deviceManager->OnDeviceReset = onDeviceReset;

		//Create a Camera
		camera = new Camera(D3DXVECTOR3(0, 0, -5), D3DXVECTOR3(0, 0, 0), D3DXVECTOR3(0, 1, 0), Width, Height);

		//Create resources
		meshes->onDeviceReset(deviceManager->getDevice());
		#pragma endregion

		#pragma region //Initialization
		//Show the window
		window->Show();

		//Set the cursor off
		ShowCursor(false);

		//Set the input focus
		inputFocus = true;

		//Initialize gameTime
		time->InitializeGameTime();

		//Initialize msg
		MSG msg;
		ZeroMemory(&msg, sizeof(msg));
		#pragma endregion
		
		//Main loop
		SetCursorPos(600, 600);
		while(msg.message != WM_QUIT)
		{
			if(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
			else
			{
				//Check for the active window focus
				bool windowFocus = (window->getHandle() == GetActiveWindow());

				//If the window has the full attention, input focus and active focus as well as device focus
				if(inputFocus && windowFocus && (deviceManager->getDevice()->TestCooperativeLevel() == D3D_OK))
				{
					//Then Update and draw
					Update();
					Draw();
				}
				else if(windowFocus && (deviceManager->getDevice()->TestCooperativeLevel() != D3D_OK)) //If window focus is regained but the device is lost
				{
					//If the device is recoverable then recover
					if(deviceManager->getDevice()->TestCooperativeLevel() == D3DERR_DEVICELOST  || deviceManager->getDevice()->TestCooperativeLevel() == D3DERR_DEVICENOTRESET) 
						deviceManager->changeViewMode(window, (int)Width, (int)Height, Fullscreen);

					//If theres a driver error then say goodbye
					if(deviceManager->getDevice()->TestCooperativeLevel() == D3DERR_DRIVERINTERNALERROR)
					{
						MessageBox(NULL, TEXT("Driver Internal Error"), TEXT("Error"), MB_OK | MB_ICONERROR);

						break;
					}
				}
			}
		}

		//Clean
		Clean();
	}

	//Clean Application
	void Clean()
	{
		//Delete camera
		if(camera)
		{
			delete camera;
			camera = NULL;
		}

		//Delete deviceManager
		if(deviceManager)
		{
			delete deviceManager;
			deviceManager = NULL;
		}

		//Delete window
		if(window)
		{
			delete window;
			window = NULL;
		}

		//Delete time
		if(time)
		{
			delete time;
			time = NULL;
		}
	}

	//Handle device lost event
	void onDeviceLost()
	{
		//Handle meshes
		meshes->onDeviceLost();
	}

	//Handle device reset event
	void onDeviceReset()
	{
		//Handle meshes
		meshes->onDeviceReset(deviceManager->getDevice());

		//Handle camera
		camera->onDeviceReset(Width, Height);
	}

	//Update Application
	void Update()
	{
		//Get Escape key state
		bool Escape = (GetAsyncKeyState(VK_ESCAPE) & 0x8000) ? true : false;

		//Quit if pressed
		if(Escape) PostQuitMessage(0);

		//Update Time
		time->Update();

		//Update Camera
		camera->Update(60.0f / time->getFps());

		//Update meshes
		meshes->Update(time->delta);
	}

	//Draw Meshes
	void Draw()
	{
		deviceManager->getDevice()->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0x00000000, 1.0f, 0);

		deviceManager->getDevice()->BeginScene();

		meshes->Draw(deviceManager, camera);

		deviceManager->getDevice()->EndScene();

		deviceManager->Present();
	}

	//Message handler
	LRESULT CALLBACK messageHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
	{
		switch(msg)
		{
		case WM_DESTROY:
			PostQuitMessage(0);
			return 0;
		case WM_CLOSE:
			PostQuitMessage(0);
			return 0;
		case WM_SETFOCUS:
			inputFocus = true;
			return 0;
		case WM_KILLFOCUS:
			inputFocus = false;
			break;
		case WM_SYSCOMMAND:
			switch(wParam)
			{
			case SC_CLOSE:
				PostQuitMessage(0);
				return 0;
			case SC_MINIMIZE:
				break;
			case SC_MOVE:
				break;
			case SC_RESTORE:
				break;
			case SC_MAXIMIZE:
				break;
			default:
				return 0;
			}
			break;
		}

		return DefWindowProc(hWnd, msg, wParam, lParam);
	}
}
