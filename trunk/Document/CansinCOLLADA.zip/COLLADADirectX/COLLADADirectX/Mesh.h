#pragma once

//-------------------------------------------------
// Licence
//-------------------------------------------------
//Copyright (c) 2010 Celal Cansin Kayi
//
//This software is provided 'as-is', without any express or implied
//warranty. In no event will the authors be held liable for any damages
//arising from the use of this software.
//
//Permission is granted to anyone to use this software for any purpose,
//including commercial applications, and to alter it and redistribute it
//freely, subject to the following restrictions:
//
//   1. The origin of this software must not be misrepresented; you must not
//   claim that you wrote the original software. If you use this software
//   in a product, an acknowledgment in the product documentation would be
//   appreciated but is not required.
//
//   2. Altered source versions must be plainly marked as such, and must not be
//   misrepresented as being the original software.
//
//   3. This notice may not be removed or altered from any source
//   distribution.
//-------------------------------------------------
//
//-------------------------------------------------

#include "Vertex.h"
#include "dae.h"
#include "dom.h"
//#include "dom/domCOLLADA.h"
#pragma comment(lib, "libcollada141dom21-d.lib")
//#pragma comment(lib, "libxml2_a.lib")
// #pragma comment(lib, "zlib.lib")
// #pragma comment(lib, "wsock32.lib")
// #pragma comment(lib, "pcre-d.lib")
// #pragma comment(lib, "pcrecpp-d.lib")
// #pragma comment(lib, "minizip-d.lib")
// #pragma comment(lib, "libboost_filesystem.lib")
// #pragma comment(lib, "libboost_system.lib")
#include <string>
#include <vector>

using namespace std;

class Mesh
{
private:
	#pragma region //COLLADA members
	//<geometry> element to get mesh data from
	daeElement* geometry;

	//Component Vertex Data, to be compiled into Vertices later...
	vector<D3DXVECTOR3> Positions;
	vector<D3DXVECTOR2> UVs;
	vector<D3DXVECTOR3> Normals;
	vector<D3DXVECTOR3> Tangents;
	vector<D3DXVECTOR3> BiTangents;

	//Set it so COLLADALoader can access privates
	friend class COLLADALoader;

	//Combine the component vertex data to Vertices array
	void combineComponents()
	{
		for(unsigned int i = 0; i < Positions.size(); i++)
		{
			Vertices.push_back(Vertex(Positions[i], Normals[i], UVs[i], Tangents[i], BiTangents[i]));
		}
	}
	#pragma endregion

	//Vertex Buffer
	IDirect3DVertexBuffer9* vertexBuffer;

	//Index Buffer
	IDirect3DIndexBuffer9* indexBuffer;

	//Stride size
	static const int STRIDE_SIZE = (sizeof(DWORD) * 14);

	//Set access rights
	friend class MorphingMesh;

public:
	//Name of this mesh
	string Name;

	//World transform
	D3DXMATRIX World;

	//Combined Vertex Data, ready for Vertex Buffer
	vector<Vertex> Vertices;

	//Index data, ready for Index Buffer
	vector<unsigned int> Indices;

	//Constructor
	Mesh(string Name, D3DXMATRIX World)
	{
		//Set Name
		this->Name = Name;

		//Set World
		this->World = World;

		//Initialize Component Vertex Data arrays
		Positions = vector<D3DXVECTOR3>();
		UVs = vector<D3DXVECTOR2>();
		Normals = vector<D3DXVECTOR3>();
		Tangents = vector<D3DXVECTOR3>();
		BiTangents = vector<D3DXVECTOR3>();

		//Initialize Combined Vertex Data array
		Vertices = vector<Vertex>();

		//Initialize Index Data Array
		Indices = vector<unsigned int>();

		//Initialize COLLADA pointers to NULL
		geometry = NULL;

		//Initialize DirectX resources to NULL
		vertexBuffer = NULL;
		indexBuffer = NULL;
	}

	//Destructor
	~Mesh()
	{
		//Release indexBuffer
		if(indexBuffer)
		{
			indexBuffer->Release();
			indexBuffer = NULL;
		}

		//Release vertexBuffer
		if(vertexBuffer)
		{
			vertexBuffer->Release();
			vertexBuffer = NULL;
		}
	}

	//OnDeviceLost
	void onDeviceLost()
	{
		//Release indexBuffer
		if(indexBuffer)
		{
			indexBuffer->Release();
			indexBuffer = NULL;
		}

		//Release vertexBuffer
		if(vertexBuffer)
		{
			vertexBuffer->Release();
			vertexBuffer = NULL;
		}
	}

	//OnDeviceReset
	void onDeviceReset(IDirect3DDevice9* Device)
	{
		void* BufferMemory;

		//Get vertex buffer size
		UINT bSize = Vertices.size() * STRIDE_SIZE;

		//Create VertexBuffer on gpu
		HRESULT r = Device->CreateVertexBuffer(bSize, D3DUSAGE_WRITEONLY, 0, D3DPOOL_DEFAULT, &vertexBuffer, 0);

		if(r == D3D_OK)
		{
			//Lock VertexBuffer and set the address to BufferMemory pointer
			vertexBuffer->Lock(0, bSize, &BufferMemory, 0);

			//Write to VertexBuffer
			memcpy(BufferMemory, &Vertices[0], bSize);

			//Unlock the VertexBuffer
			vertexBuffer->Unlock();
		}

		//Get index buffer size
		bSize = sizeof(unsigned int) * Indices.size();

		//Create IndexBuffer on gpu
		r = Device->CreateIndexBuffer(bSize, D3DUSAGE_WRITEONLY, D3DFMT_INDEX32, D3DPOOL_DEFAULT, &indexBuffer, 0);

		if(r == D3D_OK)
		{
			//Lock the IndexBuffer for writing
			indexBuffer->Lock(0, bSize, &BufferMemory, 0);

			//Copy Indice data to IndexBuffer
			memcpy(BufferMemory, &Indices[0], bSize);

			//Unlock the IndexBuffer
			indexBuffer->Unlock();
		}
	}

	//Draw
	void Draw(IDirect3DDevice9* Device, ID3DXEffect* effect)
	{
		//Set vertex buffer
		Device->SetStreamSource(0, vertexBuffer, 0, STRIDE_SIZE);

		//Set index buffer
		Device->SetIndices(indexBuffer);

		//Set parameters
		effect->SetMatrix("World", &World);

		//Begin drawing
		effect->Begin(NULL, NULL);
		effect->BeginPass(0);

		//Draw
		Device->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, Vertices.size(), 0, Indices.size() / 3);

		//End drawing
		effect->EndPass();
		effect->End();
	}
};
