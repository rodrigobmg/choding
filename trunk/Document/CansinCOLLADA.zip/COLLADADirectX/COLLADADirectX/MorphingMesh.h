#pragma once

//-------------------------------------------------
// Licence
//-------------------------------------------------
//Copyright (c) 2010 Celal Cansin Kayi
//
//This software is provided 'as-is', without any express or implied
//warranty. In no event will the authors be held liable for any damages
//arising from the use of this software.
//
//Permission is granted to anyone to use this software for any purpose,
//including commercial applications, and to alter it and redistribute it
//freely, subject to the following restrictions:
//
//   1. The origin of this software must not be misrepresented; you must not
//   claim that you wrote the original software. If you use this software
//   in a product, an acknowledgment in the product documentation would be
//   appreciated but is not required.
//
//   2. Altered source versions must be plainly marked as such, and must not be
//   misrepresented as being the original software.
//
//   3. This notice may not be removed or altered from any source
//   distribution.
//-------------------------------------------------
//
//-------------------------------------------------

#include "Mesh.h"
#include "MorphAnimationKey.h"
#include "TargetVertex.h"
#include <dae.h>
#include <dom.h>
#include <dom/domCOLLADA.h>
#pragma comment(lib, "libcollada141dom21-d.lib")
//#pragma comment(lib, "libxml2_a.lib")
// #pragma comment(lib, "zlib.lib")
// #pragma comment(lib, "wsock32.lib")
// #pragma comment(lib, "pcre-d.lib")
// #pragma comment(lib, "pcrecpp-d.lib")
// #pragma comment(lib, "minizip-d.lib")
// #pragma comment(lib, "libboost_filesystem.lib")
// #pragma comment(lib, "libboost_system.lib")
#include <string>
#include <vector>

using namespace std;

class MorphingMesh
{
private:
	#pragma region //COLLADA members

	//Set it so COLLADALoader can access privates
	friend class COLLADALoader;

	//Bubble sort Animation array by least-most time
	void sortAnimation()
	{	
		for(unsigned int i = 0; i < Animations.size(); i++)
		{
			for(unsigned int j = 0; j < i; j++)
			{
				if(Animations[i].Time < Animations[j].Time)
				{
					MorphAnimationKey temp = Animations[i];
					Animations[i] = Animations[j];
					Animations[j] = temp;
				}
			}
		}
	}

	#pragma endregion

	//Accumulated time for the animation
	float accumulatedTime;

	//Target Vertex Buffers
	vector<IDirect3DVertexBuffer9*> targetVertexBuffers;

	//Stride size for Target Vertices
	static const int TARGET_STRIDE_SIZE = (sizeof(DWORD) * 6);

public:
	//Name
	string Name;

	//Base mesh
	Mesh* Base;

	//Morph Targets
	vector<Mesh*> Targets;

	//Animation
	vector<MorphAnimationKey> Animations;

	//Morph Weights
	float Weights[4];

	//Target indices
	short targetIndices[4];

	//Constructor
	MorphingMesh(string Name)
	{
		//Set Name
		this->Name = Name;

		//Set Base to NULL
		Base = NULL;

		//Initialize Targets
		Targets = vector<Mesh*>();

		//Initialize Animation
		Animations = vector<MorphAnimationKey>();

		//Initialize targetVertexBuffers array
		targetVertexBuffers = vector<IDirect3DVertexBuffer9*>();

		//Set accumulatedTime to 0
		accumulatedTime = 0;

		//Set each of the targetIndices to -1 and Weights to 0
		for(unsigned int i = 0; i < 4; i++) 
		{
			targetIndices[i] = -1;
			Weights[i] = 0;
		}
	}

	//Destructor
	~MorphingMesh()
	{
		//Release targetVertexBuffers
		while(!targetVertexBuffers.empty())
		{
			targetVertexBuffers.back()->Release(); targetVertexBuffers.pop_back();
		}

		//Delete Targets
		while(!Targets.empty())
		{
			delete Targets.back(); Targets.pop_back();
		}

		//Delete Base Mesh
		if(Base)
		{
			delete Base;
			Base = NULL;
		}
	}

	//OnDeviceLost
	void onDeviceLost()
	{
		//Release targetVertexBuffers
		while(!targetVertexBuffers.empty())
		{
			targetVertexBuffers.back()->Release(); targetVertexBuffers.pop_back();
		}

		//Handle Targets
		for(unsigned int i = 0; i < Targets.size(); i++) Targets[i]->onDeviceLost();

		//Handle Base
		Base->onDeviceLost();
	}

	//OnDeviceReset
	void onDeviceReset(IDirect3DDevice9* Device)
	{
		//Create vertex and index buffer for the base
		Base->onDeviceReset(Device);

		//Create vertex buffer for each target
		for(unsigned int i = 0; i < Targets.size(); i++)
		{
			//Make full VertexBuffer for it
			Targets[i]->onDeviceReset(Device);

			//First make an array of just the two components needed
			vector<TargetVertex> targetVertices = vector<TargetVertex>();

			for(unsigned int z = 0; z < Targets[i]->Vertices.size(); z++) 
				targetVertices.push_back(TargetVertex(Targets[i]->Vertices[z].Position, Targets[i]->Vertices[z].Normal));

			#pragma region //Then make the vertex buffer
			IDirect3DVertexBuffer9* vertexBuffer = NULL;
			void* BufferMemory;

			//Get vertex buffer size
			UINT bSize = targetVertices.size() * TARGET_STRIDE_SIZE;

			//Create VertexBuffer on gpu
			HRESULT r = Device->CreateVertexBuffer(bSize, D3DUSAGE_WRITEONLY, 0, D3DPOOL_DEFAULT, &vertexBuffer, 0);

			if(r == D3D_OK)
			{
				//Lock VertexBuffer and set the address to BufferMemory pointer
				vertexBuffer->Lock(0, bSize, &BufferMemory, 0);

				//Write to VertexBuffer
				memcpy(BufferMemory, &targetVertices[0], bSize);

				//Unlock the VertexBuffer
				vertexBuffer->Unlock();
			}
			#pragma endregion

			//Push back
			targetVertexBuffers.push_back(vertexBuffer);
		}
	}

	//Update with delta time
	void Update(float dt)
	{
		if(Animations.size() < 1) return;

		//Add to the accumulatedTime
		accumulatedTime += dt;

		//If the accumulatedTime is greater than the end time set it back to the start
		if(accumulatedTime > Animations.back().Time) accumulatedTime = 0;

		//Linear Animate
		LinearAnimate();
	}

	//Render
	void Draw(IDirect3DDevice9* Device, ID3DXEffect* effect)
	{
		//Set Base vertexBuffer and indexBuffer
		Device->SetStreamSource(0, Base->vertexBuffer, 0, Base->STRIDE_SIZE);
		Device->SetIndices(Base->indexBuffer);

		//Set Target vertexBuffer's
		for(unsigned int i = 0; i < 4; i++)
		{
			if((Weights[i] <= 0) || (targetIndices[i] < 0)) continue;

			Device->SetStreamSource(i+1, targetVertexBuffers[targetIndices[i]], 0, TARGET_STRIDE_SIZE);
		}

		//Set World
		effect->SetMatrix("World", &Base->World);
		effect->SetFloatArray("Weight", &Weights[0], 4);

		//Begin drawing
		effect->Begin(NULL, NULL);
		effect->BeginPass(0);

		//Draw
		Device->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, Base->Vertices.size(), 0, Base->Indices.size() / 3);

		//End drawing
		effect->EndPass();
		effect->End();

		//Set each stream back to nothing
		for(unsigned int i = 1; i < 5; i++) Device->SetStreamSource(i, NULL, 0, 0);
	}

	//Draw it's targets as they are
	void DrawPeripheral(IDirect3DDevice9* Device, ID3DXEffect* effect)
	{
		//For each target...
		for(unsigned int i = 0; i < Targets.size(); i++)
		{
			//Draw
			Targets[i]->Draw(Device, effect);
		}
	}

private:
	//Step Animation
	void StepAnimate()
	{
		//Weights for each target
		float* weightsList = new float[Targets.size()];

		//Set Weights and targetIndices to default values
		for(unsigned int i = 0; i < 4; i++) 
		{
			targetIndices[i] = -1;
			Weights[i] = 0;
		}

		//Set weightsList to default values
		for(unsigned int i = 0; i < Targets.size(); i++) weightsList[i] = 0;

		//Get the value for each target for this frame
		for(unsigned int i = 0; i < Animations.size(); i++)
		{
			//Check if this keyframe applies to this time
			if(Animations[i].Time > accumulatedTime) break;

			//Set the weight for the target being referenced
			weightsList[Animations[i].Target] = Animations[i].Weight;
		}

		//Set the Weights and targetIndices for this frame
		short currentIndex = 0;
		for(unsigned int i = 0; i < Targets.size(); i++)
		{
			//Check if there is some contribution by this target
			if(weightsList[i] > 0)
			{
				//Set the weight at the currentIndex
				Weights[currentIndex] = weightsList[i];
				
				//Set the targetIndex at the currentIndex
				targetIndices[currentIndex] = i;
				
				//Index to next to fill
				currentIndex++;
			}

			//Check if no more targets can be added
			if(currentIndex > 3) break;
		}

		//Dereference pointers
		delete [] weightsList;
	}

	//Linear Animation
	void LinearAnimate()
	{
		//Weights for each target
		float* weightsList = new float[Targets.size()];

		//Keyframe for this frame
		short* KI1 = new short[Targets.size()];

		//Keyframe for the next frame
		short* KI2 = new short[Targets.size()];

		//Keep track of which targets next keyframe has been found
		bool* KB = new bool[Targets.size()];

		//Keep track of where to search for the next keyframes
		unsigned int nextSearchStart = 0;

		//Set Weights and targetIndices to default values
		for(unsigned int i = 0; i < 4; i++)
		{
			targetIndices[i] = -1;
			Weights[i] = 0;
		}

		//Set weightsList, KI1, KI2 and KB to default values
		for(unsigned int i = 0; i < Targets.size(); i++)
		{
			weightsList[i] = 0;
			KI1[i] = -1;
			KI2[i] = -1;
			KB[i] = false;
		}

		//Get the current keyframes
		for(unsigned int i = 0; i < Animations.size(); i++)
		{
			//Set nextSearch
			nextSearchStart = i;

			//Check if this keyframe applies to this time
			if(Animations[i].Time > accumulatedTime) break;

			//Set the keyframe index for this target at this frame
			KI1[Animations[i].Target] = i;
		}

		//Get the next keyframes
		unsigned int targetTrack = 0;
		for(unsigned int i = nextSearchStart; i < Animations.size(); i++)
		{
			//If no next keyframe has been found yet for this Target
			if(!KB[Animations[i].Target])
			{
				//Set the next keyframe index for this target
				KI2[Animations[i].Target] = i;

				//Set the bool for this to true
				KB[Animations[i].Target] = true;

				//Add to the target complete count
				targetTrack++;
			}

			//If all the Targets next frames have been found, break
			if(targetTrack > Targets.size()) break;
		}

		//Linear interpolation of each Targets weight
		for(unsigned int i = 0; i < Targets.size(); i++)
		{
			//Get the values
			float a = (KI1[i] >= 0) ? Animations[KI1[i]].Weight : 0;
			float b = (KI2[i] >= 0) ? Animations[KI2[i]].Weight : 0;

			//Get the times
			float T1 = (KI1[i] >= 0) ? Animations[KI1[i]].Time : Animations.front().Time;
			float T2 = (KI2[i] >= 0) ? Animations[KI2[i]].Time : Animations.back().Time;

			//Lerp
			if(T1 == T2)
			{
				weightsList[i] = a;
			}
			else
			{
				//Interpolation modifier
				float s = (accumulatedTime - T1) / (T2 - T1);

				weightsList[i] = Lerp(a, b, s);
			}
		}

		//Set the weights and targetIndices for this frame
		short currentIndex = 0;
		for(unsigned int i = 0; i < Targets.size(); i++)
		{
			//Check if there is some contribution by this target
			if(weightsList[i] > 0)
			{
				//Set the weight at the currentIndex
				Weights[currentIndex] = weightsList[i];
				
				//Set the targetIndex at the currentIndex
				targetIndices[currentIndex] = i;
				
				//Index to next to fill
				currentIndex++;
			}

			//Check if no more targets can be added
			if(currentIndex > 3) break;
		}

		//Dereference pointers
		delete [] weightsList;
		delete [] KI1;
		delete [] KI2;
		delete [] KB;
	}

	//Lerp function
	float Lerp(float a, float b, float s)
	{
		return (a + ((b - a) * s));
	}

	//Bezier Animation
	void BezierAnimate()
	{
	}

	//Hermite Animation
	void HermiteAnimate()
	{
	}
};
