#pragma once

//-------------------------------------------------
// Licence
//-------------------------------------------------
//Copyright (c) 2010 Celal Cansin Kayi
//
//This software is provided 'as-is', without any express or implied
//warranty. In no event will the authors be held liable for any damages
//arising from the use of this software.
//
//Permission is granted to anyone to use this software for any purpose,
//including commercial applications, and to alter it and redistribute it
//freely, subject to the following restrictions:
//
//   1. The origin of this software must not be misrepresented; you must not
//   claim that you wrote the original software. If you use this software
//   in a product, an acknowledgment in the product documentation would be
//   appreciated but is not required.
//
//   2. Altered source versions must be plainly marked as such, and must not be
//   misrepresented as being the original software.
//
//   3. This notice may not be removed or altered from any source
//   distribution.
//-------------------------------------------------
//
//-------------------------------------------------

#include <windows.h>
#include <cstdlib>
#include <iostream>
#include <d3d9.h>
#include <d3dx9.h>
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "Winmm.lib")

class Camera
{
private:
	D3DXVECTOR3 Position;
	D3DXVECTOR3 Direction;
	D3DXVECTOR3 Up;

	float Speed;

public:
	D3DXMATRIX View;
	D3DXMATRIX Projection;

	//Constructor
	Camera(D3DXVECTOR3 Position, D3DXVECTOR3 Target, D3DXVECTOR3 Up, float Width, float Height)
	{
		this->Position = Position;
		this->Direction = D3DXVECTOR3(Target - Position); D3DXVec3Normalize(&this->Direction, &this->Direction);
		this->Up = Up;

		this->Speed = 0.10f;

		D3DXMatrixLookAtLH(&View, &this->Position, &Target, &this->Up);
		D3DXMatrixPerspectiveFovLH(&Projection, (D3DX_PI / 4.0f), (Width / Height), 0.10f, 1000.0f);
	}

	//onDeviceReset
	void onDeviceReset(float Width, float Height)
	{
		D3DXMatrixPerspectiveFovLH(&Projection, (D3DX_PI / 4.0f), (Width / Height), 1.0f, 1000.0f);
	}

	//Update
	void Update(float fpsMod)
	{
		//Keyboard bools
		bool W = (GetAsyncKeyState(0x0057) & 0x8000) ? true : false;
		bool S = (GetAsyncKeyState(0x0053) & 0x8000) ? true : false;
		bool A = (GetAsyncKeyState(0x0041) & 0x8000) ? true : false;
		bool D = (GetAsyncKeyState(0x0044) & 0x8000) ? true : false;

		//Mouse position
		POINT Mouse;
		GetCursorPos(&Mouse);
		
		//Set cursor back to middle
		SetCursorPos(600, 600);

		D3DXVECTOR3 cAxis;
		D3DXVec3Cross(&cAxis, &Up, &Direction);

		if(W) Position += Direction * (Speed * fpsMod);
		if(S) Position -= Direction * (Speed * fpsMod);
		if(A) Position -= cAxis * (Speed * fpsMod);
		if(D) Position +=  cAxis * (Speed * fpsMod);

		D3DXVECTOR4 TransformTemp; // Vec3Transform returns Vector4, use this to convert

		//Yaw Quaternion
		D3DXQUATERNION RXq;
		D3DXQuaternionRotationAxis(&RXq, &Up, ( (D3DX_PI / 4.0f) / 150) * (Mouse.x - 600));

		//Converted to Matrix
		D3DXMATRIX RX;
		D3DXMatrixRotationQuaternion(&RX, &RXq);

		//Transform Direction
		D3DXVec3Transform(&TransformTemp, &Direction, &RX);
		Direction.x = TransformTemp.x; Direction.y = TransformTemp.y; Direction.z = TransformTemp.z;

		//Pitch Quaternion
		D3DXQUATERNION RYq;
		D3DXVec3Cross(&cAxis, &Up, &Direction);
		D3DXQuaternionRotationAxis(&RYq, &cAxis, ( (D3DX_PI / 4.0f) / 150) * (Mouse.y - 600));

		//Convert to Matrix
		D3DXMATRIX RY;
		D3DXMatrixRotationQuaternion(&RY, &RYq);

		//Transform Direction
		D3DXVec3Transform(&TransformTemp, &Direction, &RY);
		Direction.x = TransformTemp.x; Direction.y = TransformTemp.y; Direction.z = TransformTemp.z;

		//Calculate Target
		D3DXVECTOR3 Target = Position + Direction;

		//Calculate View Matrix
		D3DXMatrixLookAtLH(&View, &this->Position, &Target, &this->Up);
	}
};
