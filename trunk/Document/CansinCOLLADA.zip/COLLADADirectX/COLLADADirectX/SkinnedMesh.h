#pragma once

//-------------------------------------------------
// Licence
//-------------------------------------------------
//Copyright (c) 2010 Celal Cansin Kayi
//
//This software is provided 'as-is', without any express or implied
//warranty. In no event will the authors be held liable for any damages
//arising from the use of this software.
//
//Permission is granted to anyone to use this software for any purpose,
//including commercial applications, and to alter it and redistribute it
//freely, subject to the following restrictions:
//
//   1. The origin of this software must not be misrepresented; you must not
//   claim that you wrote the original software. If you use this software
//   in a product, an acknowledgment in the product documentation would be
//   appreciated but is not required.
//
//   2. Altered source versions must be plainly marked as such, and must not be
//   misrepresented as being the original software.
//
//   3. This notice may not be removed or altered from any source
//   distribution.
//-------------------------------------------------
//
//-------------------------------------------------

#include "SkinnedVertex.h"
#include "Joint.h"
#include <dae.h>
#include <dom.h>
#include <dom/domCOLLADA.h>
#pragma comment(lib, "libcollada141dom21-d.lib")
//#pragma comment(lib, "libxml2_a.lib")
// #pragma comment(lib, "zlib.lib")
// #pragma comment(lib, "wsock32.lib")
// #pragma comment(lib, "pcre-d.lib")
// #pragma comment(lib, "pcrecpp-d.lib")
// #pragma comment(lib, "minizip-d.lib")
// #pragma comment(lib, "libboost_filesystem.lib")
//#pragma comment(lib, "libboost_system.lib")
#include <string>
#include <vector>

using namespace std;

class SkinnedMesh
{
private:
	#pragma region //COLLADA members
	//<controller>
	daeElement* controller;

	//<geometry>
	daeElement* geometry;

	//Root <node> for skeleton
	daeElement* rootJoint;
	
	//Component Vertex Data, to be compiled into Vertices later...
	vector<D3DXVECTOR3> Positions;
	vector<D3DXVECTOR2> UVs;
	vector<D3DXVECTOR3> Normals;
	vector<D3DXVECTOR3> Tangents;
	vector<D3DXVECTOR3> BiTangents;
	vector<Index> boneIndices;
	vector<Weight> Weights;

	//Set it so COLLADALoader can access privates
	friend class COLLADALoader;

	//Combine the component vertex data to Vertices array
	void combineComponents()
	{
		for(unsigned int i = 0; i < Positions.size(); i++)
		{
			Vertices.push_back(SkinnedVertex(Positions[i], UVs[i], Normals[i], Tangents[i], BiTangents[i], boneIndices[i], Weights[i]));
		}
	}

	//Make Animation list
	void combineJointAnimations()
	{
		//Put all the Animations together
		for(unsigned int i = 0; i < Joints.size(); i++)
		{
			for(unsigned int z = 0; z < Joints[i].Animations.size(); z++)
			{
				Animations.push_back(Joints[i].Animations[z]);
			}
		}

		//Do a simple Bubble Sort by Time
		for(unsigned int i = 0; i < Animations.size(); i++)
		{
			for(unsigned int j = 0; j < i; j++)
			{
				if(Animations[i].Time < Animations[j].Time)
				{
					JointAnimationKey temp = Animations[i];
					Animations[i] = Animations[j];
					Animations[j] = temp;
				}
			}
		}

		//Set Matrix Pallette to appropiate size, this is to avoid all that extra cpu work every frame
		for(unsigned int i = 0; i < Joints.size(); i++)
		{
			boneTransforms.push_back(D3DXMATRIX());
			worldTransforms.push_back(D3DXMATRIX());
			Pallette.push_back(D3DXMATRIX());
		}
	}

	#pragma endregion

	//Accumulated time for the animation
	float accumulatedTime;

	//Vertex Buffer
	IDirect3DVertexBuffer9* vertexBuffer;

	//Index Buffer
	IDirect3DIndexBuffer9* indexBuffer;

	//Stride size
	static const int STRIDE_SIZE = sizeof(DWORD) * 18 + (sizeof(short) * 4);

	//Bone Transforms
	vector<D3DXMATRIX> boneTransforms;

	//World Transforms
	vector<D3DXMATRIX> worldTransforms;

	//Matrix Pallette
	vector<D3DXMATRIX> Pallette;
public:
	//Name
	string Name;

	//Root Transform Matrix
	D3DXMATRIX RootTransform;

	//BindShape Matrix
	D3DXMATRIX BindShape;

	//Joints
	vector<Joint> Joints;

	//Time sorted Animation Key list
	vector<JointAnimationKey> Animations;

	//Combined Vertex Data, ready for Vertex Buffer
	vector<SkinnedVertex> Vertices;

	//Index data, ready for Index Buffer
	vector<unsigned int> Indices;

	//Constructor
	SkinnedMesh(string Name, D3DXMATRIX RootTransform)
	{
		//Set pointer to NULL
		controller = NULL;

		//Set pointer to NULL
		geometry = NULL;

		//Set pointer to NULL
		rootJoint = NULL;
		
		//Initialize Component Vertex Data
		Positions = vector<D3DXVECTOR3>();
		UVs = vector<D3DXVECTOR2>();
		Normals = vector<D3DXVECTOR3>();
		Tangents = vector<D3DXVECTOR3>();
		BiTangents = vector<D3DXVECTOR3>();
		boneIndices = vector<Index>();
		Weights = vector<Weight>();
		
		//Set Name
		this->Name = Name;

		//Set Root Transform Matrix
		this->RootTransform = RootTransform;

		//Set BindShape Matrix
		D3DXMatrixIdentity(&BindShape);

		//Initialize Joints
		Joints = vector<Joint>();

		//Initialize Time sorted Animation Key list
		Animations = vector<JointAnimationKey>();

		//Initialize Combined Vertex Data, ready for Vertex Buffer
		Vertices = vector<SkinnedVertex>();

		//Initialize Index data, ready for Index Buffer
		Indices = vector<unsigned int>();

		//Vertex Buffer
		vertexBuffer = NULL;

		//Index Buffer
		indexBuffer = NULL;

		//Set accumulatedTime to 0
		accumulatedTime = 0;
	}

	//Destructor
	~SkinnedMesh()
	{
		//Release Index Buffer
		if(indexBuffer)
		{
			indexBuffer->Release();
			indexBuffer = NULL;
		}

		//Release Vertex Buffer
		if(vertexBuffer)
		{
			vertexBuffer->Release();
			vertexBuffer = NULL;
		}
	}

	//OnDeviceLost
	void onDeviceLost()
	{
		//Release Index Buffer
		if(indexBuffer)
		{
			indexBuffer->Release();
			indexBuffer = NULL;
		}

		//Release Vertex Buffer
		if(vertexBuffer)
		{
			vertexBuffer->Release();
			vertexBuffer = NULL;
		}
	}

	//OnDeviceReset
	void onDeviceReset(IDirect3DDevice9* Device)
	{
		void* BufferMemory;

		//Get vertex buffer size
		UINT bSize = Vertices.size() * STRIDE_SIZE;

		//Create VertexBuffer on gpu
		HRESULT r = Device->CreateVertexBuffer(bSize, D3DUSAGE_WRITEONLY, 0, D3DPOOL_DEFAULT, &vertexBuffer, 0);

		if(r == D3D_OK)
		{
			//Lock VertexBuffer and set the address to BufferMemory pointer
			vertexBuffer->Lock(0, bSize, &BufferMemory, 0);

			//Write to VertexBuffer
			memcpy(BufferMemory, &Vertices[0], bSize);

			//Unlock the VertexBuffer
			vertexBuffer->Unlock();
		}

		//Get index buffer size
		bSize = sizeof(unsigned int) * Indices.size();

		//Create IndexBuffer on gpu
		r = Device->CreateIndexBuffer(bSize, D3DUSAGE_WRITEONLY, D3DFMT_INDEX32, D3DPOOL_DEFAULT, &indexBuffer, 0);

		if(r == D3D_OK)
		{
			//Lock the IndexBuffer for writing
			indexBuffer->Lock(0, bSize, &BufferMemory, 0);

			//Copy Indice data to IndexBuffer
			memcpy(BufferMemory, &Indices[0], bSize);

			//Unlock the IndexBuffer
			indexBuffer->Unlock();
		}
	}

	//Update with delta time
	void Update(float dt)
	{
		if(Animations.size() < 1) 
		{
			//Bone Transforms
			for(unsigned int i = 0; i < Joints.size(); i++) boneTransforms[i] = Joints[i].bind_matrix;

			//Calculate Skin
			CalculateSkin();

			return;
		}

		//Add to the accumulatedTime
		accumulatedTime += dt;

		//If the accumulatedTime is greater than the end time set it back to the start
		if(accumulatedTime > Animations.back().Time) accumulatedTime = 0;

		//Bone Transforms
		LinearAnimate();

		//Calculate Skin
		CalculateSkin();
	}

	//Draw
	void Draw(IDirect3DDevice9* Device, ID3DXEffect* effect)
	{
		//Set vertex buffer
		Device->SetStreamSource(0, vertexBuffer, 0, STRIDE_SIZE);

		//Set index buffer
		Device->SetIndices(indexBuffer);

		//Set parameters
		effect->SetMatrix("BindShape", &BindShape);
		effect->SetMatrixArray("MatrixPallette", &Pallette[0], Pallette.size());

		//Begin drawing
		effect->Begin(NULL, NULL);
		effect->BeginPass(0);

		//Draw
		Device->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, Vertices.size(), 0, Indices.size() / 3);

		//End drawing
		effect->EndPass();
		effect->End();
	}

private:
	//Step Animation
	void StepAnimate()
	{
		//First off set the boneTransforms for each joint to bindpose
		for(unsigned int i = 0; i < Joints.size(); i++) boneTransforms[i] = Joints[i].bind_matrix;

		//Now get the latest animation for each joint
		for(unsigned int i = 0; i < Animations.size(); i++)
		{
			//Check if done
			if(Animations[i].Time > accumulatedTime) break;

			//Set this keyframes joint's boneTransform
			boneTransforms[Animations[i].Bone] = Animations[i].Matrix;
		}
	}

	//Linear Animation
	void LinearAnimate()
	{
		//Keyframe index for current frame
		short* KI1 = new short[Joints.size()];

		//Keyframe index for next frame
		short* KI2 = new short[Joints.size()];

		//Keep track of which joints keyframes have been found, this is to ensure that you will only get one next frame key
		bool* KB = new bool[Joints.size()];

		//Keep a running count of the total joints keyframes found, this is to make an early out and save some time
		unsigned int jointTrack = 1;

		//Keep track of where to search for the next frame
		unsigned int nextSearchStart = 0;

		//Set the boneTransforms for each joint to bindpose, set Keyframe indices to -1 and KB to false
		for(unsigned int i = 0; i < Joints.size(); i++)
		{
			//BindPose
			boneTransforms[i] = Joints[i].bind_matrix;

			//Keyframe index for this joint to -1
			KI1[i] = -1; KI2[i] = -1;

			//Set KB for this joint to false
			KB[i] = false;
		}

		//Get the Keyframe index for each joint for this frame
		for(unsigned int i = 0; i < Animations.size(); i++)
		{
			//Set nextSearchStart to current i
			nextSearchStart = i;

			//Check if done
			if(Animations[i].Time > accumulatedTime) break;

			//Set this keyframes joint's boneTransform
			KI1[Animations[i].Bone] = i;
		}

		//Get the Keyframe index for the next frame
		for(unsigned int i = nextSearchStart; i < Animations.size(); i++)
		{
			//If no next keyframe was found yet for this joint
			if(!KB[Animations[i].Bone])
			{
				//Set the next Keyframe index for this joint
				KI2[Animations[i].Bone] = i;

				//Set the bool for this joint true as we have just found the next Keyframe index
				KB[Animations[i].Bone] = true;

				//Add to the joint complete count
				jointTrack++;
			}

			//If every joint has been processed break!
			if(jointTrack >= Joints.size()) break;
		}

		//Linear interpolation for each joint
		for(unsigned int i = 0; i < Joints.size(); i++)
		{
			//Values
			D3DXMATRIX a = (KI1[i] >= 0) ? Animations[KI1[i]].Matrix : boneTransforms[i];
			D3DXMATRIX b = (KI2[i] >= 0) ? Animations[KI2[i]].Matrix : boneTransforms[i];

			//Times
			float T1 = (KI1[i] >= 0) ? Animations[KI1[i]].Time : Animations.front().Time;
			float T2 = (KI2[i] >= 0) ? Animations[KI2[i]].Time : Animations.back().Time;

			//No point interpolating if its the same times, also a division by zero safety check
			if(T1 == T2) 
			{
				boneTransforms[i] = a;
			}
			else
			{
				//Interpolation modifier
				float s = (accumulatedTime - T1) / (T2 - T1);

				boneTransforms[i] = Lerp(a, b, s);
			}
		}

		//Dereference pointers
		delete KI1;
		delete KI2;
		delete KB;
	}

	//Lerp matrices function
	D3DXMATRIX Lerp(D3DXMATRIX a, D3DXMATRIX b, float s)
	{
		//Decompose a
		D3DXVECTOR3 t1, s1;
		D3DXQUATERNION q1;
		D3DXMatrixDecompose(&s1, &q1, &t1, &a);

		//Decompose b
		D3DXVECTOR3 t2, s2;
		D3DXQUATERNION q2;
		D3DXMatrixDecompose(&s2, &q2, &t2, &b);

		//Lerp each component
		D3DXVECTOR3 ti;
		D3DXVec3Lerp(&ti, &t1, &t2, s);

		D3DXVECTOR3 si;
		D3DXVec3Lerp(&si, &s1, &s2, s);

		D3DXQUATERNION qi;
		D3DXQuaternionSlerp(&qi, &q1, &q2, s);

		//Recompose each component
		D3DXMATRIX Tr, Sc, Rt;

		D3DXMatrixTranslation(&Tr, ti.x, ti.y, ti.z);
		D3DXMatrixScaling(&Sc, si.x, si.y, si.z);
		D3DXMatrixRotationQuaternion(&Rt, &qi);

		//Product
		D3DXMATRIX p = Sc * Rt * Tr;

		//Return
		return p;
	}

	//Calculate Skin
	void CalculateSkin()
	{
		//World Transforms
		worldTransforms[0] = boneTransforms[0] * RootTransform;

		for(unsigned int i = 1; i < Joints.size(); i++)
		{
			worldTransforms[i] = boneTransforms[i] * worldTransforms[Joints[i].parentIndex];
		}

		//Skin Transforms
		for(unsigned int i = 0; i < Joints.size(); i++)
		{
			Pallette[i] = Joints[i].inv_bind_matrix * worldTransforms[i];
		}
	}
};
