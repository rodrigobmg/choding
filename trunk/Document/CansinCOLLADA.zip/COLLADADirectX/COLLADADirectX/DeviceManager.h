#pragma once

//-------------------------------------------------
// Licence
//-------------------------------------------------
//Copyright (c) 2010 Celal Cansin Kayi
//
//This software is provided 'as-is', without any express or implied
//warranty. In no event will the authors be held liable for any damages
//arising from the use of this software.
//
//Permission is granted to anyone to use this software for any purpose,
//including commercial applications, and to alter it and redistribute it
//freely, subject to the following restrictions:
//
//   1. The origin of this software must not be misrepresented; you must not
//   claim that you wrote the original software. If you use this software
//   in a product, an acknowledgment in the product documentation would be
//   appreciated but is not required.
//
//   2. Altered source versions must be plainly marked as such, and must not be
//   misrepresented as being the original software.
//
//   3. This notice may not be removed or altered from any source
//   distribution.
//-------------------------------------------------
//
//-------------------------------------------------

#include "Window.h"
#include <windows.h>
#include <iostream>
#include <cstdlib>
#include <vector>
#include <d3d9.h>
#include <d3dx9.h>
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "Winmm.lib")

#ifndef SAFE_DELETE
#define SAFE_DELETE(p) { if(p) { delete p; p = NULL; } }
#endif
#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p) { if(p) { p->Release(); p = NULL; } }
#endif

//Function pointers
typedef void (*ON_DEVICE_LOST)();
typedef void (*ON_DEVICE_RESET)();

//PerfHud enable?
#define PERF

//Unlocked Framerate?
#define FREE

class DeviceManager
{
private:
	//Context
	IDirect3D9* Context;

	//Device
	IDirect3DDevice9* Device;

	//BackBuffer
	IDirect3DSurface9* BackBuffer;

	//AutoDepthBuffer
	IDirect3DSurface9* DepthBuffer;

	//Vertex Declarations
	IDirect3DVertexDeclaration9* MeshVD;
	IDirect3DVertexDeclaration9* SkinnedMeshVD;
	IDirect3DVertexDeclaration9* MorphingMeshVD;

	//Synchronising Query
	IDirect3DQuery9* Query;

	//Presentation Parameters
	D3DPRESENT_PARAMETERS Parameters;

public:
	//Pointer to onDeviceLost/onDeviceReset functions outside of this class
	ON_DEVICE_LOST OnDeviceLost;
	ON_DEVICE_RESET OnDeviceReset;

	#pragma region //Get methods
	IDirect3D9* getContext() { return Context; }
	IDirect3DDevice9* getDevice() { return Device; }
	IDirect3DSurface9* getBackBuffer() { return BackBuffer; }
	IDirect3DSurface9* getDepthBuffer() { return DepthBuffer; }
	IDirect3DQuery9* getQuery() { return Query; }
	D3DPRESENT_PARAMETERS getPresentationParameters() { return Parameters; }
	#pragma endregion

	#pragma region //Set methods
	void setBackBuffer() { Device->SetRenderTarget(0, BackBuffer); }
	void setAutoDepthStencil() { Device->SetDepthStencilSurface(DepthBuffer); }

	void setMeshDeclaration() { Device->SetVertexDeclaration(MeshVD); }
	void setSkinnedMeshDeclaration() { Device->SetVertexDeclaration(SkinnedMeshVD); }
	void setMorphingMeshDeclaration() { Device->SetVertexDeclaration(MorphingMeshVD); }
	#pragma endregion

	//Constructor
	DeviceManager(HWND Window, UINT Width, UINT Height, bool Fullscreen)
	{
		//Set all pointers to NULL in one line
		Context = NULL; Device = NULL; BackBuffer = NULL; DepthBuffer = NULL; MeshVD = NULL; SkinnedMeshVD = NULL; MorphingMeshVD = NULL; Query = NULL; OnDeviceLost = NULL; OnDeviceReset = NULL;

		//Initialize Context
		Context = Direct3DCreate9(D3D_SDK_VERSION);

		//Check if Context initialization was successful
		if(!Context) throw("Could not create Direct3D context!\n");

		#pragma region //Set up Presentation Parameters
		Parameters.BackBufferWidth = Width;
		Parameters.BackBufferHeight = Height;
		Parameters.BackBufferFormat = D3DFMT_A8R8G8B8;
		Parameters.BackBufferCount = 1;
		
		Parameters.MultiSampleType = D3DMULTISAMPLE_NONE;
		Parameters.MultiSampleQuality = 0;

		Parameters.SwapEffect = D3DSWAPEFFECT_DISCARD;
		Parameters.hDeviceWindow = Window;
		Parameters.Windowed = !Fullscreen;
		Parameters.EnableAutoDepthStencil = true;
		Parameters.AutoDepthStencilFormat = D3DFMT_D24S8;
		Parameters.Flags = NULL;
		
		Parameters.FullScreen_RefreshRateInHz = 0;
		Parameters.PresentationInterval = Fullscreen ? D3DPRESENT_INTERVAL_DEFAULT : D3DPRESENT_INTERVAL_ONE;
		#pragma endregion

		#pragma region //Pre-Processor directives and device creation
		#ifdef FREE
		Parameters.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;
		#endif

		#ifdef PERF
		UINT AdapterToUse = D3DADAPTER_DEFAULT;
		D3DDEVTYPE DeviceType = D3DDEVTYPE_HAL;

		for (UINT Adapter = 0; Adapter < Context->GetAdapterCount(); Adapter++)
		{
			D3DADAPTER_IDENTIFIER9 Identifier;
			HRESULT Res;

			Res = Context->GetAdapterIdentifier(Adapter, 0, &Identifier);

			if (strstr(Identifier.Description,"PerfHUD") != 0)
			{
				AdapterToUse = Adapter;
				DeviceType = D3DDEVTYPE_REF;
				break;
			}
		}

		HRESULT result = Context->CreateDevice(AdapterToUse, DeviceType, Window, D3DCREATE_HARDWARE_VERTEXPROCESSING, &Parameters, &Device);
		#else
		HRESULT result = Context->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, Window, D3DCREATE_HARDWARE_VERTEXPROCESSING, &Parameters, &Device);
		#endif
		#pragma endregion

		//Check Device creation for error
		errorCheck(result, L"DeviceManager Constructor: Failed to create device!\r\n");

		#pragma region //Turn the cursor off
		if(Fullscreen)
			while(ShowCursor(false) >= 0);
		else
			while(ShowCursor(true) < 0);
		#pragma endregion

		//Initialize resources
		onDeviceReset();
	}

	//Destructor
	~DeviceManager()
	{
		//Release Query
		SAFE_RELEASE(Query);

		//Release Vertex Declarations
		SAFE_RELEASE(MeshVD);
		SAFE_RELEASE(SkinnedMeshVD);
		SAFE_RELEASE(MorphingMeshVD);

		//Release AutoDepthBuffer
		SAFE_RELEASE(DepthBuffer);

		//Release BackBuffer
		SAFE_RELEASE(BackBuffer);

		//Release Device
		SAFE_RELEASE(Device);

		//Release Context
		SAFE_RELEASE(Context);
	}

	//OnDeviceLost
	void onDeviceLost()
	{
		//Call function pointer
		if(OnDeviceLost) OnDeviceLost();

		//Release Vertex Declarations
		SAFE_RELEASE(MeshVD);
		SAFE_RELEASE(SkinnedMeshVD);
		SAFE_RELEASE(MorphingMeshVD);

		//Release AutoDepthBuffer
		SAFE_RELEASE(DepthBuffer);

		//Release BackBuffer
		SAFE_RELEASE(BackBuffer);

		//Release Query
		SAFE_RELEASE(Query);
	}

	//OnDeviceReset
	void onDeviceReset()
	{
		//Create Query
		Device->CreateQuery(D3DQUERYTYPE_EVENT, &Query);

		//Store a reference to the Back and AutoDepth buffers
		Device->GetRenderTarget(0, &BackBuffer);
		Device->GetDepthStencilSurface(&DepthBuffer);

		//Create vertex declaration for static meshes
		{
			D3DVERTEXELEMENT9 ve[] =
			{
				{0, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
				{0, 12, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL, 0},
				{0, 24, D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},
				{0, 32, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TANGENT, 0},
				{0, 44, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_BINORMAL, 0},
				D3DDECL_END()
			};

			Device->CreateVertexDeclaration(ve, &MeshVD);
		}

		//Create vertex declaration for skinned meshes
		{
			D3DVERTEXELEMENT9 ve[] =
			{
				{0, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
				{0, 12, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL, 0},
				{0, 24, D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},
				{0, 32, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TANGENT, 0},
				{0, 44, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_BINORMAL, 0},
				{0, 56, D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_BLENDWEIGHT, 0},
				{0, 72, D3DDECLTYPE_SHORT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_BLENDINDICES, 0},
				D3DDECL_END()
			};

			Device->CreateVertexDeclaration(ve, &SkinnedMeshVD);
		}

		//Create vertex declaration for morphing meshes
		{
			D3DVERTEXELEMENT9 ve[] =
			{
				//1st Stream: Base Mesh
				{0, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
				{0, 12, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL, 0},
				{0, 24, D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},
				{0, 32, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TANGENT, 0},
				{0, 44, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_BINORMAL, 0},

				//2nd Stream
				{1, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 1},
				{1, 12, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL, 1},

				//3rd Stream
				{2, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 2},
				{2, 12, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL, 2},
				
				//4th Stream
				{3, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 3},
				{3, 12, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL, 3},

				//5th Stream
				{4, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 4},
				{4, 12, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL, 4},

				D3DDECL_END()
			};

			Device->CreateVertexDeclaration(ve, &MorphingMeshVD);
		}
		
		//Call function pointer
		if(OnDeviceReset) OnDeviceReset();
	}

	//Change view mode
	void changeViewMode(Window* window, int Width, int Height, bool Fullscreen)
	{
		#pragma region //Change the parameters that create the device to the new ones
		Parameters.BackBufferWidth = Width;
		Parameters.BackBufferHeight = Height;
		Parameters.Windowed = !Fullscreen;

		if(Fullscreen) Parameters.PresentationInterval = D3DPRESENT_INTERVAL_DEFAULT;
		else Parameters.PresentationInterval = D3DPRESENT_INTERVAL_ONE;

		#ifdef FREE
		Parameters.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;
		#endif
		#pragma endregion

		//Release resources
		onDeviceLost();

		//Reset the device
		if(Device->Reset(&Parameters) != D3D_OK) return;

		//If in windowed mode change the window size
		if(!Fullscreen) window->setSize(Width, Height);

		//Reset resources
		onDeviceReset();

		#pragma region //Turn the cursor off
		if(Fullscreen)
			while(ShowCursor(false) >= 0);
		else
			while(ShowCursor(true) < 0);
		ShowCursor(false);
		#pragma endregion
	}

	//Error check a DirectX thrown HRESULT
	void errorCheck(HRESULT result, LPCTSTR debugInfo)
	{
		if(result == D3D_OK) return;

		LPTSTR text;

		#pragma region Switch check
		switch(result)
		{
		case D3DERR_WRONGTEXTUREFORMAT:
			text = TEXT("D3DERR_WRONGTEXTUREFORMAT");
			MessageBox(NULL, TEXT("D3DERR_WRONGTEXTUREFORMAT"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_UNSUPPORTEDCOLOROPERATION:
			text = TEXT("D3DERR_UNSUPPORTEDCOLOROPERATION");
			MessageBox(NULL, TEXT("D3DERR_UNSUPPORTEDCOLOROPERATION"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_UNSUPPORTEDCOLORARG:
			text = TEXT("D3DERR_UNSUPPORTEDCOLORARG");
			MessageBox(NULL, TEXT("D3DERR_UNSUPPORTEDCOLORARG"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_UNSUPPORTEDALPHAOPERATION:
			text = TEXT("D3DERR_UNSUPPORTEDALPHAOPERATION");
			MessageBox(NULL, TEXT("D3DERR_UNSUPPORTEDALPHAOPERATION"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_UNSUPPORTEDALPHAARG:
			text = TEXT("D3DERR_UNSUPPORTEDALPHAARG");
			MessageBox(NULL, TEXT("D3DERR_UNSUPPORTEDALPHAARG"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_TOOMANYOPERATIONS:
			text = TEXT("D3DERR_TOOMANYOPERATIONS");
			MessageBox(NULL, TEXT("D3DERR_TOOMANYOPERATIONS"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_CONFLICTINGTEXTUREFILTER:
			text = TEXT("D3DERR_CONFLICTINGTEXTUREFILTER");
			MessageBox(NULL, TEXT("D3DERR_CONFLICTINGTEXTUREFILTER"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_UNSUPPORTEDFACTORVALUE:
			text = TEXT("D3DERR_UNSUPPORTEDFACTORVALUE");
			MessageBox(NULL, TEXT("D3DERR_UNSUPPORTEDFACTORVALUE"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_CONFLICTINGRENDERSTATE:
			text = TEXT("D3DERR_CONFLICTINGRENDERSTATE");
			MessageBox(NULL, TEXT("D3DERR_CONFLICTINGRENDERSTATE"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_UNSUPPORTEDTEXTUREFILTER:
			text = TEXT("D3DERR_UNSUPPORTEDTEXTUREFILTER");
			MessageBox(NULL, TEXT("D3DERR_UNSUPPORTEDTEXTUREFILTER"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_CONFLICTINGTEXTUREPALETTE:
			text = TEXT("D3DERR_CONFLICTINGTEXTUREPALETTE");
			MessageBox(NULL, TEXT("D3DERR_CONFLICTINGTEXTUREPALETTE"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_DRIVERINTERNALERROR:
			text = TEXT("D3DERR_DRIVERINTERNALERROR");
			MessageBox(NULL, TEXT("D3DERR_DRIVERINTERNALERROR"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;

		case D3DERR_NOTFOUND:
			text = TEXT("D3DERR_NOTFOUND");
			MessageBox(NULL, TEXT("D3DERR_NOTFOUND"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_MOREDATA:
			text = TEXT("D3DERR_MOREDATA");
			MessageBox(NULL, TEXT("D3DERR_MOREDATA"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_DEVICELOST:
			text = TEXT("D3DERR_DEVICELOST");
			MessageBox(NULL, TEXT("D3DERR_DEVICELOST"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_DEVICENOTRESET:
			text = TEXT("D3DERR_DEVICENOTRESET");
			MessageBox(NULL, TEXT("D3DERR_DEVICENOTRESET"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_NOTAVAILABLE:
			text = TEXT("D3DERR_NOTAVAILABLE");
			MessageBox(NULL, TEXT("D3DERR_NOTAVAILABLE"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_OUTOFVIDEOMEMORY:
			text = TEXT("D3DERR_OUTOFVIDEOMEMORY");
			MessageBox(NULL, TEXT("D3DERR_OUTOFVIDEOMEMORY"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_INVALIDCALL:
			text = TEXT("D3DERR_INVALIDCALL");
			MessageBox(NULL, TEXT("D3DERR_INVALIDCALL"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_DRIVERINVALIDCALL:
			text = TEXT("D3DERR_DRIVERINVALIDCALL");
			MessageBox(NULL, TEXT("D3DERR_DRIVERINVALIDCALL"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		case D3DERR_WASSTILLDRAWING:
			text = TEXT("D3DERR_WASSTILLDRAWING");
			MessageBox(NULL, TEXT("D3DERR_WASSTILLDRAWING"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;

		case D3DERR_DEVICEREMOVED:
			text = TEXT("D3DERR_DEVICEREMOVED");
			MessageBox(NULL, TEXT("D3DERR_DEVICEREMOVED"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;		
		case D3DERR_DEVICEHUNG:
			text = TEXT("D3DERR_DEVICEHUNG");
			MessageBox(NULL, TEXT("D3DERR_DEVICEHUNG"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		
		default:
			text = TEXT("D3DERR_UNSPECIFIED");
			MessageBox(NULL, TEXT("D3DERR_UNSPECIFIED"), TEXT("DirectX error!"), MB_OK | MB_ICONERROR);
			break;
		}
		#pragma endregion

		LPTSTR error = new TCHAR[256];
		wsprintf(error, TEXT("%s\r\n%s"), debugInfo, text);
		throw(error);
	}

	//Synchronising function
	void Present()
	{
		//Present the BackBuffer
		Device->Present(0, 0, 0, 0);

		//End the query
		Query->Issue(D3DISSUE_END);
		Query->GetData( NULL, 0, D3DGETDATA_FLUSH );

		//Until query is processed, do not move on
		while(Query->GetData(NULL, 0, D3DGETDATA_FLUSH) == S_FALSE)
		{
			if(Query->GetData(NULL, 0, D3DGETDATA_FLUSH) == D3DERR_DEVICELOST) break;
		}
	}
};
