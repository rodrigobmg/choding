#pragma once

//-------------------------------------------------
// Licence
//-------------------------------------------------
//Copyright (c) 2010 Celal Cansin Kayi
//
//This software is provided 'as-is', without any express or implied
//warranty. In no event will the authors be held liable for any damages
//arising from the use of this software.
//
//Permission is granted to anyone to use this software for any purpose,
//including commercial applications, and to alter it and redistribute it
//freely, subject to the following restrictions:
//
//   1. The origin of this software must not be misrepresented; you must not
//   claim that you wrote the original software. If you use this software
//   in a product, an acknowledgment in the product documentation would be
//   appreciated but is not required.
//
//   2. Altered source versions must be plainly marked as such, and must not be
//   misrepresented as being the original software.
//
//   3. This notice may not be removed or altered from any source
//   distribution.
//-------------------------------------------------
//
//-------------------------------------------------

#include "Camera.h"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <d3d9.h>
#include <d3dx9.h>
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")
#include "Mesh.h"
#include "SkinnedMesh.h"
#include "MorphingMesh.h"
#include "DeviceManager.h"
#include <vector>

using std::string;
using std::vector;

class MeshManager
{
private:
	//Static mesh effect
	ID3DXEffect* staticEffect;

	//Skin mesh effect
	ID3DXEffect* skinEffect;

	//Morph mesh effect
	ID3DXEffect* morphEffect;

	//Convert matrix
	D3DXMATRIX collada2DirectX(D3DXMATRIX input)
	{
		D3DXMATRIX out;

		out.m[0][0] = input.m[0][0];
		out.m[0][1] = input.m[1][0];
		out.m[0][2] = input.m[2][0];
		out.m[0][3] = input.m[3][0];
		
		out.m[1][0] = input.m[0][1];
		out.m[1][1] = input.m[1][1];
		out.m[1][2] = input.m[2][1];
		out.m[1][3] = input.m[3][1];

		out.m[2][0] = input.m[0][2];
		out.m[2][1] = input.m[1][2];
		out.m[2][2] = input.m[2][2];
		out.m[2][3] = input.m[3][2];

		out.m[3][0] = input.m[0][3];
		out.m[3][1] = input.m[1][3];
		out.m[3][2] = input.m[2][3];
		out.m[3][3] = input.m[3][3];

		return out;
	}

public:
	//Array of static meshes
	vector<Mesh*> StaticMeshes;

	//Array of skinned meshes
	vector<SkinnedMesh*> SkinnedMeshes;

	//Array of morphing meshes
	vector<MorphingMesh*> MorphingMeshes;

	//Constructor
	MeshManager()
	{
		//Initialize Meshes
		StaticMeshes = vector<Mesh*>();

		//Initialize Skinned Meshes
		SkinnedMeshes = vector<SkinnedMesh*>();

		//Initialize Morphing Meshes
		MorphingMeshes = vector<MorphingMesh*>();

		//Set DirectX resources to NULL
		staticEffect = NULL; skinEffect = NULL; morphEffect = NULL;
	}

	//Destructor
	~MeshManager()
	{
		//Release Morph mesh effect
		if(morphEffect)
		{
			morphEffect->Release();
			morphEffect = NULL;
		}

		//Release Skin mesh effect
		if(skinEffect)
		{
			skinEffect->Release();
			skinEffect = NULL;
		}

		//Release Static mesh effect
		if(staticEffect)
		{
			staticEffect->Release();
			staticEffect = NULL;
		}

		//Delete Morphing Meshes
		while(!MorphingMeshes.empty())
		{
			delete MorphingMeshes.back(); MorphingMeshes.pop_back();
		}

		//Delete Skinned Meshes
		while(!SkinnedMeshes.empty())
		{
			delete SkinnedMeshes.back(); SkinnedMeshes.pop_back();
		}

		//Delete Meshes
		while(!StaticMeshes.empty())
		{
			delete StaticMeshes.back(); StaticMeshes.pop_back();
		}
	}

	//Convert each mesh of all types to be DirectX friendly
	void makeDirectXFriendly()
	{
		//Create negative z scale matrix
		D3DXMATRIX Scale; D3DXMatrixScaling(&Scale, 1, 1, -1);

		//Convert static meshes
		for(unsigned int i = 0; i < StaticMeshes.size(); i++)
		{
			//Multiply World by Scale
			StaticMeshes[i]->World = collada2DirectX(StaticMeshes[i]->World) * Scale;

			//Change Index buffer to render counter clockwise
			for(unsigned int z = 0; z < StaticMeshes[i]->Indices.size(); (z += 3))
			{
				unsigned int v0 = StaticMeshes[i]->Indices[z];
				unsigned int v1 = StaticMeshes[i]->Indices[z+1];
				unsigned int v2 = StaticMeshes[i]->Indices[z+2];

				StaticMeshes[i]->Indices[z] = v0;
				StaticMeshes[i]->Indices[z+1] = v2;
				StaticMeshes[i]->Indices[z+2] = v1;
			}
		}

		//Convert skinned meshes
		for(unsigned int i = 0; i < SkinnedMeshes.size(); i++)
		{
			//Set Root Transform to Scale
			SkinnedMeshes[i]->RootTransform = collada2DirectX(SkinnedMeshes[i]->RootTransform) * Scale;

			//Convert each Animation matrix
			for(unsigned int z = 0; z < SkinnedMeshes[i]->Animations.size(); z++) SkinnedMeshes[i]->Animations[z].Matrix = collada2DirectX(SkinnedMeshes[i]->Animations[z].Matrix);

			//Convert the bind and inverse bind matrices
			for(unsigned int z = 0; z < SkinnedMeshes[i]->Joints.size(); z++)
			{
				SkinnedMeshes[i]->Joints[z].bind_matrix = collada2DirectX(SkinnedMeshes[i]->Joints[z].bind_matrix);
				SkinnedMeshes[i]->Joints[z].inv_bind_matrix = collada2DirectX(SkinnedMeshes[i]->Joints[z].inv_bind_matrix);
			}

			//Convert BindShape
			SkinnedMeshes[i]->BindShape = collada2DirectX(SkinnedMeshes[i]->BindShape);
			
			//Change Index buffer to render counter clockwise
			for(unsigned int z = 0; z < SkinnedMeshes[i]->Indices.size(); (z += 3))
			{
				unsigned int v0 = SkinnedMeshes[i]->Indices[z];
				unsigned int v1 = SkinnedMeshes[i]->Indices[z+1];
				unsigned int v2 = SkinnedMeshes[i]->Indices[z+2];

				SkinnedMeshes[i]->Indices[z] = v0;
				SkinnedMeshes[i]->Indices[z+1] = v2;
				SkinnedMeshes[i]->Indices[z+2] = v1;
			}
		}

		//Convert morphing meshes
		for(unsigned int i = 0; i < MorphingMeshes.size(); i++)
		{
			//Multiply World of Base mesh by Scale
			MorphingMeshes[i]->Base->World = collada2DirectX(MorphingMeshes[i]->Base->World) * Scale;

			//Multiply World of each Target mesh by Scale
			for(unsigned int z = 0; z < MorphingMeshes[i]->Targets.size(); z++)
			{
				MorphingMeshes[i]->Targets[z]->World = collada2DirectX(MorphingMeshes[i]->Targets[z]->World) * Scale;
				
				//Change Index buffer to render counter clockwise for Targets
				for(unsigned int x = 0; x < MorphingMeshes[i]->Targets[z]->Indices.size(); (x += 3))
				{
					unsigned int v0 = MorphingMeshes[i]->Targets[z]->Indices[x];
					unsigned int v1 = MorphingMeshes[i]->Targets[z]->Indices[x+1];
					unsigned int v2 = MorphingMeshes[i]->Targets[z]->Indices[x+2];

					MorphingMeshes[i]->Targets[z]->Indices[x] = v0;
					MorphingMeshes[i]->Targets[z]->Indices[x+1] = v2;
					MorphingMeshes[i]->Targets[z]->Indices[x+2] = v1;
				}
			}

			//Change Index buffer to render counter clockwise for Base
			for(unsigned int z = 0; z < MorphingMeshes[i]->Base->Indices.size(); (z += 3))
			{
				unsigned int v0 = MorphingMeshes[i]->Base->Indices[z];
				unsigned int v1 = MorphingMeshes[i]->Base->Indices[z+1];
				unsigned int v2 = MorphingMeshes[i]->Base->Indices[z+2];

				MorphingMeshes[i]->Base->Indices[z] = v0;
				MorphingMeshes[i]->Base->Indices[z+1] = v2;
				MorphingMeshes[i]->Base->Indices[z+2] = v1;
			}
		}
	}

	//onDeviceLost
	void onDeviceLost()
	{
		//Handle static meshes
		for(unsigned int i = 0; i < StaticMeshes.size(); i++) StaticMeshes[i]->onDeviceLost();

		//Handle skinned meshes
		for(unsigned int i = 0; i < SkinnedMeshes.size(); i++) SkinnedMeshes[i]->onDeviceLost();

		//Handle morphing meshes
		for(unsigned int i = 0; i < MorphingMeshes.size(); i++) MorphingMeshes[i]->onDeviceLost();
		
		//Release Morph mesh effect
		if(morphEffect)
		{
			morphEffect->Release();
			morphEffect = NULL;
		}

		//Release Skin mesh effect
		if(skinEffect)
		{
			skinEffect->Release();
			skinEffect = NULL;
		}

		//Release Static mesh effect
		if(staticEffect)
		{
			staticEffect->Release();
			staticEffect = NULL;
		}

	}

	//onDeviceReset
	void onDeviceReset(IDirect3DDevice9* Device)
	{
		//Handle static meshes
		for(unsigned int i = 0; i < StaticMeshes.size(); i++) StaticMeshes[i]->onDeviceReset(Device);

		//Handle skinned meshes
		for(unsigned int i = 0; i < SkinnedMeshes.size(); i++) SkinnedMeshes[i]->onDeviceReset(Device);

		//Handle morphing meshes
		for(unsigned int i = 0; i < MorphingMeshes.size(); i++) MorphingMeshes[i]->onDeviceReset(Device);

		//Load static mesh effect
		D3DXCreateEffectFromFile(Device, L"Content/Effects/Static.fx", NULL, NULL, NULL, NULL, &staticEffect, NULL);
		D3DXCreateEffectFromFile(Device, L"Content/Effects/Skinned.fx", NULL, NULL, NULL, NULL, &skinEffect, NULL);
		D3DXCreateEffectFromFile(Device, L"Content/Effects/Morph.fx", NULL, NULL, NULL, NULL, &morphEffect, NULL);
	}

	//Update
	void Update(float dt)
	{
		//Update SkinnedMeshes
		for(unsigned int i = 0; i < SkinnedMeshes.size(); i++) SkinnedMeshes[i]->Update(dt);

		//Update MorphingMeshes
		for(unsigned int i = 0; i < MorphingMeshes.size(); i++) MorphingMeshes[i]->Update(dt);
	}

	//Draw
	void Draw(DeviceManager* deviceManager, Camera* camera)
	{
		#pragma region //Static meshes
		//Set Vertex Declaration
		deviceManager->setMeshDeclaration();

		//Set effect globals
		staticEffect->SetMatrix("View", &camera->View);
		staticEffect->SetMatrix("Projection", &camera->Projection);

		//Draw each Static Mesh
		for(unsigned int i = 0; i < StaticMeshes.size(); i++)
		{
			StaticMeshes[i]->Draw(deviceManager->getDevice(), staticEffect);
		}

		//Draw each Morph Mesh's Morph Targets
		for(unsigned int i = 0; i < MorphingMeshes.size(); i++)
		{
			MorphingMeshes[i]->DrawPeripheral(deviceManager->getDevice(), staticEffect);
		}
		#pragma endregion
// 
// 		#pragma region //Skinned meshes
// 		//Set Vertex Declaration
// 		deviceManager->setSkinnedMeshDeclaration();
// 
// 		//Set effect globals
// 		skinEffect->SetMatrix("View", &camera->View);
// 		skinEffect->SetMatrix("Projection", &camera->Projection);
// 
// 		//Draw each
// 		for(unsigned int i = 0; i < SkinnedMeshes.size(); i++)
// 		{
// 			SkinnedMeshes[i]->Draw(deviceManager->getDevice(), skinEffect);
// 		}
// 		#pragma endregion
// 
// 		#pragma region //Morph meshes
// 		//Set Vertex Declaration
// 		deviceManager->setMorphingMeshDeclaration();
// 
// 		//Set effect globals
// 		morphEffect->SetMatrix("View", &camera->View);
// 		morphEffect->SetMatrix("Projection", &camera->Projection);
// 
// 		//Draw each
// 		for(unsigned int i = 0; i < MorphingMeshes.size(); i++)
// 		{
// 			MorphingMeshes[i]->Draw(deviceManager->getDevice(), morphEffect);
// 		}
// 		#pragma endregion
	}
};