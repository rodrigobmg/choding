//-------------------------------------------------
// Licence
//-------------------------------------------------
//Copyright (c) 2010 Celal Cansin Kayi
//
//This software is provided 'as-is', without any express or implied
//warranty. In no event will the authors be held liable for any damages
//arising from the use of this software.
//
//Permission is granted to anyone to use this software for any purpose,
//including commercial applications, and to alter it and redistribute it
//freely, subject to the following restrictions:
//
//   1. The origin of this software must not be misrepresented; you must not
//   claim that you wrote the original software. If you use this software
//   in a product, an acknowledgment in the product documentation would be
//   appreciated but is not required.
//
//   2. Altered source versions must be plainly marked as such, and must not be
//   misrepresented as being the original software.
//
//   3. This notice may not be removed or altered from any source
//   distribution.
//-------------------------------------------------
//
//-------------------------------------------------


//Chapter 4 source code, written by Celal Cansin Kayi
#include "Vertex.h"
#include "Mesh.h"
#include "COLLADALoader.h"
#include <iostream>
#include <vector>

using namespace std;

int main(int argc, char** argv)
{
	//Check for correct arguments
	if(argc < 2)
	{
		cout << "No filename specified.\n";

		return 0;
	}

	//Convert argv[1] to string
	string filename(argv[1]);

	//Create Collada Loader
	COLLADALoader* cLoader = new COLLADALoader();

	//Load Static Meshes
	vector<Mesh*> meshes = cLoader->Load(filename);

	//-----------------------------------------------------------------------------------------------------------------------
	// At this point, all static meshes will have been loaded from the collada document and stored in "vector<Mesh*> meshes"
	//-----------------------------------------------------------------------------------------------------------------------

	//Delete meshes
	while(!meshes.empty())
	{
		delete meshes.back(); meshes.pop_back();
	}

	//Delete Collada Loader
	if(cLoader)
	{
		delete cLoader;
		cLoader = NULL;
	}

	return 0;
}