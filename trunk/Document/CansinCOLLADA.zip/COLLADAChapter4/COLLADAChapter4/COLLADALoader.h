#pragma once

//-------------------------------------------------
// Licence
//-------------------------------------------------
//Copyright (c) 2010 Celal Cansin Kayi
//
//This software is provided 'as-is', without any express or implied
//warranty. In no event will the authors be held liable for any damages
//arising from the use of this software.
//
//Permission is granted to anyone to use this software for any purpose,
//including commercial applications, and to alter it and redistribute it
//freely, subject to the following restrictions:
//
//   1. The origin of this software must not be misrepresented; you must not
//   claim that you wrote the original software. If you use this software
//   in a product, an acknowledgment in the product documentation would be
//   appreciated but is not required.
//
//   2. Altered source versions must be plainly marked as such, and must not be
//   misrepresented as being the original software.
//
//   3. This notice may not be removed or altered from any source
//   distribution.
//-------------------------------------------------
//
//-------------------------------------------------

#include <dae.h>
#include <dom.h>
#include <dom/domCOLLADA.h>
#pragma comment(lib, "libcollada14dom21-d.lib")
#pragma comment(lib, "libxml2_a.lib")
#pragma comment(lib, "zlib.lib")
#pragma comment(lib, "wsock32.lib")
#pragma comment(lib, "pcre-d.lib")
#pragma comment(lib, "pcrecpp-d.lib")
#pragma comment(lib, "minizip-d.lib")
#pragma comment(lib, "libboost_filesystem.lib")
#pragma comment(lib, "libboost_system.lib")
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <d3d9.h>
#include <d3dx9.h>
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")
#include "Mesh.h"
#include <vector>

using namespace std;

class COLLADALoader
{
private:
	//Dae file
	DAE dae;

	//Root node
	daeElement* root;
	
	//<library_visual_scenes> node
	daeElement* library_visual_scenes;

	//<library_geometries> node
	daeElement* library_geometries;

public:
	//Constructor
	COLLADALoader()
	{
		root = NULL;
		library_visual_scenes = NULL;
		library_geometries = NULL;
	}

	//Load all the meshes from a file
	vector<Mesh*> Load(string filename)
	{
		//Output array
		vector<Mesh*> meshes = vector<Mesh*>();

		#pragma region //Open the file and get the root node
		root = dae.open(filename);

		//Check if import succeded
		if(!root)
		{
			cout << "Document import failed. \n";
			return meshes;
		}
		#pragma endregion
		
		#pragma region //Get the library_visual_scenes
		library_visual_scenes = root->getDescendant("library_visual_scenes");

		//Check if there is a <library_visual_scenes>
		if(!library_visual_scenes)
		{
			cout << "<library_visual_scenes> not found.\n";
			return meshes;
		}
		#pragma endregion

		#pragma region //Get the library_geometries
		library_geometries = root->getDescendant("library_geometries");

		//Check if there is a <library_geometries>
		if(!library_geometries)
		{
			cout << "<library_geometries> not found.\n";
			return meshes;
		}
		#pragma endregion

		//Process <library_visual_scenes>
		processVisualScenes(meshes);

		//Process the <geometry> node for each mesh
		processGeometries(meshes);

		//Compile vertex components into one buffer
		for(unsigned int i = 0; i < meshes.size(); i++) meshes[i]->combineComponents();

		//Close the .dae file
		dae.close(filename);

		//Set the pointers back to NULL, safety precaution for Debug build
		root = NULL; library_visual_scenes = NULL; library_geometries = NULL;

		//Return list of meshes
		return meshes;
	}

private:
	//Process a <library_visual_scenes> node
	void processVisualScenes(vector<Mesh*> &meshes)
	{
		//Get the <visual_scene> node
		daeElement* visual_scene = library_visual_scenes->getDescendant("visual_scene");

		//Get all the <node>'s for the <visual_scene>
		daeTArray<daeElementRef> nodes = visual_scene->getChildren();

		//For each <node>...
		for(unsigned int i = 0; i < nodes.getCount(); i++)
		{
			//Get the name and the type, if they exist
			string Name = nodes[i]->getAttribute("name").data();
			string Type = nodes[i]->getAttribute("type").data();

			//Skip JOINT node's, only meshes
			if(Type == "JOINT") continue;

			//Get the <instance_geometry> node that corresponds to this <node>
			domInstance_geometry* instance_geometry = NULL;
			instance_geometry = (domInstance_geometry*)nodes[i]->getDescendant("instance_geometry");

			//If there is no <instance_geometry>, this isn't a static mesh and we will skip it.
			if(!instance_geometry) continue;

			//Get the <geometry> node that is referenced by the <instance_geometry>
			daeElement* geometry = instance_geometry->getUrl().getElement();

			//If the referenced node was not found, skip this node
			if(!geometry) continue;

			//Now create a new mesh, set it's <geometry> node and get it's World transform.
			meshes.push_back(new Mesh(Name, processMatrix(nodes[i]->getDescendant("matrix"))));
			meshes.back()->geometry = geometry;
		}
	}

	//Process a <geometry> node for each mesh
	void processGeometries(vector<Mesh*> &meshes)
	{
		//Foreach mesh...
		for(unsigned int i = 0; i < meshes.size(); i++)
		{
			//Get the <mesh> node
			daeElement* mesh = meshes[i]->geometry->getDescendant("mesh");

			//Get the <source> nodes
			daeTArray<daeElementRef> sources = mesh->getChildren();

			//Get the <triangles> node (yes it will be in the sources array above if you wish to find it that way)
			daeElement* triangles = mesh->getDescendant("triangles");

			//Process each <source> child
			for(unsigned int z = 0; z < sources.getCount(); z++) processSource(meshes[i], sources[z]);

			//Process the <triangles> child
			processTriangles(meshes[i], triangles);
		}
	}

	//Process a <source> node
	void processSource(Mesh* mesh, daeElement* source)
	{
		//Get Positions
		if(source->getAttribute("name").find("position") != string::npos)
		{
			//Get the <float_array> node
			daeElement* float_array = source->getChild("float_array");

			//Get the number of raw float's contained
			unsigned int count = atoi(float_array->getAttribute("count").data());

			//Get the raw string representation
			string positionArray = float_array->getCharData();

			//Set up a stringstream to read from the raw array
			stringstream stm(positionArray);

			//Read each float, in groups of three
			for(unsigned int i = 0; i < (count / 3); i++)
			{
				float x, y, z;

				stm >> x;
				stm >> y;
				stm >> z;

				//Push this back as another Position component
				mesh->Positions.push_back(D3DXVECTOR3(x, y, z));
			}
			
			return;
		}

		//Get Normals
		if(source->getAttribute("name").find("normal") != string::npos)
		{
			//Get the <float_array> node
			daeElement* float_array = source->getChild("float_array");

			//Get the number of raw float's contained
			unsigned int count = atoi(float_array->getAttribute("count").data());

			//Get the raw string representation
			string normalsArray = float_array->getCharData();

			//Set up a stringstream to read from the raw array
			stringstream stm(normalsArray);

			//Read each float, in groups of three
			for(unsigned int i = 0; i < (count / 3); i++)
			{
				float x, y, z;

				stm >> x;
				stm >> y;
				stm >> z;

				//Push this back as another Position component
				mesh->Normals.push_back(D3DXVECTOR3(x, y, z));
			}

			return;
		}

		//Get UVs at layer0
		if(source->getAttribute("name").find("map1") != string::npos)
		{
			//Get the <float_array> node
			daeElement* float_array = source->getChild("float_array");

			//Get the number of raw float's contained
			unsigned int count = atoi(float_array->getAttribute("count").data());

			//Get the raw string representation
			string uvArray = float_array->getCharData();

			//Set up a stringstream to read from the raw array
			stringstream stm(uvArray);

			//Read each float, in groups of three
			for(unsigned int i = 0; i < (count / 2); i++)
			{
				float x, y;

				stm >> x;
				stm >> y;

				//Push this back as another Position component
				mesh->UVs.push_back(D3DXVECTOR2(x, y));
			}

			return;
		}

		//Get Tangents at layer0, the reason there are different naming schemes, this covers the ones I've come into contact with
		if(source->getAttribute("id").find("map1-tangents") != string::npos || source->getAttribute("id").find("textangents") != string::npos)
		{
			//Get the <float_array> node
			daeElement* float_array = source->getChild("float_array");

			//Get the number of raw float's contained
			unsigned int count = atoi(float_array->getAttribute("count").data());

			//Get the raw string representation
			string tangentsArray = float_array->getCharData();

			//Set up a stringstream to read from the raw array
			stringstream stm(tangentsArray);

			//Read each float, in groups of three
			for(unsigned int i = 0; i < (count / 3); i++)
			{
				float x, y, z;

				stm >> x;
				stm >> y;
				stm >> z;

				//Push this back as another Position component
				mesh->Tangents.push_back(D3DXVECTOR3(x, y, z));
			}

			return;
		}

		//Get BiTangents at layer0, read above about the different names
		if(source->getAttribute("id").find("map1-binormals") != string::npos || source->getAttribute("id").find("texbinormals") != string::npos)
		{
			//Get the <float_array> node
			daeElement* float_array = source->getChild("float_array");

			//Get the number of raw float's contained
			unsigned int count = atoi(float_array->getAttribute("count").data());

			//Get the raw string representation
			string biTangentsArray = float_array->getCharData();

			//Set up a stringstream to read from the raw array
			stringstream stm(biTangentsArray);

			//Read each float, in groups of three
			for(unsigned int i = 0; i < (count / 3); i++)
			{
				float x, y, z;

				stm >> x;
				stm >> y;
				stm >> z;

				//Push this back as another Position component
				mesh->BiTangents.push_back(D3DXVECTOR3(x, y, z));
			}

			return;
		}
	}

	//Process a <triangles> node
	void processTriangles(Mesh* mesh, daeElement* triangles)
	{
		//Get the <p> node
		daeElement* p = triangles->getDescendant("p");

		//Get the number of faces, multiply by 3 to get number of indices
		unsigned int count = atoi(triangles->getAttribute("count").data()) * 3;

		//Get the raw string representation
		string pArray = p->getCharData();

		//Set up a stringstream to read from the raw array
		stringstream stm(pArray);

		//Read each unsigned int
		for(unsigned int i = 0; i < count; i++)
		{
			unsigned int p = 0;

			stm >> p;

			mesh->Indices.push_back(p);
		}
	}

	//Read a <matrix> node, better to have this as a generalized function, will read into OpenGL style, conversion to DirectX later...
	D3DXMATRIX processMatrix(daeElement* node)
	{
		D3DXMATRIX out;
		string world = node->getCharData();
		stringstream stm(world);

		#pragma region Read the matrix
		stm >> out.m[0][0];
		stm >> out.m[0][1];
		stm >> out.m[0][2];
		stm >> out.m[0][3];

		stm >> out.m[1][0];
		stm >> out.m[1][1];
		stm >> out.m[1][2];
		stm >> out.m[1][3];
		
		stm >> out.m[2][0];
		stm >> out.m[2][1];
		stm >> out.m[2][2];
		stm >> out.m[2][3];
		
		stm >> out.m[3][0];
		stm >> out.m[3][1];
		stm >> out.m[3][2];
		stm >> out.m[3][3];
		#pragma endregion

		return out;
	}
};
