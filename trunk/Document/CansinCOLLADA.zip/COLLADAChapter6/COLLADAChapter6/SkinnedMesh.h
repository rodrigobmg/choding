#pragma once

//-------------------------------------------------
// Licence
//-------------------------------------------------
//Copyright (c) 2010 Celal Cansin Kayi
//
//This software is provided 'as-is', without any express or implied
//warranty. In no event will the authors be held liable for any damages
//arising from the use of this software.
//
//Permission is granted to anyone to use this software for any purpose,
//including commercial applications, and to alter it and redistribute it
//freely, subject to the following restrictions:
//
//   1. The origin of this software must not be misrepresented; you must not
//   claim that you wrote the original software. If you use this software
//   in a product, an acknowledgment in the product documentation would be
//   appreciated but is not required.
//
//   2. Altered source versions must be plainly marked as such, and must not be
//   misrepresented as being the original software.
//
//   3. This notice may not be removed or altered from any source
//   distribution.
//-------------------------------------------------
//
//-------------------------------------------------

#include "SkinnedVertex.h"
#include "Joint.h"
#include <dae.h>
#include <dom.h>
#include <dom/domCOLLADA.h>
#pragma comment(lib, "libcollada14dom21-d.lib")
#pragma comment(lib, "libxml2_a.lib")
#pragma comment(lib, "zlib.lib")
#pragma comment(lib, "wsock32.lib")
#pragma comment(lib, "pcre-d.lib")
#pragma comment(lib, "pcrecpp-d.lib")
#pragma comment(lib, "minizip-d.lib")
#pragma comment(lib, "libboost_filesystem.lib")
#pragma comment(lib, "libboost_system.lib")
#include <string>
#include <vector>

using namespace std;

class SkinnedMesh
{
private:
	//<controller>
	daeElement* controller;

	//<geometry>
	daeElement* geometry;

	//Root <node> for skeleton
	daeElement* rootJoint;
	
	//Component Vertex Data, to be compiled into Vertices later...
	vector<D3DXVECTOR3> Positions;
	vector<D3DXVECTOR2> UVs;
	vector<D3DXVECTOR3> Normals;
	vector<D3DXVECTOR3> Tangents;
	vector<D3DXVECTOR3> BiTangents;
	vector<Index> boneIndices;
	vector<Weight> Weights;

	//Set it so COLLADALoader can access privates
	friend class COLLADALoader;

	//Combine the component vertex data to Vertices array
	void combineComponents()
	{
		for(unsigned int i = 0; i < Positions.size(); i++)
		{
			Vertices.push_back(SkinnedVertex(Positions[i], UVs[i], Normals[i], Tangents[i], BiTangents[i], boneIndices[i], Weights[i]));
		}
	}

	//Make Animation list
	void combineJointAnimations()
	{
		//Put all the Animations together
		for(unsigned int i = 0; i < Joints.size(); i++)
		{
			for(unsigned int z = 0; z < Joints[i].Animations.size(); z++)
			{
				Animations.push_back(Joints[i].Animations[z]);
			}
		}

		//Do a simple Bubble Sort by Time
		for(unsigned int i = 0; i < Animations.size(); i++)
		{
			for(unsigned int j = 0; j < i; j++)
			{
				if(Animations[i].Time < Animations[j].Time)
				{
					JointAnimationKey temp = Animations[i];
					Animations[i] = Animations[j];
					Animations[j] = temp;
				}
			}
		}
	}

public:
	//Name
	string Name;

	//Root Transform Matrix
	D3DXMATRIX RootTransform;

	//BindShape Matrix
	D3DXMATRIX BindShape;

	//Joints
	vector<Joint> Joints;

	//Time sorted Animation Key list
	vector<JointAnimationKey> Animations;

	//Combined Vertex Data, ready for Vertex Buffer
	vector<SkinnedVertex> Vertices;

	//Index data, ready for Index Buffer
	vector<unsigned int> Indices;

	//Constructor
	SkinnedMesh(string Name, D3DXMATRIX RootTransform)
	{
		//Set pointer to NULL
		controller = NULL;

		//Set pointer to NULL
		geometry = NULL;

		//Set pointer to NULL
		rootJoint = NULL;
		
		//Initialize Component Vertex Data
		Positions = vector<D3DXVECTOR3>();
		UVs = vector<D3DXVECTOR2>();
		Normals = vector<D3DXVECTOR3>();
		Tangents = vector<D3DXVECTOR3>();
		BiTangents = vector<D3DXVECTOR3>();
		boneIndices = vector<Index>();
		Weights = vector<Weight>();
		
		//Set Name
		this->Name = Name;

		//Set Root Transform Matrix
		this->RootTransform = RootTransform;

		//Set BindShape Matrix
		D3DXMatrixIdentity(&BindShape);

		//Initialize Joints
		Joints = vector<Joint>();

		//Initialize Time sorted Animation Key list
		Animations = vector<JointAnimationKey>();

		//Initialize Combined Vertex Data, ready for Vertex Buffer
		Vertices = vector<SkinnedVertex>();

		//Initialize Index data, ready for Index Buffer
		Indices = vector<unsigned int>();
	}
};
