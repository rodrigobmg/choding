#pragma once

//-------------------------------------------------
// Licence
//-------------------------------------------------
//Copyright (c) 2010 Celal Cansin Kayi
//
//This software is provided 'as-is', without any express or implied
//warranty. In no event will the authors be held liable for any damages
//arising from the use of this software.
//
//Permission is granted to anyone to use this software for any purpose,
//including commercial applications, and to alter it and redistribute it
//freely, subject to the following restrictions:
//
//   1. The origin of this software must not be misrepresented; you must not
//   claim that you wrote the original software. If you use this software
//   in a product, an acknowledgment in the product documentation would be
//   appreciated but is not required.
//
//   2. Altered source versions must be plainly marked as such, and must not be
//   misrepresented as being the original software.
//
//   3. This notice may not be removed or altered from any source
//   distribution.
//-------------------------------------------------
//
//-------------------------------------------------

#include "JointAnimationKey.h"
#include <dae.h>
#include <dom.h>
#include <dom/domCOLLADA.h>
#pragma comment(lib, "libcollada14dom21-d.lib")
#pragma comment(lib, "libxml2_a.lib")
#pragma comment(lib, "zlib.lib")
#pragma comment(lib, "wsock32.lib")
#pragma comment(lib, "pcre-d.lib")
#pragma comment(lib, "pcrecpp-d.lib")
#pragma comment(lib, "minizip-d.lib")
#pragma comment(lib, "libboost_filesystem.lib")
#pragma comment(lib, "libboost_system.lib")
#include <string>
#include <vector>
#include <d3d9.h>
#include <d3dx9.h>
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")

using namespace std;

class Joint
{
private:
	//SID
	string SID;

	//Node for this in the COLLADA file
	daeElement* Node;

	//Animation Keys for this Joint
	vector<JointAnimationKey> Animations;

	//COLLADALoader access rights
	friend class COLLADALoader;

	//SkinnedMesh access rights
	friend class SkinnedMesh;

public:
	//Name
	string Name;

	//Bind_Matrix
	D3DXMATRIX bind_matrix;

	//Inv_Bind_Matrix
	D3DXMATRIX inv_bind_matrix;

	//Parent Index
	int parentIndex;

	//Parent Joint*
	Joint* parentJoint;

	//Base Constructor
	Joint()
	{
		//Initialize SID
		SID = string();

		//Initialize Node
		Node = NULL;

		//Initialize Animations
		Animations = vector<JointAnimationKey>();

		//Initialize Name
		Name = string();

		//Initialize bind_matrix
		D3DXMatrixIdentity(&bind_matrix);

		//Initialize inv_bind_matrix
		D3DXMatrixIdentity(&inv_bind_matrix);

		//Initialize parentIndex
		parentIndex = 0;

		//Initialize parentJoint
		parentJoint = NULL;
	}

	//Detailed Constructor
	Joint(string Name, string SID, daeElement* Node)
	{
		//Initialize SID
		this->SID = SID;

		//Initialize Node
		this->Node = Node;

		//Initialize Animations
		Animations = vector<JointAnimationKey>();

		//Initialize Name
		this->Name = Name;

		//Initialize bind_matrix
		D3DXMatrixIdentity(&bind_matrix);

		//Initialize inv_bind_matrix
		D3DXMatrixIdentity(&inv_bind_matrix);

		//Initialize parentIndex
		parentIndex = 0;

		//Initialize parentJoint
		parentJoint = NULL;
	}
};
