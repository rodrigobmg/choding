#include <d3dx9.h>
#include <stdio.h>
#include "MD2Loader.h"

CMD2Loader::CMD2Loader( void )
{
	m_pd3dDevice	= NULL;
	m_pVB			= NULL;
	m_pTexture		= NULL;
	m_dFVF			= (D3DFVF_XYZ|D3DFVF_TEX1);
	m_uPrimitive	= 0;	
}

CMD2Loader::~CMD2Loader( void )
{
	Cleanup();
}

void CMD2Loader::Cleanup( void )
{
	if( m_pVB != NULL )
	{
		m_pVB->Release();
		m_pVB = NULL;
	}

	if( m_pTexture != NULL )
	{
		m_pTexture->Release();
		m_pTexture = NULL;
	}
}

HRESULT CMD2Loader::InitData( LPDIRECT3DDEVICE9 g_pd3dDevice )
{
	m_pd3dDevice	= g_pd3dDevice;
	D3DXCreateTextureFromFile( m_pd3dDevice, "./skin.jpg" , &m_pTexture );

///////////////////���� �б�(���, ��ü)///////////////////////////////////////

	FILE *rfpt;
	//���� ����
	rfpt = fopen( "./tris.md2", "rb" );

	MD2HEADER *pMD2Header = new MD2HEADER;
	ZeroMemory( pMD2Header, sizeof(MD2HEADER) );
	//��� �б�
	fread( pMD2Header, sizeof(MD2HEADER), 1, rfpt );

	BYTE *pMD2Data = new BYTE[pMD2Header->offsetEnd];
	ZeroMemory( pMD2Data, pMD2Header->offsetEnd * sizeof(BYTE) );
	//��ü ������ �б�
	fread( &pMD2Data[sizeof(MD2HEADER)], sizeof(BYTE), (pMD2Header->offsetEnd - sizeof(MD2HEADER)), rfpt );
	//���� �ݱ�
	fclose( rfpt );

///////////////////�ﰢ�� �׸��� ���� ����/////////////////////////////////////
	m_uPrimitive = pMD2Header->numTris;

///////////////////��Ʈ���� �б�(������, �̵���)///////////////////////////////

	MD2MATRIX *pMD2Matrix = new MD2MATRIX;
	ZeroMemory( pMD2Matrix, sizeof(MD2MATRIX) );
	memcpy( pMD2Matrix, &pMD2Data[pMD2Header->offsetFrames], sizeof(MD2MATRIX) );

///////////////////���ؽ� �б�(x,z,y)//////////////////////////////////////////

	MD2VERTEX *pMD2Vertex = new MD2VERTEX[pMD2Header->numXYZ];
	ZeroMemory( pMD2Vertex, pMD2Header->numXYZ * sizeof(MD2VERTEX) );
	memcpy( pMD2Vertex, &pMD2Data[pMD2Header->offsetFrames + sizeof(MD2MATRIX)], pMD2Header->numXYZ * sizeof(MD2VERTEX) );

///////////////////�ؽ���(tu,tv)�б�///////////////////////////////////////////

	MD2TEXTURE *pMD2Texture = new MD2TEXTURE[pMD2Header->numST];
	ZeroMemory( pMD2Texture, pMD2Header->numST * sizeof(MD2TEXTURE) );
	memcpy( pMD2Texture, &pMD2Data[pMD2Header->offsetST], pMD2Header->numST * sizeof(MD2TEXTURE) );

///////////////////�ε���(���ؽ�[3],�ؽ���[3])/////////////////////////////////

	MD2INDICES *pMD2Index = new MD2INDICES[pMD2Header->numTris];
	ZeroMemory( pMD2Index, pMD2Header->numTris * sizeof(MD2INDICES) );
	memcpy( pMD2Index, &pMD2Data[pMD2Header->offsetTris], pMD2Header->numTris * sizeof(MD2INDICES) );

///////////////////VB ����/////////////////////////////////////////////////////

	UINT Size = 3 * pMD2Header->numTris;
	MD2_VERTEX *Vertices = new MD2_VERTEX[Size];
	ZeroMemory( Vertices, Size * sizeof(MD2_VERTEX) );

	for( int i = 0; i < pMD2Header->numTris; i++ )
	{
		for( int j = 0; j < 3; j++ )
		{
			Vertices[i*3+j].v = D3DXVECTOR3( //��ǥ = ��ǥ * ������ + �̵���
				pMD2Vertex[pMD2Index[i].vertex[j]].v[0] * pMD2Matrix->scale[0] + pMD2Matrix->translate[0],
				pMD2Vertex[pMD2Index[i].vertex[j]].v[2] * pMD2Matrix->scale[2] + pMD2Matrix->translate[2],
				pMD2Vertex[pMD2Index[i].vertex[j]].v[1] * pMD2Matrix->scale[1] + pMD2Matrix->translate[1] );

			D3DXVec3Scale( &Vertices[i*3+j].v, &Vertices[i*3+j].v, pMD2Matrix->scale[0] );

			Vertices[i*3+j].t = D3DXVECTOR2( 
				pMD2Texture[pMD2Index[i].texture[j]].tu / (float)pMD2Header->skinwidth,
				pMD2Texture[pMD2Index[i].texture[j]].tv / (float)pMD2Header->skinheight );
		}
	}

	if( FAILED( m_pd3dDevice->CreateVertexBuffer( Size * sizeof(MD2_VERTEX), 0, m_dFVF, D3DPOOL_DEFAULT, &m_pVB, NULL ) ) )
	{ return E_FAIL; }

	void *pVertices;
	if( FAILED( m_pVB->Lock( 0, Size * sizeof(MD2_VERTEX), (void**)&pVertices, 0 ) ) )
	{ return E_FAIL; }
	memcpy( pVertices, Vertices, Size * sizeof(MD2_VERTEX) );
	m_pVB->Unlock();

	///////////////////�޸� ����//////////////////////////////////////////////////////
	delete pMD2Header;		//��� 68����Ʈ
	delete []pMD2Data;		//�����Ҵ�
	delete pMD2Matrix;		//��Ʈ���� 40����Ʈ
	delete []pMD2Vertex;	//�����Ҵ�
	delete []pMD2Texture;	//�����Ҵ�
	delete []pMD2Index;		//�����Ҵ�
	delete []Vertices;		//�����Ҵ�

	return S_OK;
}

void CMD2Loader::Render( void )
{
	D3DXMATRIXA16 matWorld;
	D3DXMatrixIdentity( &matWorld );
	m_pd3dDevice->SetTransform( D3DTS_WORLD, &matWorld );

	m_pd3dDevice->SetTexture( 0, m_pTexture );
	m_pd3dDevice->SetStreamSource( 0, m_pVB, 0, sizeof(MD2_VERTEX) );	
	m_pd3dDevice->SetFVF( m_dFVF );
	m_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLELIST, 0, m_uPrimitive );
}