
#include ".\patch.h"

CPatch::CPatch(void)
: m_pDevice	( NULL )
, m_pVB		( NULL )
, m_pIB		( NULL )

, m_bShowPoints ( true )
, m_bShowGrids	( true )

, m_nPatchSize	( 0 )
, m_nLevel		( 0 )
, m_nEast		( 0 )
, m_nSouth		( 0 )
, m_nWest		( 0 )
, m_nNorth		( 0 )
{
}

CPatch::~CPatch(void)
{
	SAFE_RELEASE( m_pVB );
	SAFE_RELEASE( m_pIB );
}

void	
CPatch::Create( int nPatchSize )
{
	if( m_nPatchSize == nPatchSize )
		return;

	m_IndexGenerator.Generate( nPatchSize );
	//m_IndexGenerator.Save( "output.txt" );				//! �׽�Ʈ�� �ڵ�

 	CreateVB();
	CreateIB();

	m_nPatchSize = nPatchSize;

	m_nLevel = 0;
	m_nNorth = 0;
	m_nSouth = 0;
	m_nEast = 0;
	m_nWest = 0;
}

void	
CPatch::CreateVB()
{
	SAFE_RELEASE( m_pVB );

	int nSide	= m_IndexGenerator.GetSideVertCnt();
	int nTotal	= m_IndexGenerator.GetTotalVertCnt();

	if( FAILED( m_pDevice->CreateVertexBuffer( nTotal * sizeof(CUSTOMVERTEX), 0 , CustomFVF , D3DPOOL_MANAGED , &m_pVB , 0 ) ) )
		return;

	CUSTOMVERTEX * pVertices = NULL;
	m_pVB->Lock( 0 , 0 , (void**)&pVertices , D3DLOCK_DISCARD );

	float fInc	=  1.0f / (nSide/2 + 1);
	float fPosX = -1.0f + fInc;
	float fPosY = -1.0f + fInc;

	for( int i=0; i<nTotal; i++ , pVertices++ , fPosX += fInc )
	{
		if( i && 0 == (i % nSide) )
		{
			fPosY += fInc;				//! Z �� ����
			fPosX = -1.0f + fInc;		//! X �� �ʱ�ȭ
		}

		pVertices->x = fPosX;
		pVertices->y = fPosY;
		pVertices->z = 0.0f;
	}

	m_pVB->Unlock();
}

void	
CPatch::CreateIB()
{
	SAFE_RELEASE( m_pIB );

	int nTotal = m_IndexGenerator.GetIndexCount();
	m_pDevice->CreateIndexBuffer( nTotal * sizeof(WORD) , D3DUSAGE_WRITEONLY , D3DFMT_INDEX16 , D3DPOOL_MANAGED , &m_pIB , 0 );

	WORD * pInices = NULL;
	m_pIB->Lock( 0 , 0 , (void**)&pInices , D3DLOCK_DISCARD );
	m_IndexGenerator.GetIndices( pInices );
	m_pIB->Unlock();
}

void	
CPatch::SetLevel( int nLevel )
{ 
	int nMax = m_IndexGenerator.GetLevelCount();
	if( nLevel < nMax )
		m_nLevel = nLevel;
}

void	
CPatch::SetNeighbors( int nEast , int nSouth , int nWest , int nNorth )
{
	m_nEast = nEast;
	m_nSouth = nSouth;
	m_nWest = nWest;
	m_nNorth = nNorth;
}

void
CPatch::Render()
{
	if( NULL == m_pVB || NULL == m_pIB )
		return;
    
	if( FAILED( m_pDevice->SetTexture( 0 , NULL ) ) )
		OutputDebugStr(L"Failed To Set Texture");

	if( FAILED( m_pDevice->SetFVF( CustomFVF ) ) )
		OutputDebugStr(L"Failed To Set FVF");
	
	if( FAILED( m_pDevice->SetStreamSource( 0 , m_pVB , 0 , sizeof(CUSTOMVERTEX) ) ) )
		OutputDebugStr(L"Failed To Set Stream Source");

	if( FAILED( m_pDevice->SetIndices( m_pIB ) ) )
		OutputDebugStr(L"Failed To Set Indices");

	m_pDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TFACTOR );
	m_pDevice->SetTextureStageState( 0, D3DTSS_COLOROP	, D3DTOP_SELECTARG1 );

	if( m_bShowGrids )
		RenderGrid();
	if( m_bShowPoints )
		RenderPoint();
}

/*!
 * \brief
 * ��ġ �ﰢ������ �������� ����մϴ�.
 */
void
CPatch::RenderGrid()
{
	int nOffset = 0, nCnt = 0;
	int nVertCnt = m_IndexGenerator.GetTotalVertCnt();

	if( false == m_IndexGenerator.GetDrawParams( nOffset , nCnt , m_nLevel , m_nEast , m_nSouth , m_nWest , m_nNorth ) )
		return;

	m_pDevice->SetRenderState( D3DRS_FILLMODE , D3DFILL_WIREFRAME );
	m_pDevice->SetRenderState( D3DRS_TEXTUREFACTOR , D3DCOLOR_ARGB(255,0,0,0) );
	m_pDevice->DrawIndexedPrimitive( D3DPT_TRIANGLELIST, 0 , 0 , nVertCnt, nOffset , nCnt / 3 );
	m_pDevice->SetRenderState( D3DRS_FILLMODE , D3DFILL_SOLID );
}

/*!
 * \brief
 * ��ġ �������� ����մϴ�.
 */
void
CPatch::RenderPoint()
{
	int nCnt = m_IndexGenerator.GetTotalVertCnt();
	m_pDevice->SetRenderState( D3DRS_TEXTUREFACTOR , D3DCOLOR_ARGB(255,255,255,255) );
	HRESULT hr = m_pDevice->DrawPrimitive( D3DPT_POINTLIST , 0 , nCnt );
}

void
CPatch::OnDestroyDevice()
{
	SAFE_RELEASE( m_pVB );
	SAFE_RELEASE( m_pIB );
}