// �� ������ postList, postView���� �������� ����ϴ� ������.
// common.js, skin.js, scrap5.js ���� ������ �ϳ��� ������ ����.
// 2005.07.07 by jhhany

//===============================================================
// common.jsp ����
//===============================================================
// Browse Type
// IE Script
var IE = false ;
if (window.navigator.appName.indexOf("Explorer") !=-1)
{
	IE = true;
}

// Iframe ������ ȣ���Ͽ� ������ ���̸� �����.
function cm_paperInit(minHeight)
{
	try
	{
		var timeArray = new Array(200, 500, 1500, 3500, 7000, 12000, 20000);
		//alert("1_cm_paperInit, timeArray.length="+timeArray.length);
		for(var i=0; i < timeArray.length; i++)
			setTimeout('_cm_paperInit(\''+minHeight+'\')', timeArray[i]);

		if(self.name!=null && self.name=="papermain")
		{
			top.window.scrollTo(0,0);
		}
	}catch (e) {}
}

// ���ۿ��� ȣ��.
function cm_paperInit_more(minHeight)
{
	try
	{
		var timeArray = new Array(200, 500, 1500, 3500, 7000, 12000, 20000);
		//alert("1_cm_paperInit, timeArray.length="+timeArray.length);
		for(var i=0; i < timeArray.length; i++)
			setTimeout('_cm_paperInit(\''+minHeight+'\')', timeArray[i]);
	}catch (e) {}
}

// Iframe ������ ȣ���Ͽ� ������ ���̸� �����.
// �ִ� ���� 3�ܱ����� ������¡�� �ϵ��� �Ѵ�.
function _cm_paperInit(minHeight)
{
	try
	{
		//	alert("2_cm_paperInit");
		if(minHeight==null) minHeight = 0;
		if (self.name!=null && self.name!="" && parent!=null
	    	&& parent._cm_resizeIframe!=null)
	    {
	        parent._cm_resizeIframe(self.name, minHeight);
	    }

		if (parent.name!=null && parent.name!=""
			&& (parent.name=="papermain" || parent.name=="mainFrame")
	    	&& parent.parent!=null && parent.parent._cm_resizeIframe!=null && parent.parent._cm_paperInit!=null)
	    {
	        parent.parent._cm_resizeIframe(parent.name, minHeight);
	    }

		if (parent.parent.name!=null && parent.parent.name!=""
			&& (parent.parent.name=="papermain" || parent.parent.name=="mainFrame")
	    	&& parent.parent.parent!=null && parent.parent.parent._cm_resizeIframe!=null && parent.parent.parent._cm_paperInit!=null)
	    {
	        parent.parent.parent._cm_resizeIframe(parent.parent.name, minHeight);
	    }
	}catch (e) {}
}

// ��������� ����. cm_paperInit()�� ����Ұ�.
function _cm_resizeIframe(name, minHeight)
{
	//alert("cm_resizeIframe, name="+name);
	if(minHeight==null) minHeight = 0;
    if(name==null || name=="") return;

    try
    {
        if (IE)
            var oBody = document.frames(name).document.body;
		else
            var oBody = document.getElementById(name).contentDocument.body;

		var oIFrame = document.getElementById(name);

        var frmWidth  = oBody.scrollWidth;// + (oBody.offsetWidth - oBody.clientWidth);
        var frmHeight = oBody.scrollHeight;// + (oBody.offsetHeight - oBody.clientHeight);

		if(name=="papermain" || name=="mainFrame")
		{
			if(frmHeight >= 1024)
				oIFrame.style.height = frmHeight;
			else
				oIFrame.style.height = 1024;

			var oOpacityDiv = document.getElementById("opacityDiv");
			if(oOpacityDiv!=null)
			{
				oOpacityDiv.style.height = parseInt(oIFrame.style.height) + 200;
			}
		}
		else
		{
			oIFrame.style.height = frmHeight;
		}

		// ���ὺŲ ����2���� ���. ����Ʈ�� �������� �����Ѵ�.
        if(applyResizeContentWidth)
        {
        	if(frmWidth > 590) oIFrame.style.width = frmWidth;
        	//else oIFrame.style.width = 590;
        }

    }catch (e) {}
}
//===============================================================
// common.jsp ��.
//===============================================================
//===============================================================
// skin.jsp ����
//===============================================================

function setSkinCss(){
	//var parentFrame = parent;
	//alert(parent);

	if(IE){
		document.styleSheets[0].addRule("body","background-color:transparent");

	    for(var i=0;i<parent.document.styleSheets.length;i++ ){
		    var styleRules = parent.document.styleSheets(i).rules;
		    //alert(styleRules.length);
		    for(var j=0;j<styleRules.length;j++){
		    	var styleId = styleRules.item(j).selectorText;
		    	//alert(styleId);
		    	if(styleId != null && styleId == ".post"){
					//alert(styleRules.item(j).style.cssText);
					//try{ document.styleSheets[0].removeRule(".post"); }catch(e){}
					//document.styleSheets[0].addRule(".post",styleRules.item(j).style.cssText);
					document.styleSheets[0].addRule(".post",styleRules.item(j).style.cssText);
		    		break;
		    	}

		    }
	    }
	}else{
		document.body.style.backgroundColor = "";
	}

}

//===============================================================
// skin.jsp ��
//===============================================================
//===============================================================
// scrap5.jsp ����
//===============================================================

var jsv_logNo = "";
var jsv_openYn = "";
var jsv_valid = "";
var jsv_num = "";
var jsv_blogid = "";
/*
function ui_scrap(logNo,openYn,valid) {
	jsv_logNo = logNo;
	jsv_openYn = openYn;
	jsv_valid = valid;
}
*/
function ui_scrap(num) {
	jsv_num = num;
}

function ui_scrap2(blogid,num,no) {
	jsv_blogid = blogid;
	jsv_num = num;
	jsv_logNo = no;
}
function ui_scrap3(num) {
	jsv_num = num;
}
function ui_scrap4(blogid,num,no) {
	ui_scrap2(blogid,num,no);
}
function ui_scrap5(num) {
	ui_scrap3(num);
}
function ui_scrap6(blogid,num,no) {
	jsv_blogid = blogid;
	jsv_num = num;
	jsv_logNo = no;
}

function exec_menuitem(key) {
	switch(key) {
		case "EVENT1" :
//			scrap(jsv_logNo,jsv_openYn,jsv_valid);
			scrap(jsv_num);
			break;
		case "EVENT2" :
			scrap_cafe(jsv_num);
			break;
		case "EVENT3" :
			printPost(jsv_num);
			break;
		case "EVENT4" :
			openbook(jsv_num);	// �ӽ� ������ by jhhany
			//openbook();
			break;
		case "EVENT5" :
			add_prologue();
			break;
	}
}

//	IE Script

	//var NS4;
	//var IE4;
	var mouse_top;
	var mouse_left;
	var scroll_top;
	var scroll_left;
	var event_id = "none";
	var status_over = false;
	var parent_menu_name = "menu_parent";
	var child_menu_array = ["menu_child1"];
//	var child_menu_array = ["menu_child1", "menu_child2", "menu_child3"];
	var submenu_left_indent = 70;
	var column_height = 18;
	var submenu_top_indent = 0;
	var mainmenu_top_indent = 0;
	var menuover_bgcolor = "#e4ff75";
	var menuover_fgcolor = "#ffffff";
	var default_menuover_bgcolor = "#ffffff";
	var default_menuover_fgcolor = "#000000";

	//NS4 = (document.layers);
	//IE4 = (document.all);
	//isWin = (navigator.appVersion.indexOf("Win") != -1)

	if (IE) {
		document.onclick = MouseDown;
	}else {
		document.captureEvents(Event.CLICK)
		document.onclick = MouseDown;
	}

	function startIt() {
	}

	function menuOver(ar_obj, ar_id) {
		status_over = true;
		changeOnColor(ar_obj);
		hideChild(event_id);
		if (ar_id != "none")  viewSubMenu(event, ar_obj, ar_id);
	}

	function menuOut(ar_obj) {
		status_over = false;
		changeOutColor(ar_obj);
	}

	/*function SubmenuOver(ar_obj) {
		status_over = true;
		changeColor(ar_obj);
	}*/

	function MouseDown(e) {

		if (!e) e = window.event;
    	event_target = (IE) ? e.srcElement : e.target;
		event_target = event_target.toString();
		event_check = event_target.indexOf("javascript:ui_scrap(");
		event_check2 = event_target.indexOf("javascript:ui_scrap2(");
		event_check3 = event_target.indexOf("javascript:ui_scrap3(");
		event_check4 = event_target.indexOf("javascript:ui_scrap4(");
		event_check5 = event_target.indexOf("javascript:ui_scrap5(");
		event_check6 = event_target.indexOf("javascript:ui_scrap6(");


		if (!status_over) hideAll();
		if (!event_check) {
			parent_menu_name = "menu_parent";
			viewMenu(e,  parent_menu_name);
		}
		else if(!event_check2){
			parent_menu_name = "menu_parent2";
			eval("document.getElementById(\"menu_parent2_scrap_type\").innerHTML = \"��ũ�� : �㰡��\"");
			eval("document.getElementById(\"regToPrologue\").innerHTML = \"\"");
			eval("document.getElementById(\"regToPrologue\").height = 1");
			viewMenu(e,  parent_menu_name);
		}
		else if(!event_check3){
			parent_menu_name = "menu_parent3";
			eval("document.getElementById(\"menu_parent3_scrap_type\").innerHTML = \"��ũ�� : �㰡��\"");
			viewMenu(e,  parent_menu_name);
		}
		else if(!event_check4){
			parent_menu_name = "menu_parent2";
			eval("document.getElementById(\"menu_parent2_scrap_type\").innerHTML = \"��ũ�� : ������\"");
			eval("document.getElementById(\"regToPrologue\").innerHTML = \"\"");
			eval("document.getElementById(\"regToPrologue\").height = 1");
			viewMenu(e,  parent_menu_name);
		}
		else if(!event_check5){
			parent_menu_name = "menu_parent3";
			eval("document.getElementById(\"menu_parent3_scrap_type\").innerHTML = \"��ũ�� : ������\"");
			viewMenu(e,  parent_menu_name);
		}
		else if(!event_check6){
			parent_menu_name = "menu_parent2";
			eval("document.getElementById(\"menu_parent2_scrap_type\").innerHTML = \"��ũ�� : �㰡��\"");
			eval("document.getElementById(\"regToPrologue\").innerHTML = \"<span class='n_id'>���ѷα׿� ���</span>\"");
			eval("document.getElementById(\"regToPrologue\").height = 22");
			viewMenu(e,  parent_menu_name);
		}
		else {
			if (!status_over) hideAll();
			return;
		}
	}

	function hideChild(ar_id) {
		if (event_id == "none") return;
		var menu_len = child_menu_array.length;
		for (i=0; i<menu_len; i++) eval(child_menu_array[i] + ".style.display = \"none\"");
	}

	function hideAll() {
		eval("document.getElementById('" + parent_menu_name + "').style.display = \"none\"");
		if (event_id == "none") return;
		var menu_len = child_menu_array.length;
		for (i=0; i<menu_len; i++) eval(child_menu_array[i] + ".style.display = \"none\"");
	}

	function viewMenu(e, ar_id) {

		if (ar_id == "none") return;
		menuLocBod = window.document.body;
		xPos = menuLocBod.scrollLeft + e.clientX;
		yPos = e.clientY + menuLocBod.scrollTop;
		screen_height = window.document.body.offsetHeight;
		screen_width = window.document.body.offsetWidth;
		mouse_top = e.y;
		mouse_left = e.x;
		mainmenu_top_indent = eval("document.getElementById('" + parent_menu_name + "').childNodes[0].childNodes[0].childNodes.length");
		mainmenu_top_indent = mainmenu_top_indent * column_height;
		if (screen_height > mouse_top + mainmenu_top_indent)
			yPos = e.clientY + menuLocBod.scrollTop;
		else
			yPos = (e.clientY + menuLocBod.scrollTop) - mainmenu_top_indent;

		if (mouse_top - mainmenu_top_indent < 0)
			yPos = e.clientY + menuLocBod.scrollTop;
		yPos = yPos - 75;
		xPos = xPos - 115;

		if (parent_menu_name=="menu_parent2")
		{
			yPos = yPos - 22;
		}

		var objMenu = eval("document.getElementById('" + ar_id + "')");
		objMenu.style.top = yPos;
		objMenu.style.left = xPos;
		objMenu.style.display = "";
	}

	function viewSubMenu(e, ar_obj, ar_id) {
		if (ar_id == "none") return;
		event_id = ar_id;
		parent_top = menu_parent.style.pixelTop;
		parent_left = menu_parent.style.pixelLeft;
		child_top = ar_obj.style.pixelTop;
		child_left = ar_obj.style.pixelLeft;
		screen_height = window.document.body.offsetHeight;
		screen_width = window.document.body.offsetWidth;
		mouse_top = e.y;
		mouse_left = e.x;
		menuLocBod = window.document.body;
		xPos = menuLocBod.scrollLeft + parent_left + submenu_left_indent;
		submenu_top_indent = eval("document.getElementById('" + ar_id + "').childNodes[0].childNodes[0].childNodes.length");
		submenu_top_indent = submenu_top_indent * column_height;
		if (screen_height > mouse_top + submenu_top_indent)
			yPos = event.clientY + menuLocBod.scrollTop;
		else
			yPos = (event.clientY + menuLocBod.scrollTop) - submenu_top_indent;

		if (mouse_top - submenu_top_indent < 0)
			yPos = event.clientY + menuLocBod.scrollTop;

		var objMenu = eval("document.getElementById('" + ar_id + "')");
		objMenu.style.top = yPos;
		objMenu.style.left = xPos;
		objMenu.style.display = "";
	}

	function changeOnColor(obj)
	{
	    obj.style.backgroundColor = menuover_bgcolor;
	}
	function changeOutColor(obj)
	{
	    obj.style.backgroundColor = default_menuover_bgcolor;
	}


document.write("<div id=\"menu_parent\" style=\"position:absolute;display:none;top:0;left:0\">");
document.write("<table width=\"115\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" bgcolor=\"#B6B6B6\">");
document.write("<tr><td> ");
document.write("<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" bgcolor=\"#FFFFFF\">");
document.write("<tr> ");
document.write("<td style=\"padding: 3 0 0 10\" height=\"23\" onmouseout=\"menuOut(this);\" onmouseover=\"menuOver(this, 'none');\" onclick=\"exec_menuitem('EVENT1');\" style=\"cursor:hand\"><span class=\"n_id\">�� ���α׿� ���</span></td>");
document.write("</tr><tr> ");
document.write("<td style=\"padding: 2 0 0 10\" height=\"22\" onmouseout=\"menuOut(this);\" onmouseover=\"menuOver(this, 'none');\" onclick=\"exec_menuitem('EVENT2');\" style=\"cursor:hand\"><span class=\"n_id\">ī�信 ���</span></td>");
document.write("</tr><tr> ");
document.write("<td background=\"http://blogimgs.naver.com/imgs/bg_dot.gif\" height=\"1\"></td>");
document.write("</tr><tr> ");
document.write("<td style=\"padding: 2 0 0 10\" height=\"22\" onmouseout=\"menuOut(this);\" onmouseover=\"menuOver(this, 'none');\" onclick=\"exec_menuitem('EVENT3');\" style=\"cursor:hand\"><span class=\"n_id\">����Ʈ �ϱ�</span></td>");
document.write("</tr></table></td></tr></table>");
document.write("</div>");

document.write("<div id=\"menu_parent2\" style=\"position:absolute;display:none;top:0;left:0\">");
document.write("<table width=\"115\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" bgcolor=\"#B6B6B6\">");
document.write("<tr><td> ");
document.write("<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" bgcolor=\"#FFFFFF\">");
document.write("<tr> ");
document.write("<td style=\"padding: 3 0 0 10\" height=\"23\" ><span class=\"n_id\" style=color:#999999 id=\"menu_parent2_scrap_type\">��ũ�� : ������</span></td>");
document.write("</tr><tr> ");
document.write("<td style=\"padding: 2 0 0 10\" height=\"22\" onmouseout=\"menuOut(this);\" onmouseover=\"menuOver(this, 'none');\" onclick=\"exec_menuitem('EVENT2');\" style=\"cursor:hand\"><span class=\"n_id\">ī�信 ���</span></td>");
document.write("</tr><tr> ");
document.write("<td style=\"padding: 2 0 0 10\" height=\"22\" onmouseout=\"menuOut(this);\" onmouseover=\"menuOver(this, 'none');\" onclick=\"exec_menuitem('EVENT4');\" style=\"cursor:hand\"><span class=\"n_id\">���»����� ���</span></td>");
document.write("</tr><tr> ");
document.write("<td id=\"regToPrologue\" style=\"padding: 2 0 0 10\" height=\"22\" onmouseout=\"menuOut(this);\" onmouseover=\"menuOver(this, 'none');\" onclick=\"exec_menuitem('EVENT5');\" style=\"cursor:hand\"><span class=\"n_id\">���ѷα׿� ���</span></td>");
document.write("</tr><tr> ");
document.write("<td background=\"http://blogimgs.naver.com/imgs/bg_dot.gif\" height=\"1\"></td>");
document.write("</tr><tr> ");
document.write("<td style=\"padding: 2 0 0 10\" height=\"22\" onmouseout=\"menuOut(this);\" onmouseover=\"menuOver(this, 'none');\" onclick=\"exec_menuitem('EVENT3');\" style=\"cursor:hand\"><span class=\"n_id\">����Ʈ �ϱ�</span></td>");
document.write("</tr></table></td></tr></table>");
document.write("</div>");

document.write("<div id=\"menu_parent3\" style=\"position:absolute;display:none;top:0;left:0\">");
document.write("<table width=\"115\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" bgcolor=\"#B6B6B6\">");
document.write("<tr><td> ");
document.write("<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" bgcolor=\"#FFFFFF\">");
document.write("<tr> ");
document.write("<td style=\"padding: 3 0 0 10\" height=\"23\" ><span class=\"n_id\" style=color:#999999 id=\"menu_parent3_scrap_type\">��ũ�� : ������</span></td>");
document.write("</tr><tr> ");
document.write("<td style=\"padding: 2 0 0 10\" height=\"22\" onmouseout=\"menuOut(this);\" onmouseover=\"menuOver(this, 'none');\" onclick=\"exec_menuitem('EVENT2');\" style=\"cursor:hand\"><span class=\"n_id\">ī�信 ���</span></td>");
document.write("</tr><tr> ");
document.write("<td background=\"http://blogimgs.naver.com/imgs/bg_dot.gif\" height=\"1\"></td>");
document.write("</tr><tr> ");
document.write("<td style=\"padding: 2 0 0 10\" height=\"22\" onmouseout=\"menuOut(this);\" onmouseover=\"menuOver(this, 'none');\" onclick=\"exec_menuitem('EVENT3');\" style=\"cursor:hand\"><span class=\"n_id\">����Ʈ �ϱ�</span></td>");
document.write("</tr></table></td></tr></table>");
document.write("</div>");
//create by iceangel17

String.prototype.row0replace = function()
{
	return this.replace(/(href)|(src)|(alt)/g, "").replace(/(width=21 height=9)/g,"width=0 height=0");
}

String.prototype.row2replace = function()
{
	return this.replace(/(href)|(src)|(alt)/g, "");
}

String.prototype.row3replace = function()
{
	return this.replace(/(target=_top)|(target=_parent)/g, "target='_blank'");
}

String.prototype.row4replace = function()
{
	return this.replace(/(onclick)|(CURSOR: hand)|(alt)/g, "").replace(/(target=_top)|(target=_parent)/g, "target='_blank'").replace(/(setTimeout)/g, "opener.setTimeout");
}

function printPost(num){
	var printWin = open("/post/print/postprint.jsp", "printWin", "width=610, height=600, resizable=no, scrollbars=yes");
}

function viewPrintPost(printWin){
	var printObj = document.all["printPost" + jsv_num];
	var printHTML = "";

	if(typeof(printObj) == "object" && typeof(printWin.document.all.printArea) == "object"){
		printHTML = "<TABLE cellSpacing=0 cellPadding=0 width=572 border=0>"
						+ printObj.rows[0].outerHTML.row0replace()
						+ printObj.rows[1].outerHTML
						+ printObj.rows[2].outerHTML.row2replace()
						+ printObj.rows[3].outerHTML.row3replace()
						+ printObj.rows[4].outerHTML.row3replace()
						+ printObj.rows[5].outerHTML.row4replace()
						+ "</TABLE>";

//alert(printHTML);
		printWin.document.all.printArea.innerHTML = printHTML;
//alert(printWin.html.outerHTML);
	}
}
function openbook_old(){ // �ӽ�

	window.open("/export/opendic/sendData.jsp?blogId=" + jsv_blogid + "&logNo=" + jsv_logNo,"openbook","width=100,height=100");

}

function add_prologue(){
	window.open(url_prologue + "/PrologueFrontSetting.nhn?blogId="+ jsv_blogid + "&logno=" + jsv_logNo, "prologue", "width=440,height=160");
}
////////////////////////////

//===============================================================
// scrap5.jsp ��
//===============================================================

